# Nusu Academy S1 Term 1 Subject Package: Mathematics

**Level:** Senior One (S1)  
**Term:** 1  
**Package type:** Opening-term starter notes  
**Subject:** Mathematics

## How to use this package

These notes are a compact starting package, not a complete textbook. They are designed for discussion, board work, pair activities, practice and short reviews. Learners should explain methods in their own words and check whether an answer makes sense in its context.

The NCDC Mathematics syllabus places four topics in the S1 Term 1 programme planner: Number Bases, Working with Integers, Fractions/Percentages/Decimals, and Rectangular Cartesian Coordinates in 2 Dimensions. Each is allocated 15 periods in the planner [1]. This package follows that order as a **proposed school sequence** for opening Term 1. The sequence should be adjusted to the school calendar, learners’ readiness and the teacher’s scheme of work; it is not presented as a compulsory weekly order for every school.

The supplied timetable was used only as context. It describes a typical S1 timetable and advises schools to adapt it to their calendar, staffing and current guidance. It is not a curriculum authority.

---

## Topic 1: Number Bases

### Big idea

Our familiar number system is base ten, but numbers can be written in other bases. The value of a digit depends on its place and on the base being used.

### Learning objectives

By the end of the topic, the learner should be able to:

- identify the base of a number and the place value of its digits;
- convert whole numbers from one base to another;
- convert a number in another base to base ten;
- add and multiply simple numbers in a non-decimal base; and
- explain why a digit must be less than the base.

These objectives reflect the NCDC outcomes for identifying numbers in different bases, converting between bases and manipulating numbers using operations [1].

### Key terms

- **Base:** The number of different digits used, including zero. Base ten uses 0–9; base two uses 0 and 1.
- **Digit:** A symbol used to write a number.
- **Place value:** The value contributed by a digit because of its position.
- **Binary:** A number system with base two.
- **Denary/decimal:** The ordinary base-ten number system.
- **Conversion:** Changing a number from one base to another without changing its value.

### Understanding place value

In base ten, the places from right to left are ones, tens, hundreds and thousands:

`10^0, 10^1, 10^2, 10^3, ...`

In base five, the places from right to left are:

`5^0, 5^1, 5^2, 5^3, ...` or `1, 5, 25, 125, ...`.

Therefore,

`243_5 = 2 × 5^2 + 4 × 5^1 + 3 × 5^0`.

A digit in base `b` must be one of `0, 1, ..., b − 1`. Thus, `8_8` is not a valid base-eight number because 8 is not an allowed digit in base eight.

### Worked example 1: Convert base five to base ten

Convert `243_5` to base ten.

`243_5 = 2 × 25 + 4 × 5 + 3 × 1`

`= 50 + 20 + 3`

`= 73_10`

So, `243_5 = 73_10`.

### Worked example 2: Convert base ten to base two

Convert `13_10` to base two by repeated division by 2.

- `13 ÷ 2 = 6 remainder 1`
- `6 ÷ 2 = 3 remainder 0`
- `3 ÷ 2 = 1 remainder 1`
- `1 ÷ 2 = 0 remainder 1`

Read the remainders from bottom to top: `1101_2`.

Therefore, `13_10 = 1101_2`.

Check using place values:

`1101_2 = 1 × 8 + 1 × 4 + 0 × 2 + 1 × 1 = 13_10`.

### Worked example 3: Addition in base five

Add `243_5 + 132_5`.

Work from the units column. In base five, five units make one group of five.

```text
   243_5
 + 132_5
 --------
   430_5
```

Check in base ten: `243_5 = 73`, `132_5 = 42`, and `73 + 42 = 115`. Also, `430_5 = 4 × 25 + 3 × 5 = 115`.

### Suggested activities

1. Make place-value cards labelled `1, 5, 25, 125` and represent several base-five numbers with counters or stones.
2. In pairs, write the numbers 1 to 20 in base two. Compare patterns in the ones, twos, fours and eights places.
3. Play a matching game: pair a base-two number with its base-ten value.
4. Discuss where different bases appear in technology, counting systems or measurement. The NCDC syllabus suggests using an abacus, number games and designed counters for this topic [1].

### Quick review

1. What is the value of the `3` in `132_5`?
2. Convert `10110_2` to base ten.
3. Convert `29_10` to base two.
4. Is `304_4` valid? Explain.
5. Add `24_5 + 13_5`.

**Answers:** 1. 3. 2. 22. 3. `11101_2`. 4. No; digit 4 is not allowed in base four. 5. `42_5`.

---

## Topic 2: Working with Integers

### Big idea

Integers include positive whole numbers, zero and negative whole numbers. A number line and real-life contexts help us compare, add, subtract, multiply and divide them correctly.

### Learning objectives

By the end of the topic, the learner should be able to:

- read and write large natural numbers in numerals and words;
- distinguish natural numbers, whole numbers and integers;
- locate and compare directed numbers on a number line;
- use integers in contexts such as temperature, floors and height above or below sea level;
- apply the hierarchy of operations; and
- identify factors, multiples, primes, composites, HCF, LCM and divisibility patterns.

These outcomes are drawn from the NCDC Senior 1 Term 1 integers section [1].

### Key terms

- **Natural numbers:** Counting numbers, commonly `1, 2, 3, ...`.
- **Whole numbers:** Natural numbers together with zero.
- **Integer:** Any positive whole number, zero or negative whole number.
- **Directed number:** A number with a direction or sign, such as `−4` or `+4`.
- **Factor:** A number that divides another number exactly.
- **Multiple:** A result obtained by multiplying a number by an integer.
- **Prime number:** A number greater than 1 with exactly two factors: 1 and itself.
- **HCF:** Highest common factor.
- **LCM:** Lowest common multiple.

### Integers on a number line

Numbers increase as we move right and decrease as we move left. Therefore, `−2` is greater than `−5` because `−2` is farther to the right. The opposite of `+7` is `−7`; both are 7 units from zero.

For addition, moving right means adding a positive number and moving left means adding a negative number. Subtracting a number is equivalent to adding its opposite:

`7 − (−3) = 7 + 3 = 10`.

### Worked example 1: Adding and subtracting integers

A diver is at `−8 m` relative to sea level and rises 5 m. New position:

`−8 + 5 = −3 m`.

The diver is still 3 m below sea level.

### Worked example 2: Hierarchy of operations

Evaluate `18 − 3 × (4 − 7)`.

1. Brackets: `4 − 7 = −3`.
2. Multiplication: `3 × (−3) = −9`.
3. Subtraction: `18 − (−9) = 27`.

Therefore, the answer is `27`.

### Worked example 3: Prime factors, HCF and LCM

Find the HCF and LCM of 84 and 126.

`84 = 2 × 2 × 3 × 7 = 2^2 × 3 × 7`

`126 = 2 × 3 × 3 × 7 = 2 × 3^2 × 7`

Use the smallest powers for the HCF:

`HCF = 2 × 3 × 7 = 42`.

Use the largest powers for the LCM:

`LCM = 2^2 × 3^2 × 7 = 252`.

### Suggested activities

1. Mark a large number line on the ground. Learners stand at temperatures, building floors or heights above and below sea level.
2. Sort cards into natural numbers, whole numbers, integers, primes and composites. Discuss numbers that belong to more than one group.
3. Investigate a 1–100 number grid. Circle multiples of 2, 3, 5 and 10 and describe patterns.
4. Use the challenge “make as many whole-number answers as possible using exactly four 4s.” Explain each calculation.
5. Discuss which divisibility tests work for 2, 3, 5, 9 and 10. These activities are consistent with NCDC’s suggested use of number lines, real-life directed numbers, factor investigations and divisibility patterns [1].

### Quick review

1. Which is greater: `−3` or `−8`?
2. Calculate `−12 + 7 − (−4)`.
3. Write the prime factorisation of 180.
4. Find the HCF and LCM of 18 and 24.
5. A lift moves from floor `−2` to floor `6`. How many floors does it move?

**Answers:** 1. `−3`. 2. `−1`. 3. `2^2 × 3^2 × 5`. 4. HCF `6`, LCM `72`. 5. 8 floors.

---

## Topic 3: Fractions, Percentages and Decimals

### Big idea

Fractions, decimals and percentages are different ways of describing parts of a whole. Moving between the forms helps us compare quantities and solve everyday problems.

### Learning objectives

By the end of the topic, the learner should be able to:

- identify proper, improper and mixed fractions;
- convert between improper fractions and mixed numbers;
- add, subtract, multiply and divide fractions and decimals;
- convert fractions to decimals and percentages, and reverse the process;
- distinguish terminating, non-terminating and recurring decimals; and
- solve problems involving percentage of a quantity, discounts, scores and comparisons.

These objectives follow the NCDC outcomes for fractions, decimals, percentages and real-life applications [1].

### Key terms

- **Numerator:** The top number of a fraction.
- **Denominator:** The bottom number; it shows the number of equal parts.
- **Proper fraction:** Numerator smaller than denominator, such as `3/5`.
- **Improper fraction:** Numerator equal to or larger than denominator, such as `7/5`.
- **Mixed number:** A whole number and a proper fraction, such as `1 2/5`.
- **Percentage:** A fraction out of 100.
- **Terminating decimal:** A decimal that ends, such as `0.75`.
- **Recurring decimal:** A decimal in which a digit or group of digits repeats forever, such as `0.333...`.

### Fractions and decimals

Equivalent fractions have the same value. For example, `1/2 = 2/4 = 50/100`. To add or subtract fractions, first express them with a common denominator. To multiply, multiply numerators and denominators. To divide by a fraction, multiply by its reciprocal.

### Worked example 1: Add mixed fractions

Calculate `2 1/3 + 1 3/4`.

Convert to improper fractions:

`2 1/3 = 7/3` and `1 3/4 = 7/4`.

The LCM of 3 and 4 is 12:

`7/3 + 7/4 = 28/12 + 21/12 = 49/12 = 4 1/12`.

### Worked example 2: Fraction, decimal and percentage

Convert `3/8` into a decimal and a percentage.

`3 ÷ 8 = 0.375`.

`0.375 × 100% = 37.5%`.

Therefore, `3/8 = 0.375 = 37.5%`.

### Worked example 3: Percentage of a quantity

Find 15% of 240.

`15% of 240 = 15/100 × 240`

`= 0.15 × 240 = 36`.

### Worked example 4: Recurring decimal as a fraction

Let `x = 0.333...`.

Multiply by 10: `10x = 3.333...`.

Subtract the first equation: `10x − x = 3.333... − 0.333...`.

So, `9x = 3`, and `x = 1/3`.

### Suggested activities

1. Fold paper strips or use bottle tops to model equivalent fractions.
2. Make matching cards for fractions, decimals and percentages.
3. Compare two test results, such as 21 out of 25 and 31 out of 40, by converting both to percentages.
4. Collect examples of percentages from shop labels, sports statistics, examination scores and household information. Discuss what the percentage is “out of.”
5. Use a calculator to investigate which fractions give terminating decimals and which give recurring decimals. The NCDC syllabus recommends fraction strips, number lines, matching games and everyday percentage contexts [1].

### Quick review

1. Convert `17/4` to a mixed number.
2. Calculate `2/3 − 1/6`.
3. Convert `0.45` to a fraction in simplest form and to a percentage.
4. Find 12% of 350.
5. Write `0.272727...` as a fraction.

**Answers:** 1. `4 1/4`. 2. `1/2`. 3. `9/20`, `45%`. 4. `42`. 5. `3/11`.

---

## Topic 4: Rectangular Cartesian Coordinates in Two Dimensions

### Big idea

A coordinate grid gives every point a precise position using an ordered pair. Coordinates can be used to draw shapes and display relationships between two measurements.

### Learning objectives

By the end of the topic, the learner should be able to:

- draw and label the Cartesian plane;
- identify the x-axis, y-axis and origin;
- read and plot ordered pairs;
- complete or describe shapes on a coordinate grid;
- choose a suitable scale for two-variable data; and
- interpret a simple scatter graph.

These objectives reflect the NCDC competency that the learner plots and interprets points in different contexts [1].

### Key terms

- **Cartesian plane:** A grid formed by two perpendicular number lines.
- **x-axis:** The horizontal axis.
- **y-axis:** The vertical axis.
- **Origin:** The point `(0, 0)`.
- **Ordered pair:** A coordinate written `(x, y)`; x is read first, then y.
- **Scale:** The value represented by each grid interval.
- **Scatter graph:** A graph showing paired values for two variables.

### Plotting points

To plot `(x, y)`, start at the origin. Move horizontally according to x, then move vertically according to y. A positive x-value means right and a negative x-value means left. A positive y-value means up and a negative y-value means down.

For example, to plot `A(−3, 2)`, move 3 units left and 2 units up. The order matters: `(−3, 2)` is not the same point as `(2, −3)`.

### Worked example 1: Completing a rectangle

Three vertices of a rectangle are `A(1, 1)`, `B(6, 1)` and `C(6, 4)`. Find the fourth vertex.

A and B have the same y-coordinate, so AB is horizontal. B and C have the same x-coordinate, so BC is vertical. The missing point must have x-coordinate 1 and y-coordinate 4.

The fourth vertex is `D(1, 4)`.

### Worked example 2: Reading a scatter graph

A learner records the following ages and heights:

`(12, 145), (13, 150), (14, 157), (15, 161)`.

The ordered pair `(14, 157)` means that a 14-year-old learner in the sample has a height of 157 cm. A graph of the points may suggest a positive association in this small sample, but it does not prove that age alone causes height differences.

### Suggested activities

1. Draw a large coordinate grid on the ground using string or chalk. Call out coordinates for pairs to stand on.
2. Play “four in a line” by plotting points and recording each coordinate. The NCDC syllabus suggests this game [1].
3. Draw a simple house, arrow or letter on squared paper and give the coordinates of its vertices. Swap with another pair and ask them to reproduce it.
4. Measure learners’ heights and one other agreed measurement, such as arm span or head circumference. Plot paired data on a scatter graph using a clear scale. Protect learners’ privacy and use codes instead of names.
5. Give learners two vertices of a square or rectangle and ask them to find possible remaining vertices. Explain how the grid supports the reasoning.

### Quick review

1. In which direction do you move to plot `(−4, 3)` from the origin?
2. State the coordinates of the origin.
3. What is the missing vertex of a rectangle with vertices `(2, 1)`, `(7, 1)`, `(7, 5)` and `D`?
4. Explain what `(8, 152)` could mean on a graph of age against height.
5. Why must a graph show its scale and labels?

**Answers:** 1. 4 left and 3 up. 2. `(0, 0)`. 3. `(2, 5)`. 4. An observation with x-value 8 and y-value 152, for example age 8 years and height 152 cm, if those are the axis labels. 5. So the reader can interpret values accurately.

---

## Term 1 consolidation activity

In groups, create a “Mathematics around us” poster with four sections:

1. a number written in another base and converted to base ten;
2. an integer situation involving a positive and a negative value;
3. one quantity represented as a fraction, decimal and percentage; and
4. a small coordinate drawing or scatter graph with labelled axes and scale.

Each group should explain one worked solution to the class. List one error that a learner might make and how to avoid it.

## Short end-of-package review

1. Convert `132_4` to base ten.
2. Evaluate `−6 + 4 × (−3)`.
3. Find the LCM of 12 and 18.
4. Convert `5/8` to a decimal and percentage.
5. Find 25% of 96.
6. Plot and label `P(−2, 4)` and `Q(3, −1)` on a coordinate grid.
7. A rectangle has vertices `(−1, 2)`, `(4, 2)`, `(4, 6)` and one missing vertex. Find it.

**Answers:** 1. `30_10`. 2. `−18`. 3. `36`. 4. `0.625`, `62.5%`. 5. `24`. 6. P is 2 left and 4 up; Q is 3 right and 1 down. 7. `(−1, 6)`.

## References

[1]: https://ncdc.go.ug/wp-content/uploads/2024/02/Mathematics_Syllabus_compressed.pdf "NCDC Mathematics Syllabus"

[2]: https://ncdc.go.ug/books/s-1-s-2-mathematics/ "NCDC S.1 & S.2 Mathematics resource page"

[3]: https://ncdc.go.ug/ "National Curriculum Development Centre (NCDC), Uganda"
