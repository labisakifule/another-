# Nusu Academy S1 Term 1 Subject Package: Physical Education

## How to use this starter package

This is a starter package for the opening part of Senior One Physical Education. The NCDC Physical Education syllabus labels Term 1 **“Theory and Practice of Physical Education”** and lists four opening topics: Introduction to PE, Safety and First Aid, Body Conditioning, and Movement Concepts. This package follows that syllabus sequence. It is not a claim that every school must teach topics in exactly this order; schools may adjust the pace for facilities, weather, learner needs, assessment, and the school calendar. [1]

The supplied timetable is used only as context. Its S1 sample places PE on Wednesday from 1:20–2:00 p.m., but the timetable itself says that schools should adapt it to their circumstances. Use the actual Nusu Academy timetable and available facilities when planning lessons.

Physical Education means **education through the physical**. Learners learn through action, awareness and observation while developing movement competence, safety knowledge, confidence, collaboration and healthy-life habits. PE should be inclusive: no learner should be excluded because of gender, culture, race or ability. [3]

## Proposed opening sequence for Term 1

1. **Introduction to PE** — meaning, components, sport, games and benefits.
2. **Safety and First Aid** — safe participation, common injuries, first response and the first-aid box.
3. **Body Conditioning** — body awareness, injury prevention, warm-up and cool-down.
4. **Movement Concepts** — educational gymnastics, body shapes, space, locomotion and safe movement.

The first three topics are in the NCDC syllabus under the Theory and Practice theme. The fourth is under the Term 1 Aesthetics theme in the same syllabus. The syllabus gives suggested periods of 2, 8, 6 and 8 respectively; teachers should adapt the number of lessons to the school's timetable and teaching time. [1]

---

## Topic 1: Introduction to Physical Education

### Learner-friendly explanation

Physical Education is learning that uses movement and physical activity to develop the whole person. It includes knowledge, skills, attitudes and values. In PE, learners do not only “play”; they learn how to move safely, cooperate, make decisions, follow rules, care for their bodies and appreciate activity.

A **sport** is an organised physical activity with agreed rules, skills and competition. Examples include football, netball, athletics and volleyball. A **game** is an activity played for enjoyment, learning or competition under rules. Games may be physical or less physical, and they may be informal. A sport can be played as a game, but not every game is a formal sport.

### Learning objectives

By the end of the topic, the learner should be able to:

- explain Physical Education in their own words;
- identify some components of PE, such as movement skills, fitness, games, sports, health and safety;
- distinguish between a sport and a game using examples; and
- describe at least five benefits of PE to an individual or the community.

### Key terms

- **Physical Education (PE):** Education through physical activity and movement.
- **Physical activity:** Any body movement that uses energy, such as walking, running or dancing.
- **Sport:** An organised physical activity with agreed rules and skills.
- **Game:** A rule-based activity played for enjoyment, practice or competition.
- **Fitness:** The ability to perform daily activities and physical tasks effectively without excessive tiredness.
- **Fair play:** Respecting rules, opponents, officials and teammates.

### Benefits of PE

Regular, well-managed activity can help learners to improve fitness, coordination, balance and confidence. It can encourage healthy choices and provide opportunities to manage stress and emotions. Team activities build communication, cooperation, leadership and respect. At community level, sport and PE can bring people together and provide recreation and possible career pathways. [2] [3]

### Learning activities

1. **Think–pair–share:** Each learner writes a definition of PE. Pairs compare definitions and agree on one clear class definition.
2. **Sort the examples:** In groups, sort football, tag, athletics, skipping, chess, netball and dancing into “sport”, “game”, “both” or “needs discussion”. Explain each choice.
3. **Benefits map:** Draw a person in the centre of a page. Around the person write physical, mental, social and community benefits of PE.
4. **Inclusive activity challenge:** Adapt a simple relay so that learners with different speeds or physical abilities can participate meaningfully. Discuss why the adaptation is fair.

### Evidence of learning

A learner should be able to give a clear PE definition, explain the difference between a sport and a game, and present five benefits. Observe teamwork, confidence, respectful listening and relevance of contributions. The NCDC syllabus suggests a group write-up and discussion presentation as evidence. [1]

### Quick review

1. What is Physical Education?
2. Give one difference between a sport and a game.
3. Name three components or areas of PE.
4. State five benefits of PE.
5. What does fair play look like during a class game?

---

## Topic 2: Safety and First Aid

### Learner-friendly explanation

Safety means taking steps to prevent injury before, during and after physical activity. First aid is the immediate, temporary help given to an injured or ill person until qualified medical help is available. First aid does not replace professional treatment.

Before an activity, check the playing area, equipment, weather, clothing and learner readiness. During the activity, follow rules, use equipment correctly, avoid dangerous contact and stop when a learner is hurt. After an activity, cool down, report injuries and store equipment safely.

The NCDC syllabus introduces the **DRABC** routine for first response. In this package, teach it as a supervised recognition and response routine: **Danger**—check that the place is safe; **Response**—check whether the person responds; **Airway**—check that the airway is clear; **Breathing**—check for normal breathing; **Circulation/Call for help**—get urgent help and follow the school's emergency procedure. Learners should not take risks, move a seriously injured person unnecessarily, or attempt procedures beyond their training. A teacher or trained first aider should lead actual care. [1]

### Learning objectives

By the end of the topic, the learner should be able to:

- explain first aid and why it matters in a healthy lifestyle;
- identify hazards before and during a PE lesson;
- demonstrate the safe sequence for reporting an emergency and obtaining adult help;
- recognise basic injuries such as a cut, bruise, muscle pull, sprain or fainting; and
- identify common contents of a first-aid box and state their uses.

### Key terms

- **Hazard:** Something that can cause harm.
- **Injury:** Damage to the body caused by an accident, activity or other event.
- **First aid:** Immediate temporary care before professional treatment.
- **Sprain:** Injury to a ligament around a joint.
- **Strain or muscle pull:** Injury caused by overstretching or tearing a muscle or tendon.
- **Bruise:** A darkened or painful area caused by bleeding under the skin after a blow.
- **Sterile dressing:** Clean material placed over a wound to help protect it.

### Basic response principles

- **Small cut:** Tell the teacher or first aider, wash hands if appropriate, use clean materials, apply gentle pressure to control bleeding, cover the wound and dispose of waste safely.
- **Bruise:** Stop the activity, rest the area and report it. A trained adult may use a wrapped cold pack briefly; never put ice directly on skin.
- **Suspected sprain or muscle pull:** Stop activity, support the person comfortably and seek adult assessment. Do not force the joint or “play through” pain.
- **Fainting or collapse:** Clear the area, call an adult, check response and breathing, and follow the school's emergency plan. Do not give food or drink to an unconscious person.
- **Suspected fracture, severe bleeding, head or neck injury:** Treat as urgent. Keep the person still and comfortable, do not straighten a limb, and obtain medical help immediately. The NCDC resource book similarly warns against straightening a fractured limb and advises seeking medical aid. [3]

### First-aid box activity

In groups, examine a teacher-approved first-aid box without contaminating its contents. Draw and label items such as gloves, dressings, gauze, bandages, antiseptic or cleaning supplies approved by the school, scissors and a waste bag. For each item, write its safe purpose. Do not practise on a real wound, and do not give medicines unless authorised by a qualified adult and school policy.

### Safety audit and role-play

Walk around the playing area in small groups. Mark hazards on a simple plan: stones, holes, slippery ground, broken equipment, overcrowding, heat, traffic or unsafe boundaries. Suggest one control measure for each hazard.

Role-play an emergency: one learner reports an injury, one calls the teacher or first aider, one keeps other learners away, and one records what happened. Rotate roles. The task is about communication and safe decisions, not pretending to perform advanced medical treatment.

### Evidence of learning

Assess whether the learner identifies hazards, calls for help clearly, follows the safe DRABC sequence under supervision, explains the purpose of first-aid items and chooses an appropriate response to a stated injury. The NCDC syllabus recommends observation, discussion and a record of first aid offered. [1]

### Quick review

1. Define first aid.
2. What should you do before using a playing area?
3. What does each letter in DRABC remind you to check?
4. Why should a suspected fracture not be straightened?
5. Name four items in a first-aid box and state one use for each.

---

## Topic 3: Body Conditioning

### Learner-friendly explanation

Body conditioning prepares the body to perform physical tasks and helps develop safe movement habits. It includes body awareness, suitable exercise, warm-up, stretching, cool-down and injury prevention. Learners should work at an appropriate level and stop if they feel sharp pain, dizziness, breathing difficulty or illness.

A **warm-up** gradually prepares the body and mind for activity. It may begin with light movement such as walking or easy jogging, followed by dynamic movements and activities related to the sport. The NCDC resource book notes that a general warm-up may take about five to ten minutes for an average person, but the length and intensity must match the learner, weather and activity. [3]

A **cool-down** is a gradual reduction of activity after exercise. It can include slow walking and gentle stretches. It helps the learner return gradually to a resting state and provides time to notice discomfort and recover. Warming up and cooling down do not make all injuries impossible, so safe surfaces, correct technique, hydration and supervision remain important.

### Learning objectives

By the end of the topic, the learner should be able to:

- describe body awareness and explain why it matters in activity;
- identify ways of preventing injuries;
- demonstrate a safe warm-up with general, dynamic and activity-specific parts;
- demonstrate a safe cool-down; and
- explain the value of warming up and cooling down.

### Key terms

- **Body awareness:** Knowing where the body is and how it is moving.
- **Conditioning:** Planned activity that improves the body's ability to perform.
- **Warm-up:** Gradual preparation for physical activity.
- **Dynamic movement:** Controlled movement through a comfortable range, such as arm circles or high-knee walking.
- **Stretch:** Lengthening a muscle in a controlled way.
- **Cool-down:** Gradual reduction of activity after exercise.
- **Injury prevention:** Actions taken to reduce the chance or seriousness of injury.

### Sample warm-up routine

1. **General movement:** Walk or jog gently around a marked area for 3–5 minutes.
2. **Dynamic movement:** March with arm swings, heel raises, side steps, gentle lunges and controlled arm circles.
3. **Activity-specific practice:** For a ball game, use gentle passes and changes of direction. For athletics, practise relaxed running drills at low intensity.
4. **Readiness check:** Learners report pain, dizziness or illness before the main activity begins.

Avoid forcing a stretch or bouncing aggressively. A stretch should be controlled and comfortable. The teacher should demonstrate and offer easier and harder options.

### Sample cool-down routine

Walk slowly for 2–3 minutes, breathe comfortably, shake out tension, and perform gentle, held stretches for the major muscles used. Discuss how the body feels. Rehydrate according to school guidance and report pain or injury.

### Practical activity: design a safe routine

In pairs, choose a familiar activity such as football, netball, running or dance. Design a five-to-eight-minute warm-up with three parts and a three-minute cool-down. Demonstrate it to the class. The class identifies one safe feature and one improvement. Record the routine in a notebook so it can be reused.

### Evidence of learning

Observe whether the learner uses controlled dynamic movements, progresses from easy to more specific activity, maintains personal space and demonstrates a gradual cool-down. Ask the learner to explain how the routine reduces risk and prepares the body. The NCDC syllabus asks learners to plan warm-up activities and demonstrate warm-up and cool-down exercises. [1]

### Quick review

1. What is body awareness?
2. Name the three parts of the sample warm-up.
3. Give two examples of dynamic movement.
4. Why should a learner stop and report sharp pain or dizziness?
5. Explain one purpose of a cool-down.

---

## Topic 4: Movement Concepts and Educational Gymnastics

### Learner-friendly explanation

Educational gymnastics uses simple, controlled movement to develop coordination, body awareness, balance, strength, flexibility and safe use of space. It is not a competition to perform dangerous tricks. Learners begin with basic shapes and movements on a safe surface and progress only when the teacher judges that it is appropriate.

The NCDC syllabus includes locomotion, weight bearing, transference of weight, personal space, body shapes, floor and air patterns, support levels and figures. It also introduces **spotting**: a trained helper's planned support and observation of a performer during a skill. A spotter does not replace safe teaching, mats or professional supervision. [1]

### Learning objectives

By the end of the topic, the learner should be able to:

- explain educational gymnastics and its value for health and fitness;
- demonstrate safe use of personal and general space;
- perform basic body shapes, locomotor movements and changes of level;
- show controlled transfer of weight where suitable; and
- state safety rules, including when a spotter or teacher is needed.

### Key terms

- **Locomotion:** Moving from one place to another, for example walking, jogging or running.
- **Weight bearing:** Supporting some or all body weight through a body part.
- **Transference of weight:** Moving body weight from one supporting part to another.
- **Personal space:** The space immediately around one learner's body.
- **General space:** The whole area available to the group.
- **Body shape:** A planned shape made by the body, such as a tuck, straight or wide shape.
- **Level:** The height of the body, such as low, medium or high.
- **Spotter:** A trained helper who supports safety during an appropriate skill.

### Movement exploration activities

1. **Space walk:** On a signal, walk, jog or stop without touching others. Practise looking ahead, changing direction and keeping safe distance.
2. **Shapes:** Make straight, wide, narrow, tuck and curled shapes. Hold each for three seconds with controlled breathing.
3. **Levels:** Move from a low shape to a medium and then a high shape. Keep knees soft and land quietly.
4. **Pathways:** Travel along straight, curved and zigzag pathways on the floor. Draw these pathways in a notebook after the activity.
5. **Weight transfer:** With hands on a stable mat or floor and under teacher instruction, shift weight gently from feet to hands and back. Do not attempt headstands, handstands or partner lifts without specific trained supervision.
6. **Sequence:** In groups, create a short sequence containing a start shape, one locomotor action, one change of level, a safe pause and an end shape.

### Safety checklist

Use a clear, dry, level surface. Remove sharp objects. Space groups apart. Wear suitable clothing and remove dangerous jewellery. Follow start and stop signals. Land with control and bent knees when appropriate. Never push, pull or surprise a partner. Use spotting only when the teacher has taught the exact role and judged the skill safe. Stop if there is pain, fear or loss of control.

### Practical and diagram suggestion

Learners draw a top-view map of the activity area. Mark the teacher's position, group spaces, a safe pathway and a “no-go” hazard area. Next, draw stick figures showing a straight shape, a tuck shape and a low-to-high level change. Label personal space and general space. This diagram can be used to explain how good spacing prevents collisions.

### Evidence of learning

Observe the learner's start position, body shape, control, transition, use of space, smoothness and safety awareness. Ask the learner to explain why the chosen sequence is safe. The NCDC syllabus recommends performance observation, conversation about precautions and a written or video record where possible. [1]

### Quick review

1. What is educational gymnastics?
2. Distinguish personal space from general space.
3. Give two examples of locomotion.
4. What is a body shape? Name two shapes.
5. Why is a spotter used, and why must spotting be supervised?

---

## End-of-package review task

Choose one familiar school activity. Produce a one-page activity card containing:

- the name and purpose of the activity;
- two benefits of participating;
- three hazards and their control measures;
- a short warm-up and cool-down;
- one movement skill or sequence; and
- the adult or first-aid procedure to follow if someone is injured.

Present the card to a small group. The group should give feedback using three questions: Was the activity inclusive? Was it safe? Were the instructions clear? Revise the card after feedback.

## Teacher preparation and inclusion notes

Check the playing surface, weather, equipment and emergency contacts before each practical lesson. Demonstrate first, then allow practice with clear stop signals. Provide lower-impact options, larger spaces, shorter distances, visual demonstrations or peer support where needed. A learner who cannot perform a movement in the usual way can still meet the learning objective through an adapted movement, observation, planning, communication or officiating role.

Keep records of participation and observations rather than grading physical ability alone. Assess understanding, safe decisions, effort, improvement, cooperation and application of skills. Follow school safeguarding, health and emergency procedures at all times.

## References and source URLs

[1]: https://ncdc.go.ug/wp-content/uploads/2024/02/PHYSICAL_EDUCATION_Syllabus_compressed.pdf "NCDC Physical Education Syllabus"

[2]: https://ncdc.go.ug/wp-content/uploads/2024/03/Curriculum_Framework.pdf "NCDC Lower Secondary Curriculum Framework"

[3]: https://ncdc.go.ug/wp-content/uploads/2024/03/PSHPE-resource-book.pdf "NCDC Personal, Social, Health and Physical Education Resource Book"

### Context-only timetable source

The supplied archive is local context and is not an official curriculum source: `/home/ubuntu/upload/realtimetable.zip` (S1 sample timetable inside `timetables/timebles/S1.txt`).
