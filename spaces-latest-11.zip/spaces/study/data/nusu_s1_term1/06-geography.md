# Nusu Academy S1 Term 1 Geography Starter Package

## How to use this package

This is a starter package for the opening part of Senior One Geography. It is not a full textbook. The sequence below follows the **Level 1 Term 1 programme planner in the Uganda National Curriculum Development Centre (NCDC) Geography syllabus**. Schools may adjust the pace, lesson order, examples and local fieldwork according to their calendar and environment.

The NCDC planner gives the following opening sequence:

1. **Introduction to Geography** — 4 hours
2. **Showing Physical and Human Features in the Local Area on a Map** — 3 hours
3. **Map Reading and Map Use** — 6 hours
4. **Using Tables, Graphs and Charts** — 7 hours

The timetable supplied for context shows Geography periods for S1, but it does not establish a national teaching order. The order above is therefore identified as the NCDC planner sequence; the number of lessons per week may vary by school.

---

# Topic 1: Introduction to Geography

**Suggested duration:** 4 hours  
**Main competency:** The learner understands Geography, searches for geographical information from different sources and appreciates the importance of studying Geography.

## 1.1 Meaning of Geography

Geography is the study of **people and their environment**. The environment includes everything around us. Some parts are natural, while other parts have been made or changed by people.

- The **natural environment** includes soil, rocks, hills, rivers, lakes, plants, animals, air and weather.
- The **human environment** includes homes, roads, schools, farms, markets, factories, places of worship and other things made or organised by people.

Geography helps us ask useful questions such as: Where is something found? Why is it there? How does it affect people? How do people change it? How can it be used and conserved responsibly?

## 1.2 Branches of Geography

The two broad branches are:

- **Physical Geography:** the study of natural features and processes, such as landforms, rocks, soils, rivers, weather, climate, plants and animals.
- **Human Geography:** the study of people and their activities, such as settlement, population, transport, farming, trade, industry and use of resources.

The branches are connected. For example, physical Geography can explain why a valley has fertile soil, while human Geography can explain how people farm and settle in that valley.

## 1.3 Why study Geography?

Studying Geography helps learners to:

- understand how people depend on and affect the environment;
- locate places and communicate directions;
- read maps, tables, graphs and charts;
- understand local problems such as soil erosion, flooding, poor waste disposal or loss of vegetation;
- plan the careful use and conservation of resources;
- collect, interpret and communicate information;
- develop skills useful in farming, surveying, planning, transport, tourism, disaster management and many other careers.

## 1.4 Sources of geographical information

Geographical information can be obtained from direct observation and from sources such as maps, atlases, photographs, books, newspapers, statistics, the Internet, television, films, interviews and reports.

**Fieldwork** is the collection of information by visiting and observing a place. During fieldwork, learners should record observations carefully, ask respectful questions and follow safety instructions.

## Learning objectives

By the end of this topic, the learner should be able to:

1. explain Geography in simple words;
2. distinguish the natural environment from the human environment;
3. identify Physical Geography and Human Geography as broad branches;
4. give reasons why Geography is useful;
5. name sources of geographical information;
6. make a simple observation record about the school environment.

## Key terms

**Geography, environment, natural environment, human environment, Physical Geography, Human Geography, resource, fieldwork, observation, geographical information.**

## Activity: Our school environment

Work in small groups. Walk around a safe part of the school compound. List at least ten features you observe. Classify each feature as natural or human-made. Discuss:

- Which features are useful to learners?
- Which features have been changed by people?
- What environmental problem can you see?
- What practical action could help to conserve the area?

Each group should present its findings in two short paragraphs: one about the physical environment and one about the human environment.

## Short review

1. What is Geography?
2. Give four examples of natural features and four examples of human-made features.
3. State the difference between Physical Geography and Human Geography.
4. Give three reasons for studying Geography.
5. What is fieldwork? Name two sources of geographical information other than fieldwork.

---

# Topic 2: Showing Physical and Human Features in the Local Area on a Map

**Suggested duration:** 3 hours  
**Main competency:** The learner knows the main physical and human features of the local area and represents them on a map.

## 2.1 What is a map?

A **map** is a reduced drawing of the whole or part of an area, viewed from above. A map shows the position and arrangement of places or features. It is not a photograph: it uses selected symbols, lines, colours and words to communicate information clearly.

A local map may show a school, road, footpath, stream, swamp, hill, garden, market, health centre, trading centre or settlement.

## 2.2 Essential features of a simple map

A useful map should normally have:

- a **title**, which states what the map shows;
- a **frame**, which keeps the map area neat;
- a **key or legend**, which explains symbols;
- a **scale**, which relates map distance to ground distance;
- a **direction finder**, usually a north arrow or compass rose;
- clear labels and simple, recognisable symbols.

A map does not need to show every object in an area. The map-maker selects features that help the reader understand the place or follow a route.

## 2.3 Physical and human features

Physical features are natural features such as a river, lake, hill, valley, swamp, forest or rock outcrop. Human features are made or changed by people, such as a school, road, bridge, house, farm, borehole, shop or church.

## Learning objectives

By the end of this topic, the learner should be able to:

1. define a map;
2. distinguish physical features from human features;
3. draw a simple map of the school and its surroundings;
4. include a title, frame, key, scale and direction finder;
5. describe a place or route using a map;
6. explain how maps help people travel and locate places.

## Key terms

**Map, local area, physical feature, human feature, title, frame, key, legend, symbol, scale, direction, route, location.**

## Practical mapping activity

In groups, walk around the school compound and sketch the main features. Then draw a clean map on paper. Include:

1. the school name as the title;
2. a north arrow;
3. a key with at least six symbols;
4. a simple scale, such as 1 cm represents 10 m;
5. the frame and clear labels;
6. at least three physical and three human features.

Swap maps with another group. Use the other group’s map to describe a route from the school gate to a classroom, water point or nearby landmark. Give one kind comment and one improvement suggestion.

## Diagram suggestion

Draw a four-point compass rose in the margin. Label **N** at the top, **E** to the right, **S** at the bottom and **W** to the left. Add NE, SE, SW and NW between the main points.

## Short review

1. Define a map.
2. Why is a map described as a view from above?
3. List four features that should appear on a good local map.
4. Give two physical and two human features that could be shown around a school.
5. Why is a key important?

---

# Topic 3: Map Reading and Map Use

**Suggested duration:** 6 hours  
**Main competency:** The learner knows the main types and features of maps and uses maps in different situations.

## 3.1 Types of maps

Different maps serve different purposes. Examples include:

- **outline maps**, which show selected boundaries or features with little detail;
- **atlas maps**, which are collected in an atlas and show countries, regions or other large areas;
- **survey or topographical maps**, which show places and features in greater detail.

A physical map may emphasise relief, rivers and other natural features. A human or political map may emphasise boundaries, settlements, roads and population. The type of map chosen depends on the question being asked.

## 3.2 Symbols, colours and shading

Maps use symbols because real objects cannot be drawn at their full size. A line may represent a road or river. A small square may represent a building. Colours or shading may show vegetation, water, relief or other categories. Always check the key before interpreting a symbol.

Names and labels are also important. A feature may be identified by its name even when the key does not contain a special symbol for it.

## 3.3 Scale and distance

A **scale** shows the relationship between a distance on a map and the corresponding distance on the ground. It may be written as:

- a statement scale, such as **1 cm represents 1 km**;
- a representative fraction, such as **1:100,000**;
- a linear or line scale drawn on the map.

### Worked map-distance example

A map has a scale of **1 cm represents 1 km**. The distance between the school and a market measures **4.5 cm** on the map.

**Ground distance = map distance × ground distance represented by 1 cm**  
**Ground distance = 4.5 × 1 km = 4.5 km**

For a winding road, place a strip of paper or a piece of thread along the route, mark its ends, then compare the marked length with the line scale.

## 3.4 Direction and bearing

The main compass directions are north, east, south and west. The intermediate directions are north-east, south-east, south-west and north-west.

A **bearing** is a direction measured clockwise from north and written using three figures, from 000° to 360°. For example, east is 090°, south is 180° and west is 270°.

Learners should practise using a compass, a compass rose and a map. When giving a direction, name the starting place, direction and destination.

## 3.5 Grid references

A grid divides a map into squares. **Eastings** are the vertical grid lines and are read first. **Northings** are the horizontal grid lines and are read second. Remember: **along the corridor, then up the stairs**.

A four-figure grid reference identifies a grid square approximately. A six-figure grid reference identifies a more exact position within the square. Read eastings before northings and use the map’s numbers carefully.

## Learning objectives

By the end of this topic, the learner should be able to:

1. identify common types of maps;
2. interpret symbols, colours, shading and labels;
3. explain and use statement, representative fraction and linear scales;
4. estimate straight and winding distances on a map;
5. use a compass to give directions and simple bearings;
6. locate features using four-figure and six-figure grid references;
7. explain why different maps are useful in different situations.

## Key terms

**Outline map, atlas map, survey map, topographical map, symbol, shading, colour, scale, statement scale, representative fraction, linear scale, compass, direction, bearing, grid, easting, northing, grid reference, label.**

## Practical activities

- Use a local map or a teacher-prepared sketch map. Identify five features from the key and five from their labels.
- In pairs, give directions from one named feature to another using compass points.
- Measure a straight route and a winding route. Compare the two distances and discuss why they differ.
- Draw a compass rose and practise converting the four main directions into bearings.
- Use a gridded sketch map to practise reading eastings before northings. The teacher should provide the exact grid references for the map used.

## Short review

1. Name three types of maps.
2. Why do maps use symbols?
3. What is the difference between a statement scale and a linear scale?
4. A road measures 7 cm on a map with a scale of 1 cm to 2 km. What is its ground distance?
5. What is a bearing?
6. Which is read first in a grid reference: an easting or a northing? Explain why.

---

# Topic 4: Using Tables, Graphs and Charts

**Suggested duration:** 7 hours  
**Main competency:** The learner knows methods used to represent and store geographical information and uses them to analyse natural and human environments.

## 4.1 Tables and line graphs

A **table** arranges information in rows and columns. A **line graph** displays values as points joined by lines. Line graphs are useful for showing change over time, such as monthly rainfall, population growth, crop production or water level.

A good graph needs a suitable title, labelled axes, an even scale, correctly plotted points and a key where more than one line is used. When interpreting a graph, describe the general trend, highest and lowest values, unusual changes and possible reasons.

## 4.2 Bar graphs

A **bar graph** uses separate bars to compare quantities. Bars should have equal widths and equal spaces between them. A simple bar graph compares one set of values. A comparative bar graph compares two or more sets, such as maize and beans production in different years.

Use a clear title, labelled axes, a suitable scale and a key when necessary. Do not join separate bars as if they were a line graph.

## 4.3 Pie charts

A **pie chart** is a circle divided into sectors. It shows how parts contribute to a whole. The complete circle is **360°**.

To find a sector angle:

**sector angle = (part ÷ total) × 360°**

### Worked pie-chart example

A school survey records 40 learners’ preferred after-school activities:

- football: 20 learners;
- reading: 12 learners;
- music: 8 learners.

For football:

**(20 ÷ 40) × 360° = 180°**

For reading:

**(12 ÷ 40) × 360° = 108°**

For music:

**(8 ÷ 40) × 360° = 72°**

Check: **180° + 108° + 72° = 360°**. Draw each angle with a protractor, label each sector and include a title and key. The original values or percentages should be written on the finished chart.

## 4.4 Choosing the right display

- Use a **table** when exact values need to be read quickly.
- Use a **line graph** to show change or a trend over time.
- Use a **bar graph** to compare separate places, groups or categories.
- Use a **pie chart** to show parts of a total and their relative importance.

Graphs show patterns, but they do not automatically explain causes. A learner must use geographical knowledge and, where possible, additional evidence before claiming why a change occurred.

## Learning objectives

By the end of this topic, the learner should be able to:

1. distinguish between a table, line graph, bar graph and pie chart;
2. choose an appropriate way to represent a set of data;
3. draw and label simple line graphs and bar graphs;
4. construct a pie chart using sector angles;
5. describe trends, comparisons, highest values and lowest values;
6. suggest reasonable explanations for patterns in geographical data;
7. communicate findings clearly using words, numbers and diagrams.

## Key terms

**Data, statistics, table, row, column, line graph, trend, comparative line graph, bar graph, simple bar graph, comparative bar graph, pie chart, sector, total, percentage, scale, axis, key, label, relative importance.**

## Practical data activity

Collect a small, safe set of class data, such as the number of learners who walk, cycle, use public transport or travel by family vehicle. Put the results in a table. Then:

1. draw a bar graph comparing the transport categories;
2. calculate the percentage for each category;
3. draw a pie chart if time and materials allow;
4. write three sentences describing the results;
5. suggest one reason for the most common form of transport, making clear that it is a suggestion rather than proven fact.

For a line graph, use a teacher-provided data set showing monthly rainfall or weekly temperature. Include the title, axes, units and an even scale.

## Short review

1. When is a line graph more useful than a bar graph?
2. State three features of a good graph.
3. A data set has a total of 50 households, and 15 use charcoal. What percentage uses charcoal?
4. What angle represents 15 households out of 50 in a pie chart?
5. What is a trend?
6. Why should a learner avoid claiming a cause from a graph without other evidence?

---

# End-of-starter review

1. Explain how Geography is connected to the environment around your school.
2. Draw a labelled sketch map of the route from the school gate to a familiar local feature. Include a title, frame, key, scale and north arrow.
3. Explain the difference between a physical feature and a human feature.
4. Describe how to measure a winding route using a linear scale.
5. Explain the order used when reading a grid reference.
6. Choose the best display for each case and give a reason: monthly rainfall, types of crops grown, parts of a school budget, and exact figures for a field survey.
7. Suggest one fieldwork question about the local area. Name the information source or method you would use to answer it.

## Suggested learner portfolio

Keep four items in a Geography portfolio:

- the school-environment observation record;
- the local-area sketch map;
- one map-reading exercise with distance and direction work;
- one table, graph or chart with a written interpretation.

The portfolio should show neat presentation, correct labels, evidence of observation, cooperation and the ability to explain findings in the learner’s own words.

---

## References

[1]: https://ncdc.go.ug/wp-content/uploads/2024/03/GEOGRAPHY-syllabus.pdf "NCDC Geography Syllabus for the Lower Secondary Curriculum"

[2]: https://ncdc.go.ug/books/geo-textbook-s-1/ "NCDC Senior One Geography Textbook page"

[3]: https://ncdc.go.ug/wp-content/uploads/2024/03/Curriculum_Framework.pdf "NCDC Lower Secondary Curriculum Framework"

[4]: https://ncdc.go.ug/wp-content/uploads/2024/03/GEOGRAPHY_TEXTBOOK_-_SENIOR_ONE_Prototype.pdf "NCDC Senior One Geography Textbook PDF"

> Note: The official NCDC syllabus is the source for the Term 1 planner, competencies, learning outcomes and suggested activities. The supplied timetable ZIP was used only as school-timetable context and is not treated as a curriculum authority.
