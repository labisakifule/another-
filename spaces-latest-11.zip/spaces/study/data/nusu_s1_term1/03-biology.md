# Nusu Academy — Senior 1 Term 1 Biology

## Starter package: Diversity of Living Things

**Use:** This is a starter package for the opening part of Term 1, not a complete textbook. It is written for learner use and teacher-guided activities.

**Curriculum basis and sequence.** The Uganda National Curriculum Development Centre (NCDC) Senior 1 Biology syllabus places Term 1 under the theme **Diversity of Living Things** and lists **Introduction to Biology (8 periods), Cells (20 periods), and Classification (8 periods)**. This package follows those three official Term 1 topics in that order.[1] The syllabus gives topic and period guidance, but it does not prescribe every school's weekly lesson-by-lesson order. Therefore, any suggested lesson pacing below is a **proposed school sequence**, to be adjusted to the school calendar, class needs, practical resources, and current Ministry guidance. The supplied timetable is used only as context; its S1 template shows one Biology lesson on Tuesday and another on Thursday, but it is explicitly adaptable.

## Term 1 learning goals

By the end of this starter package, you should be able to:

- explain Biology as the study of life and connect it to everyday life in Uganda;
- recognise common characteristics of living organisms and distinguish living things from non-living things;
- describe cells as the basic units of living organisms;
- draw and label simple plant and animal cells and relate cell parts to their functions;
- explain how specialised cells and levels of organisation help organisms function; and
- classify organisms using similarities and differences, and explain why scientific names are useful.

The activities emphasise observation, discussion, drawing, simple investigation, reporting, and peer assessment. This matches the lower-secondary curriculum's emphasis on active learning, real situations, learner explanation in their own words, practical work, and varied assessment.[2]

---

## Topic 1: Introduction to Biology — proposed opening sequence

**NCDC guidance:** 8 periods. The official competency is that the learner understands Biology as the study of life and that living organisms experience common life processes.[1]

### 1.1 What is Biology?

Biology is the study of life and living organisms. A living organism may be a plant, animal, fungus, bacterium, or another form of life. Biology helps us understand how organisms are built, how they obtain energy and reproduce, how diseases spread, and how people can use or conserve living resources.

Biology is useful in daily life. A health worker uses biological knowledge to prevent and treat disease. A farmer applies it when choosing healthy seed, controlling pests, improving soil organisms, or selecting livestock. Families use it when handling food safely and preventing infection. Communities use it when conserving wetlands, forests, fish, and other organisms.

**Key terms:** Biology, organism, life process, botany, zoology, anatomy, physiology, ecology, genetics, taxonomy.

**Branches to know:**

- **Botany:** study of plants.
- **Zoology:** study of animals.
- **Anatomy:** study of the structure of organisms.
- **Physiology:** study of how body parts work.
- **Ecology:** study of relationships between organisms and their environment.
- **Genetics:** study of inheritance and variation.
- **Taxonomy:** identification and classification of organisms.

### 1.2 Characteristics of living things

Living organisms carry out life processes. A useful memory aid is **MRS GREN**:

- **M — Movement:** a change of position or movement of a body part. A plant shoot bends towards light; a person walks.
- **R — Respiration:** chemical reactions that release energy from food. Respiration occurs in both plants and animals.
- **S — Sensitivity:** detecting and responding to changes. A pupil becomes smaller in bright light; a plant shoot grows towards light.
- **G — Growth:** a permanent increase in size and dry mass, often accompanied by development.
- **R — Reproduction:** producing new organisms of the same kind.
- **E — Excretion:** removal of metabolic waste, such as carbon dioxide, excess water, or urea.
- **N — Nutrition:** obtaining or making substances needed for energy, growth, and repair. Green plants make food by photosynthesis; animals obtain food by eating.

The processes are common to living things, but they appear in different ways. A plant does not walk from place to place, but its roots and shoots grow and its parts show movement. A vehicle moves, but it does not respire, grow, reproduce, or carry out all the other life processes as a living organism does.

### Suggested activities

1. In pairs, observe a nearby plant, insect, bird, or other safe organism. Record evidence for as many life processes as you can. Do not harm the organism.
2. Make a two-column comparison of how a green plant and a human show nutrition, respiration, movement, sensitivity, growth, excretion, and reproduction.
3. Sort picture cards or real objects into **living**, **once-living**, and **never-living**. Give one reason for every decision.
4. Interview a family member or local worker about one way Biology is used in farming, health, food, fisheries, or environmental care. Report the answer in your own words.
5. Draw a simple pond or school-garden scene and label living organisms, non-living factors, and one relationship between them. A free drawing or simple digital drawing is acceptable.

### Check your understanding

1. Define Biology in one sentence.
2. Name the seven life processes in MRS GREN.
3. Explain why a moving motorcycle is not a living organism.
4. Give two ways Biology helps a household or community.
5. How does a green plant obtain nutrition differently from a human?

---

## Topic 2: Cells — proposed sequence within the official topic

**NCDC guidance:** 20 periods. The official competency is that the learner appreciates the cell as the basic unit of living organisms and relates specialised cell structures to their functions.[1]

### 2.1 The cell as a basic unit of life

A **cell** is the smallest unit of a living organism that can carry out life processes. Some organisms, such as many bacteria, consist of one cell. Large organisms are made of many cells that work together. Cells are too small to see clearly with the unaided eye, so a microscope may be used to magnify them.

Cells have structures that perform particular jobs. The structures are not separate organs in the same way as a human heart or stomach; they are parts inside a cell. The structures of plant and animal cells overlap, but plant cells have some additional features that support photosynthesis and a firm shape.

### 2.2 Main parts of a typical animal cell

- **Cell membrane:** a thin boundary that controls movement of substances into and out of the cell.
- **Cytoplasm:** jelly-like material where many chemical reactions occur.
- **Nucleus:** contains genetic material and helps control the activities of the cell.
- **Mitochondria:** release energy from food during aerobic respiration.

A typical animal cell is usually shown as an irregular or rounded shape. Real cells vary in shape and size.

### 2.3 Main parts of a typical plant cell

A plant cell has the cell membrane, cytoplasm, nucleus, and mitochondria described above. It also commonly has:

- **Cell wall:** a strong cellulose layer outside the membrane that supports and strengthens the cell.
- **Chloroplasts:** contain chlorophyll and absorb light energy for photosynthesis in green parts of a plant.
- **Large permanent vacuole:** contains cell sap and helps maintain pressure that supports the cell.

Not every plant cell has chloroplasts. For example, most root cells are not exposed to light and do not photosynthesise.

### Practical diagram guidance

Draw large, clear diagrams with a sharp pencil. Use single straight label lines that do not cross. Write the title, for example **“A typical plant cell”**, and include only structures you can identify. A diagram is a scientific communication tool, not an artistic picture: use simple outlines and label the correct part.

### 2.4 Specialised cells

A specialised cell has a structure adapted to carry out a particular function. Examples include:

- **Root hair cell:** has a long extension that increases surface area for absorbing water and mineral salts from soil.
- **Palisade cell:** contains many chloroplasts and is positioned near the upper surface of a leaf to absorb light.
- **Red blood cell:** has a shape and contents suited to transporting oxygen; it has no nucleus when mature in humans, leaving more room for haemoglobin.
- **Sperm cell:** has a flagellum for movement and many mitochondria to provide energy for swimming.
- **Ciliated cell:** has cilia that move mucus and trapped particles in air passages.

The structure-function link should always be stated carefully. For example: “The root hair cell has a long extension, which gives it a large surface area for absorption.”

### 2.5 Levels of organisation

In a multicellular organism, organisation can be described from simple to complex:

**cell → tissue → organ → organ system → organism**

A **tissue** is a group of similar cells working together, such as muscle tissue. An **organ** is made of different tissues working together, such as the heart. An **organ system** is a group of organs working together, such as the digestive system. An **organism** is a complete living thing.

**Example:** muscle cell → muscle tissue → heart → circulatory system → human being.

### Suggested practical and collaborative activities

1. If a microscope is available, observe a prepared plant or animal slide. Record the specimen, magnification if known, and visible structures. If no microscope is available, use a clear photograph or teacher-prepared slide image.
2. Make a wet-mount slide of onion epidermis under teacher supervision. Add a suitable stain if available, place the coverslip carefully, and observe. Follow laboratory safety instructions and do not taste or touch stains.
3. Draw and label a plant cell and an animal cell. Add a comparison paragraph with at least two similarities and three differences.
4. Use locally available materials such as paper, clay, folded card, or recycled packaging to build a cell model. Include a key explaining what each material represents and one limitation of the model.
5. In groups, act out the levels of organisation. Each learner or group represents a cell, tissue, organ, organ system, or organism. Explain how the parts depend on one another.
6. Discuss which organ systems must work together when a person is dancing, eating, or writing a story. Present a short role-play or labelled flow diagram.

### Check your understanding

1. What is a cell?
2. State one function of the cell membrane, nucleus, cytoplasm, and mitochondrion.
3. Give three structures found in a plant cell but not usually shown in a typical animal cell.
4. Explain how a root hair cell is adapted to its function.
5. Arrange these in order from simplest to most complex: organ, organism, cell, tissue, organ system.
6. Why is a cell model useful, and what can it fail to show about a real cell?

---

## Topic 3: Classification — proposed sequence within the official topic

**NCDC guidance:** 8 periods. The official competency is that the learner understands classification as sorting living things according to similarities. The syllabus expects learners to understand classification at different levels and the use of a Latin name made from genus followed by species.[1]

### 3.1 Why classify organisms?

**Classification** is the arrangement of organisms into groups using shared features. It makes the large variety of living things easier to study, identify, and communicate about. A library groups books so that a particular book can be found. In the same way, biological classification groups organisms using evidence about their similarities and differences.

Classification must use clear criteria. “Lives near my home” is a location, not necessarily a biological similarity. Useful observations may include body covering, number of legs, presence of flowers, leaf features, cell structure, and how an organism obtains food. A single visible feature may be useful for a simple key, but scientists use several features and other evidence.

### 3.2 The classification hierarchy

The main levels, from the broadest group to the most specific, are:

**Kingdom → Phylum → Class → Order → Family → Genus → Species**

A species is a group of similar organisms that can usually reproduce to produce fertile offspring. A **genus** contains closely related species.

The order matters. A kingdom contains several phyla, a phylum contains classes, and so on. As we move down the hierarchy, groups become smaller and organisms share more features.

### 3.3 Scientific names

A scientific name uses the **binomial system**, meaning two names. The first is the **genus** and begins with a capital letter. The second is the **species** name and begins with a small letter. Both words are written in italics when typed or underlined separately when handwritten. For example, the scientific name of the human species is *Homo sapiens*.

Scientific names reduce confusion caused by different local names and languages. They allow scientists in Uganda and other countries to refer to the same organism consistently. A scientific name should not be guessed from a common name; it should be checked in a reliable identification guide or database.

### Suggested practical and inquiry activities

1. Bring or sketch safe, non-protected examples such as leaves, seeds, pictures, or objects. Sort them first using your own criterion. Explain the criterion and test whether another group can use it.
2. Create a classification key for six familiar organisms or pictures. Start with a question that has two contrasting answers, such as “Does it have wings?” Test the key on an organism not used when making it.
3. Build a hierarchy using familiar organisms: begin with a broad group, then divide it into smaller groups using observable similarities. Explain where your evidence is strong and where it is limited.
4. Research the common and scientific names of three local organisms using a school textbook, library source, museum guide, or teacher-approved website. Record the source and do not collect protected organisms.
5. Compare biological hierarchy with a familiar administrative hierarchy such as district, county, and sub-county. State one way the analogy helps and one way it is not exact.

### Check your understanding

1. Define classification.
2. List the seven classification levels in the correct order.
3. Which comes first in a binomial name: genus or species?
4. State two benefits of scientific names.
5. What makes a classification key useful?
6. Explain why classification can change when new evidence becomes available.

---

## Short end-of-package review

### A. Recall

1. What is Biology?
2. Name four branches of Biology.
3. State the seven life processes.
4. Name four parts of a plant cell.
5. Write the classification hierarchy from kingdom to species.

### B. Explain

1. Explain why a green plant is a living organism even though it does not walk from place to place.
2. Compare a plant cell and an animal cell using two similarities and three differences.
3. Explain how the structure of a specialised cell is related to its work.
4. Explain why scientists need a classification system and scientific names.

### C. Apply and investigate

1. A learner finds an unfamiliar organism in the school garden. Propose three observations that could help classify it without damaging it.
2. Draw and label a plant cell. Add one sentence explaining the function of each labelled structure.
3. Design a simple investigation or observation to show that a chosen organism responds to a stimulus. State the question, prediction, materials, method, observations, and conclusion. Do not use unsafe materials or harm an organism.
4. Make a one-page poster titled **“Biology in my community”**. Include three local examples, one labelled diagram or photograph, and a short explanation of how biological knowledge supports health, food, livelihoods, or conservation.

### Suggested assessment evidence

Keep a learner folder containing the living/non-living observation table, labelled cell diagrams, microscope or image observation, specialised-cell explanation, classification key, scientific-name research, and end-of-package review. Assessment can include oral explanation, a practical demonstration, a clear diagram, a short written response, peer feedback, and self-assessment. A good answer uses correct biological terms and explains reasons rather than listing words only.

## References

[1]: https://ncdc.go.ug/wp-content/uploads/2024/02/Biology_Syllabus_compressed.pdf "National Curriculum Development Centre Uganda Biology Syllabus — Lower Secondary Curriculum"

[2]: https://ncdc.go.ug/wp-content/uploads/2024/03/Curriculum_Framework.pdf "National Curriculum Development Centre Uganda Lower Secondary Curriculum Framework"

### Context-only timetable source

The supplied file `/home/ubuntu/upload/realtimetable.zip` was consulted only for context. Its S1 timetable labels itself a typical adaptable Ugandan school timetable and shows Biology periods on Tuesday and Thursday; it is not treated as a curriculum authority and is not used to claim an official lesson order.
