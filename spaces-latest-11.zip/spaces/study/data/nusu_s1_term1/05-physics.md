# Nusu Academy S1 Term 1 Physics

## How to use this starter package

This is a **starter package**, not a complete textbook. The official Uganda National Curriculum Development Centre (NCDC) programme planner places **Introduction to Physics** in Senior 1 Term 1 for 6 periods and **Measurements in Physics** for 30 periods. [1] The four units below are therefore a practical unpacking of those two official topics for early Term 1 teaching. The order inside “Measurements in Physics” is a **proposed school sequence**, not a claim that NCDC prescribes this exact lesson-by-lesson order.

The supplied timetable ZIP was used only as context. Its sample S1 timetable gives Physics two periods per week, but schools should adapt the pace to their own calendar, staffing and current guidance.

## Term 1 proposed sequence

1. **Unit 1: What Physics is and safe practice** — drawn from the official topic *Introduction to Physics*.
2. **Unit 2: Physical quantities, units and measuring instruments** — the first part of the official topic *Measurements in Physics*.
3. **Unit 3: Investigations, accuracy and presenting data** — a proposed grouping of the NCDC measurement, fair-test and data skills.
4. **Unit 4: Area, volume, mass and density** — a proposed grouping of the NCDC measurement and density outcomes.

The units can be taught in approximately 36 periods, subject to the school calendar and practical-resource availability.

---

## Unit 1: What Physics is and safe practice

### Learner-friendly explanation

Physics is the study of matter, energy, motion, forces and the interactions that help us explain events in the natural and designed world. It helps us understand why a bicycle moves, how a torch produces light, why a metal spoon becomes hot in tea, and how buildings, machines and electrical systems work.

Physics is not only a list of facts. It is also a way of asking questions, making careful observations, taking measurements, testing ideas and explaining evidence. A physics laboratory may contain glassware, stands, wires, heat sources and other equipment, so safe behaviour protects everyone and makes results more reliable.

### Learning objectives

By the end of the unit, the learner should be able to:

- explain the meaning of Physics in their own words;
- name some branches or areas of Physics, such as mechanics, heat, light, sound, electricity and space physics;
- give examples of how Physics is used at home, at school and in Ugandan work or careers;
- identify common laboratory hazards and state suitable precautions;
- follow instructions, handle equipment responsibly and report accidents or breakages immediately.

### Key terms

**Physics:** the study of matter, energy and their interactions.  
**Observation:** information obtained using the senses or instruments.  
**Hypothesis:** a testable suggested explanation or prediction.  
**Hazard:** something that could cause harm.  
**Risk:** the chance that a hazard will cause harm.  
**Precaution:** an action taken to reduce risk.

### Activities and examples

**Activity 1 — Physics around us.** In small groups, learners list ten events or devices they meet in one day. For each, write the Physics idea involved: a boda-boda braking (force and motion), cooking food (heat), a mirror (light), a radio (sound and electricity), or rainfall and clouds (water and energy). Groups present two examples and explain them in their own words.

**Activity 2 — Safety walk.** With the teacher, learners inspect the laboratory or classroom. They identify hazards such as a wet floor, broken glass, trailing wires, an unlabelled chemical or a flame. For each hazard, state the possible harm and one precaution. Make a class safety poster with rules such as: walk, tie back long hair, do not taste substances, keep bags away from work areas, use eye protection when directed, and report accidents.

**Career link.** Learners interview or research one person whose work uses Physics, such as an electrician, builder, mechanic, laboratory technician, medical-imaging worker, meteorologist or teacher. They write three sentences on the Physics knowledge or skills used in that career.

### Quick check

1. In your own words, what does Physics study?
2. Give two examples of Physics in a kitchen and two on a road.
3. What is the difference between a hazard and a precaution?
4. Why should a learner report a broken thermometer even if nobody is hurt?

---

## Unit 2: Physical quantities, units and measuring instruments

### Learner-friendly explanation

A **physical quantity** is a property that can be measured and written with a number and a unit. For example, a desk may have a length of 1.20 metres and a mass of 8 kilograms. A number without a unit is incomplete because “5” could mean 5 centimetres, 5 seconds or 5 kilograms.

Use an instrument that matches the quantity and the required precision. A ruler or tape measure is suitable for length; a balance measures mass; a measuring cylinder measures liquid volume; and a clock or stopwatch measures time. Read a scale at eye level where possible. Record the unit and avoid reporting more decimal places than the instrument justifies.

### Learning objectives

The learner should be able to:

- distinguish a quantity from its unit;
- use common SI units for length, area, volume, mass and time;
- choose a suitable instrument for a measurement;
- estimate a value before measuring and compare the estimate with the measured value;
- record measurements clearly with units and sensible precision.

### Key terms

**Measurement:** comparison of a quantity with an agreed unit.  
**SI unit:** an internationally agreed standard unit.  
**Length:** distance from one point to another; common SI unit metre (m).  
**Area:** surface covered; common unit square metre (m²).  
**Volume:** space occupied; common unit cubic metre (m³), with litre (L) and millilitre (mL) also used for liquids.  
**Mass:** amount of matter; SI unit kilogram (kg).  
**Time:** duration of an event; SI unit second (s).

### Useful conversions

- 1 m = 100 cm; 1 cm = 10 mm.
- 1 kg = 1000 g.
- 1 L = 1000 mL.
- 1 minute = 60 seconds; 1 hour = 3600 seconds.
- 1 mL = 1 cm³ for volume conversion purposes.

### Worked examples

**Example 1 — unit conversion.** Convert 2.35 m to centimetres.

\[
2.35\text{ m} = 2.35 \times 100\text{ cm} = 235\text{ cm}
\]

**Example 2 — rectangle area.** A desk is 1.20 m long and 0.60 m wide. Find its area.

\[
\text{Area} = \text{length} \times \text{width}
= 1.20 \times 0.60 = 0.72\text{ m}^2
\]

### Practical activity: measurement stations

In pairs, estimate and then measure: the classroom length; the width of a desk; the thickness of a book; the mass of a pen or stone; the volume of water in a container; and the time taken by a partner to walk 20 paces. Record **quantity, estimate, instrument, reading, unit and comment on precision**. Compare results between pairs and discuss why readings may differ.

Where available, learners may examine a tape measure, ruler, balance, measuring cylinder, stopwatch, analogue clock and digital clock. At this level, recognise where vernier calipers and a micrometer are used, but do not attempt detailed readings unless the teacher explicitly extends the work. [1]

### Quick check

1. Which instrument would you choose to measure 25 mL of water? Why?
2. Write 4500 g in kilograms.
3. A learner records “the bottle is 12.” What information is missing?
4. Why should the eye be level with a scale when reading it?

---

## Unit 3: Investigations, accuracy and presenting data

### Learner-friendly explanation

A physics investigation begins with a question. The learner predicts what may happen, identifies what will be changed and measured, keeps other important conditions the same, collects evidence and uses the evidence to make a conclusion. This is called a **fair test** when the test changes one main factor while controlling relevant others.

Measurements are never perfectly exact. A reading can be affected by a poorly chosen instrument, parallax (viewing a scale from the side), reaction time, an unstable object or a zero error. Repeating a measurement and finding an average can make a result more dependable, although repetition cannot remove every source of error.

### Learning objectives

The learner should be able to:

- write a simple question and prediction for an investigation;
- identify the independent, dependent and controlled variables in a fair test;
- measure and record observations in a table with headings and units;
- calculate a simple average from repeated measurements;
- identify likely sources of error and suggest improvements;
- plot or interpret a simple graph and use its pattern to support a conclusion;
- write a short conclusion that refers to evidence rather than guesswork.

### Key terms

**Investigation:** a planned process for answering a question using evidence.  
**Independent variable:** the factor deliberately changed.  
**Dependent variable:** the factor measured or observed.  
**Controlled variable:** a factor kept the same for a fair comparison.  
**Accuracy:** closeness to the true or accepted value.  
**Precision:** closeness of repeated readings to one another.  
**Average (mean):** total of readings divided by the number of readings.  
**Data:** recorded observations or measurements.

### Worked example: average time

A learner measures the time for a toy car to travel a marked distance three times: 2.4 s, 2.6 s and 2.5 s.

\[
\text{Mean time} = \frac{2.4 + 2.6 + 2.5}{3}
= \frac{7.5}{3} = 2.5\text{ s}
\]

The answer should be written as **2.5 s**, not just 2.5, and the method should state how the distance and starting conditions were kept the same.

### Practical activity: cooling investigation

This follows the spirit of the NCDC suggested investigation. [1]

Question: *Does a cup of water cool at the same rate as a cup of strong salt solution?*

1. Predict which will cool faster and give a reason.
2. Measure equal volumes into two labelled containers.
3. Keep container type, starting temperature, location and measurement interval the same.
4. Measure temperature at regular times and record a table.
5. Plot temperature against time using a suitable scale.
6. Describe the pattern, identify an anomalous reading if present, and write a conclusion.
7. Suggest improvements, such as repeating the test or using a lid consistently.

Do not taste any material used in an investigation. Handle warm water only under teacher direction.

### Scientific notation and significant figures

Scientific notation writes a number as a value from 1 up to (but not including) 10 multiplied by a power of ten. For example, 4,310 = \(4.31 \times 10^3\), while 0.00431 = \(4.31 \times 10^{-3}\). Significant figures are the digits that communicate the precision of a measurement. A 2 m ruler cannot justify reporting a classroom length to six decimal places. NCDC expects scientific notation, significant figures and attention to accuracy throughout the syllabus. [1]

### Quick check

1. In a test of how surface type affects a toy car’s travel distance, name the independent and dependent variables.
2. Why are repeated readings useful?
3. Give one cause of parallax error.
4. Express 0.00056 in scientific notation.
5. What should a graph’s axes include?

---

## Unit 4: Area, volume, mass and density

### Learner-friendly explanation

Area tells how much surface a shape covers. For a rectangle, area is length multiplied by width. Volume tells how much space an object occupies. For a rectangular block, volume is length multiplied by width multiplied by height. The volume of an irregular solid can be found by displacement: the rise in water level is the object’s volume, provided the object is fully submerged and does not absorb or react with the water.

Density compares mass with volume. It helps us identify materials and explain floating and sinking. A material with greater density has more mass packed into the same volume. An object floats in a fluid when its average density is less than the fluid’s density; it sinks when its average density is greater.

### Learning objectives

The learner should be able to:

- calculate the area of a rectangle and the volume of a cuboid;
- determine the volume of a regular or irregular solid using appropriate methods;
- measure mass and volume and calculate density;
- use units such as kg/m³ and g/cm³ correctly;
- use density to make and test a prediction about floating or sinking;
- explain why repeated measurements and careful displacement improve reliability.

### Key terms

**Regular solid:** an object with a simple measurable shape.  
**Irregular solid:** an object whose volume is not easily calculated from a simple formula.  
**Displacement:** finding volume from the volume of fluid moved by a submerged object.  
**Density:** mass per unit volume.  
**Float:** remain partly or wholly supported at the surface of a fluid.  
**Sink:** move down through a fluid because its average density is greater than the fluid’s.

### Formulae

\[
\text{Area of rectangle} = l \times w
\]

\[
\text{Volume of cuboid} = l \times w \times h
\]

\[
\text{Density} = \frac{\text{mass}}{\text{volume}}
\]

### Worked examples

**Example 1 — density of a block.** A block has mass 240 g and volume 80 cm³.

\[
\text{Density} = \frac{240\text{ g}}{80\text{ cm}^3}
= 3.0\text{ g/cm}^3
\]

**Example 2 — displacement.** Water in a measuring cylinder rises from 35 mL to 58 mL when a stone is fully submerged.

\[
\text{Volume of stone} = 58 - 35 = 23\text{ mL} = 23\text{ cm}^3
\]

If the stone’s mass is 69 g:

\[
\text{Density} = \frac{69\text{ g}}{23\text{ cm}^3}=3.0\text{ g/cm}^3
\]

### Practical activity: which objects float?

Collect safe, clean objects such as a bottle top, stone, piece of wood and metal spoon. Before testing, predict whether each will float. Measure mass where a balance is available. Find the volume of regular objects by calculation and irregular objects by displacement. Record the evidence in a table and compare the object’s density with water. Explain any surprising result: a hollow object may have a low **average** density even if the material itself is dense.

NCDC specifically links density with floating and sinking and suggests learners investigate predicted and measured densities. It also notes that a density-bottle experiment should not be carried out at this level, although supplied results may be used in numerical problems. [1]

### Extension connection: water and oceans

In a short research paragraph, explain how temperature and dissolved salt can change water density and help drive ocean currents. Use a labelled sketch showing warmer, less-dense water and colder or saltier, denser water. Do not treat this extension as a reason to skip the core measurement practice.

### Quick check

1. A cuboid is 4 cm by 3 cm by 2 cm. Find its volume.
2. A liquid has mass 150 g and volume 100 cm³. Find its density.
3. Why is displacement useful for an irregular stone?
4. What two readings are needed to find volume by displacement?
5. A block has density 0.8 g/cm³. Predict what it will do in water and explain.

---

## Short end-of-package review

1. Define Physics and give one example of its use in Uganda.
2. State one laboratory rule and explain the risk it controls.
3. Choose instruments for measuring classroom length, liquid volume, mass and time.
4. Convert 3.6 kg to grams and 250 mL to cubic centimetres.
5. Explain the difference between an independent variable and a dependent variable.
6. A learner measures a length as 12.1 cm, 12.3 cm and 12.2 cm. Find the mean.
7. Write 0.000072 in scientific notation.
8. A rectangular tank is 0.50 m long, 0.40 m wide and 0.30 m high. Find its volume.
9. A sample has mass 180 g and volume 60 cm³. Find its density.
10. Suggest two ways to improve a density investigation.

### Suggested answers

1. Physics studies matter, energy and their interactions; an acceptable example is braking, heating, light, sound or electricity.
2. Answers should identify a sensible rule and the related hazard, for example reporting broken glass to prevent cuts.
3. Tape measure or ruler; measuring cylinder; balance; stopwatch or clock.
4. 3600 g; 250 cm³.
5. The independent variable is changed deliberately; the dependent variable is measured in response.
6. \((12.1+12.3+12.2)/3 = 12.2\text{ cm}\).
7. \(7.2 \times 10^{-5}\).
8. \(0.50 \times 0.40 \times 0.30 = 0.060\text{ m}^3\).
9. \(180/60 = 3.0\text{ g/cm}^3\).
10. Any two justified improvements, such as repeat readings, use a suitable instrument, read at eye level, keep variables controlled or check for zero error.

## References

[1]: https://ncdc.go.ug/wp-content/uploads/2024/02/PHYSICS_Syllabus_compressed.pdf "NCDC Physics Syllabus for the Lower Secondary Curriculum"

[2]: https://ncdc.go.ug/books/physics-syllabus/ "NCDC Physics Syllabus resource page"

[3]: https://ncdc.go.ug/wp-content/uploads/2024/03/Curriculum_Framework.pdf "NCDC Lower Secondary Curriculum Framework"
