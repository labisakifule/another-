# Nusu Academy S1 Term 1

## Starter sequence overview

This directory contains the **Nusu Academy Senior One (S1), Term 1 opening-term starter sequence**. It is organised as a set of subject-specific starter packages for teacher-guided learning, discussion, practical work, learner practice and short reviews.

The sequence is a **working starter structure**, not a complete textbook, school scheme of work, timetable or compulsory national weekly order. Topic pacing and lesson order should be adapted to the school calendar, learner readiness, staffing, facilities, assessment plan and available materials.

> **Verification note:** This starter sequence is pending verification against the current Nusu Academy school programme and the applicable National Curriculum Development Centre (NCDC) guidance. The subject notes should be reviewed by the school before formal adoption. Where a note describes a proposed school sequence, that wording should be retained until the school and NCDC references have been checked.

## S1 Term 1 structure

1. **Opening orientation and diagnostic work** — establish learner starting points, classroom routines, safety expectations and subject-specific ways of working.
2. **Core subject learning** — work through the opening Term 1 topics in each subject package, adjusting pace and examples to the school context.
3. **Practical, language and inquiry activities** — use discussions, investigations, maps, diagrams, source work, movement activities and locally relevant examples where appropriate.
4. **Consolidation and review** — collect learner evidence, revisit difficult ideas, complete end-of-package tasks and prepare for the school’s assessment programme.
5. **School-level confirmation** — confirm the final subject offering, timetable, topic order, period allocations, safeguarding requirements and NCDC alignment before treating this as the official Term 1 programme.

## Subject list and file mapping

| No. | Subject | File | Coverage in the starter package |
|---:|---|---|---|
| 1 | Mathematics | [`01-mathematics.md`](01-mathematics.md) | Number Bases; Working with Integers; Fractions, Percentages and Decimals; Rectangular Cartesian Coordinates in Two Dimensions |
| 2 | English Language | [`02-english.md`](02-english.md) | Personal Life and Family; Finding Information; Food |
| 3 | Biology | [`03-biology.md`](03-biology.md) | Introduction to Biology; Cells; Classification |
| 4 | Chemistry | [`04-chemistry.md`](04-chemistry.md) | Chemistry and Society; Experimental Chemistry; States and Changes of State of Matter; Temporary and Permanent Changes; Mixtures, Elements and Compounds |
| 5 | Physics | [`05-physics.md`](05-physics.md) | What Physics Is and Safe Practice; Physical Quantities, Units and Measuring Instruments; Investigations, Accuracy and Presenting Data; Area, Volume, Mass and Density |
| 6 | Geography | [`06-geography.md`](06-geography.md) | Introduction to Geography; Local Physical and Human Features on a Map; Map Reading and Map Use; Tables, Graphs and Charts |
| 7 | History and Political Education | [`07-history-political-education.md`](07-history-political-education.md) | Finding out about Our Past; The Origin of Man; Migration and Settlement in East Africa since 1000 AD |
| 8 | General Science | [`08-general-science.md`](08-general-science.md) | Introduction to General Science; Hazards and First Aid; Measurements and Density |
| 9 | Physical Education | [`09-physical-education.md`](09-physical-education.md) | Introduction to PE; Safety and First Aid; Body Conditioning; Movement Concepts and Educational Gymnastics |

## Subject-package conventions

- The files above are **starter notes**, not full textbooks.
- Each subject file should be read together with the school’s approved timetable, scheme of work, assessment plan and safeguarding procedures.
- References to NCDC syllabuses provide a basis for review, but do not replace confirmation by the school.
- General Science and the separate Biology, Chemistry and Physics packages are all mapped because they are present in this folder; the school should confirm whether they are taught concurrently, as alternatives, or in another arrangement.
- This README maps the existing files only. It does not rewrite, merge or replace any subject notes.

## Missing subjects

No subjects are missing from the **current nine-subject starter sequence represented by the files in this directory**. Any additional subjects offered by Nusu Academy—such as religious education, entrepreneurship, ICT, Kiswahili or other school-specific provision—must be confirmed against the school programme and current NCDC guidance before being added to this structure.
