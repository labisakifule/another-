# Nusu Academy S1 Term 1 Chemistry

## Starter package

This package introduces Chemistry through five opening topics. The topic names and order below follow the **Level One Term 1** sequence in the National Curriculum Development Centre (NCDC) *Revised Lower Secondary (Level 1 and 2) Chemistry Syllabus* prepared for the Accelerated Education Programme (AEP): Chemistry and Society; Experimental Chemistry; States and Changes of States of Matter; Temporary and Permanent Changes; and Mixtures, Elements and Compounds [1]. Because the supplied timetable is a planning context rather than a curriculum authority, teachers should adjust pacing to the school calendar, available equipment and the current Ministry of Education and Sports guidance.

The timetable context provides Chemistry periods on Tuesday 9:35–10:15, Thursday 9:35–10:15 and Friday 11:55–12:35. This package is therefore suitable for an opening block of approximately three periods per week, but it is not a claim that this exact timetable is prescribed.

The NCDC framework describes Chemistry as helping learners understand the properties of materials, transform materials into useful substances and explain changes in the natural and physical world [2]. Lessons should be active and learner-centred: learners observe, predict, investigate, discuss, record evidence and explain ideas in their own words [2].

## How to use this package

- Begin each lesson with a familiar material or event from home, school or the community.
- Use locally available, safe materials where possible. Do not ask learners to taste, smell directly, burn unknown substances or mix household chemicals.
- Keep a simple practical notebook: **date, question, prediction, apparatus/materials, method, observations, results, conclusion and safety note**.
- Treat the sequence as a **proposed school sequence grounded in the NCDC AEP Level One Term 1 listing**. The NCDC source establishes the AEP term listing, but it does not establish how many lessons every school must spend on each subtopic.

---

## Topic 1: Chemistry and Society

### Big idea

Chemistry is the study of substances, their properties, the changes they undergo and how people use or control those changes. Chemistry is not only done in a laboratory. It is present in cooking, soap making, medicine, farming, water treatment, building materials, welding, fuels and the manufacture of plastics and beverages.

The NCDC syllabus expects learners to connect Chemistry with everyday life, other subjects and Uganda’s economy. It suggests discussion, mind maps, research and a nearby field study such as observing welding, local brewing or an agricultural activity [1].

### Learning objectives

By the end of this topic, the learner should be able to:

1. Explain in simple words what Chemistry studies.
2. Identify common substances and chemical products used at home, school and in the community.
3. Give reasons for studying Chemistry and name careers that use Chemistry.
4. Describe at least two ways Chemistry contributes to Uganda’s health, agriculture, transport, manufacturing or environment.
5. Work with others to present evidence from a local observation or short research task.

### Key terms

- **Chemistry:** the study of substances, their properties and the changes they undergo.
- **Substance:** a kind of matter with particular properties.
- **Property:** a feature that helps us describe or identify a substance, such as colour, hardness, solubility or boiling point.
- **Chemical change:** a change that forms one or more new substances.
- **Chemist:** a person who studies or applies Chemistry.

### Learner-friendly explanation

A substance can be recognised by its properties. Water is a liquid at ordinary room temperature and can dissolve many substances. Iron is strong and can rust when exposed to air and moisture. Soap helps remove grease from skin or clothing. Medicines contain substances selected for particular effects in the body. In each case, chemical knowledge helps people choose, make, test or use materials safely.

Chemistry overlaps with other subjects. Biology uses Chemistry to explain digestion and medicines. Physics helps explain heating, pressure and electricity. Mathematics helps with measuring and interpreting results. Geography and agriculture help us understand minerals, soils, water and resources.

### Activity: Chemistry around us

In groups, make a three-column list:

| Item or process observed | Substance or product involved | How Chemistry helps us understand or improve it |
|---|---|---|
| Washing clothes | Soap or detergent and water | Removes dirt and grease |
| Cooking food | Food substances and heat | Heat causes physical and chemical changes |
| Treating drinking water | Water-treatment chemicals or filtration | Helps make water safer |

Add examples from your home or community. Present the list and explain one safety concern for each example.

### Short research or field task

Observe one safe local activity, such as soap use, brick making, welding, crop production, food processing or water collection. Do not handle dangerous equipment. Record:

- What materials are used?
- What useful product or service is produced?
- What change can be observed?
- What safety or environmental issue should be considered?

### Quick review

1. What does Chemistry study?
2. Name four chemical products or processes used in daily life.
3. How does Chemistry support agriculture or health in Uganda?
4. Give one link between Chemistry and Mathematics.
5. Why should a learner study the safety of a product before using it?

---

## Topic 2: Experimental Chemistry

### Big idea

Chemistry is an evidence-based subject. A chemist asks a question, makes a prediction, plans a fair investigation, uses equipment safely, records observations and measurements, then uses evidence to form a conclusion. A result is stronger when measurements are careful and observations can be checked by others.

The NCDC syllabus emphasises laboratory rules, risk assessment, equipment, accurate measuring, the scientific method and clear reporting [1].

### Learning objectives

By the end of this topic, the learner should be able to:

1. State common laboratory rules and explain why they matter.
2. Identify and use selected equipment, including a balance, measuring cylinder, thermometer, beaker, funnel and filter paper, under teacher supervision.
3. Distinguish an observation from an explanation or conclusion.
4. Write a simple prediction and identify what is changed, measured and kept the same in an investigation.
5. Record results in a table and communicate a conclusion based on evidence.

### Key terms

- **Apparatus:** equipment used in an investigation.
- **Hazard:** something that can cause harm.
- **Risk:** the chance that a hazard will cause harm and how serious that harm could be.
- **Observation:** information obtained using the senses or measuring equipment.
- **Measurement:** a value obtained using a suitable instrument and unit.
- **Variable:** a factor that can change in an investigation.
- **Hypothesis/prediction:** a testable statement about what may happen.
- **Conclusion:** a statement that answers the question using the evidence collected.

### Essential safety rules

- Follow the teacher’s instructions and read labels before use.
- Wear eye protection when directed; tie back long hair and keep loose clothing away from flames.
- Never taste chemicals. Do not smell directly; use wafting only when the teacher permits it.
- Keep bags and water away from electrical equipment and flames.
- Report spills, breakages, burns and injuries immediately.
- Never point a heated test tube at anyone.
- Wash hands after practical work and dispose of materials as instructed.

### Worked example: separating sand and water

**Question:** How can a mixture of sand and water be separated?

**Prediction:** Sand will not dissolve in water, so filtration can remove the sand.

**Method:**

1. Place filter paper in a funnel over a clean beaker.
2. Pour the sand–water mixture slowly into the filter paper.
3. Observe the material left on the paper and the liquid collected in the beaker.
4. If the teacher approves, allow the collected liquid to evaporate in a safe dish to show that dissolved substances, if present, remain after water is removed.

**Expected observation:** Sand remains as a residue on the filter paper. Water passes through as the filtrate.

**Conclusion:** Filtration separates an insoluble solid from a liquid. It does not turn the sand into a new substance.

### Activity: equipment and evidence

In groups, match each task to suitable apparatus:

- Measure 25 cm³ of water: measuring cylinder.
- Measure temperature: thermometer.
- Measure mass: balance.
- Separate an insoluble solid from a liquid: funnel and filter paper.

For each match, write one safety rule and one possible source of error. Discuss why reading a measuring cylinder at eye level is safer and more accurate than reading from above.

### Practical notebook task

Investigate whether the temperature of water changes when it is left in a warm place and in a shaded place. Use equal volumes, the same type of container and the same starting temperature. Measure at set times. Do not heat water unless the teacher is supervising. State:

- the question;
- your prediction;
- the variable measured;
- two variables kept the same;
- a results table;
- a conclusion linked to your measurements.

### Quick review

1. What is the difference between a hazard and a risk?
2. Why is a results table useful?
3. Name the apparatus used to measure mass, temperature and volume.
4. In the sand-and-water investigation, what is the residue and what is the filtrate?
5. Why should a conclusion use evidence rather than a guess?

---

## Topic 3: States and Changes of State of Matter

### Big idea

Matter is anything that has mass and occupies space. In this topic, focus on solids, liquids and gases. The particles in a solid are close together and vibrate about fixed positions. The particles in a liquid remain close but can move past one another. Gas particles are much farther apart and move freely. This particle model helps explain shape, flow, compression, diffusion and changes of state.

The NCDC syllabus includes matter, particle arrangement and motion, heating and cooling, diffusion, Brownian motion and evaporation [1].

### Learning objectives

By the end of this topic, the learner should be able to:

1. Define matter and describe solids, liquids and gases.
2. Use a particle model to explain shape, pouring and compressibility.
3. Name melting, freezing, boiling, evaporation, condensation and sublimation.
4. Explain that a change of state involves heat gain or heat loss.
5. Relate evaporation to cooling and to everyday events such as drying clothes.

### Key terms

- **Matter:** anything that has mass and occupies space.
- **Particle:** a very small unit used in a model of matter.
- **Solid:** a state with a fixed shape and fixed volume.
- **Liquid:** a state with a fixed volume but no fixed shape.
- **Gas:** a state with no fixed shape and no fixed volume.
- **Melting:** change from solid to liquid.
- **Freezing:** change from liquid to solid.
- **Boiling:** rapid vaporisation throughout a liquid at its boiling point.
- **Evaporation:** slow vaporisation from the surface of a liquid.
- **Condensation:** change from gas to liquid.
- **Sublimation:** change directly between solid and gas.
- **Diffusion:** spreading of particles from a region of higher concentration to a region of lower concentration.

### Worked example: explaining a wet shirt drying

**Observation:** A wet shirt becomes dry when hung in moving air.

**Explanation:** Water at the surface changes from liquid to gas by evaporation. The water particles that escape have enough energy to move away from the liquid. Moving air removes water vapour near the shirt, so more water can evaporate. Evaporation takes energy from the surroundings, which is why evaporation can produce a cooling effect.

### Activity: particle models

Draw three boxes labelled solid, liquid and gas. Use dots to represent particles:

- In a solid, draw close, regular particles.
- In a liquid, draw close particles with less regular spacing.
- In a gas, draw widely spaced particles.

Under each drawing, explain whether the substance keeps its shape, whether it can flow and whether it can be compressed. Remember that the drawings are models, not photographs of actual particles.

### Safe investigation: melting and cooling

With teacher supervision, place equal-sized pieces of ice in two labelled containers. Leave one in a shaded place and one in a warmer place. Record the time taken to melt. Discuss why this is not a perfectly fair test unless starting size, container and location are controlled. Do not use boiling water without direct supervision.

For a temperature investigation, the teacher may heat water and record temperature at regular intervals. Learners should plot temperature against time and mark where the water changes state. Never touch hot apparatus.

### Quick review

1. What is matter?
2. Why can a gas be compressed more easily than a solid?
3. What is the difference between boiling and evaporation?
4. Which change of state occurs when water vapour forms droplets on a cool surface?
5. Use particles to explain why a smell can spread across a room.

---

## Topic 4: Temporary and Permanent Changes

### Big idea

A temporary change can often be reversed to obtain the original material. A permanent change produces one or more new substances and is not easily reversed by simple physical means. The evidence must be considered carefully: a change of appearance alone does not always prove that a new substance has formed.

The NCDC syllabus asks learners to compare examples such as boiling and condensing water, heating and cooling wax, dissolving salt, rusting iron, breaking wood and cooking an egg [1].

### Learning objectives

By the end of this topic, the learner should be able to:

1. Describe temporary (reversible) and permanent (irreversible) changes.
2. Classify familiar changes and justify the classification.
3. Identify signs that may indicate a chemical change, such as a new colour, gas, precipitate, heat or light.
4. Explain why melting, freezing and dissolving can often be reversed.
5. Describe why burning, rusting and cooking an egg are permanent changes.

### Key terms

- **Temporary/reversible change:** a change in which the original material can be recovered by a simple process.
- **Permanent/irreversible change:** a change in which new material is formed or the original material cannot easily be recovered.
- **Physical change:** a change in state, shape or size without forming a new substance.
- **Chemical change:** a change in which new substance(s) form.
- **Rusting:** a slow chemical change in which iron reacts with oxygen and water to form rust.
- **Dissolve:** to mix uniformly into a solvent to form a solution.

### Worked examples

**Example 1: melting ice**

Ice changes from solid water to liquid water. Cooling the liquid can form ice again. This is a temporary physical change.

**Example 2: burning paper**

Burning paper produces ash and gases with properties different from paper. The ash and gases cannot simply be changed back into the original sheet. This is a permanent chemical change.

**Example 3: dissolving salt in water**

Salt seems to disappear, but it is still present in the solution. Evaporating the water can recover salt crystals. This is generally treated as a reversible physical change, although heating can create safety risks and must be done by the teacher.

### Activity: change-classification table

Complete the table and add evidence.

| Change | Temporary or permanent? | Evidence or reason |
|---|---|---|
| Melting candle wax | Temporary | Wax can solidify again when cooled |
| Boiling and condensing water | Temporary | Water changes state and can be recovered |
| Rusting an iron nail | Permanent | A new substance, rust, forms |
| Breaking a wooden stick | Usually permanent in shape, but not a chemical change | The pieces do not return to the original stick by themselves |
| Cooking an egg | Permanent | New substances and texture form |

Discuss the important point that “permanent” in everyday language can describe a lasting physical change, while “chemical change” specifically means that new substances form.

### Safe observation activity

Observe a steel nail before and after it has been left in a damp place for several days. Record colour, texture and any visible coating. Do not scrape or taste the coating. Compare with a dry nail. Explain which conditions may increase rusting and how painting or oiling can protect iron.

### Quick review

1. What makes a change temporary?
2. Is dissolving salt in water usually reversible? Explain.
3. Give two signs that may suggest a chemical change.
4. Why is rusting different from melting ice?
5. Is breaking a stick a chemical change? Explain the difference between a permanent shape change and formation of a new substance.

---

## Topic 5: Mixtures, Elements and Compounds

### Big idea

An **element** contains one type of atom. A **compound** contains elements chemically combined in a fixed composition. A **mixture** contains two or more substances together; the substances retain their own properties and can often be separated by physical methods.

The NCDC syllabus develops these ideas through classification, dissolving, filtration, evaporation, crystallisation and discussion of purity using melting and boiling points [1].

### Learning objectives

By the end of this topic, the learner should be able to:

1. Distinguish elements, compounds and mixtures.
2. Give suitable examples of each.
3. Explain the roles of solute, solvent and solution.
4. Choose a separation method for a stated mixture.
5. Use observations to decide whether a sample is likely to be pure or a mixture.

### Key terms

- **Element:** a substance made of one type of atom.
- **Atom:** a very small unit of an element.
- **Compound:** a substance formed when elements are chemically combined.
- **Mixture:** two or more substances together that can often be separated physically.
- **Solute:** a substance that dissolves.
- **Solvent:** the substance that does the dissolving.
- **Solution:** a uniform mixture of solute and solvent.
- **Soluble:** able to dissolve in a particular solvent.
- **Insoluble:** unable to dissolve, or able to dissolve only to a very small extent.
- **Filtration:** separating an insoluble solid from a liquid using a filter.
- **Evaporation/crystallisation:** recovering a dissolved solid by removing some or all solvent and allowing crystals to form.
- **Purity:** how far a sample consists of one substance rather than a mixture.

### Classification examples

- **Element:** oxygen, gold, copper or chlorine.
- **Compound:** water, carbon dioxide or sodium chloride.
- **Mixture:** air, soil, tea with sugar, muddy water or salt mixed with sand.

Water is a compound when it is pure H₂O. Water from a river or tap usually contains dissolved substances and is therefore a mixture, even though water is its main component.

### Worked example: separating rock salt

**Problem:** A sample contains rock salt, which includes salt crystals mixed with insoluble pieces of rock. How can the salt be recovered?

**Method and reasoning:**

1. Add water and stir. The salt dissolves; the rock remains insoluble.
2. Filter the mixture. The rock stays as the residue; the salt solution passes through as the filtrate.
3. Evaporate some water carefully and allow the concentrated solution to cool so salt crystals form.
4. Separate and dry the crystals as directed by the teacher.

**Conclusion:** The method uses differences in solubility and then evaporation/crystallisation. It is a physical separation because no new substance is intended to form.

### Worked example: solute, solvent and solution

When 10 g of sugar is stirred into 100 cm³ of water:

- sugar is the **solute**;
- water is the **solvent**;
- the uniform sugar-water mixture is the **solution**.

If extra sugar remains at the bottom, the water has reached its capacity to dissolve sugar under those conditions. The undissolved sugar is not part of the uniform solution.

### Activity: choose a separation method

For each mixture, state the useful property and method:

| Mixture | Useful property | Method |
|---|---|---|
| Sand and water | Sand is insoluble | Filtration |
| Salt and water | Salt is dissolved; water can be removed | Evaporation or crystallisation |
| Iron filings and sand | Iron is attracted by a magnet | Magnetic separation |
| Oil and water | Liquids form separate layers | Careful decanting or a separating funnel under teacher supervision |
| Different coloured inks | Components travel differently | Paper chromatography, if available and supervised |

### Practical investigation: distilled water and tap water

The NCDC syllabus suggests comparing equal masses of crushed ice made from distilled water and tap water. Plan a fair test with equal mass, similar particle size, identical containers and the same surroundings. Predict which may melt differently and explain that dissolved substances can affect the behaviour of water. Record repeated times and discuss sources of uncertainty. Do not claim a result before collecting evidence.

### Quick review

1. What is the difference between an element and a compound?
2. Why is air a mixture?
3. In salt water, identify the solute, solvent and solution.
4. How would you separate sand from water?
5. Why is filtration not suitable for separating dissolved salt from water?
6. What does a pure substance mean in this context?

---

## End-of-package review

1. Explain two ways Chemistry affects life in your community.
2. Write the steps of a safe investigation from question to conclusion.
3. Use particles to explain why a liquid takes the shape of its container.
4. Classify each as mainly temporary or permanent: melting butter, rusting iron, burning charcoal, dissolving sugar, cooking food. Give a reason for each.
5. Classify oxygen, water, soil and carbon dioxide as element, compound or mixture.
6. A learner says, “If a substance disappears in water, it has been destroyed.” Correct the statement using the ideas of solute, solvent and solution.
7. Design a method to separate a mixture of stones, sand and salt. List the order of operations and the property used at each step.
8. Write one safety rule for heating, one for handling glassware and one for reporting accidents.

## Suggested evidence for assessment

A teacher can collect or observe:

- a Chemistry-around-us mind map or field report;
- a labelled apparatus and laboratory-safety task;
- a practical notebook with a prediction, results table and conclusion;
- particle diagrams for solids, liquids and gases;
- the temporary/permanent change classification table;
- a separation-method plan and explanation;
- short oral explanations during group discussion.

Assess not only recall, but also safe practice, accurate observation, use of evidence, communication, collaboration and the ability to apply ideas to familiar situations. This reflects the NCDC emphasis on active, experiential and competency-based learning [1] [2].

## References

[1]: https://ncdc.go.ug/wp-content/uploads/2024/04/NCDC_AEP_CHEMISTRY_LSC_level-1and-2_Web-file_Final-08.03.2024.pdf "NCDC Revised Lower Secondary Chemistry Syllabus, Level 1 and 2, Accelerated Education Programme"

[2]: https://ncdc.go.ug/wp-content/uploads/2024/03/Curriculum_Framework.pdf "NCDC The Lower Secondary Curriculum Framework"

[3]: https://ncdc.go.ug/books/chemistry-syllabus/ "NCDC Chemistry Syllabus catalogue page"
