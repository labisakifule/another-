# Nusu Academy S1 Term 1 Starter Package
## History and Political Education

### How to use this package

This is a **starter package**, not a complete textbook. It covers the first three Senior One topics in the National Curriculum Development Centre (NCDC) Lower Secondary History and Political Education programme planner: **Finding out about our past**, **The origin of man**, and **Migration and settlement in East Africa since 1000 AD** [1]. The syllabus gives estimated periods for topics, but a school should adjust the weekly plan to its calendar, examinations, activities and learner needs. The timetable supplied with this package is used only as context; it is not an NCDC curriculum authority.

The NCDC syllabus presents learning outcomes, suggested learning activities and sample assessment activities. The activities below therefore emphasise reading, source work, discussion, mapping, presentation and reflection. They also support the Lower Secondary Curriculum Framework’s focus on critical thinking, communication, cooperation, self-directed learning and ICT proficiency [2].

## Proposed opening sequence and pacing

The sequence below follows the order in the NCDC programme planner and detailed syllabus. It is a **curriculum-aligned opening sequence**, not a claim that every school must use identical weekly dates.

1. **Finding out about our past** — approximately 10 periods. Learners begin by asking what History and Political Education means, how knowledge about the past is built, and why historical sites matter.
2. **The origin of man** — approximately 16 periods. Learners compare traditional, religious and scientific accounts respectfully and examine the idea of human evolution and migration out of Africa.
3. **Migration and settlement in East Africa since 1000 AD** — approximately 8 periods. Learners study the movement and settlement of Bantu, Luo and Ngoni groups and consider the effects of migration on communities.

The official syllabus lists **Culture and key ethnic groups in East Africa** next, but labels it under Term 2 in the detailed section. It is therefore not included in this Term 1 starter package [1].

---

# Topic 1: Finding out about our past

**Suggested duration:** 10 periods

### Competency
The learner understands different methods of finding out about the past and appreciates the importance of historical sites [1].

### Learner-friendly explanation
**History** is the study of people, events, ideas and changes in the past. The past includes everything that happened before the present, while history is the carefully selected and explained account we construct from evidence. **Political education** helps learners understand how people organise power, make decisions, exercise rights and responsibilities, and participate in community and national life. The two areas connect because past decisions and institutions affect how societies are governed today.

We find out about the past from **sources**. Some sources are written, such as letters, newspapers, books, government records and inscriptions. Other sources are oral, such as an elder’s account, a clan story, a song or a place name. Material sources include tools, pottery, buildings, coins, clothing and graves. Visual and audio-visual sources include photographs, maps, films and recorded interviews. Archaeologists study material remains, while historians compare and interpret different kinds of evidence.

A source is not automatically correct simply because it exists. A researcher asks: Who created it? When? For what purpose? What information does it provide? What might it leave out? Does another independent source support it? Oral traditions are valuable, but memory can change and stories may be shaped by later events. Written records can also contain bias or errors. Good historical work compares sources rather than accepting one account without question.

Historical sites are places connected with important past events, people or ways of life. They can teach us, strengthen identity, support tourism and provide livelihoods. They also need protection because damage or careless development can destroy evidence that cannot be replaced.

### Learning objectives
By the end of the topic, the learner should be able to:

- explain the meaning of History and Political Education in their own words;
- give reasons for studying the past;
- identify written, oral, material, visual and audio-visual sources;
- describe one strength and one limitation of each source type;
- apply simple questions to judge the reliability and usefulness of a source;
- identify historical sites in Uganda or East Africa and explain why they matter;
- communicate findings through a short report, map, presentation or reflective journal.

### Key terms

- **Past:** Time and events that have already happened.
- **History:** An evidence-based account and interpretation of the past.
- **Source:** Something from which information about the past can be obtained.
- **Oral tradition:** Knowledge passed by speaking, storytelling, song or performance.
- **Artefact:** An object made or used by people, especially one studied as evidence.
- **Archaeology:** The study of past human life through material remains.
- **Historical site:** A place with important evidence or memory from the past.
- **Evidence:** Information used to support a historical explanation.
- **Bias:** A preference or viewpoint that may influence an account.

### Learning activities

1. **Class source sort:** In groups, sort cards or objects into written, oral, material, visual and audio-visual sources. For each item, write what it might tell a historian and what it might not tell them.
2. **Family or community memory interview:** With permission, interview an older person about one local change, such as a new road, school, market or settlement. Record the interviewee’s name or agreed pseudonym, date, place and main points. Do not record private information without consent.
3. **Source comparison:** Read a short textbook paragraph about a local event and compare it with an oral account. Identify agreements, differences and possible reasons for the differences.
4. **Historical-site map:** On a sketch map of Uganda or East Africa, mark two or three known historical sites. Add a sentence explaining the importance of each. Use an atlas or an approved library/online source.
5. **Short reading and writing task:** Read a one-page account of a historical site. Write a 120-word response answering: What is the evidence? Who may benefit from preserving the site? What could threaten it?
6. **Mini portfolio:** Keep the interview notes, source comparison, map and reflection in a History folder. Add a final paragraph explaining which source was most useful and why.

### Quick review

1. What is the difference between the past and History?
2. Name four types of historical source.
3. Why should a historian compare sources?
4. Give one benefit and one danger related to historical sites.
5. Write two questions you would ask before trusting a source.

**Exit task:** Choose one object near you. In five sentences, explain how it could become historical evidence and what further information you would need.

---

# Topic 2: The origin of man

**Suggested duration:** 16 periods

### Competency
The learner understands theories about the origin of man using a series of accounts [1].

### Learner-friendly explanation
People have explained human origins in different ways. East African communities have traditional accounts that connect human beginnings with ancestors, creation, land and social values. Religious traditions also contain creation accounts. Scientific explanations use observations, fossils, artefacts, comparative anatomy, genetics and dating methods to develop and test explanations about human evolution.

These accounts should be studied accurately and respectfully. A traditional or religious account has meaning within a community or faith. A scientific theory is a carefully tested explanation that can be revised when new evidence is found. In science, the word **theory** does not mean a random guess. It means an explanation supported by substantial evidence.

The scientific account of human evolution describes gradual change in populations over very long periods. Humans and other living primates share distant ancestors; this does not mean that a modern monkey suddenly changed into a modern human. Fossil and genetic evidence shows that important stages of human development occurred in Africa. The **Out-of-Africa** model proposes that modern humans originated in Africa and later spread to other regions. The **multiregional** view gives greater emphasis to long-term development in several regions and interaction among populations. Learners should compare the evidence and limits of each explanation without presenting a classroom debate as if it settles matters that require specialist scientific study.

### Learning objectives
By the end of the topic, the learner should be able to:

- describe an East African traditional account of human origin, with its community context;
- summarise a religious creation account accurately and respectfully;
- explain how fossils, artefacts, comparative anatomy and genetics provide evidence;
- define human evolution and distinguish scientific theory from a guess;
- outline the Out-of-Africa and multiregional explanations;
- compare accounts using evidence, purpose and type of explanation;
- listen respectfully and present a reasoned conclusion without insulting another person’s belief.

### Key terms

- **Origin:** The beginning or source of something.
- **Creation account:** A religious or cultural explanation of how life or humans began.
- **Evolution:** Change in inherited characteristics of populations over generations.
- **Fossil:** Preserved remains or traces of ancient life.
- **Artefact:** A human-made object that provides evidence about past life.
- **Ancestor:** An earlier person or population from which later generations descend.
- **Hominin:** A member of the human line after it separated from the line leading to other living apes.
- **Out-of-Africa model:** The explanation that modern humans originated in Africa and later migrated widely.
- **Multiregional model:** An explanation that stresses development in several regions with interaction among populations.
- **Evidence:** Information used to support or assess an explanation.

### Learning activities

1. **Reading circle:** Read two short, age-appropriate accounts: one traditional East African account and one religious account selected by the teacher. Identify the community or faith context, main message and type of explanation. Do not rank people’s worth by their account.
2. **Evidence stations:** Rotate through stations with a fossil image, a tool image, a simple family-tree diagram, a map of Africa and a short genetics extract. At each station, record: What might this evidence show? What can it not prove by itself?
3. **Timeline activity:** Place simplified human-development milestones on a long strip. Emphasise that the timescale is many thousands or millions of years and that evidence is incomplete.
4. **Comparison writing:** Complete a three-column organiser for traditional/religious accounts, scientific evolution and migration models: source of knowledge, main claim, supporting evidence and questions that remain.
5. **Structured discussion:** In small groups, discuss the statement, “Different kinds of accounts can answer different kinds of questions.” Each learner must give one reason and respond respectfully to another view.
6. **Reading and source evaluation:** Read a short popular article about a fossil discovery. Highlight claims, evidence and words that show uncertainty. Write a 150-word summary that does not exaggerate what the evidence proves.

### Quick review

1. What is meant by human evolution?
2. Name three kinds of evidence used to study human origins.
3. Why is a scientific theory not simply a guess?
4. State the main idea of the Out-of-Africa model.
5. How can learners discuss religious, traditional and scientific accounts respectfully?

**Exit task:** In a labelled diagram, show how “account,” “evidence,” “interpretation” and “conclusion” are related. Add one sentence explaining why a conclusion may change when new evidence appears.

---

# Topic 3: Migration and settlement in East Africa since 1000 AD

**Suggested duration:** 8 periods

### Competency
The learner understands the origins of their own families as a result of migration and settlement in East Africa [1].

### Learner-friendly explanation
**Migration** is the movement of people from one place to another. People may move because of the search for land, water, pasture, security, trade, employment, family links, conflict, environmental pressure or political change. **Settlement** is the process of establishing a home and community in a new place. Migration is often gradual, involving several generations and more than one route.

The NCDC syllabus introduces the origins and movements of Bantu, Luo and Ngoni groups into East Africa since 1000 AD. These labels describe broad language and historical groupings, not single, uniform communities. People within a group have different histories, identities and experiences. Learners should avoid treating any ethnic group as naturally superior or inferior.

Migration changed East Africa in many ways. It contributed to new languages, farming and herding practices, technologies, trade links, political relationships and cultural exchange. It could also produce competition over land and resources, conflict or the displacement of earlier inhabitants. A balanced historical explanation considers both contributions and tensions, and distinguishes evidence from a stereotype.

### Learning objectives
By the end of the topic, the learner should be able to:

- define migration and settlement;
- identify groups that lived in East Africa before later migrations;
- describe the broad origins and movement of Bantu, Luo and Ngoni groups using a sketch map;
- explain several reasons for migration;
- describe positive and negative effects of migration and interaction;
- use oral, written, map and family-history sources carefully;
- present a short evidence-based account of a migration story without exposing private family information.

### Key terms

- **Migration:** Movement of people from one place to another.
- **Settlement:** Establishing residence and community in a new place.
- **Push factor:** A condition that encourages people to leave a place.
- **Pull factor:** A condition that attracts people to a new place.
- **Route:** The path followed during movement.
- **Bantu:** A broad group of related African languages and the communities that speak them; not one single tribe.
- **Luo:** A group of related peoples and languages found in parts of East Africa.
- **Ngoni:** Communities associated with migrations connected to the Mfecane and later movements into parts of East Africa.
- **Mfecane:** A period of upheavals and migrations in southern Africa in the early nineteenth century, linked to later Ngoni movements.
- **Interaction:** Contact in which people influence one another.

### Learning activities

1. **Push-and-pull sort:** Sort possible reasons for moving into push factors, pull factors or both. Add reasons relevant to present-day movement, while distinguishing current migration from the historical cases being studied.
2. **Sketch-map workshop:** Using an atlas and teacher-provided outline map, draw broad arrows for Bantu, Luo and Ngoni movements. Label the map “simplified routes” because historical movement was not one straight journey. Include a key and a north arrow.
3. **Source reading:** Read three short extracts: an oral-history account, a map caption and a historian’s summary. Identify what each source tells us, its viewpoint and one question that still needs investigation.
4. **Family-history option:** Learners may research a family or community movement only with consent. They may use a fictional case instead. Present the result as a timeline or map, not as personal information that the learner does not want shared.
5. **Effects wheel:** In groups, place “migration” at the centre and add branches for language, food, farming, technology, trade, leadership, conflict and cultural exchange. Mark each effect as possible benefit, possible challenge or both.
6. **Short writing activity:** Write 180–220 words answering: “How can migration change both migrants and the communities they meet?” Use at least two pieces of evidence from the lesson sources.

### Quick review

1. What is the difference between a push factor and a pull factor?
2. Name the three migration groupings highlighted in this topic.
3. Why should a migration route be drawn as a simplified route rather than an exact single line?
4. Give two benefits and two challenges that migration may create.
5. How can a learner investigate family history ethically?

**Exit task:** Study a migration map drawn by a classmate. Write one accurate observation, one question for further research and one suggestion for improving the map.

---

## Term 1 consolidation task

Create a three-page mini-portfolio titled **“How people, evidence and movement shape East African history.”** Page 1 should contain a source-sorting chart and a historical-site sketch map. Page 2 should compare two accounts of human origin and identify the evidence used by each. Page 3 should contain a simplified migration map and a short explanation of one benefit and one challenge of migration. End with a 100-word reflection on how studying the past can help a learner act responsibly in the present.

A teacher may assess the portfolio for historical accuracy, use of evidence, map conventions, clarity of writing, respectful discussion, cooperation and the learner’s ability to explain uncertainty. These criteria reflect the NCDC emphasis on outcomes, learner activities and sample assessment rather than memorising isolated facts [1] [2].

## References and source URLs

[1]: https://ncdc.go.ug/wp-content/uploads/2024/02/Olevel-History-syllabus-June-2023.pdf "NCDC History and Political Education Syllabus for Lower Secondary, June 2023"

[2]: https://ncdc.go.ug/wp-content/uploads/2024/03/Curriculum_Framework.pdf "NCDC Lower Secondary Curriculum Framework"

[3]: https://ncdc.go.ug/wp-content/uploads/2024/03/History-syllabus.pdf "NCDC History Syllabus resource"
