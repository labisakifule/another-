# Nusu Academy S1 Term 1 Starter Package: English

**Subject:** English Language  
**Class:** Senior One (S1)  
**Term:** Term 1  
**Package type:** Opening-topic starter package, not a full textbook

## How to use this package

This package follows the three Senior One Term 1 topics named in the National Curriculum Development Centre (NCDC) English syllabus: **Personal Life and Family** (24 periods), **Finding Information** (26 periods), and **Food** (22 periods), giving 72 periods in total. [1] The timetable supplied for context shows several English periods each week, but it is not treated as a curriculum authority. Teachers should adjust the pace to the school calendar, learner needs, available books and the current school programme.

The NCDC syllabus emphasises four practical skills—speaking, listening, reading and writing—and expects learners to work with real situations, pictures, diagrams and texts from different sources. [1] The activities below therefore integrate skills instead of teaching grammar as isolated rules. The three-topic order is the NCDC Term 1 programme-planner order. The smaller subtopic order within each topic is a **proposed school sequence** for a realistic opening term; it is not presented as an official weekly order.

## Term 1 overview

| Proposed teaching block | NCDC topic | Suggested periods | Main language work | Main product |
|---|---|---:|---|---|
| 1 | Personal Life and Family | 24 | Describing people and relationships; present forms of **to be**; personal pronouns; abstract nouns; likes and dislikes | Family profile and family-tree presentation |
| 2 | Finding Information | 26 | Sources, library use, skimming, scanning, note-taking, questions, summaries, survey language | Short class survey and evidence-based report |
| 3 | Food | 22 | Food vocabulary, recipes, sequencing, instructions, countable/uncountable nouns, taste adjectives, etiquette, vowel sounds | Recipe flowchart, demonstration and polite meal role-play |

A short diagnostic activity at the beginning of Term 1 should check reading fluency, listening, spelling, sentence construction and confidence in speaking. It should guide support, not be used to label learners.

# Topic 1: Personal Life and Family — 24 periods

**NCDC competency:** The learner narrates experiences, reads and responds to stories about personal and family life. [1]

### Proposed school sequence

1. **Introducing self and others** (about 4 periods)
2. **Family members, relationships and responsibilities** (about 6 periods)
3. **Family trees and describing people** (about 5 periods)
4. **Present forms of _to be_, personal pronouns and abstract nouns** (about 5 periods)
5. **Likes, dislikes and respectful family stories** (about 4 periods)

This is a proposed progression from familiar self-description to family relationships and then to a short integrated presentation. The NCDC syllabus does not prescribe these exact weekly divisions.

## Learner-friendly explanation

A family can include people related by birth, marriage, adoption or care. Families may be organised in different ways, and no single family pattern should be treated as the only “normal” one. We describe people and family life by giving factual information, explaining responsibilities and expressing opinions respectfully.

When we introduce ourselves, we usually use the **present simple** for regular facts: “I live in Gulu.” We use forms of **to be** to identify or describe someone: “I am a learner.” “She is my aunt.” “They are my cousins.” We use pronouns so that we do not repeat names unnecessarily.

A family tree is a diagram that shows family relationships. It may include names, relationships, occupations and dates when people are comfortable sharing them. A learner may make a fictional or simplified family tree instead of revealing private information.

## Objectives

By the end of the topic, the learner should be able to:

- speak and write about self, family members and family responsibilities;
- listen to another learner’s account and respond with interest and respect;
- read a short personal or family-life story and identify its main idea and details;
- interpret and construct a family tree or another simple graphical representation;
- use **am, is, are** accurately in present-tense descriptions;
- use subject, object and possessive personal pronouns in speech and writing;
- use selected abstract nouns such as *honesty*, *love*, *responsibility* and *kindness*;
- express likes and dislikes and give a simple reason.

## Key terms

**family**, **relative**, **parent**, **guardian**, **sibling**, **grandparent**, **cousin**, **aunt**, **uncle**, **responsibility**, **relationship**, **occupation**, **family tree**, **pronoun**, **possessive**, **abstract noun**, **like**, **prefer**, **dislike**.

## Language focus and examples

### Forms of _to be_

- I **am** a learner.
- He/She/It **is** helpful.
- You/We/They **are** responsible.
- Negative: “I **am not** late.” “They **are not** at home.”
- Question: “**Is** she your sister?” “**Are** they your cousins?”

Common correction: “My brothers **are** friendly,” not “My brothers is friendly.”

### Personal pronouns

- Subject: **I, you, he, she, it, we, they** — “**They** help at home.”
- Object: **me, you, him, her, it, us, them** — “Our teacher helps **us**.”
- Possessive adjectives: **my, your, his, her, its, our, their** — “This is **our** home.”

### Abstract nouns

An abstract noun names an idea or quality that cannot usually be touched. Examples: **respect, honesty, patience, love, courage, responsibility**.

Example paragraph: “My grandmother is patient. She shows love to the family. Her advice teaches us responsibility.”

### Expressing preference politely

- “I like reading because it is relaxing.”
- “I prefer tea to soda.”
- “I do not like loud music, but I respect people who enjoy it.”
- “What do you like doing?” — “I enjoy playing netball.”

## Reading activity: “A new home”

Read the short passage below, then answer the questions.

> When Amina joined S1, she lived with her mother, two brothers and her aunt. Her mother sold vegetables, while her aunt repaired clothes. Everyone had a responsibility. Amina washed cups and prepared her books for school. Her brothers collected water. In the evening, the family talked about the day. They did not always agree, but they listened to one another and solved problems calmly.

1. Who lived with Amina?  
2. What work did her aunt do?  
3. Name two responsibilities in the family.  
4. Find one sentence that shows cooperation.  
5. Which abstract noun best describes the family’s way of solving problems: *patience*, *anger* or *fear*? Give a reason.

**Suggested answers:** 1. Her mother, two brothers and aunt. 2. She repaired clothes. 3. Any two accurate examples. 4. “Everyone had a responsibility” or the final sentence. 5. *Patience*, because they listened and solved problems calmly.

## Activities and assessment evidence

- **Pair interview:** Learners ask and answer: “Where do you live?”, “Who do you live with?”, “What responsibility do you have at home?” Partners report two facts without mocking or exposing private information.
- **Family-tree task:** Learners create a labelled diagram using real, fictional or mixed information. They add occupations only where known and use a key for relationships.
- **Listening circle:** One learner gives a one-minute family description. Listeners write the main idea and two details, then respond with one encouraging sentence.
- **Grammar repair:** In pairs, correct sentences such as “She are my aunt,” “Them helps me,” and “We is respectful.” Learners explain the correction.
- **Short writing:** Write 8–10 sentences titled “People who support me.” Use at least three pronouns, two forms of **to be**, and two abstract nouns.
- **Assessment:** Use a simple checklist for accurate language, clear organisation, respectful listening, relevant detail and confidence. Do not grade a learner’s family structure.

## Short review

1. Complete: “I ___ in S1.” “My friends ___ helpful.”  
2. Replace the repeated noun: “Peter helps Peter’s sister because Peter is kind.”  
3. Give two abstract nouns connected with a good family relationship.  
4. Write one sentence expressing a like and a reason.  
5. What information can a family tree show?

**Answers:** 1. *am; are*. 2. “Peter helps **his** sister because **he** is kind.” 3. Any two suitable nouns, such as *respect* and *love*. 4. Any grammatically correct answer with a reason. 5. Family relationships and, if appropriate, names or other agreed details.

# Topic 2: Finding Information — 26 periods

**NCDC competency:** The learner finds information needed, carries out surveys, interprets oral and recorded materials, and reads information from different sources for a variety of purposes. [1]

### Proposed school sequence

1. **Sources and purposes of information** (about 5 periods)
2. **Using the school library and catalogues** (about 5 periods)
3. **Reading for gist: titles, headings and skimming** (about 5 periods)
4. **Reading for specific information: scanning and note-taking** (about 5 periods)
5. **Questions, surveys, summaries and presenting results** (about 6 periods)

This is a proposed sequence from identifying sources to using them in a small inquiry. The official syllabus gives the topic outcomes and activities but does not require these exact subtopic boundaries.

## Learner-friendly explanation

Information is knowledge we obtain from people, books, broadcasts, recordings, newspapers, websites, pictures, maps and other sources. A good learner chooses a source that fits the question, checks whether the information is relevant, records important points and gives credit to the source.

**Skimming** means reading quickly to get the general idea. Look at the title, headings, first sentences and pictures. **Scanning** means looking quickly for a particular detail such as a name, date, number or place. Good notes use short phrases, headings and key words rather than copying every sentence.

A survey collects answers from a group using clear, fair questions. A summary gives the main points in fewer words. It should not add invented information or copy a whole passage.

## Objectives

By the end of the topic, the learner should be able to:

- identify print, oral, visual and digital sources of information;
- explain why a dictionary, atlas, newspaper, textbook, interview or website may be useful for a particular purpose;
- locate books and information in the school library with guidance from the librarian;
- skim a short text to identify its topic and main idea;
- scan a text to locate stated facts and specific details;
- take organised notes using headings and key words;
- prepare clear questions for a class survey or interview;
- summarise a short spoken or written text accurately;
- present simple survey results in sentences or a basic chart;
- distinguish a fact from an unsupported opinion and mention the source used.

## Key terms

**source**, **information**, **library**, **catalogue**, **author**, **title**, **reference book**, **dictionary**, **encyclopedia**, **newspaper**, **periodical**, **website**, **interview**, **survey**, **questionnaire**, **fact**, **opinion**, **skimming**, **scanning**, **keyword**, **heading**, **note**, **summary**, **evidence**.

## Worked reading strategy

Text:

> The school garden provides vegetables for the cooking club. Learners prepare the beds, plant seeds and record rainfall. The garden also gives science learners a place to observe insects and plant growth. In the dry season, the club saves water by covering the soil with dry leaves.

**Skim:** The topic is the uses of a school garden.  
**Scan:** What do learners record? **Rainfall.**  
**Scan:** What protects the soil? **Dry leaves.**  
**Notes:**

- cooking club: vegetables
- science: insects and plant growth
- dry season: save water with dry leaves

**Summary:** “The school garden supplies vegetables and supports science learning. Learners record rainfall and conserve water with dry leaves.”

## Activities and assessment evidence

- **Source sort:** Groups sort cards into books, people, broadcasts, recordings, print media and digital media. For each card they state one question the source could answer.
- **Library walk:** With the librarian, learners locate a fiction book, a reference book and one book about a local or national topic. They record title, author, shelf or catalogue information and one useful fact.
- **Skimming race without competition pressure:** Give a short article with a title and headings. In two minutes learners write the topic and suggest a new title. Discuss which text clues helped.
- **Scanning grid:** Learners find five facts—one name, place, date, number and action—in a short notice or article. They underline the evidence rather than guessing.
- **Survey project:** In groups, choose a safe school topic such as preferred reading materials or ways learners travel to school. Write five neutral questions, ask a small agreed sample, tally responses and present two findings. Do not collect sensitive personal data.
- **Source check:** For one claim, learners answer: “Where did this come from?” and “Is it a fact, an observation or an opinion?”
- **Assessment:** Check whether questions are clear, notes are selective, the summary contains the main points and the presentation distinguishes results from personal opinion.

## Model survey questions

Topic: reading habits in S1

1. Which do you read most often: storybooks, newspapers, textbooks or digital texts?
2. How many days per week do you read outside class?
3. Where do you usually find reading material?
4. What makes a text easy or difficult to understand?
5. Which topic would you like to read about this month?

Avoid questions that pressure learners to reveal private information. Explain that respondents may decline to answer.

## Short review

1. What is the difference between skimming and scanning?  
2. Name two sources that can provide information about local weather.  
3. Write one neutral survey question about library use.  
4. What should a summary contain?  
5. Why should a learner record the source of information?

**Answers:** 1. Skimming finds the general idea; scanning finds a particular detail. 2. Any two suitable sources, such as a weather report and an interview with a local observer. 3. Example: “How often do you use the school library?” 4. The main points in fewer words, without invented details. 5. To show where the information came from and make checking possible.

# Topic 3: Food — 22 periods

**NCDC competency:** The learner discusses food grown in different parts of Uganda and how it can be prepared, expresses likes and dislikes, and appreciates mealtime etiquette. [1]

### Proposed school sequence

1. **Food grown and eaten in Uganda** (about 4 periods)
2. **Recipes, ingredients and preparation steps** (about 6 periods)
3. **Instructions, sequence words and measurements** (about 5 periods)
4. **Countable/uncountable nouns and taste adjectives** (about 4 periods)
5. **Preferences, short and long vowels, and table etiquette** (about 3 periods)

This is a proposed teaching sequence. It moves from familiar food vocabulary to integrated speaking, reading and writing tasks; it does not claim that NCDC has prescribed these exact weekly divisions.

## Learner-friendly explanation

Uganda has many food crops and dishes. What grows in a place can depend on climate, soil, farming practice, markets and culture. Learners should share local knowledge without saying that one community’s food is better than another’s.

A **recipe** tells us the ingredients and steps for preparing food. Instructions often use command verbs: **wash**, **peel**, **cut**, **boil**, **stir**, **serve**. Sequence words make the order clear: **first**, **next**, **then**, **after that**, **finally**.

Some nouns can be counted: **one banana, three tomatoes, two eggs**. Some are usually measured rather than counted one by one: **water, rice, flour, sugar, oil**. We can say **some rice**, **some water**, **any flour**, **two cups of flour**.

## Objectives

By the end of the topic, the learner should be able to:

- name foods grown or commonly eaten in different parts of Uganda;
- read and interpret a short recipe, food article or nutrition passage;
- sequence preparation steps logically;
- give and follow clear instructions;
- use **some** and **any** with suitable countable and uncountable nouns;
- use adjectives such as **sweet, sour, salty, bitter, hot, fresh, delicious** to describe taste;
- use verbs of preference such as **like, enjoy, prefer, dislike**;
- pronounce selected short and long vowel contrasts clearly enough to be understood;
- demonstrate polite asking, accepting and refusing at a meal;
- write a simple recipe with ingredients, quantities, steps and a final check.

## Key terms

**crop**, **ingredient**, **recipe**, **method**, **prepare**, **peel**, **wash**, **cut**, **boil**, **fry**, **stir**, **serve**, **measure**, **quantity**, **countable noun**, **uncountable noun**, **taste**, **sweet**, **sour**, **salty**, **bitter**, **preference**, **etiquette**, **polite**, **vowel**, **sequence**.

## Example recipe and language focus

### Simple fruit salad

**Ingredients:** two bananas, one pineapple slice, three tomatoes only if making a savoury version, some clean water and a little lemon juice.  
**Method:**

1. First, wash the fruit.
2. Next, peel and cut the bananas.
3. Then, cut the pineapple into small pieces.
4. Add a little lemon juice.
5. Finally, mix the pieces and serve safely.

The recipe uses countable nouns (**two bananas**, **one slice**) and an uncountable noun (**some water**, **a little lemon juice**). Learners should adapt the ingredients to locally available food and should not taste food that has not been prepared safely.

### Instructions and sequence

- **First**, wash your hands.
- **Next**, measure the ingredients.
- **Then**, heat the pan with adult supervision where needed.
- **After that**, add the ingredients in the stated order.
- **Finally**, turn off the heat and serve carefully.

### Preferences and etiquette

- “Would you like some matooke?” — “Yes, please.”
- “Would you like more sauce?” — “No, thank you.”
- “I prefer beans to peas.”
- “May I have some water, please?”

Good etiquette includes washing hands where appropriate, waiting one’s turn, asking politely, using utensils or customary eating practices appropriately, avoiding waste and respecting a guest’s food choices. Practices differ between homes and communities, so learners should compare them respectfully.

### Sound practice

Practise short and long vowel pairs with teacher modelling and repetition: **ship/sheep**, **bit/beat**, **full/fool**. Learners listen, hold up a card for the word they hear, then use each word in a sentence. The aim is intelligible pronunciation, not imitation of one particular accent.

## Reading and practical activities

- **Food map discussion:** Learners list foods familiar in their homes and discuss where they may be grown. They should distinguish personal experience from information gathered from a source.
- **Recipe sequencing:** Cut up the steps of a safe, no-cook recipe. Groups put them in order and explain why.
- **Flowchart:** Learners turn a recipe into boxes with arrows. Each box begins with a clear action verb.
- **Instruction listening:** One learner explains a preparation sequence while a partner checks each step on a list and asks for clarification where necessary.
- **Role-play:** A host offers food and a guest accepts or refuses politely. Learners then identify which words showed respect.
- **Taste vocabulary:** Use pictures, descriptions or safe teacher-provided examples rather than forcing tasting. Learners match foods with adjectives and justify their choices.
- **Recipe writing:** Write a recipe for a familiar dish. Include title, ingredients, measurements, numbered steps, sequence words and one safety reminder.
- **Assessment:** Check the logical order of steps, clarity of commands, accurate use of some/any, suitable food vocabulary, polite interaction and understandable pronunciation.

## Short review

1. Put in order: **finally**, **first**, **then**, **next**.  
2. Complete: “There is ___ rice in the bowl.” “Are there ___ bananas?”  
3. Is **three eggs** countable or uncountable? Is **some oil** countable or uncountable?  
4. Write one polite way to refuse more food.  
5. Name three verbs used in a recipe.

**Answers:** 1. *first, next, then, finally*. 2. *some; any*. 3. *Three eggs* is countable; *some oil* is uncountable. 4. “No, thank you.” or another equally polite response. 5. Any three suitable verbs, such as *wash, cut, boil, stir* or *serve*.

# End-of-term integrated task

In groups, learners prepare a **“Healthy and Helpful Home”** display or short presentation. It must include:

1. a fictional or consent-based family profile with a labelled family tree;
2. a short paragraph describing shared responsibilities and preferences;
3. one information source and three notes about a chosen local food;
4. a safe recipe flowchart with sequence words;
5. a two-minute oral presentation in which each learner speaks or has an agreed supporting role.

The teacher may assess communication, listening, reading, writing, organisation, source use, grammar, pronunciation and respectful teamwork. Give feedback on improvement as well as accuracy.

# Teacher preparation and inclusion notes

Use locally familiar names, foods, occupations and settings while avoiding stereotypes. Allow learners who cannot or do not wish to disclose family details to use a fictional family, a supportive group or a community example. Provide word banks, sentence starters, picture cards, paired rehearsal and additional reading time for learners who need them. For learners ready for extension, ask them to compare two sources, write a longer summary or justify a survey conclusion with evidence.

For practical food activities, prioritise hygiene, allergy awareness, safe handling and school rules. A demonstration, picture sequence or dry-food sorting activity can replace cooking. For information activities, teach learners not to copy unknown online claims and not to share personal data.

## References

[1]: https://ncdc.go.ug/wp-content/uploads/2024/02/ENGLISH_SYLLABUS_compressed.pdf "NCDC English Language Syllabus, Lower Secondary Curriculum"

[2]: https://ncdc.go.ug/wp-content/uploads/2024/03/Curriculum_Framework.pdf "NCDC Lower Secondary Curriculum Framework"

[3]: https://ncdc.go.ug/books/s-1-s-2-english/ "NCDC S.1 & S.2 English assessment materials page"
