# Nusu Academy S1 Term 1 Subject Package
## General Science

**Package purpose:** A usable opening-term starter package for Senior One. It follows the three-topic Term 1 sequence shown in the Uganda National Curriculum Development Centre (NCDC) General Science syllabus. The syllabus gives topic period totals, but it does not prescribe every school’s lesson-by-lesson calendar. The weekly order below is therefore a **proposed school sequence** that can be adjusted to the school calendar, learner needs and available equipment.

**Suggested pacing:**

- **Weeks 1–2:** Topic 1 — Introduction to General Science (about 10 periods)
- **Weeks 3–7:** Topic 2 — Hazards and First Aid (about 26 periods)
- **Weeks 8–13:** Topic 3 — Measurements and Density (about 36 periods)
- **Week 14:** Consolidation, practical catch-up and end-of-term review, if the calendar allows.

The supplied S1 timetable shows General Science periods on Wednesday morning, Monday mid-morning and Friday mid-morning. It is used here only as context; the NCDC syllabus remains the curriculum reference.

---

## How to learn General Science

General Science uses ideas and skills from physics, chemistry and biology to explain everyday situations. Science is based on questions, observations, evidence and explanations that can be tested. A scientific explanation may be changed when better evidence becomes available.

In lessons, keep a science notebook. Write the date, question or aim, apparatus, method, observations, results, conclusion and safety precautions. Record measurements with a number and a unit, for example **25 cm**, not simply **25**.

### Term learning goals

By the end of this starter package, a learner should be able to:

1. explain what science, technology, natural science and social science mean;
2. use simple scientific steps to investigate a familiar problem;
3. recognise hazards and safety signs at home, at school and during practical work;
4. explain the purpose and contents of a first-aid box and describe safe first responses;
5. choose suitable instruments and units for common measurements;
6. measure length, mass, time, area and volume and record results clearly;
7. calculate density and use density to make a reasoned prediction about floating or sinking.

These goals reflect the NCDC competency-based approach, which expects active learning, problem solving, communication and use of evidence rather than memorising notes alone. [1] [2]

---

# Topic 1: Introduction to General Science

**NCDC allocation:** 10 periods  
**Theme:** Introduction to General Science  
**Core competency:** The learner understands the meaning of integrated science and why it is important. [2]

## 1.1 What is science?

Science is an organised way of gaining knowledge about the natural world through observation, measurement, questioning, investigation and evidence. It includes both knowledge and processes. A scientific idea should be clear enough to be checked by observation or an investigation.

- **Natural science** studies the natural world. Examples include living things, matter, energy, weather and the human body.
- **Social science** studies people, society and how people live together. Examples include history, geography, economics and political studies.
- **Technology** is the use of knowledge, skills, materials and tools to solve problems or meet human needs. A bicycle, water filter, mobile phone and improved seed are examples of technology.

Science and technology are related but are not the same. Science helps us understand how and why things happen. Technology applies knowledge to design or improve useful products and processes.

## 1.2 Science in daily life

Many ordinary events can be explained scientifically:

- A metal spoon becomes hot in tea because thermal energy moves from the hot tea through the spoon.
- Clothes dry because water changes from liquid to water vapour and moves into the air.
- A bicycle slows when the rider stops pedalling because friction and air resistance oppose motion.
- Salt disappears in water because it dissolves and spreads through the water; it has not simply vanished.
- A seed grows when it has suitable conditions such as water, air and warmth.

A statement such as “the clothes dried faster in the sun than in the shade” is an observation. A possible reason, such as “the sun warmed the clothes and increased evaporation,” is an explanation that can be investigated.

## 1.3 A simple scientific investigation

A useful investigation can follow these steps:

1. **Identify a problem or ask a question.** Example: Does wind make wet cloth dry faster?
2. **Suggest a prediction.** Example: Cloth placed in moving air will dry faster.
3. **Plan a fair test.** Keep the cloth size, amount of water and location as similar as possible. Change only the air movement.
4. **Observe and measure.** Record drying time and any relevant conditions.
5. **Compare results and draw a conclusion.** State whether the evidence supports the prediction.
6. **Communicate and improve.** Report the method, results and any limitation.

A fair test does not mean that every investigation must be perfect. It means that the learner tries to control important conditions and records evidence honestly.

## 1.4 Benefits and misuse of science and technology

Science and technology can improve health, farming, transport, communication, water supply and access to information. They can also cause harm when knowledge or technology is misused. Examples include pollution from careless industrial processes, unsafe use of chemicals, weapons and spreading false information through digital tools.

Responsible scientific thinking asks: What evidence supports this claim? Who may benefit? Who may be harmed? How can the risk be reduced? Scientific knowledge does not remove the need for values, responsibility and good judgement.

## Learning objectives

By the end of the topic, the learner should be able to:

- recall a science idea studied in primary school and connect it to daily life;
- distinguish natural science from social science;
- distinguish science from technology and give examples of their relationship;
- identify daily phenomena that can be explained using scientific knowledge;
- outline simple steps for investigating a community problem;
- discuss useful applications and possible misuse of science and technology;
- communicate an observation, prediction and conclusion in clear sentences.

## Key terms

**Science:** A systematic study of the natural world using evidence.  
**Technology:** The application of knowledge and skills to solve problems or meet needs.  
**Observation:** Information obtained using the senses or instruments.  
**Evidence:** Observations or measurements used to support a conclusion.  
**Prediction:** A statement about what is expected to happen.  
**Investigation:** A planned attempt to answer a question.  
**Natural science:** The study of the natural world.  
**Social science:** The study of people and society.

## Activities

1. In groups, list ten science-related activities seen at home or in the community. Sort them into health, agriculture, transport, communication, energy or environment.
2. Compare a thermometer and a mobile-phone weather application. What does each measure or provide? What evidence would you need to decide whether a reading is reliable?
3. Investigate whether paper, cloth or plastic absorbs the most water. Use equal-sized pieces, the same volume of water and a simple results table.
4. Choose one local problem, such as unsafe drinking water or poor waste disposal. Write the question, a prediction, two observations or measurements needed, and one possible solution.

## Short review

1. State two differences between science and technology.
2. Give one natural-science example and one social-science example.
3. Which is an observation: “the plant is healthy” or “the plant has six green leaves”? Explain.
4. Why should a scientific investigation control important conditions?
5. Give one beneficial and one harmful use of technology.

---

# Topic 2: Hazards and First Aid

**NCDC allocation:** 26 periods  
**Theme:** Science for Health and Safety  
**Core competency:** The learner identifies hazards and devises appropriate methods of preventing hazards at home and at school. [2]

## 2.1 Hazards and risks

A **hazard** is anything that can cause harm. A **risk** is the chance that the hazard will cause harm in a particular situation. For example, a wet floor is a hazard. The risk of slipping is greater when people walk quickly across it without warning.

Common hazards include:

- **Physical:** broken glass, sharp tools, fire, hot liquids, slippery floors and falling objects.
- **Electrical:** bare wires, overloaded sockets, wet hands near electricity and damaged plugs.
- **Chemical:** acids, cleaning products, pesticides and unknown substances.
- **Biological:** contaminated food or water, blood, mould and disease-causing organisms.
- **Environmental:** smoke, poor lighting, noise, extreme heat and unsafe buildings.

A simple hazard check asks: What can cause harm? Who may be harmed? How can the hazard be removed or controlled? Never taste, smell directly or touch an unknown chemical.

## 2.2 Safety signs and prevention

Safety signs communicate danger or required action quickly. Learners should notice the colour, shape, symbol and accompanying words. Examples include:

- a red circle with a line: **prohibited action**;
- a yellow triangle: **warning**;
- a blue circle: **required action**;
- a green sign: **safe condition or first-aid information**.

Local signs may vary in design, so read the symbol and words together. Prevent hazards by keeping walkways clear, storing chemicals in labelled containers, using protective equipment when instructed, reporting damaged equipment, washing hands and following teacher instructions. A safety rule is useful only when it is followed consistently.

## 2.3 First aid

**First aid** is the immediate, temporary care given to an injured or suddenly ill person before qualified medical help is available. Its aims are to preserve life, prevent the condition from becoming worse and promote recovery.

A first-aid box may contain sterile gauze, adhesive plasters, clean bandages, triangular bandages, cotton wool, disposable gloves, antiseptic solution or wipes, scissors, safety pins, a clean cloth, a thermometer and a first-aid guide. Contents should be checked, kept clean, clearly labelled and replaced after use. Medicines should not be given casually; follow school policy and seek an adult or health professional.

### Safe first responses to common injuries

- **Minor cut:** Wash hands or use gloves, apply gentle pressure with clean gauze to control bleeding, rinse a minor wound with clean running water and cover it. Seek help for heavy bleeding, a deep wound or an embedded object.
- **Burn or scald:** Move away from the heat source. Cool the area under clean, cool running water for at least 20 minutes where possible. Remove jewellery or loose clothing near the injury, but do not pull off clothing stuck to the skin. Cover loosely with a sterile non-stick dressing or clean material. Do not apply ice, butter, oil, toothpaste or break blisters.
- **Electric shock:** Do not touch the person while they are still in contact with the electrical source. Switch off the supply if it is safe to do so, or get an adult and emergency help. Check for breathing only when the area is safe.
- **Chemical contact:** Alert the teacher or adult immediately. For skin or eye contact, flush with plenty of clean running water and follow the product or school emergency guidance. Do not neutralise a chemical with another chemical.
- **Fracture or suspected spinal injury:** Keep the person still, support the injured area in the position found and seek urgent medical help. Do not straighten the limb.
- **Fainting:** Lay the person safely on their back, loosen tight clothing, allow fresh air and monitor them. Do not force food or drink into an unconscious person. Seek help if recovery is not prompt or if injury occurred.
- **Bite or sting:** Move away from danger, wash the area and seek medical advice if there is severe swelling, breathing difficulty, a suspected venomous bite or signs of serious illness.

First aid is not a substitute for professional medical care. Tell a teacher, parent, school nurse or other responsible adult and contact emergency services according to local arrangements.

## Learning objectives

By the end of the topic, the learner should be able to:

- define hazard and give examples at home and at school;
- classify common hazards as physical, electrical, chemical, biological or environmental;
- interpret common warning, prohibition, required-action and safe-condition signs;
- suggest precautions that remove or reduce risks;
- define first aid and explain its purposes;
- identify basic contents of a first-aid box and their uses;
- demonstrate or describe safe first responses for a cut, burn, scald, electric shock, fracture, fainting episode, bite and chemical contact;
- explain when to call an adult or seek professional medical help.

## Key terms

**Hazard:** Something that can cause harm.  
**Risk:** The chance that harm will occur.  
**Safety precaution:** An action taken to prevent or reduce harm.  
**First aid:** Immediate temporary care before professional help.  
**Sterile:** Free from living disease-causing organisms.  
**Fracture:** A break or crack in a bone.  
**Scald:** A burn caused by hot liquid or steam.  
**Protective equipment:** Items used to reduce exposure to a hazard.

## Activities

1. Walk around the classroom or school compound in supervised groups. Record five hazards, the possible harm and one control measure for each.
2. Draw and label four safety signs. Explain their meanings and design a poster for safe science lessons.
3. With a teacher, inspect an empty first-aid box or a labelled picture. Match each item to its likely use. Do not handle medicines or practise on an injured person.
4. Role-play a safe response to a minor cut or burn using a mannequin, drawing or clean cloth. The “helper” must first check the scene, call an adult and explain each action.
5. Write a three-sentence emergency message: location, what happened and what help is needed.

## Short review

1. Distinguish a hazard from a risk.
2. Name two electrical hazards and two ways to reduce them.
3. What is the purpose of first aid?
4. Why should butter or ice not be put on a burn?
5. What is the first action when a person may still be connected to electricity?
6. Name four items in a first-aid box and state one use for each.

---

# Topic 3: Measurements and Density

**NCDC allocation:** 36 periods  
**Theme:** Science and Technology  
**Core competency:** The learner estimates and measures length, mass, time, area, volume and density and expresses them in appropriate units. [2]

## 3.1 Why measurement matters

Measurement is the comparison of a quantity with an agreed standard unit. It allows people to communicate results, compare objects, design safely and check whether a prediction is reasonable. An estimate is an informed approximation made before measuring.

Use an instrument that matches the quantity:

- length: ruler or metre rule; **millimetre (mm), centimetre (cm), metre (m)**;
- mass: balance; **gram (g), kilogram (kg)**;
- time: clock or stopwatch; **second (s), minute (min), hour (h)**;
- temperature: thermometer; **degree Celsius (°C)**;
- liquid volume: measuring cylinder; **millilitre (mL), litre (L)**.

Read a scale at eye level where possible. For a liquid in a measuring cylinder, read the bottom of the meniscus at eye level. Record an appropriate unit and avoid reporting more precision than the instrument allows.

## 3.2 Fundamental and derived quantities

A **fundamental quantity** is a basic measurable quantity, such as length, mass or time. A **derived quantity** is obtained by combining quantities. Area is length multiplied by length. Volume is length multiplied by width multiplied by height. Density is mass divided by volume.

For a rectangular object:

- **Area = length × width**
- **Volume = length × width × height**

Use consistent units. A result in cm × cm gives cm². A result in cm × cm × cm gives cm³.

## 3.3 Measuring volume

For a regular block, measure its length, width and height and multiply them. For an irregular object, use water displacement:

1. Put enough water in a measuring cylinder to cover the object.
2. Record the initial volume, **V₁**.
3. Lower the object gently into the water so that it is fully submerged. Avoid splashing and trapped air.
4. Record the final volume, **V₂**.
5. Calculate the object’s volume: **volume = V₂ − V₁**.

Do not use this method with an object that dissolves, reacts dangerously with water or traps water in a way that makes the reading unreliable.

## 3.4 Density

Density describes how much mass is contained in a given volume. The formula is:

> **Density = mass ÷ volume**
>
> **ρ = m / V**

Common units are **g/cm³** and **kg/m³**. A dense material has more mass packed into the same volume than a less dense material. The density of water is approximately **1 g/cm³** under ordinary classroom conditions. An object less dense than water tends to float; an object more dense than water tends to sink, provided other effects such as trapped air are considered.

**Relative density** compares the density of a substance with the density of water. It has no unit:

> **Relative density = density of substance ÷ density of water**

## Worked examples

### Example 1: Area and volume of a block

A block is 8 cm long, 4 cm wide and 3 cm high.

- Area of the top = length × width = 8 cm × 4 cm = **32 cm²**.
- Volume = length × width × height = 8 cm × 4 cm × 3 cm = **96 cm³**.

### Example 2: Density and floating

A block has a mass of 600 g and a volume of 200 cm³.

- Density = mass ÷ volume
- Density = 600 g ÷ 200 cm³
- Density = **3 g/cm³**

Since 3 g/cm³ is greater than the approximate density of water, 1 g/cm³, the block is expected to **sink** in water.

### Example 3: Irregular object

The water level in a cylinder is 50 mL. After a stone is fully submerged, the level is 68 mL.

- Volume of stone = 68 mL − 50 mL = **18 mL**.
- Since 1 mL = 1 cm³, volume = **18 cm³**.

If the stone’s mass is 45 g:

- Density = 45 g ÷ 18 cm³ = **2.5 g/cm³**.
- It is denser than water, so it is expected to sink.

### Example 4: Unit conversion

A rectangular block has a density of 2 g/cm³. Since 1 g/cm³ = 1,000 kg/m³:

- 2 g/cm³ = **2,000 kg/m³**.

Learners should show the unit conversion rather than writing a bare number.

## Learning objectives

By the end of the topic, the learner should be able to:

- explain why measurement is important;
- identify fundamental quantities and suitable measuring instruments;
- estimate and measure length, mass, time, area, volume and temperature;
- select and write appropriate units;
- calculate the area and volume of regular objects;
- determine the volume of an irregular object by displacement;
- define density and solve simple density problems;
- determine the density of a solid or liquid using measurements;
- relate density to floating and sinking;
- record measurements with sensible precision and communicate results in a table or short report.

## Key terms

**Measurement:** Comparison with an agreed standard unit.  
**Estimate:** A reasoned approximation.  
**Quantity:** Something that can be measured.  
**Unit:** An agreed standard used for measurement.  
**Mass:** The amount of matter in an object.  
**Volume:** The space occupied by an object or substance.  
**Density:** Mass per unit volume.  
**Meniscus:** The curved surface of a liquid in a container.  
**Displacement:** The rise in liquid level caused by a submerged object.  
**Relative density:** Density compared with the density of water.

## Practical activities

1. Measure the length, width and thickness of a desk. Calculate its top area and compare estimates with actual measurements.
2. Measure the time taken by a partner to walk 20 paces. Repeat the measurement and discuss why repeated results may differ.
3. Measure the mass of safe classroom objects using a balance. Arrange them from least to greatest mass.
4. Determine the volume of a regular block and an irregular stone by displacement. Draw the measuring cylinder and label **V₁**, **V₂** and the displaced volume.
5. Measure equal volumes of water, cooking oil and another safe liquid if available. Compare their masses and discuss which liquid is denser. Clean spills immediately.
6. Test safe objects such as a cork, plastic piece, wood, glass marble or stone in water. Predict first, then observe whether each floats or sinks. Explain using density and evidence.

## Short review

1. Name the instrument and unit you would use to measure the mass of a pen.
2. A desk is 120 cm long and 50 cm wide. What is its top area?
3. A stone raises the water level from 35 mL to 47 mL. What is its volume in mL and cm³?
4. A sample has mass 150 g and volume 50 cm³. Calculate its density.
5. Why should a measuring cylinder be read at eye level?
6. A material has density 0.8 g/cm³. Predict whether it floats or sinks in water and explain.
7. State one difference between mass and volume.

---

# End-of-term consolidation task

Work in groups to prepare a one-page **“Safe and Measurable School”** report. Include:

1. a labelled sketch of three hazards in or near the classroom and a control measure for each;
2. a first-aid response flow for one minor injury, including when to call an adult;
3. a table of three objects showing estimated length or mass, measured value, unit and an observation;
4. one density calculation using your own measurements;
5. a short conclusion explaining how evidence helped your group make a decision.

The teacher can assess scientific vocabulary, safe conduct, choice of instrument, accuracy of recording, calculation, teamwork and clarity of communication. This combines the NCDC emphasis on learning outcomes, suggested activities and formative assessment rather than relying only on a recall test. [2]

## References

[1]: https://ncdc.go.ug/wp-content/uploads/2024/03/Curriculum_Framework.pdf "Uganda NCDC Lower Secondary Curriculum Framework"

[2]: https://ncdc.go.ug/wp-content/uploads/2024/02/GENERAL-SCIENCE-syllabus.pdf "Uganda NCDC General Science Syllabus"

[3]: https://ncdc.go.ug/lower-secondary-curriculum-embraced/ "NCDC Lower Secondary Curriculum Embraced"

## Context file used

The supplied timetable ZIP was consulted only for S1 pacing context: `/home/ubuntu/upload/realtimetable.zip` (S1 timetable entry). It is not an authoritative curriculum source and does not establish topic order.
