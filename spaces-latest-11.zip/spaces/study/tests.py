from django.contrib.auth import get_user_model
from django.test import TestCase
from django.urls import reverse

from .models import StudyResource, StudyUnit


class GlobalCurriculumTests(TestCase):
    def setUp(self):
        User = get_user_model()
        self.teacher = User.objects.create_user(username='independent-teacher', email='independent-teacher@example.invalid', password='test-password')
        self.learner = User.objects.create_user(username='learner', email='learner@example.invalid', password='test-password')

    def make_resource(self, *, access_level='public', members_only=False):
        return StudyResource.objects.create(
            title='S1 Mathematics Term 1',
            description='Public Senior One Mathematics notes.',
            resource_type='text',
            content='Curriculum notes.',
            creator=self.teacher,
            institution=None,
            access_level=access_level,
            access_cost=0,
            members_only=members_only,
            is_approved=True,
        )

    def create_root(self, resource):
        self.client.force_login(self.teacher)
        response = self.client.post(reverse('study:curriculum_root_create', kwargs={'resource_id': resource.pk}), secure=True)
        self.assertEqual(response.status_code, 302)
        resource.refresh_from_db()
        self.assertIsNotNone(resource.study_unit_id)
        return resource.study_unit

    def test_independent_creator_can_create_global_root(self):
        resource = self.make_resource()
        root = self.create_root(resource)
        self.assertIsNone(root.institution_id)
        self.assertEqual(root.created_by_id, self.teacher.id)
        self.assertFalse(root.is_published)

    def test_public_global_root_is_visible_only_after_publication(self):
        resource = self.make_resource()
        root = self.create_root(resource)
        path = reverse('study:curriculum_unit', kwargs={'pk': root.pk})
        self.client.force_login(self.learner)
        self.assertGreaterEqual(self.client.get(path, secure=True).status_code, 400)
        root.is_published = True
        root.save(update_fields=['is_published'])
        self.assertEqual(self.client.get(path, secure=True).status_code, 200)

    def test_private_global_root_is_not_visible_to_other_users(self):
        resource = self.make_resource(access_level='private')
        root = self.create_root(resource)
        root.is_published = True
        root.save(update_fields=['is_published'])
        self.client.force_login(self.learner)
        response = self.client.get(reverse('study:curriculum_unit', kwargs={'pk': root.pk}), secure=True)
        self.assertGreaterEqual(response.status_code, 400)

    def test_published_public_global_root_appears_in_study_path(self):
        resource = self.make_resource()
        root = self.create_root(resource)
        root.is_published = True
        root.save(update_fields=['is_published'])
        self.client.force_login(self.learner)
        response = self.client.get(reverse('study:study_path'), secure=True)
        self.assertEqual(response.status_code, 200)
        self.assertIn((root, 0), response.context['unit_rows'])
