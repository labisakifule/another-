import math
from django.core.management.base import BaseCommand, CommandError
from django.db import transaction
from django.contrib.auth import get_user_model
from study.models import StudyUnit
from trends.models import Institution, EducationLevel, Subject, Topic

SUBJECT_PERIODS = {
    'English': {'Listening and Speaking': 24, 'Reading and Writing': 26, 'Grammar and Language Use': 22},
    'Mathematics': {'Number Concepts and Operations': 15, 'Algebra': 15, 'Geometry': 15, 'Data and Probability': 15},
    'Biology': {'Introduction to Biology': 8, 'Cells': 20, 'Nutrition': 8},
    'Physics': {'Introduction to Physics': 6, 'Measurement': 30},
    'Chemistry': {'Chemistry and Society': 6, 'Experimental Chemistry': 8, 'States and Changes of State of Matter': 8, 'Temporary and Permanent Changes': 6, 'Mixtures, Elements and Compounds': 8},
    'Geography': {'Map Reading': 4, 'Weather': 3, 'The Earth and Its Movements': 6, 'Fieldwork': 7},
    'History': {'Introduction to History': 8, 'The Early Peoples of East Africa': 10, 'The Coming of Foreigners': 10},
    'Christian Religious Education': {'The Bible': 8, 'Creation and Human Responsibility': 8, 'The Call to Faith': 8},
    'Islamic Religious Education': {'The Quran and Hadith': 8, 'Faith and Worship': 8, 'Moral Conduct': 8},
}

class Command(BaseCommand):
    help = 'Create the reusable S1 Term 1 Study period skeleton without creating lesson notes.'

    def add_arguments(self, parser):
        parser.add_argument('--institution', default='Nusu Academy')
        parser.add_argument('--creator', default='kasoma')
        parser.add_argument('--level', default='Senior One')
        parser.add_argument('--term', default='Term 1')
        parser.add_argument('--publish', action='store_true')
        parser.add_argument('--dry-run', action='store_true')
        parser.add_argument('--list-levels', action='store_true', help='List existing level labels and stop.')

    @transaction.atomic
    def handle(self, *args, **opts):
        institution = Institution.objects.filter(name__iexact=opts['institution']).first()
        if not institution:
            raise CommandError(f"Institution not found: {opts['institution']}")
        if opts['list_levels']:
            for row in EducationLevel.objects.filter(institution_level=institution).order_by('order', 'name'):
                self.stdout.write(f'{row.id}\t{row.name}')
            return
        creator = get_user_model().objects.filter(username__iexact=opts['creator']).first()
        if not creator:
            raise CommandError(f"Creator not found: {opts['creator']}")
        level = EducationLevel.objects.filter(institution_level=institution, name__iexact=opts['level']).first()
        if not level:
            level = EducationLevel.objects.filter(name__iexact=opts['level']).first()
        if not level:
            normalized = opts['level'].lower().replace('.', '').replace('-', ' ').strip()
            aliases = {
                'senior one': ['s1', 's 1', 'senior 1', 'level 1', 'level one', 'form 1', 'form one'],
                's1': ['s1', 's 1', 'senior 1', 'senior one', 'level 1', 'level one', 'form 1', 'form one'],
            }.get(normalized, [normalized])
            candidates = EducationLevel.objects.filter(institution_level=institution)
            if not candidates.exists():
                candidates = EducationLevel.objects.all()
            for candidate in candidates:
                candidate_name = candidate.name.lower().replace('.', '').replace('-', ' ').strip()
                if candidate_name in aliases:
                    level = candidate
                    break
        if not level:
            available = ', '.join(EducationLevel.objects.filter(institution_level=institution).values_list('name', flat=True)) or '(none)'
            raise CommandError(f"Education level not found: {opts['level']}. Available for {institution.name}: {available}. Use --list-levels.")
        created = updated = 0
        for subject_name, topics in SUBJECT_PERIODS.items():
            subject = Subject.objects.filter(name__iexact=subject_name, institution=institution, education_level=level).first()
            if not subject:
                subject = Subject.objects.filter(name__iexact=subject_name, institution=institution).first()
            if not subject:
                self.stdout.write(self.style.WARNING(f'Skipping missing subject: {subject_name}'))
                continue
            for topic_name, period_count in topics.items():
                topic = Topic.objects.filter(subject=subject, name__icontains=topic_name).first()
                if not topic:
                    topic = Topic.objects.filter(subject=subject, name__icontains=topic_name.split()[0]).first()
                if not topic:
                    self.stdout.write(self.style.WARNING(f'Skipping missing topic: {subject_name} / {topic_name}'))
                    continue
                parent, was_created = StudyUnit.objects.get_or_create(
                    institution=institution, education_level=level, subject=subject,
                    topic=topic, parent=None, term=opts['term'],
                    defaults={'title': topic.name, 'template_type': 'traditional', 'created_by': creator, 'is_published': opts['publish']},
                )
                if was_created: created += 1
                else:
                    changed = False
                    if parent.created_by_id != creator.id: parent.created_by = creator; changed = True
                    if opts['publish'] and not parent.is_published: parent.is_published = True; changed = True
                    if changed: parent.save(update_fields=['created_by', 'is_published', 'updated_at']); updated += 1
                if not opts['dry_run']:
                    for number in range(1, period_count + 1):
                        _, made = StudyUnit.objects.get_or_create(
                            institution=institution, education_level=level, subject=subject,
                            topic=topic, parent=parent, term=opts['term'], period_number=number,
                            defaults={'title': f'Period {number}', 'template_type': 'traditional', 'dependency_required': number > 1, 'created_by': creator, 'is_published': opts['publish']},
                        )
                        if made: created += 1
                else:
                    created += period_count
        self.stdout.write(self.style.SUCCESS(f'S1 skeleton complete: {created} units planned/created, {updated} parents updated. Existing notes were not changed.'))
