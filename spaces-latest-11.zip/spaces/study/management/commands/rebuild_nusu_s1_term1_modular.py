from pathlib import Path

from django.conf import settings
from django.core.management import call_command
from django.core.management.base import BaseCommand, CommandError
from django.db import transaction

from study.models import StudyResource, StudyUnit
from trends.models import EducationLevel, Institution, User
from study.management.commands.import_nusu_s1_term1_notes import SUBJECTS


class Command(BaseCommand):
    help = (
        'Replace Nusu Academy S1 Term 1 Study materials and rebuild them as '
        'editable subject/topic/subtopic/period threads.'
    )

    def add_arguments(self, parser):
        parser.add_argument('--institution', default='Nusu Academy')
        parser.add_argument('--created-by', default='kasoma')
        parser.add_argument('--notes-dir', default='')
        parser.add_argument('--dry-run', action='store_true')
        parser.add_argument(
            '--replace', action='store_true',
            help='Delete the existing Nusu S1 Term 1 materials before rebuilding.',
        )

    @transaction.atomic
    def handle(self, *args, **options):
        institution = Institution.objects.filter(name__iexact=options['institution']).first()
        creator = User.objects.filter(username__iexact=options['created_by']).first()
        if not institution:
            raise CommandError(f"Institution not found: {options['institution']}")
        if not creator:
            raise CommandError(f"Creator user not found: {options['created_by']}")

        level = EducationLevel.objects.filter(
            institution_level=institution, name__iexact='S1'
        ).first()
        if not level:
            level = EducationLevel.objects.filter(
                institution_level=institution, name__icontains='Senior One'
            ).first()
        if not level:
            raise CommandError('Nusu Academy institution-owned S1 level was not found.')

        notes_dir = Path(options['notes_dir'] or (Path(settings.BASE_DIR) / 'study' / 'data' / 'nusu_s1_term1'))
        for filename in SUBJECTS:
            if not (notes_dir / filename).exists():
                raise CommandError(f'Missing subject note file: {notes_dir / filename}')

        old_resource_ids = list(StudyResource.objects.filter(
            institution=institution,
            education_level=level,
            subjects__education_level=level,
            subjects__name__in=list(SUBJECTS.values()),
        ).distinct().values_list('pk', flat=True))
        old_resources = StudyResource.objects.filter(pk__in=old_resource_ids)
        old_units = StudyUnit.objects.filter(
            institution=institution, education_level=level, term='Term 1',
        )
        self.stdout.write(
            f'Found {len(old_resource_ids)} Nusu S1 resources and {old_units.count()} curriculum items.'
        )

        if not options['replace']:
            raise CommandError(
                'Refusing to delete existing Nusu materials. Re-run with --replace '
                'after reviewing the preview.'
            )

        if options['dry_run']:
            self.stdout.write(self.style.WARNING('Dry run: no database changes will be committed.'))
            transaction.set_rollback(True)
            return

        old_resources.delete()
        old_units.delete()

        call_command(
            'import_nusu_s1_term1_notes',
            institution=institution.name,
            created_by=creator.username,
            notes_dir=str(notes_dir),
        )

        # Nusu's prepared notes are institution-only: accepted members,
        # their creator, and authorized administrators can access them.
        StudyResource.objects.filter(
            institution=institution, education_level=level,
            subjects__name__in=list(SUBJECTS.values()),
        ).update(access_level='institutional', members_only=True, is_approved=True)

        call_command(
            'build_nusu_s1_term1_threads',
            institution=institution.name,
            created_by=creator.username,
            notes_dir=str(notes_dir),
        )

        self.stdout.write(self.style.SUCCESS(
            'Nusu S1 Term 1 materials were rebuilt as modular Study threads. '
            'Each subject now contains editable topics, nested subtopics, and periods.'
        ))
