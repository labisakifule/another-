from django.core.management.base import BaseCommand
from study.models import StudyResource
from trends.models import Institution, Profile
import cloudinary.uploader
import os

class Command(BaseCommand):
    help = 'Migrate existing local media files to Cloudinary'

    def handle(self, *args, **options):
        # Migrate study resource files
        resources = StudyResource.objects.exclude(file='')
        for resource in resources:
            if resource.file and not hasattr(resource.file, 'public_id'):
                try:
                    result = cloudinary.uploader.upload(
                        resource.file.path,
                        folder='study_resources/',
                        resource_type='auto',
                        public_id=f"resource_{resource.id}",
                        overwrite=True
                    )
                    resource.file = result['public_id']
                    resource.save()
                    self.stdout.write(self.style.SUCCESS(f"✓ Migrated resource {resource.id}"))
                except Exception as e:
                    self.stdout.write(self.style.ERROR(f"✗ Failed resource {resource.id}: {e}"))

        # Migrate thumbnails
        resources = StudyResource.objects.exclude(thumbnail='')
        for resource in resources:
            if resource.thumbnail and not hasattr(resource.thumbnail, 'public_id'):
                try:
                    result = cloudinary.uploader.upload(
                        resource.thumbnail.path,
                        folder='resource_thumbnails/',
                        public_id=f"thumb_{resource.id}",
                        overwrite=True,
                        transformation=[
                            {'width': 400, 'height': 300, 'crop': 'fill'},
                            {'quality': 'auto'},
                            {'fetch_format': 'auto'}
                        ]
                    )
                    resource.thumbnail = result['public_id']
                    resource.save()
                    self.stdout.write(self.style.SUCCESS(f"✓ Migrated thumbnail for resource {resource.id}"))
                except Exception as e:
                    self.stdout.write(self.style.ERROR(f"✗ Failed thumbnail {resource.id}: {e}"))

        # Migrate institution logos
        institutions = Institution.objects.exclude(logo='')
        for institution in institutions:
            if institution.logo and not hasattr(institution.logo, 'public_id'):
                try:
                    result = cloudinary.uploader.upload(
                        institution.logo.path,
                        folder='institution_logos/',
                        public_id=f"logo_{institution.id}",
                        overwrite=True,
                        transformation=[
                            {'width': 200, 'height': 200, 'crop': 'fill', 'gravity': 'auto'},
                            {'quality': 'auto'},
                            {'fetch_format': 'auto'}
                        ]
                    )
                    institution.logo = result['public_id']
                    institution.save()
                    self.stdout.write(self.style.SUCCESS(f"✓ Migrated logo for institution {institution.id}"))
                except Exception as e:
                    self.stdout.write(self.style.ERROR(f"✗ Failed logo {institution.id}: {e}"))

        # Migrate institution banners
        institutions = Institution.objects.exclude(banner='')
        for institution in institutions:
            if institution.banner and not hasattr(institution.banner, 'public_id'):
                try:
                    result = cloudinary.uploader.upload(
                        institution.banner.path,
                        folder='institution_banners/',
                        public_id=f"banner_{institution.id}",
                        overwrite=True,
                        transformation=[
                            {'width': 1200, 'height': 300, 'crop': 'fill'},
                            {'quality': 'auto'},
                            {'fetch_format': 'auto'}
                        ]
                    )
                    institution.banner = result['public_id']
                    institution.save()
                    self.stdout.write(self.style.SUCCESS(f"✓ Migrated banner for institution {institution.id}"))
                except Exception as e:
                    self.stdout.write(self.style.ERROR(f"✗ Failed banner {institution.id}: {e}"))

        # Migrate profile pictures
        profiles = Profile.objects.exclude(profile_picture='')
        for profile in profiles:
            if profile.profile_picture and not hasattr(profile.profile_picture, 'public_id'):
                try:
                    result = cloudinary.uploader.upload(
                        profile.profile_picture.path,
                        folder='profile_pictures/',
                        public_id=f"profile_{profile.user.id}",
                        overwrite=True,
                        transformation=[
                            {'width': 300, 'height': 300, 'crop': 'fill', 'gravity': 'face'},
                            {'quality': 'auto'},
                            {'fetch_format': 'auto'}
                        ]
                    )
                    profile.profile_picture = result['public_id']
                    profile.save()
                    self.stdout.write(self.style.SUCCESS(f"✓ Migrated profile picture for user {profile.user.id}"))
                except Exception as e:
                    self.stdout.write(self.style.ERROR(f"✗ Failed profile picture {profile.user.id}: {e}"))

        self.stdout.write(self.style.SUCCESS('Cloudinary migration complete!'))