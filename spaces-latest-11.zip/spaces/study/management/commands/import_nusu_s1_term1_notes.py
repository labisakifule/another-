from pathlib import Path
import re
from django.conf import settings
from django.core.management.base import BaseCommand, CommandError
from django.db import transaction
from django.utils.html import escape
from trends.models import Institution, EducationLevel, Subject, Topic, User
from study.models import StudyResource

SUBJECTS = {
    '01-mathematics.md': 'Mathematics',
    '02-english.md': 'English',
    '03-biology.md': 'Biology',
    '04-chemistry.md': 'Chemistry',
    '05-physics.md': 'Physics',
    '06-geography.md': 'Geography',
    '07-history-political-education.md': 'History and Political Education',
    '08-general-science.md': 'General Science',
    '09-physical-education.md': 'Physical Education',
}


def markdown_to_html(markdown):
    """Small dependency-free renderer for headings, paragraphs, lists and emphasis."""
    lines = markdown.replace('\r\n', '\n').split('\n')
    output, paragraph, in_list = [], [], False

    def flush_paragraph():
        if paragraph:
            text = ' '.join(x.strip() for x in paragraph).strip()
            text = re.sub(r'\*\*(.+?)\*\*', r'<strong>\1</strong>', escape(text))
            text = re.sub(r'`(.+?)`', r'<code>\1</code>', text)
            output.append(f'<p>{text}</p>')
            paragraph.clear()

    def close_list():
        nonlocal in_list
        if in_list:
            output.append('</ul>')
            in_list = False

    for raw in lines:
        line = raw.strip()
        if not line:
            flush_paragraph(); close_list(); continue
        if line.startswith('```'):
            flush_paragraph(); close_list(); continue
        heading = re.match(r'^(#{1,4})\s+(.+)$', line)
        if heading:
            flush_paragraph(); close_list()
            level = min(len(heading.group(1)) + 1, 6)
            output.append(f'<h{level}>{escape(heading.group(2))}</h{level}>')
            continue
        item = re.match(r'^[-*]\s+(.+)$', line)
        if item:
            flush_paragraph()
            if not in_list:
                output.append('<ul>'); in_list = True
            value = re.sub(r'\*\*(.+?)\*\*', r'<strong>\1</strong>', escape(item.group(1)))
            output.append(f'<li>{value}</li>')
            continue
        if re.match(r'^\|.*\|$', line) or re.match(r'^[-:| ]+$', line):
            flush_paragraph(); close_list(); continue
        close_list(); paragraph.append(line)
    flush_paragraph(); close_list()
    return '\n'.join(output)


class Command(BaseCommand):
    help = 'Import the prepared Nusu Academy S1 Term 1 starter notes as Study Materials.'

    def add_arguments(self, parser):
        parser.add_argument('--institution', default='Nusu Academy')
        parser.add_argument('--created-by', default='kasoma')
        parser.add_argument('--notes-dir', default='')
        parser.add_argument('--dry-run', action='store_true')

    @transaction.atomic
    def handle(self, *args, **options):
        institution = Institution.objects.filter(name__iexact=options['institution']).first()
        if not institution:
            raise CommandError(f"Institution not found: {options['institution']}")
        creator = User.objects.filter(username__iexact=options['created_by']).first()
        if not creator:
            raise CommandError(f"Creator user not found: {options['created_by']}")
        notes_dir = Path(options['notes_dir'] or (Path(settings.BASE_DIR) / 'study' / 'data' / 'nusu_s1_term1'))
        if not notes_dir.is_dir():
            raise CommandError(f'Notes directory does not exist: {notes_dir}')
        level = EducationLevel.objects.filter(institution_level=institution, name__iexact='S1').first()
        if not level:
            level = EducationLevel.objects.filter(institution_level=institution, name__icontains='Senior One').first()
        if not level:
            raise CommandError('S1 education level was not found for the institution.')

        created = updated = 0
        for filename, subject_name in SUBJECTS.items():
            path = notes_dir / filename
            if not path.exists():
                raise CommandError(f'Missing subject note file: {path}')
            subject = Subject.objects.filter(education_level=level, name__iexact=subject_name).first()
            if not subject:
                raise CommandError(f'Subject not found for S1: {subject_name}')
            raw = path.read_text(encoding='utf-8')
            title = f'S1 Term 1 — {subject_name} Starter Notes'
            topic_names = re.findall(r'^## Topic[^:]*:\s*(.+?)(?:\s+—.*)?$', raw, flags=re.MULTILINE)
            topics = []
            for order, topic_name in enumerate(topic_names, start=1):
                topic_name = topic_name.strip().rstrip('#').strip()
                topic, _ = Topic.objects.get_or_create(subject=subject, name=topic_name, defaults={'order': order, 'created_by': creator, 'is_approved': True})
                topics.append(topic)
            resource, was_created = StudyResource.objects.get_or_create(
                title=title, creator=creator, institution=institution,
                defaults={'description': f'Nusu Academy S1 Term 1 starter notes for {subject_name}. Prepared by Kasoma for institutional review.', 'resource_type': 'text', 'content': markdown_to_html(raw), 'education_level': level, 'is_approved': False, 'members_only': True}
            )
            if not was_created:
                resource.description = f'Nusu Academy S1 Term 1 starter notes for {subject_name}. Prepared by Kasoma for institutional review.'
                resource.content = markdown_to_html(raw)
                resource.resource_type = 'text'
                resource.education_level = level
                resource.members_only = True
                resource.is_approved = False
                resource.save(update_fields=['description', 'content', 'resource_type', 'education_level', 'members_only', 'is_approved'])
                updated += 1
            else:
                created += 1
            resource.subjects.set([subject])
            resource.topics.set(topics)

        self.stdout.write(self.style.SUCCESS(f'Prepared {created} new and updated {updated} S1 Term 1 Study Materials for {institution.name}.'))
        self.stdout.write('They remain institution-only and pending approval for review by the Nusu Academy administrator.')
        if options['dry_run']:
            transaction.set_rollback(True)
            self.stdout.write('Dry run only: no database records were changed.')
