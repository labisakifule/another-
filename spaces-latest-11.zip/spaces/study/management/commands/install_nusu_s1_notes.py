import json
from pathlib import Path

from django.contrib.auth import get_user_model
from django.core.management.base import BaseCommand, CommandError
from django.db import transaction
from django.db.models import Q
from django.conf import settings

from study.models import StudyResource
from trends.models import EducationLevel, Institution, Subject, Topic


LEVEL_NAMES = ('Senior One (S1)', 'Senior One', 'Senior 1', 'S1')
SYSTEM_NAME = 'Uganda lower secondary curriculum'


class Command(BaseCommand):
    help = 'Install the NUSU Academy Senior One Term 1 notes as public Study resources.'

    def add_arguments(self, parser):
        parser.add_argument('--institution', default='Nusu Academy')
        parser.add_argument('--creator', default='kasoma', help='Username of the staff account to own the notes.')
        parser.add_argument(
            '--notes-dir',
            default=str(Path(settings.BASE_DIR) / 'nusu_notes_data'),
            help='Directory containing manifest.json and html/.',
        )
        parser.add_argument('--dry-run', action='store_true', help='Validate all records without saving anything.')

    def handle(self, *args, **options):
        notes_dir = Path(options['notes_dir']).expanduser().resolve()
        manifest_path = notes_dir / 'manifest.json'
        if not manifest_path.is_file():
            raise CommandError(f'Notes manifest not found: {manifest_path}')
        try:
            manifest = json.loads(manifest_path.read_text(encoding='utf-8'))
        except (OSError, json.JSONDecodeError) as exc:
            raise CommandError(f'Could not read notes manifest: {exc}')

        institution = Institution.objects.filter(name__iexact=options['institution']).first()
        if institution is None:
            raise CommandError(f'Institution not found: {options["institution"]}')

        User = get_user_model()
        creator = User.objects.filter(username__iexact=options['creator']).first()
        if creator is None:
            raise CommandError(f'Creator account not found: {options["creator"]}')

        items = manifest.get('items')
        if not isinstance(items, list) or len(items) != 9:
            raise CommandError('Expected exactly nine notes in the package manifest.')

        prepared = []
        for item in items:
            subject_name = item.get('subject', '').strip()
            subject = self._find_s1_subject(subject_name, institution)
            if subject is None:
                raise CommandError(
                    f'Senior One subject not found: {subject_name}. '
                    'Seed/check NUSU Academy curriculum subjects before installing notes.'
                )

            html_path = notes_dir / 'html' / item.get('html', '')
            if not html_path.is_file():
                raise CommandError(f'Rendered note content is missing: {html_path}')
            content = html_path.read_text(encoding='utf-8').strip()
            if not content:
                raise CommandError(f'Note content is empty: {html_path}')

            topics = []
            for topic_name in item.get('topics', []):
                topic = Topic.objects.filter(subject=subject, name__iexact=topic_name).first()
                if topic is None:
                    raise CommandError(
                        f'Topic not found under {subject_name}: {topic_name}. '
                        'Seed/check the NUSU curriculum topics before installing notes.'
                    )
                topics.append(topic)

            prepared.append({
                'item': item,
                'subject': subject,
                'topics': topics,
                'content': content,
            })

        if options['dry_run']:
            self.stdout.write(self.style.SUCCESS(
                f'Dry run passed: {len(prepared)} notes, institution={institution.name}, '
                f'creator={creator.get_username()}. Nothing was saved.'
            ))
            return

        created_count = 0
        updated_count = 0
        with transaction.atomic():
            for entry in prepared:
                item = entry['item']
                matches = StudyResource.objects.filter(
                    title=item['title'],
                    institution=institution,
                    creator=creator,
                )
                if matches.count() > 1:
                    raise CommandError(f'Multiple existing resources match this package title: {item["title"]}')
                resource = matches.first()
                created = resource is None
                if created:
                    resource = StudyResource(
                        title=item['title'],
                        creator=creator,
                        institution=institution,
                    )

                resource.title = item['title']
                resource.description = item['description']
                resource.resource_type = 'text'
                resource.content = entry['content']
                resource.education_level = entry['subject'].education_level
                resource.access_level = 'public'
                resource.access_cost = 0
                resource.members_only = False
                resource.is_approved = True
                resource.save()
                resource.subjects.set([entry['subject']])
                resource.topics.set(entry['topics'])

                if created:
                    created_count += 1
                else:
                    updated_count += 1

        self.stdout.write(self.style.SUCCESS(
            f'Installed {created_count} new and updated {updated_count} existing public notes '
            f'for {institution.name}, owned by {creator.get_username()}.'
        ))
        self.stdout.write(
            'Public settings: access_level=public, members_only=False, is_approved=True, access_cost=0.'
        )

    @staticmethod
    def _find_s1_subject(subject_name, institution):
        candidates = list(
            Subject.objects.select_related('education_level', 'education_level__system')
            .filter(name__iexact=subject_name, education_level__name__in=LEVEL_NAMES)
            .filter(Q(institution__isnull=True) | Q(institution=institution))
        )
        if not candidates:
            return None

        def score(subject):
            value = 0
            system = getattr(subject.education_level, 'system', None)
            if system and system.name.casefold() == SYSTEM_NAME.casefold():
                value += 5
            if subject.institution_id == institution.id:
                value += 10
            if subject.education_level.institution_level_id == institution.id:
                value += 20
            if subject.is_approved:
                value += 1
            return value

        candidates.sort(key=score, reverse=True)
        if len(candidates) > 1 and score(candidates[0]) == score(candidates[1]):
            raise CommandError(
                f'Multiple equally suitable Senior One subjects named {subject_name!r} were found; '
                'resolve the duplicate curriculum records before installation.'
            )
        return candidates[0]
