from django.core.management.base import BaseCommand, CommandError
from django.db import transaction

from study.management.commands.import_nusu_s1_term1_notes import SUBJECTS
from study.models import StudyResource
from trends.models import EducationLevel, Institution


class Command(BaseCommand):
    help = 'Make Nusu Academy S1 Term 1 Study materials institution-only.'

    def add_arguments(self, parser):
        parser.add_argument('--institution', default='Nusu Academy')
        parser.add_argument('--dry-run', action='store_true')

    @transaction.atomic
    def handle(self, *args, **options):
        institution = Institution.objects.filter(name__iexact=options['institution']).first()
        if not institution:
            raise CommandError(f"Institution not found: {options['institution']}")
        level = EducationLevel.objects.filter(
            institution_level=institution, name__iexact='S1'
        ).first() or EducationLevel.objects.filter(
            institution_level=institution, name__icontains='Senior One'
        ).first()
        if not level:
            raise CommandError('Nusu Academy institution-owned S1 level was not found.')

        resource_ids = list(StudyResource.objects.filter(
            institution=institution,
            education_level=level,
            subjects__education_level=level,
            subjects__name__in=list(SUBJECTS.values()),
        ).distinct().values_list('pk', flat=True))
        count = len(resource_ids)
        self.stdout.write(f'Found {count} Nusu S1 Study resources.')
        if options['dry_run']:
            transaction.set_rollback(True)
            self.stdout.write(self.style.WARNING('Dry run: no visibility changes were saved.'))
            return

        updated = StudyResource.objects.filter(pk__in=resource_ids).update(
            access_level='institutional',
            members_only=True,
            is_approved=True,
        )
        self.stdout.write(self.style.SUCCESS(
            f'Locked {updated} Nusu S1 resources to accepted Nusu Academy members, creators, and authorized administrators.'
        ))
