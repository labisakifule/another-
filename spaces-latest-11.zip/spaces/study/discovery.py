
import logging

from django.db.models import Q, Count

from core.models import RecommendationEvent
from core.services.recommendations import (
    rank_items,
    record_event,
    record_search,
)
from .models import StudyResource
from trends.access import accepted_institution_ids, is_institution_member, is_creator_member

logger = logging.getLogger(__name__)


def resource_metadata(resource):
    """
    Convert a StudyResource into universal recommendation metadata.
    """
    education_level = getattr(
        resource.education_level,
        'name',
        '',
    )

    education_system = ''
    education_stage = ''

    if resource.education_level:
        system = getattr(
            resource.education_level,
            'system',
            None,
        )

        education_system = getattr(
            system,
            'name',
            '',
        )

        education_stage = getattr(
            resource.education_level,
            'level_type',
            '',
        )

    subjects = list(
        resource.subjects.values_list(
            'name',
            flat=True,
        )
    )

    topics = list(
        resource.topics.values_list(
            'name',
            flat=True,
        )
    )

    subject_text = ', '.join(subjects)
    topic_text = ', '.join(topics)

    popularity_score = min(
        15,
        max(
            0,
            int(resource.view_count or 0),
        ),
    )

    return {
        'id': str(resource.id),
        'title': resource.title,
        'description': resource.description,
        'source_app': 'spaces',
        'content_type': 'study_resource',
        'education_system': education_system,
        'education_stage': education_stage,
        'education_level': education_level,
        'subject': subject_text,
        'subject_or_course_unit': subject_text,
        'topic': topic_text,
        'popularity_score': popularity_score,
        'created_at': resource.created_at.isoformat() if resource.created_at else None,
    }


def apply_resource_recommendation(resource, metadata):
    """
    Attach recommendation information to the object without saving
    extra fields to the database.
    """
    resource.recommendation_score = metadata.get(
        'recommendation_score',
        0,
    )

    resource.recommendation_reasons = metadata.get(
        'recommendation_reasons',
        [],
    )

    return resource


def _has_learning_context(user):
    profile = getattr(user, 'profile', None)
    if not profile:
        return False
    return bool(
        getattr(profile, 'institution_id', None)
        or getattr(profile, 'education_level_id', None)
        or getattr(profile, 'education_system_id', None)
        or profile.studying_subjects.exists()
    )

def discoverable_resources(user, *, searching=False):
    """Return approved resources appropriate for discovery or exact search."""
    public = Q(access_level='public', members_only=False, is_approved=True)
    institution_ids = accepted_institution_ids(user)
    # Search must use the same visibility boundary as the normal listing.
    # Starting from every approved row leaked private/institution titles.
    visibility_filter = public
    if user and getattr(user, 'is_authenticated', False):
        visibility_filter |= (
            Q(creator=user)
            | Q(creator__creator_memberships__member=user, creator__creator_memberships__status='accepted')
            | Q(institution_id__in=institution_ids, is_approved=True)
            | Q(institution__admin=user, is_approved=True)
        )
    return StudyResource.objects.filter(visibility_filter).annotate(
        module_count=Count(
            'study_unit__children',
            filter=Q(study_unit__children__node_type='topic'),
            distinct=True,
        ),
    ).distinct().select_related(
        'creator', 'education_level', 'education_level__system',
    ).prefetch_related('subjects', 'topics', 'skill_domains')

def discover_resources(
    user,
    query='',
    resource_type='',
    subject_id='',
    level_id='',
    limit=30,
):
    """
    Return public or owner-owned resources ranked by the universal
    recommendation service.
    """
    query = (query or '').strip()

    if not query and not _has_learning_context(user) and not accepted_institution_ids(user):
        return []
    resources = discoverable_resources(user, searching=bool(query))

    if resource_type:
        resources = resources.filter(
            resource_type=resource_type,
        )

    if subject_id:
        resources = resources.filter(
            subjects__id=subject_id,
        )

    if level_id:
        resources = resources.filter(
            education_level_id=level_id,
        )

    if query:
        resources = resources.filter(
            Q(title__icontains=query)
            | Q(description__icontains=query)
            | Q(content__icontains=query)
            | Q(subjects__name__icontains=query)
            | Q(topics__name__icontains=query)
            | Q(education_level__name__icontains=query)
            | Q(education_level__system__name__icontains=query)
        ).distinct()

        record_search(
            user=user,
            query=query,
            source_app='spaces',
        )

    resources = resources.order_by(
        '-view_count',
        '-created_at',
    )

    resource_objects = list(
        resources[:limit]
    )

    metadata_items = [
        resource_metadata(resource)
        for resource in resource_objects
    ]

    ranked_items = rank_items(
        user=user,
        items=metadata_items,
        query=query,
        limit=limit,
    )

    resource_by_id = {
        str(resource.id): resource
        for resource in resource_objects
    }

    ranked_resources = []

    for item in ranked_items:
        resource = resource_by_id.get(
            str(item.get('id')),
        )

        if resource:
            apply_resource_recommendation(
                resource,
                item,
            )
            ranked_resources.append(resource)

    return ranked_resources


def record_resource_view(user, resource):
    """
    Record a resource detail-page view for recommendations.
    """
    if not user or not user.is_authenticated:
        return None

    try:
        return record_event(
            user=user,
            event_type=RecommendationEvent.EVENT_VIEW,
            source_app='spaces',
            content_type='study_resource',
            content_id=resource.id,
            metadata=resource_metadata(resource),
        )
    except Exception:
        # Analytics must never turn a valid Study page into a 500 response.
        logger.exception('Unable to record Study resource view for %s', resource.pk)
        return None
