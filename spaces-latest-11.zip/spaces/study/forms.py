from django import forms
from django.db.models import Q
from .models import *
import json
from trends.models import Subject, Topic, EducationLevel, SkillDomain
from trends.access import is_institution_staff
from django.contrib.auth.decorators import login_required, user_passes_test




# In study/forms.py - Update StudyResourceForm __init__

class StudyResourceForm(forms.ModelForm):
    class Meta:
        model = StudyResource
        fields = [
            'title', 'description', 'resource_type', 'education_level',
            'subjects', 'topics', 'access_level', 'access_cost', 'members_only',
            'file', 'thumbnail', 'transcript', 'duration', 'content', 'study_unit'
        ]
    
    def __init__(self, *args, **kwargs):
        user = kwargs.pop('user', None)
        super().__init__(*args, **kwargs)
        
        # Make fields optional
        self.fields['file'].required = False
        self.fields['thumbnail'].required = False
        self.fields['transcript'].required = False
        self.fields['duration'].required = False
        self.fields['content'].required = False
        self.fields['study_unit'].required = False
        self.fields['access_cost'].required = False
        self.fields['education_level'].required = False
        self.fields['subjects'].required = False
        self.fields['topics'].required = False
        
        # Set querysets
        self.fields['subjects'].queryset = Subject.objects.filter(is_approved=True).order_by('name')
        self.fields['topics'].queryset = Topic.objects.filter(is_approved=True).order_by('name')
        self.fields['education_level'].queryset = EducationLevel.objects.filter(is_approved=True).order_by('order')
        profile = getattr(user, 'profile', None) if user and user.is_authenticated else None
        scope_id = self.instance.institution_id if not self.instance._state.adding else getattr(profile, 'institution_id', None)
        units = StudyUnit.objects.select_related('subject', 'topic').filter(institution_id=scope_id)
        if not (user and user.is_authenticated and (user.is_staff or user.is_superuser or (profile and scope_id and is_institution_staff(user, profile.institution)))):
            units = units.filter(Q(created_by=user) | Q(resources__creator=user)).distinct() if user and user.is_authenticated else units.none()
        self.fields['study_unit'].queryset = units.order_by('term', 'title')
        
        # Set initial values from user's profile
        if user and user.is_authenticated:
            if user.profile.onboarding_completed and user.profile.education_level:
                self.fields['education_level'].initial = user.profile.education_level


# study/forms.py

# Add to study/forms.py - Update PassPaperForm

class PassPaperForm(forms.ModelForm):
    """Form for uploading past papers"""
    
    class Meta:
        model = PassPaper
        fields = [
            'title', 'description', 'subject', 'education_level',
            'year', 'term', 'paper_type', 'file', 'is_public', 'requires_credits'
        ]
        widgets = {
            'description': forms.Textarea(attrs={'rows': 3, 'class': 'w-full px-4 py-3 border rounded-xl'}),
            'year': forms.NumberInput(attrs={'min': 2000, 'max': 2100, 'class': 'w-full px-4 py-3 border rounded-xl'}),
            'term': forms.Select(attrs={'class': 'w-full px-4 py-3 border rounded-xl'}),
            'paper_type': forms.Select(attrs={'class': 'w-full px-4 py-3 border rounded-xl'}),
            'subject': forms.Select(attrs={'class': 'w-full px-4 py-3 border rounded-xl'}),
            'education_level': forms.Select(attrs={'class': 'w-full px-4 py-3 border rounded-xl'}),
            'file': forms.ClearableFileInput(attrs={'class': 'w-full px-4 py-3 border rounded-xl'}),
            'is_public': forms.CheckboxInput(attrs={'class': 'rounded'}),
            'requires_credits': forms.NumberInput(attrs={'min': 0, 'class': 'w-full px-4 py-3 border rounded-xl'}),
        }
    
    def __init__(self, *args, **kwargs):
        self.user = kwargs.pop('user', None)
        super().__init__(*args, **kwargs)
        
        # Filter subjects by education level if selected
        self.fields['education_level'].queryset = EducationLevel.objects.filter(is_approved=True).order_by('order')
        self.fields['subject'].queryset = Subject.objects.filter(is_approved=True).order_by('name')
        
        # Set initial values from user's profile
        if self.user and self.user.is_authenticated:
            if self.user.profile.onboarding_completed and self.user.profile.education_level:
                self.fields['education_level'].initial = self.user.profile.education_level
                
                # Filter subjects by that education level
                self.fields['subject'].queryset = Subject.objects.filter(
                    education_level=self.user.profile.education_level,
                    is_approved=True
                ).order_by('name')
        
        # If education level is selected, filter subjects accordingly
        if self.data.get('education_level'):
            try:
                level_id = int(self.data.get('education_level'))
                self.fields['subject'].queryset = Subject.objects.filter(
                    education_level_id=level_id,
                    is_approved=True
                ).order_by('name')
            except (ValueError, TypeError):
                pass
        elif self.instance and self.instance.pk and self.instance.education_level:
            self.fields['subject'].queryset = Subject.objects.filter(
                education_level=self.instance.education_level,
                is_approved=True
            ).order_by('name')
    
    def save(self, commit=True):
        instance = super().save(commit=False)
        instance.uploaded_by = self.user
        
        if commit:
            instance.save()
        
        return instance


@login_required
@user_passes_test(lambda u: u.profile.role in ['setter', 'teacher', 'admin'])
def upload_passpaper(request):
    if request.method == 'POST':
        form = PassPaperForm(request.POST, request.FILES, user=request.user)
        if form.is_valid():
            paper = form.save()
            messages.success(request, f"Pass paper '{paper.title}' uploaded successfully!")
            return redirect('study:passpaper_detail', pk=paper.id)
    else:
        form = PassPaperForm(user=request.user)
    
    return render(request, 'study/passpaper_form.html', {'form': form})

class LessonExerciseForm(forms.ModelForm):
    questions_json = forms.CharField(widget=forms.Textarea(attrs={'rows': 10, 'placeholder': '[{"question":"What did you learn?","type":"text"}]'}), required=False, label='Questions (JSON)')
    guided_steps_json = forms.CharField(widget=forms.Textarea(attrs={'rows': 12, 'placeholder': '[{"title":"Step 1","explanation":"...","hint":"..."}]'}), required=False, label='Guided steps (JSON)')
    template_config_json = forms.CharField(widget=forms.Textarea(attrs={'rows': 12, 'placeholder': '{"passage":"...","materials":["..."],"image_url":"..."}'}), required=False, label='Template configuration (JSON)')
    class Meta:
        model = LessonExercise
        fields = ['title', 'instructions', 'template_type', 'concept', 'mastery_threshold', 'marking_mode']
    def __init__(self, *args, **kwargs):
        super().__init__(*args, **kwargs)
        if self.instance and self.instance.pk:
            self.fields['questions_json'].initial = json.dumps(self.instance.questions, indent=2)
            self.fields['guided_steps_json'].initial = json.dumps(self.instance.guided_steps, indent=2)
            self.fields['template_config_json'].initial = json.dumps(self.instance.template_config, indent=2)
    def save(self, commit=True):
        instance = super().save(commit=False)
        try:
            value = json.loads(self.cleaned_data.get('questions_json') or '[]')
            if not isinstance(value, list): raise ValueError
            instance.questions = value
            steps = json.loads(self.cleaned_data.get('guided_steps_json') or '[]')
            if not isinstance(steps, list): raise ValueError
            instance.guided_steps = steps
            config = json.loads(self.cleaned_data.get('template_config_json') or '{}')
            if not isinstance(config, dict): raise ValueError
            instance.template_config = config
        except (ValueError, TypeError, json.JSONDecodeError):
            self.add_error('questions_json', 'Use a JSON list of question objects.')
            return instance
        if commit: instance.save()
        return instance
