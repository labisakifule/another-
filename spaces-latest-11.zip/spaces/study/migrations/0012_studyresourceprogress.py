from django.conf import settings
from django.db import migrations, models
import django.db.models.deletion

class Migration(migrations.Migration):
    dependencies = [('study', '0011_studyresource_is_approved')]
    operations = [migrations.CreateModel(
        name='StudyResourceProgress',
        fields=[
            ('id', models.BigAutoField(auto_created=True, primary_key=True, serialize=False, verbose_name='ID')),
            ('status', models.CharField(choices=[('not_started', 'Not started'), ('in_progress', 'In progress'), ('completed', 'Completed'), ('needs_review', 'Needs review')], db_index=True, default='not_started', max_length=20)),
            ('progress_percent', models.PositiveSmallIntegerField(default=0)),
            ('views', models.PositiveIntegerField(default=0)),
            ('exercises_attempted', models.PositiveIntegerField(default=0)),
            ('exercises_completed', models.PositiveIntegerField(default=0)),
            ('average_score', models.FloatField(blank=True, null=True)),
            ('first_opened_at', models.DateTimeField(blank=True, null=True)),
            ('last_opened_at', models.DateTimeField(blank=True, null=True)),
            ('completed_at', models.DateTimeField(blank=True, null=True)),
            ('updated_at', models.DateTimeField(auto_now=True)),
            ('resource', models.ForeignKey(on_delete=django.db.models.deletion.CASCADE, related_name='learner_progress', to='study.studyresource')),
            ('user', models.ForeignKey(on_delete=django.db.models.deletion.CASCADE, related_name='study_resource_progress', to=settings.AUTH_USER_MODEL)),
        ],
        options={'ordering': ['-updated_at'], 'indexes': [models.Index(fields=['user', 'status'], name='study_studyre_user_id_7fb6b7_idx'), models.Index(fields=['resource', 'status'], name='study_studyre_resourc_11c1c4_idx')]},
        bases=(models.Model,),
    ), migrations.AddConstraint(model_name='studyresourceprogress', constraint=models.UniqueConstraint(fields=('user', 'resource'), name='unique_study_resource_progress'))]
