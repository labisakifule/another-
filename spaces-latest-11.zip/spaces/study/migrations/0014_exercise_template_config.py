from django.db import migrations, models


class Migration(migrations.Migration):
    dependencies = [('study', '0013_study_hierarchy')]

    operations = [
        migrations.AddField(
            model_name='lessonexercise',
            name='template_config',
            field=models.JSONField(blank=True, default=dict),
        ),
    ]
