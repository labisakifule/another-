from django.db import migrations


class Migration(migrations.Migration):
    dependencies = [('study', '0016_nested_study_threads')]

    operations = [
        migrations.AlterModelOptions(
            name='studyunitmedia',
            options={'ordering': ['order', 'id']},
        ),
    ]
