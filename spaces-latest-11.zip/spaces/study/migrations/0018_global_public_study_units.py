from django.db import migrations, models
import django.db.models.deletion


class Migration(migrations.Migration):
    dependencies = [
        ('study', '0017_studyunitmedia_ordering'),
    ]

    operations = [
        migrations.AlterField(
            model_name='studyunit',
            name='institution',
            field=models.ForeignKey(
                blank=True,
                null=True,
                on_delete=django.db.models.deletion.SET_NULL,
                related_name='study_units',
                to='trends.institution',
            ),
        ),
    ]
