from django.db import migrations, models


class Migration(migrations.Migration):
    dependencies = [('study', '0014_exercise_template_config')]

    operations = [
        migrations.AddIndex(
            model_name='studyunit',
            index=models.Index(fields=['institution', 'education_level', 'term'], name='study_study_institu_3d53c4_idx'),
        ),
        migrations.AddIndex(
            model_name='studyunit',
            index=models.Index(fields=['parent', 'period_number'], name='study_study_parent__44a7f4_idx'),
        ),
        migrations.RenameIndex(
            model_name='studyunitprogress',
            old_name='study_unitpr_user_id_5b45_idx',
            new_name='study_study_user_id_7472a2_idx',
        ),
        migrations.RenameIndex(
            model_name='studyunitprogress',
            old_name='study_unitpr_unit_id_7c14_idx',
            new_name='study_study_unit_id_9c6e79_idx',
        ),
    ]
