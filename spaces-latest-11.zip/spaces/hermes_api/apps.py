from django.apps import AppConfig


class HermesApiConfig(AppConfig):
    default_auto_field = 'django.db.models.BigAutoField'
    name = 'hermes_api'
    label = 'hermes_api'
