import json
import logging
from datetime import datetime

from django.http import JsonResponse
from django.db.models import Q
from django.utils import timezone
from django.views.decorators.csrf import csrf_exempt

from exams.constants import QUESTION_TYPE_MCQ, QUESTION_TYPE_TEXT
from exams.models import ExamSection, ExamSet, Question
from liveclass.models import LiveClass
from study.models import StudyResource
from trends.constants import AccessLevel
from trends.models import EducationLevel, Institution, Subject, Topic

from core.api_auth import api_view, scoped_queryset
from .permissions import json_body, method_not_allowed
from .serializers import exam_data, institution_data, live_class_data, resource_data

logger = logging.getLogger('hermes_api')


def health(request):
    error = method_not_allowed(request, ('GET',))
    if error:
        return error
    return JsonResponse({'ok': True, 'service': 'spaces-hermes-api', 'version': 'v1'})


@api_view()
def me(request):
    error = method_not_allowed(request, ('GET',))
    if error:
        return error
    return JsonResponse({
        'username': request.api_user.username,
        'institution': institution_data(request.api_institution),
        'scopes': request.api_token.scopes or [],
    })


@api_view(('institution:read',))
def institution_detail(request):
    error = method_not_allowed(request, ('GET',))
    if error:
        return error
    return JsonResponse({'institution': institution_data(request.api_institution)})


def _subject(payload, institution):
    value = payload.get('subject') or payload.get('subject_id')
    if not value:
        raise ValueError('subject is required')
    query = Subject.objects.filter(Q(institution=institution) | Q(institution__isnull=True))
    try:
        return query.get(pk=value)
    except (Subject.DoesNotExist, ValueError):
        item = query.filter(name__iexact=str(value)).first()
        if not item:
            raise ValueError('Subject was not found in the token institution scope.')
        return item


def _education_level(payload, institution):
    value = payload.get('level') or payload.get('education_level_id')
    if not value:
        return None
    query = EducationLevel.objects.filter(Q(institution_level=institution) | Q(institution_level__isnull=True))
    try:
        return query.get(pk=value)
    except (EducationLevel.DoesNotExist, ValueError):
        return query.filter(name__iexact=str(value)).first()


def _question_payload(exam, questions):
    if not isinstance(questions, list) or not questions:
        raise ValueError('questions must be a non-empty list')
    for index, item in enumerate(questions, start=1):
        if not isinstance(item, dict) or not item.get('prompt'):
            raise ValueError(f'question {index} must include prompt')
        qtype = str(item.get('type', 'mcq')).upper()
        if qtype in ('MCQ', 'MULTIPLE_CHOICE'):
            choices = item.get('options') or item.get('choices')
            if not isinstance(choices, list) or len(choices) < 2:
                raise ValueError(f'question {index} MCQ needs at least two options')
            answer = item.get('answer')
            if answer is None:
                raise ValueError(f'question {index} MCQ needs answer')
            answer_text = str(answer)
            if answer_text in choices:
                correct = chr(ord('A') + choices.index(answer_text))
            elif len(answer_text) == 1 and answer_text.upper() in 'ABCDEFGHIJKLMNOPQRSTUVWXYZ':
                correct = answer_text.upper()
            else:
                correct = answer_text[:1].upper()
            Question.objects.create(
                exam_set=exam, text=str(item['prompt']), order=index, points=int(item.get('marks', 1)),
                question_type=QUESTION_TYPE_MCQ, choices=choices, correct_choice=correct,
                created_by=exam.creator,
            )
        elif qtype in ('TEXT', 'ESSAY', 'SHORT_ANSWER'):
            Question.objects.create(
                exam_set=exam, text=str(item['prompt']), order=index, points=int(item.get('marks', 1)),
                question_type=QUESTION_TYPE_TEXT, reference_answer=str(item.get('answer', '')),
                max_length=item.get('max_length'), created_by=exam.creator,
            )
        else:
            raise ValueError(f'question {index} has unsupported type')


def _exam_queryset(request):
    return scoped_queryset(ExamSet.objects.select_related('creator', 'subject'), request.api_institution)


@api_view(('exam:read',))
def exam_list(request):
    error = method_not_allowed(request, ('GET',))
    if error:
        return error
    items = _exam_queryset(request).order_by('-created_at')[:100]
    return JsonResponse({'results': [exam_data(item) for item in items]})


@csrf_exempt
@api_view(('exam:create_draft',))
def exam_draft_create(request):
    error = method_not_allowed(request, ('POST',))
    if error:
        return error
    payload, error = json_body(request)
    if error:
        return error
    try:
        subject = _subject(payload, request.api_institution)
        exam = ExamSet.objects.create(
            title=str(payload.get('title', '')).strip(),
            description=str(payload.get('description', '')).strip(),
            creator=request.api_user,
            subject=subject,
            topic=Topic.objects.filter(pk=payload.get('topic_id'), subject=subject).first() if payload.get('topic_id') else None,
            duration_minutes=int(payload.get('duration_minutes', 30)),
            education_level=_education_level(payload, request.api_institution),
            is_active=False,
        )
        if not exam.title or not exam.description:
            exam.delete()
            raise ValueError('title and description are required')
        _question_payload(exam, payload.get('questions'))
    except (ValueError, TypeError, OverflowError) as exc:
        if 'exam' in locals() and exam.pk:
            exam.delete()
        return JsonResponse({'error': str(exc)}, status=400)
    logger.info('hermes_api create exam_draft user_id=%s token_id=%s institution_id=%s object_id=%s', request.api_user.id, request.api_token.id, request.api_institution.id, exam.id)
    return JsonResponse(exam_data(exam), status=201)


@api_view(('exam:read',))
def exam_detail(request, object_id):
    error = method_not_allowed(request, ('GET',))
    if error:
        return error
    item = _exam_queryset(request).filter(pk=object_id).first()
    if not item:
        return JsonResponse({'error': 'Not found.'}, status=404)
    return JsonResponse(exam_data(item))


@csrf_exempt
@api_view(('exam:submit_for_review',))
def exam_submit(request, object_id):
    error = method_not_allowed(request, ('POST',))
    if error:
        return error
    item = _exam_queryset(request).filter(pk=object_id).first()
    if not item:
        return JsonResponse({'error': 'Not found.'}, status=404)
    return JsonResponse({'error': 'Submission workflow is not enabled yet; human review is required.'}, status=403)


def _resource_queryset(request):
    return scoped_queryset(StudyResource.objects.select_related('creator'), request.api_institution)


@api_view(('study_resource:read',))
def resource_list(request):
    error = method_not_allowed(request, ('GET',))
    if error:
        return error
    return JsonResponse({'results': [resource_data(item) for item in _resource_queryset(request).order_by('-created_at')[:100]]})


@csrf_exempt
@api_view(('study_resource:create_draft',))
def resource_draft_create(request):
    error = method_not_allowed(request, ('POST',))
    if error:
        return error
    payload, error = json_body(request)
    if error:
        return error
    title = str(payload.get('title', '')).strip()
    description = str(payload.get('description', '')).strip()
    if not title or not description:
        return JsonResponse({'error': 'title and description are required'}, status=400)
    item = StudyResource.objects.create(
        title=title, description=description, content=str(payload.get('content', '')),
        resource_type=str(payload.get('resource_type', 'text')), creator=request.api_user,
        access_level=AccessLevel.PRIVATE,
        education_level=_education_level(payload, request.api_institution),
    )
    logger.info('hermes_api create study_resource_draft user_id=%s token_id=%s institution_id=%s object_id=%s', request.api_user.id, request.api_token.id, request.api_institution.id, item.id)
    return JsonResponse(resource_data(item), status=201)


@api_view(('study_resource:read',))
def resource_detail(request, object_id):
    error = method_not_allowed(request, ('GET',))
    if error:
        return error
    item = _resource_queryset(request).filter(pk=object_id).first()
    if not item:
        return JsonResponse({'error': 'Not found.'}, status=404)
    return JsonResponse(resource_data(item))


@csrf_exempt
@api_view(('study_resource:submit_for_review',))
def resource_submit(request, object_id):
    error = method_not_allowed(request, ('POST',))
    if error:
        return error
    if not _resource_queryset(request).filter(pk=object_id).exists():
        return JsonResponse({'error': 'Not found.'}, status=404)
    return JsonResponse({'error': 'Submission workflow is not enabled yet; human review is required.'}, status=403)


@api_view(('liveclass:read',))
def live_class_list(request):
    error = method_not_allowed(request, ('GET',))
    if error:
        return error
    items = LiveClass.objects.filter(institution=request.api_institution, deleted_at__isnull=True).order_by('-created_at')[:100]
    return JsonResponse({'results': [live_class_data(item) for item in items]})


@csrf_exempt
@api_view(('liveclass:create_draft',))
def live_class_draft_create(request):
    error = method_not_allowed(request, ('POST',))
    if error:
        return error
    payload, error = json_body(request)
    if error:
        return error
    title = str(payload.get('title', '')).strip()
    if not title:
        return JsonResponse({'error': 'title is required'}, status=400)
    scheduled_start = None
    if payload.get('scheduled_start'):
        try:
            scheduled_start = datetime.fromisoformat(str(payload['scheduled_start']).replace('Z', '+00:00'))
            if timezone.is_naive(scheduled_start):
                scheduled_start = timezone.make_aware(scheduled_start)
        except ValueError:
            return JsonResponse({'error': 'scheduled_start must be an ISO-8601 datetime'}, status=400)
    item = LiveClass.objects.create(
        title=title, description=str(payload.get('description', '')), teacher=request.api_user,
        institution=request.api_institution, status='scheduled', visibility=LiveClass.VISIBILITY_PRIVATE,
        scheduled_start=scheduled_start, scheduled_end=None, subject_or_course_unit=str(payload.get('subject', '')),
        topic=str(payload.get('topic', '')), language=str(payload.get('language', 'en')),
    )
    logger.info('hermes_api create liveclass_draft user_id=%s token_id=%s institution_id=%s object_id=%s', request.api_user.id, request.api_token.id, request.api_institution.id, item.id)
    return JsonResponse(live_class_data(item), status=201)


@api_view(('liveclass:read',))
def live_class_detail(request, object_id):
    error = method_not_allowed(request, ('GET',))
    if error:
        return error
    item = LiveClass.objects.filter(pk=object_id, institution=request.api_institution, deleted_at__isnull=True).first()
    if not item:
        return JsonResponse({'error': 'Not found.'}, status=404)
    return JsonResponse(live_class_data(item))


@csrf_exempt
@api_view(('liveclass:submit_for_review',))
def live_class_submit(request, object_id):
    error = method_not_allowed(request, ('POST',))
    if error:
        return error
    if not LiveClass.objects.filter(pk=object_id, institution=request.api_institution).exists():
        return JsonResponse({'error': 'Not found.'}, status=404)
    return JsonResponse({'error': 'Submission workflow is not enabled yet; human review is required.'}, status=403)
