from django.http import JsonResponse


def json_body(request):
    import json
    try:
        payload = json.loads(request.body or '{}')
    except (TypeError, ValueError):
        return None, JsonResponse({'error': 'Request body must be valid JSON.'}, status=400)
    if not isinstance(payload, dict):
        return None, JsonResponse({'error': 'Request body must be a JSON object.'}, status=400)
    return payload, None


def institution_match(request, institution_id):
    if str(request.api_institution.id) != str(institution_id):
        return JsonResponse({'error': 'Object is outside the token institution scope.'}, status=404)
    return None


def method_not_allowed(request, methods=('GET',)):
    if request.method not in methods:
        return JsonResponse({'error': 'Method not allowed.'}, status=405)
    return None
