def user_data(user):
    return {'id': str(user.id), 'username': user.username}


def institution_data(institution):
    return {'id': str(institution.id), 'name': institution.name, 'subdomain': institution.subdomain, 'is_approved': institution.is_approved}


def exam_data(exam):
    return {'id': str(exam.id), 'title': exam.title, 'description': exam.description, 'creator': user_data(exam.creator), 'status': 'draft' if not exam.is_active else 'active', 'duration_minutes': exam.duration_minutes, 'subject': exam.subject.name if exam.subject_id else None, 'created_at': exam.created_at.isoformat()}


def resource_data(resource):
    return {'id': str(resource.id), 'title': resource.title, 'description': resource.description, 'creator': user_data(resource.creator), 'status': 'draft' if resource.access_level != 'public' else 'published', 'resource_type': resource.resource_type, 'access_level': resource.access_level, 'created_at': resource.created_at.isoformat()}


def live_class_data(item):
    return {'id': str(item.id), 'title': item.title, 'description': item.description, 'teacher': user_data(item.teacher), 'institution': institution_data(item.institution) if item.institution_id else None, 'status': 'draft', 'scheduled_start': item.scheduled_start.isoformat() if item.scheduled_start else None, 'visibility': item.visibility}
