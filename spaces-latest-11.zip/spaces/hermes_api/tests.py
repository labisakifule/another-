from django.test import TestCase
from django.urls import reverse


class HermesHealthTests(TestCase):
    def test_health_is_available_without_token(self):
        response = self.client.get('/api/hermes/v1/health/')
        self.assertEqual(response.status_code, 200)
        self.assertTrue(response.json()['ok'])

    def test_me_requires_a_bearer_token(self):
        response = self.client.get('/api/hermes/v1/me/')
        self.assertEqual(response.status_code, 401)
