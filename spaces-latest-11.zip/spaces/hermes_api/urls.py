from django.urls import path

from . import views

app_name = 'hermes_api'

urlpatterns = [
    path('health/', views.health, name='health'),
    path('me/', views.me, name='me'),
    path('institution/', views.institution_detail, name='institution'),
    path('exams/', views.exam_list, name='exam_list'),
    path('exams/drafts/', views.exam_draft_create, name='exam_draft_create'),
    path('exams/<uuid:object_id>/', views.exam_detail, name='exam_detail'),
    path('exams/<uuid:object_id>/submit-for-review/', views.exam_submit, name='exam_submit'),
    path('study-resources/', views.resource_list, name='resource_list'),
    path('study-resources/drafts/', views.resource_draft_create, name='resource_draft_create'),
    path('study-resources/<uuid:object_id>/', views.resource_detail, name='resource_detail'),
    path('study-resources/<uuid:object_id>/submit-for-review/', views.resource_submit, name='resource_submit'),
    path('live-classes/', views.live_class_list, name='live_class_list'),
    path('live-classes/drafts/', views.live_class_draft_create, name='live_class_draft_create'),
    path('live-classes/<uuid:object_id>/', views.live_class_detail, name='live_class_detail'),
    path('live-classes/<uuid:object_id>/submit-for-review/', views.live_class_submit, name='live_class_submit'),
]
