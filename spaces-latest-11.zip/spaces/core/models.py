from django.conf import settings
from django.db import models


class RecommendationEvent(models.Model):
    """
    Universal activity record used by the recommendation system.

    It is intentionally app-neutral so it can record activity from:
    - Spaces Live Classes
    - Spaces Exams
    - Spaces Study Resources
    - NUSU
    - Labisa
    """

    EVENT_SEARCH = 'search'
    EVENT_VIEW = 'view'
    EVENT_JOIN = 'join'
    EVENT_SAVE = 'save'
    EVENT_COMPLETE = 'complete'
    EVENT_ATTEMPT = 'attempt'
    EVENT_DISMISS = 'dismiss'

    EVENT_CHOICES = [
        (EVENT_SEARCH, 'Search'),
        (EVENT_VIEW, 'View'),
        (EVENT_JOIN, 'Join'),
        (EVENT_SAVE, 'Save'),
        (EVENT_COMPLETE, 'Complete'),
        (EVENT_ATTEMPT, 'Attempt'),
        (EVENT_DISMISS, 'Dismiss'),
    ]

    user = models.ForeignKey(
        settings.AUTH_USER_MODEL,
        on_delete=models.CASCADE,
        related_name='recommendation_events',
    )

    # Identifies the application that produced the event.
    # Examples: spaces, nusu, labisa.
    source_app = models.CharField(
        max_length=40,
        default='spaces',
    )

    # Examples: live_class, exam, study_resource, course.
    content_type = models.CharField(
        max_length=80,
        blank=True,
    )

    # Stored as text so this supports UUIDs, integers, slugs,
    # and external identifiers from NUSU or Labisa.
    content_id = models.CharField(
        max_length=200,
        blank=True,
    )

    event_type = models.CharField(
        max_length=20,
        choices=EVENT_CHOICES,
    )

    # The original user search, when event_type is "search".
    query = models.CharField(
        max_length=300,
        blank=True,
    )

    # Optional structured information from another application.
    # Example:
    # {
    #   "subject": "Mathematics",
    #   "level": "P.6",
    #   "topic": "Fractions"
    # }
    metadata = models.JSONField(
        default=dict,
        blank=True,
    )

    created_at = models.DateTimeField(
        auto_now_add=True,
    )

    class Meta:
        ordering = ['-created_at']
        indexes = [
            models.Index(
                fields=['user', '-created_at'],
                name='rec_event_user_date_idx',
            ),
            models.Index(
                fields=['source_app', 'event_type'],
                name='rec_event_source_type_idx',
            ),
            models.Index(
                fields=['content_type', 'content_id'],
                name='rec_event_content_idx',
            ),
            models.Index(
                fields=['query'],
                name='rec_event_query_idx',
            ),
        ]

    def __str__(self):
        target = self.content_id or self.query or 'general'
        return (
            f'{self.user.username} - '
            f'{self.source_app} - '
            f'{self.event_type} - '
            f'{target}'
        )




# SPACES_NOTIFICATION_CENTER_V1
class Notification(models.Model):
    recipient = models.ForeignKey(settings.AUTH_USER_MODEL, on_delete=models.CASCADE, related_name='notifications')
    actor = models.ForeignKey(settings.AUTH_USER_MODEL, on_delete=models.SET_NULL, null=True, blank=True, related_name='notifications_caused')
    kind = models.CharField(max_length=60, default='system')
    title = models.CharField(max_length=180)
    body = models.TextField(blank=True)
    url = models.CharField(max_length=500, blank=True)
    metadata = models.JSONField(default=dict, blank=True)
    read_at = models.DateTimeField(null=True, blank=True, db_index=True)
    created_at = models.DateTimeField(auto_now_add=True, db_index=True)
    class Meta:
        ordering = ['-created_at']
        indexes = [
            models.Index(fields=['recipient', '-created_at'], name='notif_recipient_date_idx'),
            models.Index(fields=['recipient', 'read_at'], name='notif_recipient_read_idx'),
        ]
    @property
    def is_read(self):
        return self.read_at is not None


class APIToken(models.Model):
    user = models.ForeignKey(settings.AUTH_USER_MODEL, on_delete=models.CASCADE, related_name='api_tokens')
    institution = models.ForeignKey('trends.Institution', on_delete=models.CASCADE, related_name='api_tokens')
    name = models.CharField(max_length=120)
    key_prefix = models.CharField(max_length=32, db_index=True)
    hashed_token = models.CharField(max_length=256)
    scopes = models.JSONField(default=list)
    created_at = models.DateTimeField(auto_now_add=True)
    last_used_at = models.DateTimeField(null=True, blank=True)
    expires_at = models.DateTimeField(null=True, blank=True)
    revoked_at = models.DateTimeField(null=True, blank=True)

    class Meta:
        constraints = [models.UniqueConstraint(fields=['user', 'name'], name='unique_api_token_name')]
        indexes = [models.Index(fields=['key_prefix', 'revoked_at'], name='api_token_prefix_revoked_idx')]

    def has_scope(self, scope):
        return scope in (self.scopes or [])

    @property
    def is_valid(self):
        from django.utils import timezone
        return not self.revoked_at and (not self.expires_at or self.expires_at > timezone.now())
