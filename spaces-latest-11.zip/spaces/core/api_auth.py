import hashlib
import logging
from functools import wraps

from django.contrib.auth.hashers import check_password
from django.http import JsonResponse
from django.utils import timezone

from core.models import APIToken
from trends.models import InstitutionMembership
from trends.constants import UserRole

logger = logging.getLogger('hermes_api')

STAFF_ROLES = {
    UserRole.INSTITUTION_ADMIN,
    UserRole.INSTITUTION_MANAGER,
    UserRole.STAFF,
    UserRole.TEACHER,
    UserRole.SETTER,
}


def _unauthorized():
    return JsonResponse({'error': 'Unauthorized'}, status=401)


def _forbidden(message='Forbidden'):
    return JsonResponse({'error': message}, status=403)


def authenticate_bearer(request):
    header = request.headers.get('Authorization', '')
    if not header.startswith('Bearer '):
        return None
    raw = header[7:].strip()
    if not raw or len(raw) > 300:
        return None
    prefix = raw[:24]
    candidates = APIToken.objects.select_related('user', 'institution').filter(key_prefix=prefix)
    token = next((item for item in candidates if check_password(raw, item.hashed_token)), None)
    if not token or not token.is_valid or not token.user.is_active:
        return None
    membership = InstitutionMembership.objects.filter(
        user=token.user,
        institution=token.institution,
        status=InstitutionMembership.STATUS_ACCEPTED,
    ).first()
    profile = getattr(token.user, 'profile', None)
    role_ok = bool(
        membership and membership.requested_role in STAFF_ROLES
    ) or bool(
        profile and profile.institution_id == token.institution_id
        and profile.institution_role in STAFF_ROLES
    ) or token.institution.admin_id == token.user_id
    if not token.institution.is_active or not token.institution.is_approved or not role_ok:
        return None
    token.last_used_at = timezone.now()
    token.save(update_fields=['last_used_at'])
    request.api_user = token.user
    request.api_token = token
    request.api_institution = token.institution
    logger.info('hermes_api auth user_id=%s token_id=%s institution_id=%s', token.user_id, token.pk, token.institution_id)
    return token


def api_view(scopes=()):
    def decorator(view):
        @wraps(view)
        def wrapped(request, *args, **kwargs):
            token = authenticate_bearer(request)
            if not token:
                return _unauthorized()
            missing = [scope for scope in scopes if not token.has_scope(scope)]
            if missing:
                return _forbidden('Missing required scope.')
            return view(request, *args, **kwargs)
        return wrapped
    return decorator


def scoped_queryset(queryset, institution, user_field='creator'):
    return queryset.filter(**{f'{user_field}__profile__institution': institution})


def fingerprint(value):
    return hashlib.sha256(value.encode()).hexdigest()[:12]
