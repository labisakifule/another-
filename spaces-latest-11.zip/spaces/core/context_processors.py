# core/context_processors.py
from django.conf import settings

def cloudinary_settings(request):
    return {
        'cloudinary_cloud_name': settings.CLOUDINARY_CLOUD_NAME,
    }

from core.models import Notification


def notifications(request):
    if not getattr(request, 'user', None) or not request.user.is_authenticated:
        return {'notification_unread_count': 0, 'recent_notifications': []}
    qs = Notification.objects.filter(recipient=request.user)
    return {
        'notification_unread_count': qs.filter(read_at__isnull=True).count(),
        'recent_notifications': list(qs.select_related('actor')[:5]),
    }
