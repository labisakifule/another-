import json
from channels.generic.websocket import AsyncWebsocketConsumer

class SignalingConsumer(AsyncWebsocketConsumer):
    async def connect(self):
        await self.accept()
    
    async def disconnect(self, close_code):
        pass
    
    async def receive(self, text_data):
        try:
            data = json.loads(text_data)
            # Broadcast to all clients in the group
            await self.channel_layer.group_send(
                "signaling_group",
                {
                    "type": "signal_message",
                    "data": data
                }
            )
        except json.JSONDecodeError:
            pass
    
    async def signal_message(self, event):
        await self.send(text_data=json.dumps(event["data"]))
