from django.utils import timezone
from core.models import Notification


def notify_user(recipient, title, body='', url='', kind='system', actor=None, metadata=None):
    """Create one notification for an in-app recipient."""
    if not recipient or not getattr(recipient, 'is_active', True):
        return None
    return Notification.objects.create(
        recipient=recipient,
        actor=actor,
        kind=kind,
        title=str(title)[:180],
        body=str(body or ''),
        url=str(url or '')[:500],
        metadata=metadata or {},
    )


def mark_read(notification):
    if notification.read_at is None:
        notification.read_at = timezone.now()
        notification.save(update_fields=['read_at'])
