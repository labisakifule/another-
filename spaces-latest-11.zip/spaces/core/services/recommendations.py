
"""
Universal recommendation helpers.

This module is app-neutral. It does not know how Live Classes, Exams,
Study Resources, NUSU, or Labisa store their content. Each app supplies a
small metadata dictionary and receives a relevance score.

Expected content metadata keys include:
    id, title, description, source_app, content_type,
    country, education_system, education_stage, education_level,
    institution, programme, academic_year, subject, topic, language,
    popularity_score, created_at
"""

from datetime import timedelta
from numbers import Number

from django.utils import timezone
from django.utils.text import slugify

from core.models import RecommendationEvent


TERM_ALIASES = {
    'math': 'mathematics',
    'maths': 'mathematics',
    'bio': 'biology',
    'chem': 'chemistry',
    'ict': 'information technology',
    'it': 'information technology',
    'cs': 'computer science',
    'comp sci': 'computer science',
    'p6': 'p 6',
    'p.6': 'p 6',
    'p7': 'p 7',
    'p.7': 'p 7',
}


PROFILE_FIELDS = (
    'country',
    'education_system',
    'education_stage',
    'education_level',
    'institution',
    'program',
    'programme',
    'academic_year',
)


CONTENT_FIELDS = (
    'country',
    'education_system',
    'education_stage',
    'education_level',
    'institution',
    'program',
    'programme',
    'academic_year',
    'subject',
    'subject_or_course_unit',
    'topic',
    'language',
)


def normalize_text(value):
    """Return a forgiving, searchable representation of any value."""
    if value is None:
        return ''

    if hasattr(value, 'name'):
        value = value.name

    value = str(value).strip().lower()

    for old, new in TERM_ALIASES.items():
        value = value.replace(old, new)

    value = value.replace('-', ' ')
    value = value.replace('_', ' ')
    value = ' '.join(value.split())

    return value


def value_text(value):
    """Convert a model value or list of values to normalized text."""
    if value is None:
        return ''

    if isinstance(value, (list, tuple, set)):
        return ' '.join(value_text(item) for item in value)

    if hasattr(value, 'all'):
        try:
            return ' '.join(value_text(item) for item in value.all())
        except Exception:
            return ''

    return normalize_text(value)


def profile_context(user):
    """Build a normalized learner context from the existing Profile model."""
    profile = getattr(user, 'profile', None)

    if profile is None:
        return {}

    context = {}

    for field_name in PROFILE_FIELDS:
        if hasattr(profile, field_name):
            value = getattr(profile, field_name, None)
            text = value_text(value)

            if text:
                context[field_name] = text

    if hasattr(profile, 'studying_subjects'):
        try:
            subjects = profile.studying_subjects.all()
            context['subjects'] = [
                normalize_text(subject.name)
                for subject in subjects
                if getattr(subject, 'name', None)
            ]
        except Exception:
            context['subjects'] = []

    return context


def metadata_text(metadata):
    """Return all searchable text from a content metadata dictionary."""
    values = []

    for field_name in CONTENT_FIELDS:
        values.append(value_text(metadata.get(field_name)))

    values.append(value_text(metadata.get('title')))
    values.append(value_text(metadata.get('description')))

    return ' '.join(item for item in values if item)


def search_terms(query):
    """Normalize a natural search phrase into useful terms."""
    normalized = normalize_text(query)

    if not normalized:
        return []

    return [
        term
        for term in normalized.split()
        if len(term) > 1
    ]


def score_metadata(user_context, metadata, query=''):
    """
    Score one content item against a learner context.

    Higher score means stronger relevance.
    """
    score = 0
    reasons = []

    content = {
        key: value_text(metadata.get(key))
        for key in CONTENT_FIELDS
    }

    searchable = metadata_text(metadata)
    normalized_query = normalize_text(query)

    def add(points, reason):
        nonlocal score
        score += points
        reasons.append(reason)

    if user_context.get('country'):
        if content['country'] == user_context['country']:
            add(10, 'Matches your country')

    if user_context.get('education_system'):
        if content['education_system'] == user_context['education_system']:
            add(40, 'Matches your education system')

    if user_context.get('education_stage'):
        if content['education_stage'] == user_context['education_stage']:
            add(25, 'Matches your education stage')

    if user_context.get('education_level'):
        if content['education_level'] == user_context['education_level']:
            add(35, 'Matches your level')

    programme = (
        user_context.get('programme')
        or user_context.get('program')
    )

    content_programme = (
        content.get('programme')
        or content.get('program')
    )

    if programme and content_programme == programme:
        add(30, 'Matches your programme')

    if user_context.get('academic_year'):
        if content['academic_year'] == user_context['academic_year']:
            add(20, 'Matches your academic year')

    if user_context.get('institution'):
        if content['institution'] == user_context['institution']:
            add(15, 'Matches your institution')

    subjects = user_context.get('subjects', [])

    subject = (
        content.get('subject')
        or content.get('subject_or_course_unit')
    )

    if subject and any(
        subject == item
        or subject in item
        or item in subject
        for item in subjects
    ):
        add(30, 'Matches one of your subjects or course units')

    if normalized_query:
        query_matches = [
            term
            for term in search_terms(normalized_query)
            if term in searchable
        ]

        if query_matches:
            add(
                min(40, len(query_matches) * 10),
                'Matches your search',
            )

    language = user_context.get('language')

    if language and content.get('language') == language:
        add(10, 'Matches your language')

    popularity = metadata.get('popularity_score', 0)

    if isinstance(popularity, Number):
        add(
            min(15, max(0, int(popularity))),
            'Popular with learners',
        )

    created_at = metadata.get('created_at')

    if created_at:
        try:
            if created_at >= timezone.now() - timedelta(days=14):
                add(5, 'Recently published')
        except (TypeError, ValueError):
            pass

    return {
        'score': score,
        'reasons': reasons[:4],
    }


def rank_items(user, items, query='', limit=20):
    """
    Rank dictionaries from any application.

    Each item must contain metadata keys accepted by score_metadata.
    """
    context = profile_context(user)
    ranked = []

    for item in items:
        item_copy = dict(item)
        result = score_metadata(
            context,
            item_copy,
            query=query,
        )

        item_copy['recommendation_score'] = result['score']
        item_copy['recommendation_reasons'] = result['reasons']

        ranked.append(item_copy)

    ranked.sort(
        key=lambda item: (
            item.get('recommendation_score', 0),
            item.get('popularity_score', 0),
            str(item.get('created_at', '')),
        ),
        reverse=True,
    )

    return ranked[:limit]


def record_event(
    user,
    event_type,
    source_app='spaces',
    content_type='',
    content_id='',
    query='',
    metadata=None,
):
    """Record a universal recommendation event."""
    if not user or not getattr(user, 'is_authenticated', False):
        return None

    valid_events = dict(
        RecommendationEvent.EVENT_CHOICES
    )

    if event_type not in valid_events:
        raise ValueError(
            f'Unsupported recommendation event: {event_type}'
        )

    return RecommendationEvent.objects.create(
        user=user,
        source_app=source_app,
        content_type=content_type,
        content_id=str(content_id or ''),
        event_type=event_type,
        query=(query or '')[:300],
        metadata=metadata or {},
    )


def record_search(user, query, source_app='spaces'):
    """Convenience helper used by search views."""
    query = (query or '').strip()

    if not query:
        return None

    return record_event(
        user=user,
        event_type=RecommendationEvent.EVENT_SEARCH,
        source_app=source_app,
        query=query,
    )


def popular_score(
    viewer_count=0,
    max_viewers=0,
    join_count=0,
):
    """Return a small bounded score for fallback ranking."""
    numbers = [
        int(viewer_count or 0),
        int(max_viewers or 0),
        int(join_count or 0),
    ]

    return min(
        15,
        max(
            0,
            numbers[0] * 2
            + numbers[1]
            + numbers[2],
        ),
    )


def normalize_for_slug(value):
    """Useful for lightweight matching across external app metadata."""
    return slugify(normalize_text(value))


