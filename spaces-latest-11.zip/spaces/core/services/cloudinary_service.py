import cloudinary
import cloudinary.api
import cloudinary.uploader
from django.conf import settings

class CloudinaryService:
    def __init__(self):
        cloudinary.config(
            cloud_name=settings.CLOUDINARY_STORAGE['CLOUD_NAME'],
            api_key=settings.CLOUDINARY_STORAGE['API_KEY'],
            api_secret=settings.CLOUDINARY_STORAGE['API_SECRET'],
            secure=True
        )
    
    def upload_file(self, file, folder=None, public_id=None, resource_type='auto', **options):
        """
        Upload a file to Cloudinary
        """
        try:
            upload_options = {
                'resource_type': resource_type,
                'folder': folder,
                'public_id': public_id,
                'overwrite': True,
                **options
            }
            result = cloudinary.uploader.upload(file, **upload_options)
            return {
                'success': True,
                'url': result['secure_url'],
                'public_id': result['public_id'],
                'format': result.get('format'),
                'width': result.get('width'),
                'height': result.get('height'),
                'bytes': result.get('bytes')
            }
        except Exception as e:
            return {
                'success': False,
                'error': str(e)
            }
    
    def delete_file(self, public_id, resource_type='image'):
        """
        Delete a file from Cloudinary
        """
        try:
            result = cloudinary.uploader.destroy(public_id, resource_type=resource_type)
            return {
                'success': result['result'] == 'ok',
                'result': result
            }
        except Exception as e:
            return {
                'success': False,
                'error': str(e)
            }
    
    def get_video_thumbnail(self, public_id, **options):
        """
        Generate a thumbnail URL for a video
        """
        transform = {
            'width': options.get('width', 400),
            'height': options.get('height', 300),
            'crop': 'fill',
            'start_offset': options.get('start_offset', '1'),  # 1 second into video
            'resource_type': 'video'
        }
        url = cloudinary.CloudinaryVideo(public_id).build_url(**transform)
        return url
    
    def get_optimized_url(self, public_id, **options):
        """
        Get optimized URL with automatic format and quality
        """
        transform = {
            'quality': 'auto',
            'fetch_format': 'auto',
            **options
        }
        url = cloudinary.CloudinaryImage(public_id).build_url(**transform)
        return url
    
    def generate_signature(self, params_to_sign):
        """
        Generate signature for client-side uploads
        """
        return cloudinary.utils.api_sign_request(
            params_to_sign,
            settings.CLOUDINARY_STORAGE['API_SECRET']
        )
    
    def get_upload_preset(self):
        """
        Get upload preset for client-side uploads
        (You must create this preset in Cloudinary dashboard)
        """
        return {
            'cloud_name': settings.CLOUDINARY_STORAGE['CLOUD_NAME'],
            'api_key': settings.CLOUDINARY_STORAGE['API_KEY'],
            'upload_preset': 'your_upload_preset'  # Replace with your preset name
        }
    
    def check_connection(self):
        """
        Test Cloudinary connection
        """
        try:
            result = cloudinary.api.ping()
            return {
                'connected': True,
                'status': result.get('status', 'ok')
            }
        except Exception as e:
            return {
                'connected': False,
                'error': str(e)
            }

# Singleton instance
cloudinary_service = CloudinaryService()