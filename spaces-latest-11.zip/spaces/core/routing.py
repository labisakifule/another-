from django.urls import re_path

def get_websocket_urlpatterns():
    from . import consumers as core_consumers
    from liveclass import consumers as liveclass_consumers
    
    return [
        re_path(r'ws/signal/$', core_consumers.SignalingConsumer.as_asgi()),
        re_path(r'ws/liveclass/(?P<class_id>[^/]+)/$', liveclass_consumers.LiveClassConsumer.as_asgi()),
    ]
