import secrets
from datetime import timedelta

from django.contrib.auth import get_user_model
from django.contrib.auth.hashers import make_password
from django.core.management.base import BaseCommand, CommandError
from django.utils import timezone

from core.models import APIToken
from trends.models import Institution, InstitutionMembership
from trends.constants import UserRole


class Command(BaseCommand):
    help = 'Create a scoped Hermes API token and print the raw token once.'

    def add_arguments(self, parser):
        parser.add_argument('--username', required=True)
        parser.add_argument('--institution', required=True, help='Institution UUID, subdomain, or exact name')
        parser.add_argument('--name', required=True)
        parser.add_argument('--scopes', required=True, help='Comma-separated scopes')
        parser.add_argument('--expires-days', type=int, default=90)

    def handle(self, *args, **options):
        User = get_user_model()
        try:
            user = User.objects.get(username=options['username'])
        except User.DoesNotExist:
            raise CommandError('User not found.')
        if not user.is_active or user.is_superuser:
            raise CommandError('User must be active and must not be a superuser.')
        value = options['institution']
        institution = Institution.objects.filter(subdomain=value).first() or Institution.objects.filter(name__iexact=value).first()
        if not institution:
            try:
                institution = Institution.objects.get(pk=value)
            except (Institution.DoesNotExist, ValueError):
                raise CommandError('Institution not found.')
        if not institution.is_active or not institution.is_approved:
            raise CommandError('Institution must be active and approved.')
        membership = InstitutionMembership.objects.filter(user=user, institution=institution, status=InstitutionMembership.STATUS_ACCEPTED).first()
        profile = getattr(user, 'profile', None)
        role_ok = bool(membership and membership.requested_role in {UserRole.INSTITUTION_ADMIN, UserRole.INSTITUTION_MANAGER, UserRole.STAFF, UserRole.TEACHER, UserRole.SETTER}) or bool(profile and profile.institution_id == institution.id and profile.institution_role in {UserRole.INSTITUTION_ADMIN, UserRole.INSTITUTION_MANAGER, UserRole.STAFF, UserRole.TEACHER, UserRole.SETTER}) or institution.admin_id == user.id
        if not role_ok:
            raise CommandError('User is not an active content-capable member of this institution.')
        scopes = [item.strip() for item in options['scopes'].split(',') if item.strip()]
        raw = 'sp_live_' + secrets.token_urlsafe(48)
        token = APIToken.objects.create(user=user, institution=institution, name=options['name'], key_prefix=raw[:24], hashed_token=make_password(raw), scopes=scopes, expires_at=timezone.now() + timedelta(days=options['expires_days']))
        self.stdout.write(self.style.SUCCESS(f'Created token {token.name} for {user.username} / {institution.name}.'))
        self.stdout.write('Copy this token now. It will not be shown again:')
        self.stdout.write(raw)
