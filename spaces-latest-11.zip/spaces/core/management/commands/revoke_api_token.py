from django.core.management.base import BaseCommand, CommandError
from django.contrib.auth import get_user_model
from django.utils import timezone

from core.models import APIToken


class Command(BaseCommand):
    help = 'Revoke a Hermes API token by username and name.'

    def add_arguments(self, parser):
        parser.add_argument('--username', required=True)
        parser.add_argument('--name', required=True)

    def handle(self, *args, **options):
        User = get_user_model()
        try:
            user = User.objects.get(username=options['username'])
        except User.DoesNotExist:
            raise CommandError('User not found.')
        count = APIToken.objects.filter(user=user, name=options['name'], revoked_at__isnull=True).update(revoked_at=timezone.now())
        if not count:
            raise CommandError('Active token not found.')
        self.stdout.write(self.style.SUCCESS('Token revoked.'))
