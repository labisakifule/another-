# classroom/settings/__init__.py

import os

# Determine which settings to use based on environment variable
ENV = os.environ.get('DJANGO_ENV', 'development')

if ENV == 'production':
    from .production import *
else:
    from .development import *