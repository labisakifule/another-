# classroom/settings/production.py

import os
from .base import *

# SECURITY WARNING: don't run with debug turned on in production!
DEBUG = False

# Production hosts
ALLOWED_HOSTS = [
    '167.99.10.12',
    'localhost',
    '127.0.0.1',
    '.spaces.com',  # Allows subdomains like app.spaces.com
]

# SQLite Database for Production
DATABASES = {
    'default': {
        'ENGINE': 'django.db.backends.sqlite3',
        'NAME': BASE_DIR / 'data/prod_db.sqlite3',
        'OPTIONS': {
            'timeout': 20,  # Wait 20 seconds for database lock
            'isolation_level': None,  # Autocommit mode for performance
        },
        'CONN_MAX_AGE': 60,  # Keep connections alive for 60 seconds
    }
}

# Email for production (example with Gmail)
EMAIL_BACKEND = 'django.core.mail.backends.smtp.EmailBackend'
EMAIL_HOST = os.environ.get('EMAIL_HOST', 'smtp.gmail.com')
EMAIL_PORT = int(os.environ.get('EMAIL_PORT', 587))
EMAIL_USE_TLS = True
EMAIL_HOST_USER = os.environ.get('EMAIL_HOST_USER', '')
EMAIL_HOST_PASSWORD = os.environ.get('EMAIL_HOST_PASSWORD', '')
DEFAULT_FROM_EMAIL = os.environ.get('DEFAULT_FROM_EMAIL', 'noreply@spaces.com')

# Cache - Redis for production
CACHES = {
    'default': {
        'BACKEND': 'django_redis.cache.RedisCache',
        'LOCATION': REDIS_URL,
        'OPTIONS': {
            'CLIENT_CLASS': 'django_redis.client.DefaultClient',
            'PARSER_CLASS': 'redis.connection.HiredisParser',
            'CONNECTION_POOL_CLASS': 'redis.BlockingConnectionPool',
            'CONNECTION_POOL_CLASS_KWARGS': {
                'max_connections': 50,
                'timeout': 20,
            },
            'MAX_CONNECTIONS': 1000,
            'PICKLE_VERSION': -1,
        },
        'KEY_PREFIX': 'spaces_prod',
        'TIMEOUT': 300,  # 5 minutes
    }
}

# Session storage - Redis for production
SESSION_ENGINE = 'django.contrib.sessions.backends.cache'
SESSION_CACHE_ALIAS = 'default'

# Static files for production - compressed and cached
STATICFILES_STORAGE = 'whitenoise.storage.CompressedManifestStaticFilesStorage'
WHITENOISE_USE_FINDERS = True
WHITENOISE_MANIFEST_STRICT = False
WHITENOISE_ROOT = STATIC_ROOT

# Security settings for production
SECURE_SSL_REDIRECT = False  # Set to True if using HTTPS
SESSION_COOKIE_SECURE = False  # Set to True if using HTTPS
CSRF_COOKIE_SECURE = False  # Set to True if using HTTPS
SESSION_COOKIE_HTTPONLY = True
SESSION_COOKIE_AGE = 86400  # 24 hours

# Security headers (if using HTTPS)
# SECURE_HSTS_SECONDS = 31536000  # 1 year
# SECURE_HSTS_INCLUDE_SUBDOMAINS = True
# SECURE_HSTS_PRELOAD = True
SECURE_CONTENT_TYPE_NOSNIFF = True
SECURE_BROWSER_XSS_FILTER = True
X_FRAME_OPTIONS = 'DENY'

# Determine log directory - try /var/log/spaces first, fallback to local
LOG_DIR = '/var/log/spaces'
if not os.path.exists(LOG_DIR):
    try:
        os.makedirs(LOG_DIR, exist_ok=True)
    except (OSError, PermissionError):
        # If we can't create it, use local log directory
        LOG_DIR = BASE_DIR / 'logs'
        try:
            os.makedirs(LOG_DIR, exist_ok=True)
        except OSError:
            # If we can't create local logs, use console only
            LOG_DIR = None

# Production logging - robust with fallbacks
LOGGING = {
    'version': 1,
    'disable_existing_loggers': False,
    'formatters': {
        'verbose': {
            'format': '{levelname} {asctime} {module} {process:d} {thread:d} {message}',
            'style': '{',
        },
        'simple': {
            'format': '{levelname} {asctime} {message}',
            'style': '{',
        },
    },
    'handlers': {
        'console': {
            'class': 'logging.StreamHandler',
            'formatter': 'simple',
        },
    },
    'root': {
        'handlers': ['console'],
        'level': 'INFO',
    },
    'loggers': {
        'django': {
            'handlers': ['console'],
            'level': 'INFO',
            'propagate': False,
        },
        'django.request': {
            'handlers': ['console'],
            'level': 'ERROR',
            'propagate': False,
        },
        'django.security': {
            'handlers': ['console'],
            'level': 'ERROR',
            'propagate': False,
        },
        'exams': {
            'handlers': ['console'],
            'level': 'INFO',
            'propagate': False,
        },
    },
}

# Add file handlers if log directory exists
if LOG_DIR:
    LOGGING['handlers']['file'] = {
        'class': 'logging.handlers.RotatingFileHandler',
        'filename': os.path.join(LOG_DIR, 'django.log'),
        'maxBytes': 1024 * 1024 * 10,  # 10MB
        'backupCount': 5,
        'formatter': 'verbose',
    }
    LOGGING['handlers']['error_file'] = {
        'class': 'logging.handlers.RotatingFileHandler',
        'filename': os.path.join(LOG_DIR, 'errors.log'),
        'maxBytes': 1024 * 1024 * 10,  # 10MB
        'backupCount': 5,
        'formatter': 'verbose',
        'level': 'ERROR',
    }
    LOGGING['root']['handlers'].append('file')
    LOGGING['loggers']['django']['handlers'].append('file')
    LOGGING['loggers']['django.request']['handlers'].append('error_file')
    LOGGING['loggers']['django.security']['handlers'].append('error_file')
    LOGGING['loggers']['exams']['handlers'].append('file')

# Admin email for error notifications
ADMINS = [
    ('Admin', os.environ.get('ADMIN_EMAIL', 'admin@spaces.com')),
]
SERVER_EMAIL = os.environ.get('SERVER_EMAIL', 'server@spaces.com')

# Production specific settings
PRODUCTION = True

# CSRF trusted origins
CSRF_TRUSTED_ORIGINS = ['http://167.99.10.12', 'http://localhost']


DEBUG = False
MEDIAMTX_HOST = '167.99.10.12'
MEDIAMTX_BASE_URL = f'http://{MEDIAMTX_HOST}:8889'

# Print startup banner
print("=" * 60)
print("🚀 Starting Spaces - PRODUCTION MODE")
print(f"🐍 Database: {DATABASES['default']['NAME']}")
print(f"🔧 Debug: {DEBUG}")
print(f"🌐 Allowed Hosts: {ALLOWED_HOSTS}")
if LOG_DIR:
    print(f"📋 Logs: {LOG_DIR}")
else:
    print("📋 Logs: Console only")
print("=" * 60)