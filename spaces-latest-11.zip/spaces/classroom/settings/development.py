from .base import *

# SECURITY WARNING: don't run with debug turned on in production!
import os

# Do not expose Django tracebacks or submitted form data on the public dev host.
DEBUG = os.getenv('SPACES_DEV_DEBUG', '0') == '1'

# Development hosts
ALLOWED_HOSTS = [
    'localhost',
    '127.0.0.1',
    '167.99.10.12',
    'spacesdev.duckdns.org',
    '.duckdns.org',
    'dev.spaces.167.99.10.12',
]

# CSRF Trusted Origins - CRITICAL for HTTPS
CSRF_TRUSTED_ORIGINS = [
    'https://spacesdev.duckdns.org',
    'https://*.duckdns.org',
    'http://localhost:8001',
    'http://127.0.0.1:8001',
    'http://dev.spaces.167.99.10.12:8001',
    'http://167.99.10.12:8001',
]

# SQLite Database for Development
DATABASES = {
    'default': {
        'ENGINE': 'django.db.backends.sqlite3',
        'NAME': BASE_DIR / 'data/dev_db.sqlite3',
        'OPTIONS': {
            'timeout': 30,
        },
    }
}

# Email backend - console output for development
EMAIL_BACKEND = 'django.core.mail.backends.console.EmailBackend'

# Development cache - local memory
CACHES = {
    'default': {
        'BACKEND': 'django.core.cache.backends.locmem.LocMemCache',
        'LOCATION': 'spaces-dev-cache',
    }
}

# Development logging - verbose console output
LOGGING = {
    'version': 1,
    'disable_existing_loggers': False,
    'formatters': {
        'verbose': {
            'format': '{levelname} {asctime} {module} {process:d} {thread:d} {message}',
            'style': '{',
        },
        'simple': {
            'format': '{levelname} {asctime} {message}',
            'style': '{',
        },
    },
    'handlers': {
        'console': {
            'class': 'logging.StreamHandler',
            'formatter': 'simple',
        },
    },
    'root': {
        'handlers': ['console'],
        'level': 'DEBUG',
    },
    'loggers': {
        'django': {
            'handlers': ['console'],
            'level': 'INFO',
            'propagate': False,
        },
        'django.db.backends': {
            'handlers': ['console'],
            'level': 'DEBUG',
            'propagate': False,
        },
        'exams': {
            'handlers': ['console'],
            'level': 'DEBUG',
            'propagate': False,
        },
    },
}

# Development specific settings
DEV_SERVER = True
INSTITUTION_BASE_DOMAIN = os.getenv('INSTITUTION_BASE_DOMAIN', 'spacesdev.duckdns.org')

# Static files for development
STATICFILES_STORAGE = 'django.contrib.staticfiles.storage.StaticFilesStorage'

# HTTPS/SSL Settings - Enable for DuckDNS HTTPS
SECURE_SSL_REDIRECT = True
SESSION_COOKIE_SECURE = True
CSRF_COOKIE_SECURE = True
SECURE_PROXY_SSL_HEADER = ('HTTP_X_FORWARDED_PROTO', 'https')

# CSRF Settings
CSRF_COOKIE_HTTPONLY = False
CSRF_USE_SESSIONS = False
CSRF_COOKIE_SAMESITE = 'Lax'

# Session Settings
SESSION_COOKIE_SAMESITE = 'Lax'
SESSION_COOKIE_AGE = 1209600

# Security Headers
SECURE_BROWSER_XSS_FILTER = True
SECURE_CONTENT_TYPE_NOSNIFF = True
X_FRAME_OPTIONS = 'DENY'

# MediaMTX Configuration (Development with HTTPS)
MEDIAMTX_HOST = 'spacesdev.duckdns.org'
MEDIAMTX_PORT = 8889
MEDIAMTX_BASE_URL = f'https://{MEDIAMTX_HOST}:{MEDIAMTX_PORT}'

# Show debug toolbar if installed
if DEBUG:
    try:
        import debug_toolbar
        INSTALLED_APPS.append('debug_toolbar')
        MIDDLEWARE.insert(0, 'debug_toolbar.middleware.DebugToolbarMiddleware')
        INTERNAL_IPS = [
            '127.0.0.1',
            '167.99.10.12',
            'spacesdev.duckdns.org',
        ]
    except ImportError:
        pass

# Print startup banner
print("=" * 60)
print("Starting Spaces - DEVELOPMENT MODE")
print(f"Database: {DATABASES['default']['NAME']}")
print(f"Debug: {DEBUG}")
print(f"Allowed Hosts: {ALLOWED_HOSTS}")
print(f"HTTPS Mode: {SECURE_SSL_REDIRECT}")
print(f"MediaMTX: {MEDIAMTX_BASE_URL}")
print("=" * 60)
