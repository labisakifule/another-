"""
Django settings for classroom project.
"""

import os
from pathlib import Path
from dotenv import load_dotenv

# Load environment variables from .env file
load_dotenv()

# Build paths inside the project like this: BASE_DIR / 'subdir'.
BASE_DIR = Path(__file__).resolve().parent.parent

# SECURITY WARNING: keep the secret key used in production secret!
SECRET_KEY = os.getenv('DJANGO_SECRET_KEY', 'django-insecure-default-key-change-this')

# SECURITY WARNING: don't run with debug turned on in production!
DEBUG = os.getenv('DEBUG', 'True') == 'True'

# Allow all hosts on Hugging Face
ALLOWED_HOSTS = ['*']

# ============================================
# AI MODELS OFFLINE CONFIGURATION (Optional - remove if not using ML)
# ============================================

# Local directories for offline AI models
SENTENCE_TRANSFORMERS_HOME = os.path.join(BASE_DIR, 'sentence_transformers')
NLTK_DATA = os.path.join(BASE_DIR, 'nltk_data')

# Create directories if they don't exist
os.makedirs(SENTENCE_TRANSFORMERS_HOME, exist_ok=True)
os.makedirs(NLTK_DATA, exist_ok=True)

# Set environment variables for offline models
os.environ['SENTENCE_TRANSFORMERS_HOME'] = SENTENCE_TRANSFORMERS_HOME
os.environ['NLTK_DATA'] = NLTK_DATA

# ============================================

# Application definition
INSTALLED_APPS = [
    'django.contrib.admin',
    'django.contrib.auth',
    'django.contrib.contenttypes',
    'django.contrib.sessions',
    'django.contrib.messages',
    'django.contrib.staticfiles',
    
    # Third-party apps
    'cloudinary',
    'cloudinary_storage',
    'crispy_forms',
    'crispy_tailwind',
    'channels',
    'django_countries',
    
    # Local apps
    'core',
    'exams',
    'study',
    'trends',
]

MIDDLEWARE = [
    'django.middleware.security.SecurityMiddleware',
    'whitenoise.middleware.WhiteNoiseMiddleware',
    'django.contrib.sessions.middleware.SessionMiddleware',
    'django.middleware.common.CommonMiddleware',
    'django.middleware.csrf.CsrfViewMiddleware',
    'django.contrib.auth.middleware.AuthenticationMiddleware',
    'django.contrib.messages.middleware.MessageMiddleware',
    'django.middleware.clickjacking.XFrameOptionsMiddleware',
    'classroom.middleware.NoCacheMiddleware',
    'trends.middleware.InstitutionMiddleware',
]

ROOT_URLCONF = 'classroom.urls'

TEMPLATES = [
    {
        'BACKEND': 'django.template.backends.django.DjangoTemplates',
        'DIRS': [BASE_DIR / 'templates'],
        'APP_DIRS': True,
        'OPTIONS': {
            'context_processors': [
                'django.template.context_processors.debug',
                'django.template.context_processors.request',
                'django.contrib.auth.context_processors.auth',
                'django.contrib.messages.context_processors.messages',
            ],
        },
    },
]

WSGI_APPLICATION = 'classroom.wsgi.application'
ASGI_APPLICATION = 'classroom.asgi.application'

# ============================================
# DATABASE - SQLITE (Persistent via Hugging Face Dataset backup)
# ============================================

# Ensure data directory exists
DATA_DIR = os.path.join(BASE_DIR, 'data')
os.makedirs(DATA_DIR, exist_ok=True)

DATABASES = {
    'default': {
        'ENGINE': 'django.db.backends.sqlite3',
        'NAME': os.path.join(DATA_DIR, 'db.sqlite3'),
    }
}

# Password validation
AUTH_PASSWORD_VALIDATORS = [
    {'NAME': 'django.contrib.auth.password_validation.UserAttributeSimilarityValidator'},
    {'NAME': 'django.contrib.auth.password_validation.MinimumLengthValidator'},
    {'NAME': 'django.contrib.auth.password_validation.CommonPasswordValidator'},
    {'NAME': 'django.contrib.auth.password_validation.NumericPasswordValidator'},
]

# Internationalization
LANGUAGE_CODE = 'en-us'
TIME_ZONE = 'Africa/Kampala'
USE_I18N = True
USE_TZ = True

# Static files (CSS, JavaScript, Images)
STATIC_URL = '/static/'
STATICFILES_DIRS = [BASE_DIR / 'static'] if (BASE_DIR / 'static').exists() else []
STATIC_ROOT = BASE_DIR / 'staticfiles'

# WhiteNoise for static files
STATICFILES_STORAGE = 'whitenoise.storage.CompressedManifestStaticFilesStorage'

# Cloudinary Configuration (loaded from .env)
CLOUDINARY_STORAGE = {
    'CLOUD_NAME': os.getenv('CLOUDINARY_CLOUD_NAME'),
    'API_KEY': os.getenv('CLOUDINARY_API_KEY'),
    'API_SECRET': os.getenv('CLOUDINARY_API_SECRET'),
    'SECURE': True,
    'MEDIA_TAG': 'media',
    'INVALID_VIDEO_ERROR_MESSAGE': 'Please upload a valid video file.',
    'EXCLUSIVE_PATTERNS': [
        'study_resources/',
        'resource_thumbnails/',
        'institution_logos/',
        'institution_banners/',
        'profile_pictures/',
    ]
}

# Use Cloudinary for media file storage
DEFAULT_FILE_STORAGE = 'cloudinary_storage.storage.MediaCloudinaryStorage'

# Custom user model
AUTH_USER_MODEL = 'trends.User'

# Crispy forms
CRISPY_ALLOWED_TEMPLATE_PACKS = 'tailwind'
CRISPY_TEMPLATE_PACK = 'tailwind'

# Redis / Channels - with fallback
REDIS_URL = os.getenv('REDIS_URL', 'redis://localhost:6379')

# Check if we should use Redis
USE_REDIS = os.getenv('USE_REDIS', 'False') == 'True' and not DEBUG

if USE_REDIS:
    CHANNEL_LAYERS = {
        'default': {
            'BACKEND': 'channels_redis.core.RedisChannelLayer',
            'CONFIG': {
                'hosts': [REDIS_URL],
            },
        },
    }
else:
    # Use in-memory channel layer for Hugging Face
    CHANNEL_LAYERS = {
        'default': {
            'BACKEND': 'channels.layers.InMemoryChannelLayer',
        },
    }

REDIS_EXAM_ATTEMPTS_PREFIX = 'exam_attempt:'
REDIS_GRADING_QUEUE_KEY = 'grading_queue'
REDIS_AUTO_SUBMIT_KEY = 'auto_submit'

# Default primary key field type
DEFAULT_AUTO_FIELD = 'django.db.models.BigAutoField'

# Login/Logout URLs
LOGIN_URL = 'login'
LOGIN_REDIRECT_URL = 'dashboard'
LOGOUT_REDIRECT_URL = 'login'

# Email settings (configure for production)
EMAIL_BACKEND = 'django.core.mail.backends.console.EmailBackend'

# Cloudinary global variable for templates
CLOUDINARY_CLOUD_NAME = os.getenv('CLOUDINARY_CLOUD_NAME')

# ============================================
# HUGGING FACE SPACES SPECIFIC SETTINGS
# ============================================

# CSRF Trust for Hugging Face Spaces
CSRF_TRUSTED_ORIGINS = [
    'https://*.hf.space',
    'http://*.hf.space',
    'https://*.huggingface.co',
    'http://localhost:7860',
]

# Security settings for production on Hugging Face
if not DEBUG:
    SECURE_SSL_REDIRECT = True
    SESSION_COOKIE_SECURE = True
    CSRF_COOKIE_SECURE = True
    SECURE_PROXY_SSL_HEADER = ('HTTP_X_FORWARDED_PROTO', 'https')

# Create necessary directories
for dir_path in [STATIC_ROOT, DATA_DIR]:
    os.makedirs(dir_path, exist_ok=True)

# Print startup info
print("=" * 50)
print("🚀 Starting Django on Hugging Face Spaces")
print(f"Debug mode: {DEBUG}")
print(f"Using channel layer: {CHANNEL_LAYERS['default']['BACKEND'].split('.')[-1]}")
print(f"Database: SQLite at {DATABASES['default']['NAME']}")
print("=" * 50)