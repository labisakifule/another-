# Nusu Academy S1 Term 1 Starter Notes

This package contains starter notes for the nine S1 Term 1 subjects and a Django management command that imports them as institution-only Study Materials created by Kasoma.

The notes are deliberately marked pending approval. They are curriculum-aligned starter notes, not a replacement for the school scheme of work or official NCDC verification.

Subjects included:
- Mathematics
- English
- Biology
- Chemistry
- Physics
- Geography
- History and Political Education
- General Science
- Physical Education

Install the overlay, then run:

`/root/spaces/venv/bin/python manage.py import_nusu_s1_term1_notes --settings=classroom.settings.development --institution "Nusu Academy" --created-by kasoma`

Use `--dry-run` first if desired. The command is idempotent for the same institution, creator, and material titles.
