NUSU ACADEMY TRENDS FIX
========================

This patch keeps the existing Django Trends model and pages. It adds:
- Africa/Kampala development timezone alignment.
- Subject, Topic, and Subtopic links on Trend records.
- Secondary Uganda topic catalog and selected subtopics.
- Reusable dated academic-term timetable generation.
- Automatic fixed-date and Easter public-holiday exclusions using the Python standard library.
- Optional school-specific closure dates through --holiday-file.
- Safe V2 replacement markers for repeated term imports.
- White, emerald, and restrained gold Trends/calendar presentation.

DEPLOYMENT
----------
Copy the archive contents into /root/spaces with the existing exclusions for data,
media, logs, and venv. Then run:

cd /root/spaces
Do not run pip or install packages for this patch. The app's existing environment is used as-is.
/root/spaces/venv/bin/python manage.py migrate --settings=classroom.settings.development
/root/spaces/venv/bin/python manage.py seed_nusu_curriculum --institution "Nusu Academy" --settings=classroom.settings.development

TERM GENERATION
---------------
Use --dry-run first. The dated mode automatically skips Saturdays, Sundays, fixed-date Ugandan public holidays, and Good Friday/Easter Monday. Add a JSON file for school-specific or variable religious closure dates.

/root/spaces/venv/bin/python manage.py import_nusu_timetables \
  --institution "Nusu Academy" \
  --source-dir /root/spaces/trends/data/nusu_timetables \
  --academic-year 2027 \
  --term "Term 1" \
  --start-date 2027-02-01 \
  --end-date 2027-05-07 \
  --holiday-file /root/spaces/config/nusu_closures_2027.json \
  --dry-run \
  --settings=classroom.settings.development

After reviewing the count, run the same command without --dry-run and add --replace.
The importer generates normal Trend records with subject/topic/subtopic links.

Example closure file:
{"holidays": ["2027-02-08", "2027-03-19"]}

For a weekly template only, omit --start-date, --end-date, --academic-year,
and --term. The old recurring-template behavior is retained.
