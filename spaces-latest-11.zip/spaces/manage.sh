#!/bin/bash

set -u

PROJECT_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
VENV_DIR="$PROJECT_DIR/venv"
PYTHON_BIN="$VENV_DIR/bin/python"
LOG_DIR="$PROJECT_DIR/logs"

mkdir -p "$LOG_DIR"

if [ ! -x "$PYTHON_BIN" ]; then
    echo "ERROR: Python virtual environment not found:"
    echo "$PYTHON_BIN"
    exit 1
fi

start_production() {
    echo "Starting Production Server on port 8000..."

    cd "$PROJECT_DIR" || exit 1

    export DJANGO_SETTINGS_MODULE=classroom.settings.production

    nohup "$PYTHON_BIN" -m daphne \
        -b 0.0.0.0 \
        -p 8000 \
        classroom.asgi:application \
        > "$LOG_DIR/production.log" 2>&1 &

    echo $! > "$LOG_DIR/production.pid"

    echo "Production server started on port 8000."
}

start_development() {
    echo "Starting Development Server on port 8001..."

    cd "$PROJECT_DIR" || exit 1

    export DJANGO_SETTINGS_MODULE=classroom.settings.development

    nohup "$PYTHON_BIN" -m daphne \
        -b 0.0.0.0 \
        -p 8001 \
        classroom.asgi:application \
        > "$LOG_DIR/development.log" 2>&1 &

    echo $! > "$LOG_DIR/development.pid"

    echo "Development server started on port 8001."
}

stop_all() {
    echo "Stopping application servers..."

    pkill -f "daphne.*8000" 2>/dev/null || true
    pkill -f "daphne.*8001" 2>/dev/null || true

    rm -f "$LOG_DIR/production.pid"
    rm -f "$LOG_DIR/development.pid"

    echo "Application servers stopped."
}

status() {
    echo "Server Status:"

    if [ -f "$LOG_DIR/development.pid" ] &&
       ps -p "$(cat "$LOG_DIR/development.pid")" > /dev/null 2>&1; then
        echo "  Development: Running"
        echo "  PID: $(cat "$LOG_DIR/development.pid")"
        echo "  Port: 8001"
    else
        echo "  Development: Stopped"
    fi

    if [ -f "$LOG_DIR/production.pid" ] &&
       ps -p "$(cat "$LOG_DIR/production.pid")" > /dev/null 2>&1; then
        echo "  Production: Running"
        echo "  PID: $(cat "$LOG_DIR/production.pid")"
        echo "  Port: 8000"
    else
        echo "  Production: Stopped"
    fi
}

case "${1:-}" in
    start)
        start_production
        ;;

    start-dev)
        start_development
        ;;

    stop)
        stop_all
        ;;

    restart)
        stop_all
        sleep 2
        start_production
        start_development
        ;;

    status)
        status
        ;;

    *)
        echo "Usage: $0 {start|start-dev|stop|restart|status}"
        exit 1
        ;;
esac


