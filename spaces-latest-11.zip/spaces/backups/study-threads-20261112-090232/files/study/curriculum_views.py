from django.contrib import messages
from django.contrib.auth.decorators import login_required
from django.http import Http404
from django.shortcuts import get_object_or_404, redirect, render
from django.urls import reverse
from django.views.decorators.http import require_POST
from django.utils import timezone
from trends.access import is_institution_staff
from .forms import LessonExerciseForm
from .models import LessonExercise, StudyResource, StudyUnit, StudyUnitMedia, StudyUnitProgress
from .management.commands.import_nusu_s1_term1_notes import markdown_to_html


def _ancestors_and_self(unit):
    nodes, current = [], unit
    while current:
        nodes.append(current)
        current = current.parent
    return nodes


def _subtree_ids(unit):
    ids, frontier = [unit.pk], [unit.pk]
    while frontier:
        frontier = list(StudyUnit.objects.filter(parent_id__in=frontier).values_list('pk', flat=True))
        ids.extend(frontier)
    return ids


def _creator_can_manage(user, unit):
    if not user.is_authenticated:
        return False
    if user.is_superuser or user.is_staff or unit.created_by_id == user.id:
        return True
    if is_institution_staff(user, unit.institution):
        return True
    return StudyResource.objects.filter(study_unit__in=_ancestors_and_self(unit), creator=user).exists()


def _visible_to(user, unit):
    root = unit
    while root.parent_id:
        root = root.parent
    resources = StudyResource.objects.filter(study_unit=root)
    if not resources.exists():
        return bool(user.is_authenticated and (user.is_staff or user.is_superuser or root.created_by_id == user.id))
    if user.is_authenticated and (user.is_staff or user.is_superuser or root.created_by_id == user.id):
        return True
    if resources.filter(access_level='public', members_only=False).exists():
        return True
    if user.is_authenticated and resources.filter(creator=user).exists():
        return True
    if user.is_authenticated:
        return resources.filter(institution__membership_requests__user=user, institution__membership_requests__status='accepted').exists()
    return False


def curriculum_unit(request, pk):
    unit = get_object_or_404(StudyUnit.objects.select_related('parent', 'institution', 'subject', 'education_level'), pk=pk)
    if not _visible_to(request.user, unit):
        raise Http404
    manager = _creator_can_manage(request.user, unit)
    if not manager and any(not node.is_published for node in _ancestors_and_self(unit)):
        raise Http404
    progress = None
    if request.user.is_authenticated:
        progress, _ = StudyUnitProgress.objects.get_or_create(user=request.user, unit=unit)
        if progress.status == 'not_started':
            progress.status = 'in_progress'
            progress.progress_percent = max(progress.progress_percent, 10)
            progress.save(update_fields=['status', 'progress_percent'])
    child_units = unit.children.all().order_by('sort_order', 'period_number', 'title')
    if not manager:
        child_units = child_units.filter(is_published=True)
    children = [(child, StudyUnitProgress.objects.filter(user=request.user, unit=child).first()
                 if request.user.is_authenticated else None) for child in child_units]
    resources = unit.resources.all().order_by('created_at')
    exercises = unit.exercises.select_related('resource').order_by('order', 'created_at')
    if request.user.is_authenticated and (request.user.is_staff or is_institution_staff(request.user, unit.institution)):
        attachable_resources = StudyResource.objects.filter(institution=unit.institution).exclude(study_unit=unit).order_by('title')[:200]
    elif request.user.is_authenticated:
        attachable_resources = StudyResource.objects.filter(creator=request.user).exclude(study_unit=unit).order_by('title')[:200]
    else:
        attachable_resources = StudyResource.objects.none()
    return render(request, 'study/curriculum_unit.html', {
        'unit': unit, 'progress': progress, 'children': children,
        'resources': resources, 'exercises': exercises, 'can_manage': manager,
        'media_items': unit.media.all(),
        'exercise_types': LessonExerciseForm().fields['template_type'].choices,
        'node_types': StudyUnit.NODE_TYPES,
        'unit_template_types': StudyUnit.TEMPLATE_CHOICES,
        'content_html': markdown_to_html(unit.content or ''),
        'attachable_resources': attachable_resources,
    })


@login_required
@require_POST
def curriculum_unit_save(request, pk=None):
    parent = get_object_or_404(StudyUnit, pk=request.POST.get('parent_id')) if request.POST.get('parent_id') else None
    if pk:
        unit = get_object_or_404(StudyUnit, pk=pk)
        if not _creator_can_manage(request.user, unit):
            raise Http404
    else:
        if not parent or not _creator_can_manage(request.user, parent):
            raise Http404
        unit = StudyUnit(institution=parent.institution, education_level=parent.education_level,
                         subject=parent.subject, topic=parent.topic, parent=parent,
                         term=parent.term, academic_year=parent.academic_year,
                         created_by=request.user, is_published=False)
    title = request.POST.get('title', '').strip()
    if not title:
        messages.error(request, 'A title is required.')
        return redirect(request.META.get('HTTP_REFERER', reverse('study:curriculum_unit', args=[parent.pk if parent else unit.pk])))
    node_type = request.POST.get('node_type', unit.node_type)
    if node_type not in {choice[0] for choice in StudyUnit.NODE_TYPES}:
        messages.error(request, 'Choose a valid curriculum node type.')
        return redirect(request.META.get('HTTP_REFERER', reverse('study:curriculum_unit', args=[parent.pk if parent else unit.pk])))
    unit.title = title
    unit.node_type = node_type
    template_type = request.POST.get('template_type', unit.template_type)
    if template_type not in {choice[0] for choice in StudyUnit.TEMPLATE_CHOICES}:
        messages.error(request, 'Choose a valid Study template.')
        return redirect(request.META.get('HTTP_REFERER', reverse('study:curriculum_unit', args=[parent.pk if parent else unit.pk])))
    unit.template_type = template_type
    unit.description = request.POST.get('description', '').strip()
    unit.content = request.POST.get('content', '').strip()
    try:
        unit.sort_order = max(1, min(999, int(request.POST.get('sort_order', unit.sort_order or 1))))
        number = request.POST.get('period_number', '').strip()
        unit.period_number = int(number) if number else None
    except ValueError:
        messages.error(request, 'Order and period number must be whole numbers.')
        return redirect(request.META.get('HTTP_REFERER', reverse('study:curriculum_unit', args=[parent.pk if parent else unit.pk])))
    unit.save()
    messages.success(request, 'Curriculum item saved. Its current publication state is unchanged; use the publish control when ready.')
    return redirect('study:curriculum_unit', pk=unit.pk)


@login_required
@require_POST
def curriculum_unit_delete(request, pk):
    unit = get_object_or_404(StudyUnit, pk=pk)
    if not _creator_can_manage(request.user, unit):
        raise Http404
    parent_id = unit.parent_id
    branch_ids = _subtree_ids(unit)
    if (StudyUnitProgress.objects.filter(unit_id__in=branch_ids).exists()
            or StudyResource.objects.filter(study_unit_id__in=branch_ids).exists()
            or LessonExercise.objects.filter(study_unit_id__in=branch_ids).exists()):
        messages.error(request, 'This branch contains learner progress or attached learning material. Move or unlink it first so nothing is lost.')
        return redirect('study:curriculum_unit', pk=unit.pk)
    unit.delete()
    messages.success(request, 'Curriculum item and its empty child branch removed.')
    return redirect('study:curriculum_unit', pk=parent_id) if parent_id else redirect('study:resource_list')


@login_required
@require_POST
def curriculum_unit_publish(request, pk):
    unit = get_object_or_404(StudyUnit, pk=pk)
    if not _creator_can_manage(request.user, unit):
        raise Http404
    unit.is_published = request.POST.get('publish') == '1'
    unit.save(update_fields=['is_published', 'updated_at'])
    messages.success(request, 'This item is now published.' if unit.is_published else 'This item is now a draft.')
    return redirect('study:curriculum_unit', pk=unit.pk)


@login_required
@require_POST
def curriculum_media_add(request, pk):
    unit = get_object_or_404(StudyUnit, pk=pk)
    if not _creator_can_manage(request.user, unit):
        raise Http404
    kind = request.POST.get('media_type')
    url = request.POST.get('url', '').strip()
    title = request.POST.get('title', '').strip()
    if kind not in {'audio', 'video', 'image', 'pdf', 'external'} or not url.startswith(('https://', 'http://')):
        messages.error(request, 'Choose a media type and enter a valid http(s) URL.')
    else:
        StudyUnitMedia.objects.create(unit=unit, media_type=kind, url=url, title=title,
                                      order=(unit.media.count() + 1))
        messages.success(request, 'Media added to this curriculum item.')
    return redirect('study:curriculum_unit', pk=unit.pk)


@login_required
@require_POST
def curriculum_media_delete(request, pk):
    media = get_object_or_404(StudyUnitMedia.objects.select_related('unit'), pk=pk)
    if not _creator_can_manage(request.user, media.unit):
        raise Http404
    unit_pk = media.unit_id
    media.delete()
    return redirect('study:curriculum_unit', pk=unit_pk)


@login_required
@require_POST
def curriculum_exercise_add(request, pk):
    unit = get_object_or_404(StudyUnit, pk=pk)
    if not _creator_can_manage(request.user, unit):
        raise Http404
    anchor = next((candidate.resources.first() for candidate in _ancestors_and_self(unit) if candidate.resources.exists()), None)
    if not anchor:
        messages.error(request, 'Attach a Study Resource to this branch before adding an exercise.')
        return redirect('study:curriculum_unit', pk=unit.pk)
    form = LessonExerciseForm(request.POST)
    if form.is_valid():
        exercise = form.save(commit=False)
        if form.errors:
            messages.error(request, 'Exercise details were invalid. Check the JSON fields.')
            return redirect('study:curriculum_unit', pk=unit.pk)
        exercise.resource = anchor
        exercise.study_unit = unit
        exercise.order = unit.exercises.count() + 1
        exercise.save()
        messages.success(request, 'Exercise added to this curriculum item.')
    else:
        messages.error(request, 'Exercise details were invalid. Reopen the form and check the JSON fields.')
    return redirect('study:curriculum_unit', pk=unit.pk)


@login_required
@require_POST
def curriculum_unit_complete(request, pk):
    unit = get_object_or_404(StudyUnit, pk=pk)
    if (not _visible_to(request.user, unit) or
            any(not node.is_published for node in _ancestors_and_self(unit))):
        raise Http404
    progress, _ = StudyUnitProgress.objects.get_or_create(user=request.user, unit=unit)
    progress.status = 'completed'
    progress.progress_percent = 100
    progress.completed_at = timezone.now()
    progress.last_opened_at = timezone.now()
    progress.save()
    parent = unit.parent
    while parent:
        eligible = parent.children.filter(is_published=True)
        values = [StudyUnitProgress.objects.filter(user=request.user, unit=child).values_list('progress_percent', flat=True).first() or 0 for child in eligible]
        average = int(sum(values) / len(values)) if values else 0
        row, _ = StudyUnitProgress.objects.get_or_create(user=request.user, unit=parent)
        row.progress_percent = average
        row.status = 'completed' if average == 100 else ('in_progress' if average else 'not_started')
        row.last_opened_at = timezone.now()
        if average == 100:
            row.completed_at = timezone.now()
        row.save()
        parent = parent.parent
    return redirect('study:curriculum_unit', pk=unit.pk)


@login_required
@require_POST
def curriculum_attach_resource(request, pk):
    unit = get_object_or_404(StudyUnit, pk=pk)
    if not _creator_can_manage(request.user, unit):
        raise Http404
    resource = get_object_or_404(StudyResource, pk=request.POST.get('resource_id'))
    if not (request.user.is_staff or resource.creator_id == request.user.id or
            (resource.institution_id and is_institution_staff(request.user, resource.institution))):
        raise Http404
    if resource.institution_id and resource.institution_id != unit.institution_id:
        messages.error(request, 'Attach resources only within the same institution. The original resource remains intact.')
    else:
        resource.study_unit = unit
        resource.save(update_fields=['study_unit'])
        messages.success(request, 'Existing resource attached here without re-uploading or changing its access settings.')
    return redirect('study:curriculum_unit', pk=unit.pk)


@login_required
@require_POST
def curriculum_root_create(request, resource_id):
    resource = get_object_or_404(StudyResource.objects.select_related('institution', 'education_level'), pk=resource_id)
    if not (request.user.is_staff or request.user.is_superuser or resource.creator_id == request.user.id or
            (resource.institution_id and is_institution_staff(request.user, resource.institution))):
        raise Http404
    if not resource.institution_id:
        messages.error(request, 'Assign this resource to an institution before creating an institutional curriculum thread.')
        return redirect('study:resource_detail', pk=resource.pk)
    subject = resource.subjects.first()
    root, created = StudyUnit.objects.get_or_create(
        institution=resource.institution, education_level=resource.education_level,
        subject=subject, parent=None, term='Term 1', title=resource.title,
        defaults={'node_type': 'subject', 'description': 'Draft curriculum thread for this Study Resource.',
                  'content': '', 'sort_order': 1, 'template_type': 'traditional',
                  'is_published': False, 'created_by': request.user},
    )
    if not resource.study_unit_id:
        resource.study_unit = root
        resource.save(update_fields=['study_unit'])
    messages.success(request, 'Draft curriculum thread created. Add topics, subtopics, and periods, then publish when ready.')
    return redirect('study:curriculum_unit', pk=root.pk)
