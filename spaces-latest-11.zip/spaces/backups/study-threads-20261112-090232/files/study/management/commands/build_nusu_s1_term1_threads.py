import re
from pathlib import Path
from django.core.management.base import BaseCommand, CommandError
from django.db import transaction
from django.conf import settings
from trends.models import Institution, EducationLevel, User
from study.models import StudyResource, StudyUnit
from study.management.commands.import_nusu_s1_term1_notes import SUBJECTS

TOPIC_RE = re.compile(r'^#{1,3}\s*((?:Topic|Unit)\s+\d+\s*:[^\n]+)$', re.I | re.M)
SECTION_RE = re.compile(r'^(#{2,6})\s+(.+)$', re.M)
BOILERPLATE = {
    'big idea', 'learning objectives', 'objectives', 'key terms', 'suggested activities',
    'activities', 'activities and assessment evidence', 'learner-friendly explanation',
    'proposed school sequence', 'quick review', 'short review', 'check your understanding',
    'competency', 'evidence of learning', 'learning activities', 'references',
}


def _is_subtopic(match):
    title = match.group(2).strip()
    normalized = re.sub(r'[*_`]', '', title).strip().lower()
    return bool(re.match(r'^\d+(?:\.\d+)+\b', title)) or (len(match.group(1)) >= 3 and normalized not in BOILERPLATE)


def _unit(parent, defaults, title, node_type):
    return StudyUnit.objects.get_or_create(
        institution=defaults['institution'], education_level=defaults['education_level'],
        subject=defaults['subject'], parent=parent, term='Term 1', title=title,
        defaults={**defaults, 'node_type': node_type},
    )


class Command(BaseCommand):
    help = 'Build nested topic/subtopic/period threads from existing Nusu S1 Term 1 notes without replacing the source notes.'

    def add_arguments(self, parser):
        parser.add_argument('--institution', default='Nusu academy')
        parser.add_argument('--created-by', default='Kasoma')
        parser.add_argument('--notes-dir', default='')
        parser.add_argument('--dry-run', action='store_true')

    @transaction.atomic
    def handle(self, *args, **opts):
        institution = Institution.objects.filter(name__iexact=opts['institution']).first()
        creator = User.objects.filter(username__iexact=opts['created_by']).first()
        if not institution or not creator:
            raise CommandError('The selected institution or creator was not found; no curriculum items were created.')
        level = EducationLevel.objects.filter(institution_level=institution, name__iexact='S1').first()
        if not level:
            raise CommandError('The institution-owned S1 level was not found; refusing to use a shared level.')
        notes_dir = Path(opts['notes_dir'] or (Path(settings.BASE_DIR) / 'study' / 'data' / 'nusu_s1_term1'))
        if not notes_dir.is_dir():
            raise CommandError(f'Notes folder is missing: {notes_dir}')
        made = updated = 0
        for filename, subject_name in SUBJECTS.items():
            source = notes_dir / filename
            if not source.exists():
                raise CommandError(f'Missing note source: {source}')
            resource = StudyResource.objects.filter(
                creator=creator, institution=institution, education_level=level,
                title__icontains=subject_name,
            ).order_by('created_at').first()
            if not resource:
                raise CommandError(f'Existing Kasoma resource not found for {subject_name}; no new resource will be fabricated.')
            subject = resource.subjects.filter(education_level=level).first()
            if not subject:
                raise CommandError(f'The existing resource has no institution-owned {subject_name} subject.')
            raw = source.read_text(encoding='utf-8')
            matches = list(TOPIC_RE.finditer(raw))
            if not matches:
                raise CommandError(f'No Topic/Unit headings found in {source.name}.')
            public = resource.access_level == 'public' and not resource.members_only
            if opts['dry_run']:
                self.stdout.write(
                    f'PREVIEW {subject_name}: access={resource.access_level}, members_only={resource.members_only}, '
                    f'approved={resource.is_approved}, nested_thread_published={public}'
                )
                if resource.members_only:
                    self.stdout.write(self.style.WARNING(
                        f'  {subject_name} will remain member-restricted; no visibility setting will be changed.'
                    ))
            root_title = f'{subject_name} — Term 1'
            existing_root = resource.study_unit
            if existing_root and (existing_root.institution_id != institution.id or existing_root.subject_id != subject.id):
                raise CommandError(f'Resource {resource.pk} is already attached to a different curriculum branch.')
            root_defaults = {
                    'institution': institution, 'education_level': level, 'subject': subject,
                    'topic': None, 'parent': None, 'term': 'Term 1', 'academic_year': None,
                    'title': root_title, 'node_type': 'subject', 'sort_order': list(SUBJECTS).index(filename) + 1,
                    'description': 'Nusu Academy Senior One Term 1 subject thread. Existing source package is preserved as a reference.',
                    'content': '', 'template_type': 'traditional', 'is_published': public,
                    'created_by': creator,
                }
            if existing_root:
                root = existing_root
                created = False
            else:
                root, created = StudyUnit.objects.get_or_create(
                    institution=institution, education_level=level, subject=subject,
                    parent=None, term='Term 1', title=root_title,
                    defaults={key: value for key, value in root_defaults.items() if key not in {'institution', 'education_level', 'subject', 'parent', 'term', 'title'}},
                )
            resource.study_unit = root
            resource.save(update_fields=['study_unit'])
            made += int(created)
            updated += int(not created)
            # The existing period seeder made top-level curriculum-topic nodes.
            # Reparent those rows under the subject root instead of creating a
            # second flat path; primary keys and learner progress are retained.
            prior_topics = StudyUnit.objects.filter(
                institution=institution, education_level=level, subject=subject,
                parent__isnull=True, term='Term 1', topic__isnull=False,
            ).exclude(pk=root.pk).order_by('sort_order', 'period_number', 'title')
            for prior_index, prior in enumerate(prior_topics, start=1):
                prior.parent = root
                prior.node_type = 'topic'
                prior.sort_order = prior_index
                prior.save(update_fields=['parent', 'node_type', 'sort_order', 'updated_at'])
                updated += 1
            for index, match in enumerate(matches):
                end = matches[index + 1].start() if index + 1 < len(matches) else len(raw)
                heading = match.group(1).strip()
                title = re.sub(r'^Topic\s+\d+\s*:\s*|^Unit\s+\d+\s*:\s*', '', heading, flags=re.I).strip()
                count_match = re.search(r'\b(\d{1,2})\s+periods?\b', title, re.I)
                title = re.split(r'\s+[—–]\s+', title, maxsplit=1)[0].strip()
                body_start = match.end()
                body = raw[body_start:end].strip()
                all_sections = list(SECTION_RE.finditer(body))
                submatches = [m for m in all_sections if _is_subtopic(m)]
                topic, made_now = _unit(root, {
                    'institution': institution, 'education_level': level, 'subject': subject,
                    'topic': None, 'academic_year': None, 'created_by': creator,
                    'is_published': public, 'template_type': 'traditional',
                    'description': 'Topic from the existing subject notes. Use the periods below to distribute learning and add period-specific teaching notes.',
                    'content': '',
                }, title, 'topic')
                topic.sort_order = index + 1
                topic.save(update_fields=['sort_order'])
                made += int(made_now); updated += int(not made_now)
                if submatches:
                    for sub_index, submatch in enumerate(submatches):
                        sub_end = submatches[sub_index + 1].start() if sub_index + 1 < len(submatches) else len(body)
                        sub_title = submatch.group(2).strip()
                        sub_content = body[submatch.end():sub_end].strip()
                        sub, sub_made = _unit(topic, {
                            'institution': institution, 'education_level': level, 'subject': subject,
                            'topic': None, 'academic_year': None, 'created_by': creator,
                            'is_published': public, 'template_type': 'traditional',
                            'description': 'Subtopic from the existing package. Add a period plan and extra notes where needed.',
                            'content': sub_content,
                        }, sub_title, 'subtopic')
                        sub.sort_order = sub_index + 1
                        if not sub.content:
                            sub.content = sub_content
                            sub.save(update_fields=['sort_order', 'content'])
                        else:
                            sub.save(update_fields=['sort_order'])
                        made += int(sub_made); updated += int(not sub_made)
                    if not topic.content:
                        topic.content = body[:submatches[0].start()].strip()
                        topic.save(update_fields=['content'])
                else:
                    if not topic.content:
                        topic.content = body
                        topic.save(update_fields=['content'])
                periods = int(count_match.group(1)) if count_match else 1
                periods = min(max(periods, 1), 40)
                for period_number in range(1, periods + 1):
                    period_title = f'Period {period_number}'
                    period, period_made = _unit(topic, {
                        'institution': institution, 'education_level': level, 'subject': subject,
                        'topic': None, 'academic_year': None, 'created_by': creator,
                        'is_published': public, 'template_type': 'traditional',
                        'description': 'Suggested planning task: choose one concept or activity from this topic, teach it with an example or demonstration, give learners a short practice task, and check their understanding. Adapt the sequence to the school timetable. The period notes area is intentionally blank for the creator.',
                        'content': '', 'period_number': period_number,
                    }, period_title, 'period')
                    period.sort_order = period_number
                    if not period.description:
                        period.description = 'Suggested planning task: choose one concept or activity from this topic, teach it with an example or demonstration, give learners a short practice task, and check their understanding. Adapt the sequence to the school timetable. The period notes area is intentionally blank for the creator.'
                        period.save(update_fields=['sort_order', 'description'])
                    else:
                        period.save(update_fields=['sort_order'])
                    made += int(period_made); updated += int(not period_made)
        self.stdout.write(self.style.SUCCESS(f'Nested thread pass complete: {made} new items, {updated} existing items refreshed/linked. Original Study Resources, files, and visibility fields were not changed.'))
        if opts['dry_run']:
            transaction.set_rollback(True)
            self.stdout.write('Dry run only: all database changes rolled back.')
