import uuid
from django.db import models
from django.utils.translation import gettext_lazy as _
from django.conf import settings
from cloudinary.models import CloudinaryField
from trends.models import Subject, Topic, EducationLevel, SkillDomain
from trends.constants import AccessLevel
from .constants import ResourceType, UIDPrefix
import cloudinary
import cloudinary.uploader

User = settings.AUTH_USER_MODEL


class StudyResource(models.Model):
    id = models.UUIDField(primary_key=True, default=uuid.uuid4, editable=False)
    title = models.CharField(_('title'), max_length=200)
    description = models.TextField(_('description'))
    resource_type = models.CharField(
        _('resource type'),
        max_length=20,
        choices=ResourceType.CHOICES,
        default=ResourceType.TEXT
    )
    file = CloudinaryField(
        'file',
        resource_type='auto',
        folder='study_resources/',
        blank=True,
        null=True
    )
    content = models.TextField(_('content'), blank=True)
    creator = models.ForeignKey(
        User,
        on_delete=models.CASCADE,
        related_name='study_resources'
    )
    institution = models.ForeignKey(
        'trends.Institution', on_delete=models.SET_NULL, null=True, blank=True,
        related_name='study_resources'
    )
    members_only = models.BooleanField(default=False, db_index=True)
    created_at = models.DateTimeField(_('created at'), auto_now_add=True)
    subjects = models.ManyToManyField(Subject, blank=True)
    view_count = models.PositiveIntegerField(default=0, help_text="Number of times this resource has been viewed")
    topics = models.ManyToManyField(Topic, blank=True)
    access_level = models.CharField(
        _('access level'),
        max_length=20,
        choices=AccessLevel.ACCESS_LEVEL_CHOICES,
        default=AccessLevel.PUBLIC
    )
    access_cost = models.PositiveIntegerField(
        _('access cost'),
        default=0
    )
    is_approved = models.BooleanField(default=True, db_index=True)
    education_level = models.ForeignKey(
        'trends.EducationLevel',
        on_delete=models.SET_NULL,
        null=True,
        blank=True,
        related_name='study_resources'
    )
    skill_domains = models.ManyToManyField(
        SkillDomain,
        blank=True,
    )
    study_unit = models.ForeignKey('StudyUnit', on_delete=models.SET_NULL, null=True, blank=True, related_name='resources')
    thumbnail = CloudinaryField(
        'thumbnail',
        folder='resource_thumbnails/',
        blank=True,
        null=True,
        transformation=[
            {'width': 400, 'height': 300, 'crop': 'fill'},
            {'quality': 'auto'},
            {'fetch_format': 'auto'}
        ]
    )
    transcript = models.TextField(
        _('transcript'),
        blank=True
    )
    duration = models.PositiveIntegerField(
        _('duration (seconds)'),
        blank=True,
        null=True
    )

    def __str__(self):
        return self.title

    @property
    def uid(self):
        return f"{UIDPrefix.RESOURCE}-{str(self.id)[:7]}"

    def get_duration_display(self):
        if not self.duration:
            return None
        minutes = self.duration // 60
        seconds = self.duration % 60
        return f"{minutes}:{seconds:02d}"

    def generate_thumbnail(self):
        """
        Generate thumbnail for video resources using Cloudinary
        """
        if self.resource_type == ResourceType.VIDEO and self.file and not self.thumbnail:
            try:
                public_id = self.file.public_id
                thumbnail_url = cloudinary.CloudinaryVideo(public_id).video_thumbnail(
                    width=400,
                    height=300,
                    crop='fill',
                    start_offset='2'
                )
                result = cloudinary.uploader.upload(
                    thumbnail_url,
                    folder='resource_thumbnails/',
                    public_id=f"{public_id}_thumb",
                    overwrite=True,
                    transformation=[
                        {'width': 400, 'height': 300, 'crop': 'fill'},
                        {'quality': 'auto'},
                        {'fetch_format': 'auto'}
                    ]
                )
                self.thumbnail = result['public_id']
                return True
            except Exception as e:
                print(f"Error generating thumbnail: {e}")
                return False
        return False

    def clean(self):
        """Add validation logic if needed"""
        pass


class LessonExercise(models.Model):
    resource = models.ForeignKey(StudyResource, on_delete=models.CASCADE, related_name='exercises')
    study_unit = models.ForeignKey('StudyUnit', on_delete=models.SET_NULL, null=True, blank=True, related_name='exercises')
    order = models.PositiveSmallIntegerField(default=1)
    title = models.CharField(max_length=200, default='Practice this lesson')
    instructions = models.TextField(blank=True)
    questions = models.JSONField(default=list, blank=True)
    template_type = models.CharField(max_length=30, default='guided', choices=[('traditional', 'Traditional questions'), ('guided', 'Guided concept practice'), ('calculation', 'Calculation practice'), ('diagram', 'Diagram labelling'), ('reading', 'Reading practice'), ('practical', 'Practical activity')])
    concept = models.TextField(blank=True)
    mastery_threshold = models.PositiveSmallIntegerField(default=70)
    guided_steps = models.JSONField(default=list, blank=True)
    template_config = models.JSONField(default=dict, blank=True)
    marking_mode = models.CharField(max_length=20, choices=[('AUTO', 'Auto-marked'), ('TEACHER', 'Submit to teacher')], default='AUTO')
    created_at = models.DateTimeField(auto_now_add=True)
    updated_at = models.DateTimeField(auto_now=True)
    def __str__(self):
        return f'{self.title} · {self.resource.title}'


class LessonExerciseSubmission(models.Model):
    SUBMITTED = 'submitted'; MARKED = 'marked'
    STATUS_CHOICES = [(SUBMITTED, 'Submitted'), (MARKED, 'Marked')]
    exercise = models.ForeignKey(LessonExercise, on_delete=models.CASCADE, related_name='submissions')
    student = models.ForeignKey(User, on_delete=models.CASCADE, related_name='lesson_exercise_submissions')
    answers = models.JSONField(default=dict, blank=True)
    status = models.CharField(max_length=20, choices=STATUS_CHOICES, default=SUBMITTED)
    score = models.FloatField(null=True, blank=True)
    feedback = models.TextField(blank=True)
    reviewed_by = models.ForeignKey(User, on_delete=models.SET_NULL, null=True, blank=True, related_name='reviewed_lesson_submissions')
    submitted_at = models.DateTimeField(auto_now_add=True)
    reviewed_at = models.DateTimeField(null=True, blank=True)


class StudyResourceProgress(models.Model):
    NOT_STARTED = 'not_started'
    IN_PROGRESS = 'in_progress'
    COMPLETED = 'completed'
    NEEDS_REVIEW = 'needs_review'
    STATUS_CHOICES = [
        (NOT_STARTED, 'Not started'),
        (IN_PROGRESS, 'In progress'),
        (COMPLETED, 'Completed'),
        (NEEDS_REVIEW, 'Needs review'),
    ]
    user = models.ForeignKey(User, on_delete=models.CASCADE, related_name='study_resource_progress')
    resource = models.ForeignKey(StudyResource, on_delete=models.CASCADE, related_name='learner_progress')
    status = models.CharField(max_length=20, choices=STATUS_CHOICES, default=NOT_STARTED, db_index=True)
    progress_percent = models.PositiveSmallIntegerField(default=0)
    views = models.PositiveIntegerField(default=0)
    exercises_attempted = models.PositiveIntegerField(default=0)
    exercises_completed = models.PositiveIntegerField(default=0)
    average_score = models.FloatField(null=True, blank=True)
    first_opened_at = models.DateTimeField(null=True, blank=True)
    last_opened_at = models.DateTimeField(null=True, blank=True)
    completed_at = models.DateTimeField(null=True, blank=True)
    updated_at = models.DateTimeField(auto_now=True)

    class Meta:
        constraints = [models.UniqueConstraint(fields=['user', 'resource'], name='unique_study_resource_progress')]
        ordering = ['-updated_at']
        indexes = [models.Index(fields=['user', 'status']), models.Index(fields=['resource', 'status'])]

    def __str__(self):
        return f'{self.user} — {self.resource} ({self.progress_percent}%)'

class StudyUnit(models.Model):
    TEMPLATE_CHOICES = [('traditional', 'Traditional material'), ('guided', 'Guided lesson'), ('calculation', 'Calculation lesson'), ('diagram', 'Diagram lesson'), ('reading', 'Reading lesson'), ('practical', 'Practical lesson'), ('media', 'Mixed media lesson')]
    NODE_TYPES = [('subject', 'Subject'), ('topic', 'Topic'), ('subtopic', 'Subtopic'), ('period', 'Period / lesson'), ('section', 'Section')]
    institution = models.ForeignKey('trends.Institution', on_delete=models.CASCADE, related_name='study_units')
    education_level = models.ForeignKey('trends.EducationLevel', on_delete=models.SET_NULL, null=True, blank=True, related_name='study_units')
    subject = models.ForeignKey('trends.Subject', on_delete=models.SET_NULL, null=True, blank=True, related_name='study_units')
    topic = models.ForeignKey('trends.Topic', on_delete=models.SET_NULL, null=True, blank=True, related_name='study_units')
    parent = models.ForeignKey('self', on_delete=models.CASCADE, null=True, blank=True, related_name='children')
    academic_year = models.PositiveSmallIntegerField(null=True, blank=True)
    term = models.CharField(max_length=20, default='Term 1')
    period_number = models.PositiveSmallIntegerField(null=True, blank=True)
    title = models.CharField(max_length=200)
    node_type = models.CharField(max_length=20, choices=NODE_TYPES, default='period', db_index=True)
    description = models.TextField(blank=True)
    content = models.TextField(blank=True)
    sort_order = models.PositiveSmallIntegerField(default=1, db_index=True)
    template_type = models.CharField(max_length=30, choices=TEMPLATE_CHOICES, default='traditional')
    dependency_required = models.BooleanField(default=False)
    is_published = models.BooleanField(default=False, db_index=True)
    created_by = models.ForeignKey(settings.AUTH_USER_MODEL, on_delete=models.SET_NULL, null=True, related_name='created_study_units')
    created_at = models.DateTimeField(auto_now_add=True)
    updated_at = models.DateTimeField(auto_now=True)
    class Meta:
        ordering = ['sort_order', 'period_number', 'title']
        indexes = [models.Index(fields=['institution', 'education_level', 'term']), models.Index(fields=['parent', 'period_number'])]
    def __str__(self):
        return self.title
    @property
    def is_period(self):
        return self.period_number is not None

class StudyUnitMedia(models.Model):
    MEDIA_CHOICES = [('audio', 'Audio'), ('video', 'Video'), ('image', 'Image'), ('pdf', 'PDF'), ('external', 'External link')]
    unit = models.ForeignKey(StudyUnit, on_delete=models.CASCADE, related_name='media')
    media_type = models.CharField(max_length=20, choices=MEDIA_CHOICES)
    title = models.CharField(max_length=200, blank=True)
    url = models.URLField(max_length=1000)
    order = models.PositiveSmallIntegerField(default=1)
    class Meta:
        ordering = ['order', 'id']

class StudyUnitProgress(models.Model):
    STATUS_CHOICES = [('not_started', 'Not started'), ('in_progress', 'In progress'), ('completed', 'Completed'), ('needs_review', 'Needs review')]
    user = models.ForeignKey(settings.AUTH_USER_MODEL, on_delete=models.CASCADE, related_name='study_unit_progress')
    unit = models.ForeignKey(StudyUnit, on_delete=models.CASCADE, related_name='learner_progress')
    status = models.CharField(max_length=20, choices=STATUS_CHOICES, default='not_started', db_index=True)
    progress_percent = models.PositiveSmallIntegerField(default=0)
    last_opened_at = models.DateTimeField(null=True, blank=True)
    completed_at = models.DateTimeField(null=True, blank=True)
    class Meta:
        constraints = [models.UniqueConstraint(fields=['user', 'unit'], name='unique_study_unit_progress')]
        indexes = [models.Index(fields=['user', 'status']), models.Index(fields=['unit', 'status'])]

class ResourceCategory(models.Model):
    id = models.UUIDField(primary_key=True, default=uuid.uuid4, editable=False)
    name = models.CharField(_('name'), max_length=100)
    description = models.TextField(_('description'), blank=True)

    def __str__(self):
        return self.name

    @property
    def uid(self):
        return f"{UIDPrefix.CATEGORY}-{str(self.id)[:7]}"


class ResourceBookmark(models.Model):
    id = models.UUIDField(primary_key=True, default=uuid.uuid4, editable=False)
    user = models.ForeignKey(
        User,
        on_delete=models.CASCADE,
        related_name='resource_bookmarks'
    )
    resource = models.ForeignKey(
        StudyResource,
        on_delete=models.CASCADE,
        related_name='bookmarks'
    )
    created_at = models.DateTimeField(_('created at'), auto_now_add=True)

    class Meta:
        unique_together = [('user', 'resource')]

    def __str__(self):
        return f"{self.user.username} bookmarked {self.resource.title}"

    @property
    def uid(self):
        return f"{UIDPrefix.BOOKMARK}-{str(self.id)[:7]}"



class PassPaper(models.Model):
    """
    Past exam papers for student practice and reference
    """
    id = models.UUIDField(primary_key=True, default=uuid.uuid4, editable=False)
    title = models.CharField(max_length=200)
    description = models.TextField(blank=True)
    
    # File storage on Cloudinary
    file = CloudinaryField(
        'file',
        resource_type='auto',  # Auto-detect PDF, TXT, etc.
        folder='pass_papers/',
        null=True,
        blank=True
    )
    
    # Metadata
    subject = models.ForeignKey(Subject, on_delete=models.CASCADE)
    education_level = models.ForeignKey(EducationLevel, on_delete=models.CASCADE)
    year = models.IntegerField(help_text="Year of the exam")
    term = models.CharField(max_length=20, choices=[
        ('TERM1', 'Term 1'),
        ('TERM2', 'Term 2'),
        ('TERM3', 'Term 3'),
        ('YEARLY', 'Yearly'),
    ], default='YEARLY')
    
    # Paper type
    paper_type = models.CharField(max_length=20, choices=[
        ('QUESTION', 'Question Paper'),
        ('MARKING_SCHEME', 'Marking Scheme'),
        ('BOTH', 'Question Paper + Marking Scheme'),
    ], default='QUESTION')
    
    # Statistics
    download_count = models.PositiveIntegerField(default=0)
    view_count = models.PositiveIntegerField(default=0)
    
    # Timestamps
    uploaded_by = models.ForeignKey(User, on_delete=models.SET_NULL, null=True)
    uploaded_at = models.DateTimeField(auto_now_add=True)
    updated_at = models.DateTimeField(auto_now=True)
    
    # Access control
    is_public = models.BooleanField(default=True)
    requires_credits = models.PositiveIntegerField(default=0)
    
    class Meta:
        ordering = ['-year', 'subject__name']
    
    def __str__(self):
        return f"{self.subject.name} - {self.year} ({self.get_term_display()})"
    
    @property
    def uid(self):
        return f"pp-{str(self.id)[:7]}"
    
    @property
    def file_url(self):
        """Get optimized Cloudinary URL"""
        if self.file:
            return self.file.url
        return None
    
    @property
    def thumbnail_url(self):
        """Generate thumbnail for PDFs"""
        if self.file and self.file.resource_type == 'raw' and self.file.format == 'pdf':
            # Cloudinary can generate PDF thumbnails
            return self.file.build_url(format='jpg', page=1, width=200, height=280, crop='fill')
        return None
    
    def increment_download(self):
        self.download_count += 1
        self.save(update_fields=['download_count'])        
