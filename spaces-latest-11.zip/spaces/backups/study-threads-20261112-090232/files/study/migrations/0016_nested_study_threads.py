from django.db import migrations, models
import django.db.models.deletion


class Migration(migrations.Migration):
    dependencies = [('study', '0015_studyunit_indexes')]

    operations = [
        migrations.AddField(
            model_name='studyunit', name='node_type',
            field=models.CharField(choices=[('subject', 'Subject'), ('topic', 'Topic'), ('subtopic', 'Subtopic'), ('period', 'Period / lesson'), ('section', 'Section')], db_index=True, default='period', max_length=20),
        ),
        migrations.AddField(model_name='studyunit', name='description', field=models.TextField(blank=True)),
        migrations.AddField(model_name='studyunit', name='content', field=models.TextField(blank=True)),
        migrations.AddField(
            model_name='studyunit', name='sort_order',
            field=models.PositiveSmallIntegerField(db_index=True, default=1),
        ),
        migrations.AlterModelOptions(name='studyunit', options={'ordering': ['sort_order', 'period_number', 'title']}),
        migrations.AddField(
            model_name='lessonexercise', name='study_unit',
            field=models.ForeignKey(blank=True, null=True, on_delete=django.db.models.deletion.SET_NULL, related_name='exercises', to='study.studyunit'),
        ),
        migrations.AddField(model_name='lessonexercise', name='order', field=models.PositiveSmallIntegerField(default=1)),
    ]
