from django.shortcuts import render, redirect, get_object_or_404
from django.contrib.auth import login, logout, authenticate
from django.contrib.auth.decorators import login_required
from django.contrib import messages
from django.http import JsonResponse, HttpResponse
from django.contrib.admin.views.decorators import staff_member_required
from django.db.models import Count, Q
from django.db.models.functions import TruncDay, TruncMonth
from django.utils import timezone
from datetime import timedelta
from django.core.mail import send_mail
from django.core.paginator import Paginator
from django.core.management import call_command
from io import StringIO
from tempfile import NamedTemporaryFile
from pathlib import Path
from django.conf import settings
from urllib.parse import quote


# Your local imports
from .forms import *
from .models import *
from .constants import UserRole

# For exam and study models
from exams.models import ExamAttempt, ExamSet
from study.models import StudyResource
from liveclass.models import LiveClass
from core.models import RecommendationEvent
from core.models import Notification
from core.notifications import notify_user
from .decorators import staff_required, can_promote_to_teacher
from .access import visible_trends, can_edit_trend, is_institution_admin, is_institution_staff, user_level_ids
from .approval import submit_for_institution_approval, review_approval
from .profile_badges import get_role_badge
from .template_catalog import get_template, get_templates

from django.http import JsonResponse
from django.views.decorators.csrf import csrf_exempt
from django.views.decorators.http import require_http_methods
from django.utils import timezone
import json
from django.conf import settings

# This is the ONLY User definition you need
from django.contrib.auth import get_user_model
User = get_user_model()




# ============================================================
# HEALTH CHECK - Standalone HTML Page
# ============================================================
@csrf_exempt
def health_check(request):
    """
    Health check page for monitoring services like UptimeRobot.
    Returns a styled HTML page with system status.
    """
    if request.method == 'HEAD':
        # For lightweight keep-alive pings
        response = HttpResponse()
        response['Cache-Control'] = 'no-cache, no-store, must-revalidate'
        response['X-Health-Status'] = 'ok'
        return response
    
    # For GET requests - render the template
    context = {
        'environment': getattr(settings, 'ENVIRONMENT', 'Production'),
        'timestamp': timezone.now(),
    }
    
    response = render(request, 'health_check.html', context)
    response['Cache-Control'] = 'no-cache, no-store, must-revalidate'
    response['X-Health-Status'] = 'ok'
    return response


# Alternative: Simple text-based health check for minimal bandwidth
def health_check_text(request):
    """
    Simple text-based health check for minimal bandwidth usage.
    Returns just "OK" as plain text.
    """
    if request.method == 'HEAD':
        response = HttpResponse()
        response['Cache-Control'] = 'no-cache, no-store, must-revalidate'
        return response
    
    response = HttpResponse("OK", content_type='text/plain')
    response['Cache-Control'] = 'no-cache, no-store, must-revalidate'
    return response


# ============================================================
# SEARCH API - For Autocomplete
# ============================================================
@login_required
def search_api(request):
    """
    API endpoint for search autocomplete.
    Searches: Exams, Study Resources, Spaces, Trends
    """
    query = request.GET.get('q', '').strip()
    
    if not query or len(query) < 2:
        return JsonResponse({'results': []})
    
    results = []
    
    # 1. Search Exams (ExamSet)
    exams = ExamSet.objects.filter(
        Q(title__icontains=query) |
        Q(description__icontains=query) |
        Q(subject__name__icontains=query)
    ).filter(is_active=True)[:5]
    
    for exam in exams:
        results.append({
            'id': str(exam.id),
            'type': 'exam',
            'name': exam.title,
            'meta': f"Exam • {exam.subject.name} • {exam.duration_minutes} min",
            'url': f"/exams/sets/{exam.id}/",
            'icon': 'document-text'
        })
    
    # 2. Search Study Resources
    resources = StudyResource.objects.filter(
        Q(title__icontains=query) |
        Q(description__icontains=query)
    ).filter(
        Q(access_level='public') | Q(creator=request.user)
    )[:5]
    
    for resource in resources:
        results.append({
            'id': str(resource.id),
            'type': 'resource',
            'name': resource.title,
            'meta': f"Resource • {resource.get_resource_type_display()}",
            'url': f"/study/{resource.id}/",
            'icon': 'book'
        })
    
    # 3. Search Live Classes
    live_classes = LiveClass.objects.filter(
        deleted_at__isnull=True,
    ).filter(
        Q(title__icontains=query)
        | Q(description__icontains=query)
        | Q(teacher__username__icontains=query)
    ).select_related('teacher').order_by(
        '-viewer_count',
        '-created_at',
    )[:5]

    for live_class in live_classes:
        status_label = (
            'Live now'
            if live_class.status == 'live'
            else 'Scheduled'
        )

        results.append({
            'id': str(live_class.id),
            'type': 'liveclass',
            'name': live_class.title,
            'meta': (
                f"Live Class • {status_label} • "
                f"{live_class.teacher.username}"
            ),
            'url': live_class.get_watch_page_url(),
            'icon': 'videocam',
        })

    institutions = Institution.objects.filter(
        is_active=True, is_approved=True,
    ).filter(
        Q(name__icontains=query) | Q(subdomain__icontains=query) | Q(description__icontains=query)
    ).order_by('name')[:5]
    for institution in institutions:
        results.append({
            'id': str(institution.id), 'type': 'institution', 'name': institution.name,
            'meta': f"Institution • {institution.get_institution_type_display()}",
            'url': f"/institutions/{institution.id}/", 'icon': 'business',
        })

    # 4. Search Usernames
    users = User.objects.filter(
        is_active=True,
    ).filter(
        Q(username__icontains=query)
        | Q(first_name__icontains=query)
        | Q(last_name__icontains=query)
    ).order_by(
        'username',
    )[:5]

    for matched_user in users:
        display_name = (
            matched_user.get_full_name().strip()
            or matched_user.username
        )

        results.append({
            'id': str(matched_user.id),
            'type': 'user',
            'name': display_name,
            'meta': f"Username • @{matched_user.username}",
            'url': (
                '/members/'
                + quote(matched_user.username)
                + '/'
            ),
            'icon': 'person',
        })

    # 4. Search Spaces
    spaces = Space.objects.filter(
        Q(name__icontains=query) |
        Q(description__icontains=query)
    ).filter(
        Q(created_by=request.user) |
        Q(institution__membership_requests__user=request.user, institution__membership_requests__status=InstitutionMembership.STATUS_ACCEPTED) |
        Q(created_by=request.user) | Q(is_active=True)
    ).distinct()[:5]
    
    for space in spaces:
        results.append({
            'id': str(space.id),
            'type': 'space',
            'name': space.name,
            'meta': f"Space • {space.get_space_type_display()}",
            'url': f"/spaces/{space.id}/",
            'icon': 'people'
        })
    
    # 5. Search Trends
    trends = visible_trends(request.user, getattr(request, 'institution', None)).filter(Q(title__icontains=query) | Q(description__icontains=query) | Q(subject__name__icontains=query) | Q(topic__name__icontains=query) | Q(subtopic__name__icontains=query), is_active=True).select_related('institution', 'target_level', 'subject', 'topic', 'subtopic')[:5]
    
    for trend in trends:
        results.append({
            'id': str(trend.id),
            'type': 'trend',
            'name': trend.title,
            'meta': f"Schedule • {trend.get_trend_type_display()}",
            'url': f"/trends/calendar/",
            'icon': 'calendar'
        })
    
    return JsonResponse({'results': results})




# SPACES_COMMUNITY_FEATURES_V1
COMMUNITY_INSTITUTION_ROLES = {
    UserRole.INSTITUTION_USER, UserRole.STUDENT, UserRole.TEACHER,
    UserRole.SETTER, UserRole.STAFF, UserRole.INSTITUTION_MANAGER,
}
INSTITUTION_APPROVAL_ROLES = tuple(
    (value, label) for value, label in InstitutionMembership.ROLE_CHOICES
    if value in COMMUNITY_INSTITUTION_ROLES
)


def _community_institution_admin(request, institution):
    profile = getattr(request.user, 'profile', None)
    return bool(
        request.user.is_superuser
        or request.user == institution.admin
        or (
            profile and profile.institution_id == institution.id
            and profile.institution_role in {UserRole.INSTITUTION_ADMIN, UserRole.INSTITUTION_MANAGER}
            and InstitutionMembership.objects.filter(
                user=request.user, institution=institution,
                status=InstitutionMembership.STATUS_ACCEPTED,
            ).exists()
        )
    )


def _community_accept_membership(request, membership, approved_role=None):
    allowed = {value for value, _ in INSTITUTION_APPROVAL_ROLES}
    role = approved_role if approved_role in allowed else UserRole.INSTITUTION_USER
    profile, _ = Profile.objects.get_or_create(user=membership.user)
    profile.institution = membership.institution
    profile.institution_role = role
    profile.institution_onboarding_completed = role not in {UserRole.INSTITUTION_USER, UserRole.STUDENT}
    profile.save(update_fields=['institution', 'institution_role', 'institution_onboarding_completed'])
    membership.requested_role = role
    membership.save(update_fields=['requested_role'])
    membership.status = InstitutionMembership.STATUS_ACCEPTED
    membership.responded_at = timezone.now()
    membership.save(update_fields=['status', 'responded_at'])


@login_required
def institution_public(request, institution_id):
    institution = get_object_or_404(Institution, pk=institution_id, is_active=True, is_approved=True)
    is_member = _community_institution_admin(request, institution) or InstitutionMembership.objects.filter(user=request.user, institution=institution, status=InstitutionMembership.STATUS_ACCEPTED).exists()
    public_classes = LiveClass.objects.filter(institution=institution, deleted_at__isnull=True).filter(Q(visibility=LiveClass.VISIBILITY_PUBLIC) | Q(visibility=LiveClass.VISIBILITY_INSTITUTION, institution__membership_requests__user=request.user, institution__membership_requests__status=InstitutionMembership.STATUS_ACCEPTED)).distinct().order_by('-created_at')[:24]
    public_resources = StudyResource.objects.filter(institution=institution).filter(Q(members_only=False) | Q(creator=request.user) | Q(institution__membership_requests__user=request.user, institution__membership_requests__status=InstitutionMembership.STATUS_ACCEPTED)).distinct().order_by('-created_at')[:24]
    public_exams = ExamSet.objects.filter(institution=institution, is_active=True).filter(Q(members_only=False) | Q(creator=request.user) | Q(institution__membership_requests__user=request.user, institution__membership_requests__status=InstitutionMembership.STATUS_ACCEPTED)).distinct().order_by('-created_at')[:24]
    pending_membership = InstitutionMembership.objects.filter(user=request.user, institution=institution, status=InstitutionMembership.STATUS_PENDING).first()
    subscription = Subscription.objects.filter(subscriber=request.user, institution_target=institution).first()
    return render(request, 'trend/institution_public.html', {
        'institution': institution,
        'public_classes': public_classes,
        'public_resources': public_resources,
        'public_exams': public_exams,
        'is_subscribed': bool(subscription),
        'is_member': is_member,
        'pending_membership': pending_membership,
    })


@login_required
@require_http_methods(['POST'])
def institution_join_request(request, institution_id):
    institution = get_object_or_404(Institution, pk=institution_id, is_active=True, is_approved=True)
    wants_json = request.headers.get('Accept', '').lower().find('application/json') >= 0 or request.headers.get('X-Requested-With') == 'XMLHttpRequest'
    if _community_institution_admin(request, institution):
        if wants_json: return JsonResponse({'error': 'You already manage this institution.'}, status=409)
        messages.info(request, 'You already manage this institution.')
        return redirect('institution_public', institution_id=institution_id)
    intention = request.POST.get('intention', 'student').strip()[:40]
    other = request.POST.get('intention_other', '').strip()
    message = request.POST.get('request_message', '').strip()
    if intention == 'other' and not other:
        if wants_json: return JsonResponse({'error': 'Please explain your intention.'}, status=400)
        messages.error(request, 'Please explain your intention.')
        return redirect('institution_public', institution_id=institution_id)
    membership, _ = InstitutionMembership.objects.get_or_create(user=request.user, institution=institution)
    if membership.status == InstitutionMembership.STATUS_ACCEPTED:
        if wants_json: return JsonResponse({'error': 'You are already a member.'}, status=409)
        messages.info(request, 'You are already a member.')
        return redirect('institution_public', institution_id=institution_id)
    membership.requested_role = UserRole.INSTITUTION_USER
    membership.requested_by = request.user
    membership.status = InstitutionMembership.STATUS_PENDING
    membership.intention, membership.intention_other, membership.request_message = intention, other, message
    membership.responded_at = None
    membership.save(update_fields=['requested_role','requested_by','status','intention','intention_other','request_message','responded_at'])
    notify_user(institution.admin, 'New institution join request', f'{request.user.username} requested to join {institution.name}.', f'/institution/members/search/', kind='membership', actor=request.user)
    return JsonResponse({'ok': True, 'message': 'Join request sent.'})

@login_required
@require_http_methods(['POST'])
def institution_leave(request, institution_id):
    membership = get_object_or_404(InstitutionMembership, user=request.user, institution_id=institution_id, status=InstitutionMembership.STATUS_ACCEPTED)
    membership.status = InstitutionMembership.STATUS_REMOVED
    membership.responded_at = timezone.now()
    membership.save(update_fields=['status','responded_at'])
    Profile.objects.filter(user=request.user, institution_id=institution_id).update(institution=None, institution_role=UserRole.PARTICIPANT)
    messages.success(request, 'You left the institution.')
    return redirect('institution_public', institution_id=institution_id)

@login_required
@require_http_methods(['POST'])
def creator_join_request(request, user_id):
    creator = get_object_or_404(User, pk=user_id, is_active=True)
    wants_json = request.headers.get('Accept', '').lower().find('application/json') >= 0 or request.headers.get('X-Requested-With') == 'XMLHttpRequest'
    if creator == request.user:
        if wants_json: return JsonResponse({'error': 'You cannot join yourself.'}, status=400)
        messages.error(request, 'You cannot join yourself.')
        return redirect('member_profile', username=creator.username)
    membership, _ = CreatorMembership.objects.get_or_create(creator=creator, member=request.user)
    if membership.status == CreatorMembership.STATUS_ACCEPTED:
        if wants_json: return JsonResponse({'error': 'You are already a member.'}, status=409)
        messages.info(request, 'You are already a member.')
        return redirect('member_profile', username=creator.username)
    membership.status = CreatorMembership.STATUS_PENDING
    membership.intention = request.POST.get('intention', 'learner').strip()[:40]
    membership.intention_other = request.POST.get('intention_other', '').strip()
    membership.save(update_fields=['status','intention','intention_other'])
    notify_user(creator, 'New creator membership request', f'{request.user.username} asked to join your exclusive materials.', f'/members/{request.user.username}/', kind='membership', actor=request.user)
    return JsonResponse({'ok': True, 'message': 'Join request sent.'})

@login_required
@require_http_methods(['POST'])
def creator_membership_review(request, membership_id):
    membership = get_object_or_404(CreatorMembership, pk=membership_id, creator=request.user, status=CreatorMembership.STATUS_PENDING)
    membership.status = CreatorMembership.STATUS_ACCEPTED if request.POST.get('action') == 'accept' else CreatorMembership.STATUS_DECLINED
    membership.responded_at = timezone.now()
    membership.save(update_fields=['status','responded_at'])
    notify_user(membership.member, f'Creator membership {membership.status}', f'Your request to join {request.user.username} was {membership.status}.', f'/members/{request.user.username}/', kind='membership', actor=request.user)
    return redirect('member_profile', username=request.user.username)

@login_required
@require_http_methods(['POST'])
def institution_membership_request(request, institution_id):
    institution = get_object_or_404(Institution, pk=institution_id, is_active=True, is_approved=True)
    if not _community_institution_admin(request, institution):
        return JsonResponse({'error': 'Only an institution administrator can send requests.'}, status=403)
    user_id = request.POST.get('user_id')
    role = request.POST.get('role', UserRole.INSTITUTION_USER)
    if role not in COMMUNITY_INSTITUTION_ROLES:
        return JsonResponse({'error': 'Invalid institution role.'}, status=400)
    target = get_object_or_404(User, pk=user_id, is_active=True)
    if target == institution.admin:
        return JsonResponse({'error': 'The institution administrator is already a member.'}, status=400)
    membership, created = InstitutionMembership.objects.get_or_create(
        user=target, institution=institution,
        defaults={'requested_role': role, 'requested_by': request.user},
    )
    if not created and membership.status == InstitutionMembership.STATUS_ACCEPTED:
        return JsonResponse({'error': 'This user is already a member.'}, status=409)
    membership.requested_role = role
    membership.status = InstitutionMembership.STATUS_PENDING
    membership.requested_by = request.user
    membership.responded_at = None
    membership.save(update_fields=['requested_role', 'status', 'requested_by', 'responded_at'])
    notify_user(target, 'New institution invitation', f'{request.user.username} invited you to join {institution.name} as {membership.get_requested_role_display()}.', '/community/membership-requests/', kind='membership', actor=request.user)
    message = f'Request sent to {target.username}.'
    if request.headers.get('X-Requested-With') == 'XMLHttpRequest' or 'application/json' in request.headers.get('Accept', ''):
        return JsonResponse({'ok': True, 'message': message})
    messages.success(request, message)
    return redirect('institution_member_search')


@login_required
def membership_requests(request):
    if request.method == 'POST':
        action = request.POST.get('action')
        if action in {'admin_accept', 'admin_decline'}:
            membership = get_object_or_404(InstitutionMembership, pk=request.POST.get('membership_id'), status=InstitutionMembership.STATUS_PENDING)
            if not _community_institution_admin(request, membership.institution):
                messages.error(request, 'You are not authorized to review this institution request.')
                return redirect('membership_requests')
            if action == 'admin_accept':
                _community_accept_membership(
                    request, membership, approved_role=request.POST.get('approved_role')
                )
                notify_user(membership.user, 'Institution join request approved', f'You joined {membership.institution.name}.', f'/institutions/{membership.institution_id}/', kind='membership', actor=request.user)
                messages.success(request, 'Join request approved.')
            else:
                membership.status = InstitutionMembership.STATUS_DECLINED
                membership.responded_at = timezone.now()
                membership.save(update_fields=['status','responded_at'])
                notify_user(membership.user, 'Institution join request declined', f'Your request to join {membership.institution.name} was declined.', f'/institutions/{membership.institution_id}/', kind='membership', actor=request.user)
                messages.info(request, 'Join request rejected.')
            return redirect('membership_requests')
        membership = get_object_or_404(InstitutionMembership, pk=request.POST.get('membership_id'), user=request.user)
        if action == 'accept' and membership.status == InstitutionMembership.STATUS_PENDING:
            _community_accept_membership(request, membership)
            if membership.requested_by_id:
                notify_user(membership.requested_by, 'Membership accepted', f'{request.user.username} accepted your invitation to {membership.institution.name}.', f'/institutions/{membership.institution_id}/', kind='membership', actor=request.user)
            messages.success(request, f'You joined {membership.institution.name}.')
        elif action == 'decline' and membership.status == InstitutionMembership.STATUS_PENDING:
            membership.status = InstitutionMembership.STATUS_DECLINED
            membership.responded_at = timezone.now()
            membership.save(update_fields=['status', 'responded_at'])
            if membership.requested_by_id:
                notify_user(membership.requested_by, 'Membership declined', f'{request.user.username} declined the invitation to {membership.institution.name}.', f'/institutions/{membership.institution_id}/', kind='membership', actor=request.user)
            messages.info(request, f'You declined the request from {membership.institution.name}.')
        elif action == 'cancel' and membership.status == InstitutionMembership.STATUS_PENDING:
            membership.status = InstitutionMembership.STATUS_CANCELLED
            membership.responded_at = timezone.now()
            membership.save(update_fields=['status', 'responded_at'])
            messages.info(request, 'Membership request cancelled.')
        return redirect('membership_requests')
    incoming = InstitutionMembership.objects.filter(user=request.user, status=InstitutionMembership.STATUS_PENDING).select_related('institution', 'requested_by')
    outgoing = InstitutionMembership.objects.filter(requested_by=request.user, status=InstitutionMembership.STATUS_PENDING).select_related('institution', 'user')
    admin_pending = InstitutionMembership.objects.filter(status=InstitutionMembership.STATUS_PENDING).select_related('institution', 'user').filter(
        Q(institution__admin=request.user) | Q(institution__membership_requests__user=request.user, institution__membership_requests__status=InstitutionMembership.STATUS_ACCEPTED, institution__membership_requests__requested_role__in=['institution_admin', 'institution_manager'])
    ).distinct()
    active = InstitutionMembership.objects.filter(user=request.user, status=InstitutionMembership.STATUS_ACCEPTED).select_related('institution')
    return render(request, 'trend/membership_requests.html', {'incoming': incoming, 'outgoing': outgoing, 'admin_pending': admin_pending, 'active_memberships': active, 'institution_approval_roles': INSTITUTION_APPROVAL_ROLES})


@login_required
@require_http_methods(['POST'])
def subscription_toggle(request):
    target_user_id = request.POST.get('user_id')
    target_institution_id = request.POST.get('institution_id')
    return_to = request.POST.get('next') or request.META.get('HTTP_REFERER') or ''
    if target_user_id:
        target = get_object_or_404(User, pk=target_user_id, is_active=True)
        if target == request.user:
            return JsonResponse({'error': 'You cannot subscribe to yourself.'}, status=400)
        lookup = {'subscriber': request.user, 'user_target': target, 'institution_target': None}
        label = target.username
    elif target_institution_id:
        target = get_object_or_404(Institution, pk=target_institution_id, is_active=True, is_approved=True)
        lookup = {'subscriber': request.user, 'user_target': None, 'institution_target': target}
        label = target.name
    else:
        return JsonResponse({'error': 'A user or institution target is required.'}, status=400)
    existing = Subscription.objects.filter(**lookup).first()
    if existing:
        existing.delete()
        message = f'Unsubscribed from {label}.'
        subscribed = False
    else:
        Subscription.objects.create(**lookup)
        if target_user_id:
            notify_user(target, 'New subscriber', f'{request.user.username} subscribed to your profile.', f'/members/{target.username}/', kind='subscription', actor=request.user)
        elif target_institution_id and getattr(target, 'admin_id', None):
            notify_user(target.admin, 'New institution subscriber', f'{request.user.username} subscribed to {target.name}.', f'/institutions/{target.id}/', kind='subscription', actor=request.user)
        message = f'Subscribed to {label}.'
        subscribed = True
    if request.headers.get('X-Requested-With') == 'XMLHttpRequest' or 'application/json' in request.headers.get('Accept', ''):
        return JsonResponse({'subscribed': subscribed, 'message': message})
    messages.success(request, message)
    return redirect(return_to or 'subscription_list')


@login_required
def institution_member_search(request):
    institution = getattr(request, 'institution', None)
    if not institution or not _community_institution_admin(request, institution):
        messages.error(request, 'Only an institution administrator can manage membership requests.')
        return redirect('institution_dashboard')
    query = request.GET.get('q', '').strip()
    candidates = User.objects.filter(is_active=True).exclude(pk=institution.admin_id)
    if query:
        candidates = candidates.filter(Q(username__icontains=query) | Q(first_name__icontains=query) | Q(last_name__icontains=query) | Q(email__icontains=query))
    candidates = candidates.select_related('profile').order_by('username')[:25]
    pending = InstitutionMembership.objects.filter(institution=institution, status=InstitutionMembership.STATUS_PENDING).select_related('user')
    return render(request, 'trend/institution_member_search.html', {'institution': institution, 'candidates': candidates, 'pending': pending, 'roles': InstitutionMembership.ROLE_CHOICES, 'query': query})


@login_required
def subscription_list(request):
    subscriptions = Subscription.objects.filter(subscriber=request.user).select_related('user_target', 'institution_target').order_by('-created_at')
    return render(request, 'trend/subscriptions.html', {'subscriptions': subscriptions})




# SPACES_NOTIFICATION_CENTER_V1
@login_required
def notification_list(request):
    notifications = Notification.objects.filter(recipient=request.user).select_related('actor')[:100]
    return render(request, 'trend/notifications.html', {'notifications': notifications})


@login_required
def notification_open(request, notification_id):
    notification = get_object_or_404(Notification, pk=notification_id, recipient=request.user)
    if notification.read_at is None:
        notification.read_at = timezone.now()
        notification.save(update_fields=['read_at'])
    return redirect(notification.url or 'notification_list')


@login_required
def notification_mark_all_read(request):
    if request.method != 'POST':
        return redirect('notification_list')
    Notification.objects.filter(recipient=request.user, read_at__isnull=True).update(read_at=timezone.now())
    messages.success(request, 'All notifications marked as read.')
    return redirect('notification_list')


@login_required
def member_profile(request, username):
    """Render a safe, tabbed public member channel."""
    target_user = get_object_or_404(
        User,
        username=username,
        is_active=True,
    )
    profile = get_object_or_404(Profile, user=target_user)

    if profile.profile_visibility == 'private' and request.user != target_user:
        return render(request, '404.html', status=404)

    public_classes = list(
        LiveClass.objects.filter(
            teacher=target_user,
            visibility='public',
        ).order_by('-created_at')
    )
    public_resources = list(
        StudyResource.objects.filter(
            creator=target_user,
            access_level='public',
        ).select_related('education_level').prefetch_related('subjects', 'topics').order_by('-created_at')
    )
    public_exams = list(
        ExamSet.objects.filter(
            creator=target_user,
            is_active=True,
        ).select_related('subject', 'education_level').order_by('-created_at')
    )

    activity_resources = RecommendationEvent.objects.filter(
        user=target_user,
        source_app='spaces',
        content_type='study_resource',
        event_type__in=['view', 'save', 'complete'],
    ).values_list('content_id', flat=True)
    used_resources = list(
        StudyResource.objects.filter(
            access_level='public',
            id__in=activity_resources,
        ).order_by('-created_at')[:12]
    )
    completed_exams = list(
        ExamSet.objects.filter(
            is_active=True,
            attempts__user=target_user,
            attempts__status__in=['SUBMITTED', 'AUTO_SUBMITTED', 'GRADING_PENDING', 'GRADED'],
        ).distinct().select_related('subject').order_by('-created_at')[:12]
    )
    attended_classes = list(
        LiveClass.objects.filter(
            visibility='public',
            student_statuses__user=target_user,
        ).distinct().order_by('-created_at')[:12]
    )

    is_subscribed = Subscription.objects.filter(
        subscriber=request.user,
        user_target=target_user,
        institution_target__isnull=True,
    ).exists()

    active_tab = request.GET.get('tab', 'overview')
    valid_tabs = {'overview', 'classes', 'resources', 'exams', 'activity'}
    if active_tab not in valid_tabs:
        active_tab = 'overview'

    featured_items = []
    for item in public_classes[:3]:
        featured_items.append({'title': item.title, 'meta': f'Live Class · {item.get_status_display()}', 'url': item.get_watch_page_url(), 'icon': 'videocam-outline'})
    for item in public_resources[:3]:
        featured_items.append({'title': item.title, 'meta': f'Study Resource · {item.get_resource_type_display()}', 'url': f'/study/{item.pk}/', 'icon': 'book-outline'})
    for item in public_exams[:3]:
        featured_items.append({'title': item.title, 'meta': f'Exam · {item.subject.name}', 'url': f'/exams/sets/{item.pk}/', 'icon': 'document-text-outline'})

    return render(
        request,
        'trend/member_profile.html',
        {
            'member': target_user,
            'member_profile': profile,
            'is_subscribed': is_subscribed,
            'role_badge': get_role_badge(target_user),
            'public_classes': public_classes,
            'public_resources': public_resources,
            'public_exams': public_exams,
            'attended_classes': attended_classes,
            'used_resources': used_resources,
            'completed_exams': completed_exams,
            'featured_items': featured_items[:9],
            'active_tab': active_tab,
        },
    )


@staff_member_required
def system_metrics(request):
    # 1. User Growth Metrics (Last 30 days)
    today = timezone.now().date()
    thirty_days_ago = today - timedelta(days=30)
    
    user_growth = (
        User.objects
        .filter(date_joined__date__gte=thirty_days_ago)
        .annotate(date=TruncDay('date_joined'))
        .values('date')
        .annotate(count=Count('id'))
        .order_by('date')
    )
    
    # Prepare data for user growth chart
    user_growth_dates = [entry['date'].strftime("%Y-%m-%d") for entry in user_growth]
    user_growth_counts = [entry['count'] for entry in user_growth]
    
    # Fill in missing days with zero counts
    full_dates = []
    full_counts = []
    current_date = thirty_days_ago
    while current_date <= today:
        date_str = current_date.strftime("%Y-%m-%d")
        if date_str in user_growth_dates:
            idx = user_growth_dates.index(date_str)
            full_counts.append(user_growth_counts[idx])
        else:
            full_counts.append(0)
        full_dates.append(date_str)
        current_date += timedelta(days=1)
    
    # 2. Educational System Distribution
    system_distribution = (
        EducationalSystem.objects
        .filter(is_approved=True)
        .annotate(
            level_count=Count('levels', distinct=True),
            subject_count=Count('levels__subjects', distinct=True),
            trend_count=Count('levels__academic_trends', distinct=True)
        )
        .order_by('-trend_count')[:10]
    )
    
    # Prepare data for system distribution chart
    system_names = [system.name for system in system_distribution]
    level_counts = [system.level_count for system in system_distribution]
    subject_counts = [system.subject_count for system in system_distribution]
    trend_counts = [system.trend_count for system in system_distribution]
    
    # 3. Trend Type Distribution
    trend_types = (
        Trend.objects
        .filter(is_approved=True)
        .values('space_type')
        .annotate(count=Count('id'))
        .order_by('-count')
    )
    
    # Map space type codes to human-readable names
    space_type_names = {
        'study': 'Study Space',
        'interview': 'Interview Space',
        'meeting': 'Meeting Space'
    }
    
    trend_type_labels = [
        space_type_names.get(entry['space_type'], entry['space_type'].replace('_', ' ').title())
        for entry in trend_types
    ]
    trend_type_counts = [entry['count'] for entry in trend_types]
    
    # 4. User Role Distribution
    role_distribution = (
        Profile.objects
        .values('role')
        .annotate(count=Count('id'))
        .order_by('-count')
    )
    
    role_names = {
        'participant': 'Participant',
        'setter': 'Setter',
        'institution': 'Institution',
        'admin': 'Admin'
    }
    
    role_labels = [
        role_names.get(entry['role'], entry['role'].replace('_', ' ').title())
        for entry in role_distribution
    ]
    role_counts = [entry['count'] for entry in role_distribution]
    
    # 5. Active Content Metrics
    active_trends = Trend.objects.filter(is_approved=True).count()
    active_systems = EducationalSystem.objects.filter(is_approved=True).count()
    active_levels = EducationLevel.objects.filter(is_approved=True).count()
    active_subjects = Subject.objects.filter(is_approved=True).count()
    
    # 6. Recent Growth (Last 7 days)
    week_ago = today - timedelta(days=7)
    recent_users = User.objects.filter(date_joined__date__gte=week_ago).count()
    recent_trends = Trend.objects.filter(created_at__date__gte=week_ago).count()
    
    return render(request, 'trend/system_metrics.html', {
        # Chart data
        'user_growth_dates': full_dates,
        'user_growth_counts': full_counts,
        'system_names': system_names,
        'level_counts': level_counts,
        'subject_counts': subject_counts,
        'trend_counts': trend_counts,
        'trend_type_labels': trend_type_labels,
        'trend_type_counts': trend_type_counts,
        'role_labels': role_labels,
        'role_counts': role_counts,
        
        # Metric cards
        'active_trends': active_trends,
        'active_systems': active_systems,
        'active_levels': active_levels,
        'active_subjects': active_subjects,
        'recent_users': recent_users,
        'recent_trends': recent_trends,
    })
    

def load_education_levels(request):
    system_id = request.GET.get('system_id')
    levels = EducationLevel.objects.filter(system_id=system_id).order_by('order')
    return render(request, 'level_dropdown.html', {'levels': levels})

def load_programs(request):
    institution_id = request.GET.get('institution_id')
    programs = Program.objects.filter(institution_id=institution_id)
    return render(request, 'program_dropdown.html', {'programs': programs})

def load_years(request):
    program_id = request.GET.get('program_id')
    years = Year.objects.filter(program_id=program_id).order_by('order')
    return render(request, 'year_dropdown.html', {'years': years})


@login_required
def create_trend(request):
    if request.method == 'POST':
        form = TrendForm(request.POST, user=request.user)
        if form.is_valid():
            trend = form.save()
            
            # Automatically become a setter when creating first trend
            profile = request.user.profile
            if profile.role == UserRole.PARTICIPANT:
                profile.role = UserRole.SETTER
                profile.save()
                
            messages.success(request, 'Trend created successfully!')
            return redirect('dashboard')
    else:
        form = TrendForm(user=request.user)
    return render(request, 'trend/create_trend.html', {'form': form})

def login_view(request):
    if request.method == 'POST':
        form = LoginForm(request.POST)
        if form.is_valid():
            username = form.cleaned_data['username']
            password = form.cleaned_data['password']
            user = authenticate(request, username=username, password=password)
            if user:
                login(request, user)
                
                # Check if user needs onboarding
                if not user.profile.onboarding_completed:
                    return redirect('welcome')
                
                # Check institution context
                institution = getattr(request, 'institution', None)
                if institution:
                    return redirect('institution_dashboard')
                else:
                    return redirect('dashboard')
            messages.error(request, 'Invalid credentials')
    else:
        form = LoginForm()
    
    institution = getattr(request, 'institution', None)
    return render(request, 'trend/login.html', {
        'form': form,
        'institution': institution
    })

@login_required
def logout_view(request):
    logout(request)
    return redirect('login')


def register_view(request):
    if request.method == 'POST':
        form = RegisterForm(request.POST)
        if form.is_valid():
            user = form.save()
            login(request, user)
            messages.success(request, 'Registration successful!')
            return redirect('welcome')
    else:
        form = RegisterForm()
    return render(request, 'trend/register.html', {'form': form})


@login_required
def welcome_view(request):
    """Modern onboarding flow with role and interest selection"""
    
    profile = request.user.profile
    
    # If already completed onboarding, redirect to dashboard
    if profile.onboarding_completed:
        return redirect('dashboard')
    
    # Get stats for the welcome page
    total_exams = ExamSet.objects.filter(is_active=True).count()
    total_resources = StudyResource.objects.filter(access_level='public').count()
    
    if request.method == 'POST':
        action = request.POST.get('action')
        
        if action == 'skip':
            # Mark onboarding as completed
            profile.onboarding_completed = True
            profile.save()
            messages.info(request, 'You can complete your profile later in Settings.')
            return redirect('dashboard')
        
        elif action == 'complete':
            # Save user role
            user_role = request.POST.get('user_role')
            if user_role:
                # Map to existing role or store in session
                role_map = {
                    'student': 'participant',
                    'teacher': 'participant',           # NOT immediately granted; pending approval
                    'professional': 'participant',
                    'researcher': 'participant'
                }
                if user_role in role_map:
                    profile.role = role_map[user_role]
                    # If teacher selected: track requested intent and pending approval
                    if user_role == 'teacher':
                        profile.global_role = UserRole.PARTICIPANT
                        profile.teacher_approved = False
                        messages.info(request, 'Your teacher application is pending approval. You have student access until approved.')
                
                # Store in session for future reference
                request.session['user_role'] = user_role
                if user_role == 'teacher':
                    request.session['pending_teacher'] = True
            
            # Save interests to session
            user_interests = request.POST.get('user_interests')
            if user_interests:
                import json
                try:
                    interests = json.loads(user_interests)
                    request.session['user_interests'] = interests
                except:
                    pass
            
            # Mark onboarding as completed
            profile.onboarding_completed = True
            profile.save()
            
            messages.success(request, '🎉 Welcome to Emerald Scholar! Your preferences are saved.')
            return redirect('dashboard')
    
    context = {
        'total_exams': total_exams,
        'total_resources': total_resources,
    }
    
    return render(request, 'trend/welcome.html', context)


# Update edit_profile view
@login_required
def edit_profile(request):
    try:
        profile = request.user.profile
    except Profile.DoesNotExist:
        # This should never happen with signals, but just in case
        profile = Profile.objects.create(user=request.user)
    
    if request.method == 'POST':
        form = ProfileForm(request.POST, request.FILES, instance=profile)
        if form.is_valid():
            form.save()
            messages.success(request, 'Profile updated successfully!')
            return redirect('dashboard')
    else:
        form = ProfileForm(instance=profile)
    
    return render(request, 'trend/edit_profile.html', {'form': form})


# ============================================================
# UPDATED DASHBOARD VIEW - With Full Context for New Theme
# ============================================================
@login_required
def institution_onboarding(request):
    institution = getattr(request, 'institution', None)
    profile = request.user.profile
    if not institution or profile.institution_id != institution.id:
        return redirect('dashboard')
    if profile.institution_role not in {UserRole.INSTITUTION_USER, UserRole.STUDENT}:
        return redirect('dashboard')
    if profile.institution_onboarding_completed and profile.education_level_id:
        return redirect('institution_student_dashboard')
    levels = EducationLevel.objects.filter(
        institution_level=institution, is_approved=True
    ).order_by('order', 'name')
    if request.method == 'POST':
        level = get_object_or_404(
            EducationLevel, pk=request.POST.get('education_level'),
            institution_level=institution, is_approved=True,
        )
        # The selected class determines the student's default curriculum.
        # Students should not have to add every subject manually.
        subjects = Subject.objects.filter(
            institution=institution, education_level=level, is_approved=True,
        ).order_by('order', 'name')
        if not subjects.exists():
            # Institution levels may be seeded as short labels such as P7,
            # while the approved global curriculum uses Primary Seven (P7).
            level_key = ''.join(ch for ch in level.name.lower() if ch.isalnum())
            curriculum_levels = EducationLevel.objects.filter(
                institution_level__isnull=True, is_approved=True,
            ).prefetch_related('subjects')
            matched_level = next(
                (
                    candidate for candidate in curriculum_levels
                    if level_key and level_key in ''.join(
                        ch for ch in candidate.name.lower() if ch.isalnum()
                    )
                ),
                None,
            )
            if matched_level:
                subjects = matched_level.subjects.filter(
                    is_approved=True,
                ).order_by('order', 'name')
        profile.education_level = level
        profile.institution_onboarding_completed = True
        profile.save(update_fields=['education_level', 'institution_onboarding_completed'])
        profile.studying_subjects.set(subjects)
        messages.success(request, f'Your placement in {level.name} has been saved.')
        return redirect('dashboard')
    subjects = Subject.objects.filter(
        institution=institution, is_approved=True,
        education_level__in=levels,
    ).select_related('education_level').order_by('education_level__order', 'name')
    return render(request, 'trend/institution_onboarding.html', {
        'institution': institution, 'profile': profile,
        'levels': levels, 'subjects': subjects,
    })


@login_required
def institution_student_dashboard(request):
    institution = getattr(request, 'institution', None)
    profile = request.user.profile
    if not institution or profile.institution_id != institution.id:
        return redirect('dashboard')
    if profile.institution_role not in {UserRole.INSTITUTION_USER, UserRole.STUDENT}:
        return redirect('dashboard')
    if not profile.institution_onboarding_completed:
        return redirect('institution_onboarding')
    level = profile.education_level
    trends = visible_trends(request.user, institution).filter(
        institution=institution, is_active=True,
    ).order_by('start_time')[:8]
    subjects = profile.studying_subjects.filter(
        is_approved=True,
    ).order_by('order', 'name')
    return render(request, 'trend/institution_student_dashboard.html', {
        'institution': institution, 'profile': profile, 'level': level,
        'subjects': subjects, 'recent_trends': trends,
    })


@login_required
def institution_staff_dashboard(request):
    institution = getattr(request, 'institution', None)
    profile = request.user.profile
    creator_roles = {UserRole.TEACHER, UserRole.SETTER, UserRole.STAFF, UserRole.INSTITUTION_MANAGER}
    if not institution or profile.institution_id != institution.id or profile.institution_role not in creator_roles:
        return redirect('dashboard')
    visible = visible_trends(request.user, institution).filter(
        institution=institution, is_active=True,
    ).order_by('-created_at')[:10]
    own_trends = Trend.objects.filter(
        institution=institution, organizer=request.user,
    ).order_by('-created_at')[:8]
    levels = EducationLevel.objects.filter(institution_level=institution).order_by('order', 'name')
    subjects = Subject.objects.filter(institution=institution).select_related('education_level').order_by('name')
    approvals = InstitutionContentApproval.objects.filter(
        institution=institution, submitted_by=request.user,
    ).select_related('content_type').order_by('-created_at')[:8]
    published_trend_count = visible_trends(request.user, institution).filter(
        institution=institution, is_active=True, is_approved=True,
    ).count()
    return render(request, 'trend/institution_staff_dashboard.html', {
        'institution': institution, 'profile': profile, 'recent_trends': visible,
        'own_trends': own_trends, 'levels': levels, 'subjects': subjects,
        'approvals': approvals, 'is_institution_admin': is_institution_admin(request.user, institution),
        'published_trend_count': published_trend_count,
    })


@login_required
def dashboard_view(request):
    profile = request.user.profile
    institution = getattr(request, 'institution', None)
    # The personal dashboard is always available. Institution dashboards are
    # entered explicitly from the institution shortcut/workspace selector.
    if request.GET.get('workspace') == 'personal':
        request.session.pop('current_institution_id', None)
        institution = None
    accessible_institutions = Institution.objects.filter(
        Q(admin=request.user) | Q(membership_requests__user=request.user, membership_requests__status=InstitutionMembership.STATUS_ACCEPTED)
    ).distinct()
    
    # Get greeting based on time of day
    hour = timezone.now().hour
    if hour < 12:
        greeting = "Morning"
    elif hour < 17:
        greeting = "Afternoon"
    else:
        greeting = "Evening"
    
    # Get counts
    total_exams = ExamAttempt.objects.filter(user=request.user).count()
    exam_sets_count = ExamSet.objects.filter(is_active=True).count()
    
    study_resources_count = StudyResource.objects.filter(
        Q(access_level='public') | 
        Q(creator=request.user)
    ).count()
    
    trends_count = visible_trends(request.user, getattr(request, 'institution', None)).filter(is_active=True).count()
    
    spaces_count = Space.objects.filter(
        Q(created_by=request.user) | 
        Q(institution__membership_requests__user=request.user, institution__membership_requests__status=InstitutionMembership.STATUS_ACCEPTED)
    ).distinct().count()
    
    # Recent attempts
    recent_attempts = ExamAttempt.objects.filter(
        user=request.user
    ).select_related('exam_set').order_by('-end_time')[:5]
    
    # Recent resources
    recent_resources = StudyResource.objects.filter(
        Q(access_level='public') | 
        Q(creator=request.user)
    ).order_by('-created_at')[:5]
    
    # Upcoming exam (in progress)
    upcoming_exam = ExamAttempt.objects.filter(
        user=request.user,
        status='IN_PROGRESS'
    ).select_related('exam_set').first()
    
    # Suggested exams for search autocomplete
    suggested_exams = ExamSet.objects.filter(is_active=True)[:5]
    
    # User spaces for sidebar
    user_spaces = Space.objects.filter(
        Q(created_by=request.user) | 
        Q(institution__membership_requests__user=request.user, institution__membership_requests__status=InstitutionMembership.STATUS_ACCEPTED)
    ).distinct()[:5]
    
    context = {
        'profile': profile,
        'accessible_institutions': accessible_institutions,
        'greeting': greeting,
        'total_exams': total_exams,
        'exam_sets_count': exam_sets_count,
        'study_resources_count': study_resources_count,
        'trends_count': trends_count,
        'spaces_count': spaces_count,
        'recent_attempts': recent_attempts,
        'recent_resources': recent_resources,
        'upcoming_exam': upcoming_exam,
        'suggested_exams': suggested_exams,
        'user_spaces': user_spaces,
    }
    
    return render(request, 'index.html', context)

@login_required
def create_educational_system(request):
    if request.method == 'POST':
        form = EducationalSystemForm(request.POST, user=request.user)
        if form.is_valid():
            system = form.save()
            messages.success(request, f'Educational system "{system.name}" submitted for approval!')
            return redirect('dashboard')
    else:
        form = EducationalSystemForm(user=request.user)
    return render(request, 'trend/system_form.html', {'form': form})

@login_required
def create_education_level(request):
    if request.method == 'POST':
        form = EducationLevelForm(request.POST, user=request.user)
        if form.is_valid():
            level = form.save()
            system_name = level.system.name if level.system else "Custom"
            messages.success(request, f'Education level "{level.name}" for {system_name} submitted for approval!')
            return redirect('dashboard')
    else:
        form = EducationLevelForm(user=request.user)
    return render(request, 'trend/education_level_form.html', {'form': form})

@login_required
def create_skill_domain(request):
    if request.method == 'POST':
        form = SkillDomainForm(request.POST, user=request.user)
        if form.is_valid():
            domain = form.save()
            messages.success(request, f'Skill domain "{domain.name}" submitted for approval!')
            return redirect('dashboard')
    else:
        form = SkillDomainForm(user=request.user)
    return render(request, 'trend/skill_domain_form.html', {'form': form})

@login_required
def create_institution(request):
    if request.method == 'POST':
        form = InstitutionForm(request.POST, user=request.user)
        if form.is_valid():
            institution = form.save()
            messages.success(request, f'Institution "{institution.name}" submitted for approval!')
            return redirect('dashboard')
    else:
        form = InstitutionForm(user=request.user)
    return render(request, 'trend/institution_form.html', {'form': form})

@login_required
def create_subject(request):
    if request.method == 'POST':
        form = SubjectForm(request.POST, user=request.user)
        if form.is_valid():
            subject = form.save()
            # Get context for success message
            level_name = subject.education_level.name if subject.education_level else ""
            institution_name = subject.institution.name if subject.institution else ""
            context = level_name or institution_name or "Global"
            
            messages.success(request, f'Subject "{subject.name}" for {context} submitted for approval!')
            return redirect('dashboard')
    else:
        form = SubjectForm(user=request.user)
    return render(request, 'trend/subject_form.html', {'form': form})

def create_topic(request):
    if request.method == 'POST':
        form = TopicForm(request.POST, user=request.user)
        if form.is_valid():
            topic = form.save()
            messages.success(request, f'Topic "{topic.name}" for {topic.subject.name} submitted for approval!')
            return redirect('dashboard')
        else:
            messages.error(request, 'Please correct the errors below.')
    else:
        form = TopicForm(user=request.user)
    
    # Get education levels and subjects for the cascading dropdowns
    subject_id = request.GET.get('subject')
    context = get_education_levels_and_subjects(request, subject_id)
    context['form'] = form
    
    return render(request, 'trend/topic_form.html', context)


def edit_topic(request, pk):
    topic = get_object_or_404(Topic, pk=pk)
    
    if request.method == 'POST':
        form = TopicForm(request.POST, instance=topic, user=request.user)
        if form.is_valid():
            form.save()
            messages.success(request, f'Topic "{topic.name}" updated successfully!')
            return redirect('dashboard')
    else:
        form = TopicForm(instance=topic, user=request.user)
    
    # Get education levels and subjects with the current topic's subject selected
    context = get_education_levels_and_subjects(request, topic.subject_id)
    context['form'] = form
    context['object'] = topic
    
    return render(request, 'trend/topic_form.html', context)


@staff_member_required
def admin_dashboard(request):
    """Admin dashboard with system statistics"""
    
    today = timezone.now().date()
    week_ago = today - timedelta(days=7)
    
    # User statistics - Use trends.models.User directly
    from trends.models import User as CustomUser
    
    user_stats = {
        'total_users': CustomUser.objects.count(),
        'new_today': CustomUser.objects.filter(date_joined__date=today).count(),
        'new_this_week': CustomUser.objects.filter(date_joined__date__gte=week_ago).count(),
        'verified_users': CustomUser.objects.filter(is_verified=True).count(),
    }
    
    # Content statistics
    content_stats = {
        'pending_systems': EducationalSystem.objects.filter(is_approved=False).count(),
        'pending_levels': EducationLevel.objects.filter(is_approved=False).count(),
        'pending_subjects': Subject.objects.filter(is_approved=False).count(),
        'pending_topics': Topic.objects.filter(is_approved=False).count(),
        'pending_domains': SkillDomain.objects.filter(is_approved=False).count(),
        'pending_institutions': Institution.objects.filter(is_approved=False).count(),
        'pending_trends': Trend.objects.filter(is_approved=False).count(),
    }
    
    # Recent users
    recent_users = CustomUser.objects.order_by('-date_joined')[:5]
    
    # Recent content
    recent_content = Trend.objects.order_by('-created_at')[:5]
    
    context = {
        'user_stats': user_stats,
        'content_stats': content_stats,
        'recent_users': recent_users,
        'recent_content': recent_content,
        'now': timezone.now(),
    }
    
    return render(request, 'trend/admin_dashboard.html', context)

@staff_member_required
def admin_user_list(request):
    users = User.objects.select_related('profile').order_by('-date_joined')
    query = request.GET.get('q')
    
    if query:
        users = users.filter(
            Q(username__icontains=query) |
            Q(email__icontains=query) |
            Q(first_name__icontains=query) |
            Q(last_name__icontains=query)
        )
    
    return render(request, 'trend/admin_user_list.html', {'users': users})


@login_required
@staff_required
def admin_user_detail(request, pk):
    target_user = get_object_or_404(User, pk=pk)
    profile = get_object_or_404(Profile, user=target_user)
    trends = Trend.objects.filter(organizer=target_user)
    
    if request.method == 'POST':
        action = request.POST.get('action')
        
        # Promotion actions
        if action == 'promote_teacher':
            if request.user.is_superuser or request.user.profile.global_role == 'staff':
                profile.global_role = 'teacher'
                profile.role = 'teacher'
                profile.teacher_approved = True
                profile.save()
                messages.success(request, f"{target_user.username} has been promoted to Teacher (approved)")
        
        elif action == 'promote_staff':
            if request.user.is_superuser:
                profile.global_role = 'staff'
                profile.role = 'staff'
                profile.save()
                messages.success(request, f"{target_user.username} has been promoted to Staff")
        
        elif action == 'demote':
            if request.user.is_superuser:
                profile.global_role = 'participant'
                profile.role = 'participant'
                profile.save()
                messages.success(request, f"{target_user.username} has been demoted to Participant")
        
        elif action == 'verify':
            target_user.is_verified = True
            target_user.save()
            messages.success(request, f"{target_user.username} has been verified")
        
        elif action == 'toggle_staff':
            if request.user.is_superuser:
                target_user.is_staff = not target_user.is_staff
                target_user.save()
                status = "added to staff" if target_user.is_staff else "removed from staff"
                messages.success(request, f"{target_user.username} has been {status}")
        
        elif action == 'delete':
            if request.user.is_superuser:
                target_user.delete()
                messages.success(request, f"{target_user.username} has been deleted")
                return redirect('admin_user_list')
        
        return redirect('admin_user_detail', pk=pk)
    
    # Determine what promotion buttons to show
    show_promote_teacher = request.user.is_superuser or request.user.profile.global_role == 'staff'
    show_promote_staff = request.user.is_superuser
    show_demote = request.user.is_superuser and profile.global_role not in ['admin', 'participant']
    show_staff_toggle = request.user.is_superuser
    
    context = {
        'user': target_user,
        'profile': profile,
        'trends': trends,
        'show_promote_teacher': show_promote_teacher,
        'show_promote_staff': show_promote_staff,
        'show_demote': show_demote,
        'show_staff_toggle': show_staff_toggle,
        'can_promote': request.user.is_superuser or request.user.profile.global_role == 'staff',
    }
    return render(request, 'trend/admin_user_detail.html', context)

@staff_member_required
def content_review_dashboard(request):
    # Get pending content for review
    pending = {
        'systems': EducationalSystem.objects.filter(is_approved=False),
        'levels': EducationLevel.objects.filter(is_approved=False),
        'subjects': Subject.objects.filter(is_approved=False),
        'topics': Topic.objects.filter(is_approved=False),
        'domains': SkillDomain.objects.filter(is_approved=False),
        'institutions': Institution.objects.filter(is_approved=False),
        'trends': Trend.objects.filter(is_approved=False),
    }
    
    return render(request, 'trend/content_review.html', {'pending': pending})

@staff_member_required
def approve_item(request, model, pk):
    model_map = {
        'system': EducationalSystem,
        'level': EducationLevel,
        'subject': Subject,
        'topic': Topic,
        'domain': SkillDomain,
        'institution': Institution,
        'trend': Trend,
    }
    
    model_class = model_map.get(model)
    if not model_class:
        messages.error(request, "Invalid model type")
        return redirect('content_review')
    
    item = get_object_or_404(model_class, pk=pk)
    item.is_approved = True
    item.save()
    
    messages.success(request, f"{model.title()} approved successfully")
    return redirect('content_review')

@staff_member_required
def reject_item(request, model, pk):
    model_map = {
        'system': EducationalSystem,
        'level': EducationLevel,
        'subject': Subject,
        'topic': Topic,
        'domain': SkillDomain,
        'institution': Institution,
        'trend': Trend,
    }
    
    model_class = model_map.get(model)
    if not model_class:
        messages.error(request, "Invalid model type")
        return redirect('content_review')
    
    item = get_object_or_404(model_class, pk=pk)
    item.delete()
    
    messages.success(request, f"{model.title()} rejected and deleted")
    return redirect('content_review')


@login_required
def institution_approval_center(request):
    institution = getattr(request, 'institution', None)
    if not institution or not is_institution_admin(request.user, institution):
        messages.error(request, 'Only an authorized institution administrator can review institution content.')
        return redirect('institution_dashboard')
    approvals = InstitutionContentApproval.objects.filter(
        institution=institution,
        status=InstitutionContentApproval.STATUS_PENDING,
    ).select_related('submitted_by', 'content_type').order_by('created_at')
    return render(request, 'trend/institution_approval_center.html', {
        'institution': institution,
        'approvals': approvals,
    })


@login_required
@require_http_methods(['POST'])
def institution_review_approval(request, pk):
    institution = getattr(request, 'institution', None)
    if not institution or not is_institution_admin(request.user, institution):
        messages.error(request, 'You are not authorized to review this content.')
        return redirect('institution_dashboard')
    approval = get_object_or_404(
        InstitutionContentApproval,
        pk=pk,
        institution=institution,
        status=InstitutionContentApproval.STATUS_PENDING,
    )
    if approval.submitted_by_id == request.user.id:
        messages.error(request, 'You cannot approve content you submitted yourself.')
        return redirect('institution_approval_center')
    action = request.POST.get('action')
    status_map = {
        'approve': InstitutionContentApproval.STATUS_APPROVED,
        'reject': InstitutionContentApproval.STATUS_REJECTED,
        'changes': InstitutionContentApproval.STATUS_CHANGES,
    }
    status = status_map.get(action)
    if not status:
        messages.error(request, 'Invalid approval action.')
        return redirect('institution_approval_center')
    review_approval(approval, reviewer=request.user, status=status, note=request.POST.get('note', '').strip())
    messages.success(request, f'Content {approval.get_status_display().lower()}.')
    return redirect('institution_approval_center')


# Institution registration: safe, automatic subdomain handling.
from django.views.decorators.debug import sensitive_post_parameters

@sensitive_post_parameters('password', 'password_confirm')
def register_institution(request):
    if request.method == 'POST':
        form = InstitutionRegistrationForm(request.POST, request.FILES)
        if form.is_valid():
            institution = form.save()

            # Log in the admin user automatically.
            admin_user = institution.admin
            admin_user.backend = 'django.contrib.auth.backends.ModelBackend'
            login(request, admin_user)

            base_domain = getattr(settings, 'INSTITUTION_BASE_DOMAIN', 'spacesdev.duckdns.org')
            messages.success(
                request,
                f'Your institution "{institution.name}" has been registered! '
                f'You can access it at: https://{institution.subdomain}.{base_domain}'
            )
            return redirect('institution_switch')
    else:
        form = InstitutionRegistrationForm()

    base_domain = getattr(settings, 'INSTITUTION_BASE_DOMAIN', 'spacesdev.duckdns.org')
    return render(
        request,
        'trend/institution_registration.html',
        {'form': form, 'institution_base_domain': base_domain},
    )


@login_required
def create_institution_level(request):
    profile = request.user.profile
    if not profile.institution:
        return redirect('institution_dashboard')
    if not _can_manage_institution_trends(request.user, profile.institution):
        messages.error(request, 'Only approved institution creators or staff can submit core content.')
        return redirect('dashboard')
    if request.method == 'POST':
        form = EducationLevelForm(request.POST, user=request.user, institution=profile.institution)
        if form.is_valid():
            level = form.save()
            submit_for_institution_approval(level, institution=profile.institution, user=request.user)
            messages.success(request, f'Education level "{level.name}" submitted for administrator approval.')
            return redirect('institution_dashboard')
    else:
        form = EducationLevelForm(user=request.user, institution=profile.institution)
    
    return render(request, 'trend/institution_level_form.html', {'form': form})

@login_required
def create_institution_subject(request):
    profile = request.user.profile
    if not profile.institution:
        return redirect('institution_dashboard')
    if not _can_manage_institution_trends(request.user, profile.institution):
        messages.error(request, 'Only approved institution creators or staff can submit core content.')
        return redirect('dashboard')
    if request.method == 'POST':
        form = SubjectForm(request.POST, user=request.user, institution=profile.institution)
        if form.is_valid():
            subject = form.save()
            submit_for_institution_approval(subject, institution=profile.institution, user=request.user)
            messages.success(request, f'Subject "{subject.name}" submitted for administrator approval.')
            return redirect('institution_dashboard')
    else:
        form = SubjectForm(user=request.user, institution=profile.institution)
    
    return render(request, 'trend/institution_subject_form.html', {'form': form})

@login_required
def create_institution_topic(request):
    profile = request.user.profile
    if not profile.institution:
        return redirect('institution_dashboard')
    if not _can_manage_institution_trends(request.user, profile.institution):
        messages.error(request, 'Only approved institution creators or staff can submit core content.')
        return redirect('dashboard')
    if request.method == 'POST':
        form = TopicForm(request.POST, user=request.user, institution=profile.institution)
        if form.is_valid():
            topic = form.save()
            submit_for_institution_approval(topic, institution=profile.institution, user=request.user)
            messages.success(request, f'Topic "{topic.name}" submitted for administrator approval.')
            return redirect('institution_dashboard')
    else:
        form = TopicForm(user=request.user, institution=profile.institution)
    
    return render(request, 'trend/institution_topic_form.html', {'form': form})

@login_required
def create_institution_trend(request):
    profile = request.user.profile
    if not profile.institution:
        return redirect('institution_dashboard')

    if not _can_manage_institution_trends(request.user, profile.institution):
        messages.error(
            request,
            'Only institution administrators, managers, staff, or teachers '
            'can create official institution schedules.',
        )
        return redirect('institution_dashboard')
    
    if request.method == 'POST':
        form = TrendForm(request.POST, user=request.user, institution=profile.institution)
        if form.is_valid():
            trend = form.save()
            trend.access_level = AccessLevel.INSTITUTIONAL
            trend.institution = profile.institution
            trend.save()
            submit_for_institution_approval(trend, institution=profile.institution, user=request.user)
            messages.success(request, 'Institutional Trend submitted for administrator approval.')
            return redirect('institution_dashboard')
    else:
        form = TrendForm(user=request.user, institution=profile.institution)
    
    return render(request, 'trend/create_institution_trend.html', {'form': form})


def test_institution_registration(request):
    """Test view to verify institution creation"""
    from .models import Institution, Profile
    
    # Create a test institution manually
    from django.contrib.auth import get_user_model
    User = get_user_model()
    
    # Check if test institution already exists
    if not Institution.objects.filter(subdomain='testschool').exists():
        # Create admin user
        admin_user = User.objects.create_user(
            username='testadmin',
            email='admin@testschool.com',
            password='test123',
            first_name='Test',
            last_name='Admin',
            is_verified=True
        )
        
        # Create institution
        institution = Institution.objects.create(
            name='Test School',
            institution_type='educational',
            subdomain='testschool',
            admin=admin_user,
            is_approved=True,
            is_active=True
        )
        
        # Create profile
        Profile.objects.create(
            user=admin_user,
            global_role='participant',
            institution_role='institution_admin',
            institution=institution
        )
        
        return HttpResponse(f"Test institution created: {institution.name} - Access at: testschool.127.0.0.1:8000")
    
    return HttpResponse("Test institution already exists")


import socket

def subdomain_test(request):
    """Test view to verify subdomain detection"""
    institution = getattr(request, 'institution', None)
    
    # Get local IP for display
    try:
        hostname = socket.gethostname()
        local_ip = socket.gethostbyname(hostname)
    except:
        local_ip = '127.0.0.1'
    
    if institution:
        return HttpResponse(f"""
        <h1>Subdomain Test Successful! 🎉</h1>
        <p>Institution: {institution.name}</p>
        <p>Subdomain: {institution.subdomain}</p>
        <p>Type: {institution.get_institution_type_display()}</p>
        <p>You are accessing via: {request.get_host()}</p>
        <a href="/">Back to main site</a>
        """)
    else:
        return HttpResponse(f"""
        <h1>No Institution Detected</h1>
        <p>You are accessing the main site at: {request.get_host()}</p>
        <p>Try accessing via: testschool.127.0.0.1:8000</p>
        <p>Or: testschool.{local_ip}:8000</p>
        <a href="/">Back to main site</a>
        """)


@login_required
def space_detail(request, pk):
    """View space details"""
    institution = getattr(request, 'institution', None)
    if not institution:
        messages.error(request, "You must access this page through your institution's subdomain")
        return redirect('dashboard')
    
    space = get_object_or_404(Space, pk=pk, institution=institution)
    trends = Trend.objects.filter(space=space, start_time__gte=timezone.now()).order_by('start_time')
    
    context = {
        'space': space,
        'trends': trends,
        'institution': institution,
    }
    return render(request, 'trend/space_detail.html', context)

@login_required
def space_edit(request, pk):
    """Edit a space"""
    institution = getattr(request, 'institution', None)
    if not institution:
        messages.error(request, "You must access this page through your institution's subdomain")
        return redirect('dashboard')
    
    space = get_object_or_404(Space, pk=pk, institution=institution)
    
    if request.method == 'POST':
        form = SpaceForm(request.POST, instance=space, institution=institution, user=request.user)
        if form.is_valid():
            space = form.save()
            messages.success(request, f'Space "{space.name}" updated successfully!')
            return redirect('space_list')
    else:
        form = SpaceForm(instance=space, institution=institution, user=request.user)
    
    context = {
        'form': form,
        'space': space,
        'institution': institution,
        'title': 'Edit Space'
    }
    return render(request, 'trend/space_form.html', context)


@login_required

def _can_manage_institution_trends(user, institution):
    """Check whether a user may create official institution schedules."""
    if not user or not user.is_authenticated or not institution:
        return False

    if user.is_superuser:
        return True

    profile = getattr(user, 'profile', None)
    if not profile or profile.institution_id != institution.id:
        return False

    allowed_roles = {'institution_admin', 'institution_manager', 'staff', 'teacher', 'setter'}
    return bool(
        InstitutionMembership.objects.filter(
            user=user, institution=institution, status=InstitutionMembership.STATUS_ACCEPTED
        ).exists() and profile.institution_role in allowed_roles
    )


def _can_manage_institution_trends_for_user(user, institution):
    """Permission predicate for institution activities; called from authenticated views."""
    if not user or not institution:
        return False
    profile = getattr(user, 'profile', None)
    institution_role = getattr(profile, 'institution_role', None) if profile else None
    manager_roles = {
        UserRole.INSTITUTION_ADMIN,
        UserRole.INSTITUTION_MANAGER,
        UserRole.STAFF,
    }
    return bool(
        user.is_superuser
        or user == institution.admin
        or (
            profile
            and profile.institution_id == institution.id
            and institution_role in manager_roles
        )
    )

@login_required
def trend_templates(request):
    institution=getattr(request,'institution',None)
    if not institution: messages.error(request,'Select an institution before creating a Trend.'); return redirect('dashboard')
    if not _can_manage_institution_trends_for_user(request.user,institution): messages.error(request,'You do not have permission to create official institution schedules.'); return redirect('trend_list')
    return render(request,'trend/trend_templates.html',{'institution':institution,'trend_templates':get_templates(institution.institution_type)})

@login_required
def trend_uganda_timetable(request):
    institution=getattr(request,'institution',None)
    if not institution: messages.error(request,'Select an institution before creating a timetable.'); return redirect('dashboard')
    if institution.institution_type!='educational': messages.error(request,'The Ugandan academic timetable is for educational institutions.'); return redirect('trend_templates')
    if not _can_manage_institution_trends_for_user(request.user,institution): messages.error(request,'You do not have permission to create timetables.'); return redirect('trend_list')
    form=UgandaTimetableForm(request.POST or None); output=''; result=None
    if request.method=='POST' and form.is_valid():
        closure=None
        try:
            closure=NamedTemporaryFile(mode='w',suffix='.json',delete=False,encoding='utf-8')
            json.dump({'holidays':[d.isoformat() for d in form.cleaned_data['holiday_list']]},closure); closure.close()
            opts={'institution':institution.name,'source_dir':str(settings.BASE_DIR/'trends'/'data'/'nusu_timetables'),'academic_year':str(form.cleaned_data['academic_year']),'term':form.cleaned_data['term'],'start_date':form.cleaned_data['start_date'].isoformat(),'end_date':form.cleaned_data['end_date'].isoformat(),'holiday_file':closure.name,'replace':request.POST.get('action')=='generate','dry_run':request.POST.get('action')!='generate','no_public_holidays':False,'organizer':None,'verbosity':0}
            stream=StringIO(); call_command('import_nusu_timetables',stdout=stream,stderr=stream,**opts); output=stream.getvalue(); result='preview' if opts['dry_run'] else 'generated'
            if result=='generated': messages.success(request,'The Ugandan term timetable was created successfully.'); return redirect('trend_list')
        except Exception as exc: form.add_error(None,f'Timetable generation could not be completed: {exc}')
        finally:
            if closure:
                try: Path(closure.name).unlink(missing_ok=True)
                except OSError: pass
    return render(request,'trend/uganda_timetable.html',{'institution':institution,'form':form,'output':output,'result':result})

@login_required
def trend_create(request):
    """Create a new trend/schedule"""
    institution = getattr(request, 'institution', None)
    if not institution:
        messages.error(request, "You must access this page through your institution's subdomain")
        return redirect('dashboard')

    if not _can_manage_institution_trends_for_user(request.user, institution):
        messages.error(
            request,
            'Only institution administrators, managers, staff, or teachers '
            'can create official institution schedules.',
        )
        return redirect('institution_dashboard')
    
    template_key = request.GET.get('template', request.POST.get('template', 'general'))
    template_meta = get_template(template_key)
    if request.method == 'POST':
        form = TrendForm(request.POST, institution=institution, user=request.user)
        if form.is_valid():
            trend = form.save()
            messages.success(request, f'Schedule "{trend.title}" created successfully!')
            return redirect('trend_list')
    else:
        form = TrendForm(institution=institution, user=request.user, initial={'trend_type': template_meta.get('trend_type', 'event')})
    
    context = {'form': form, 'institution': institution, 'title': template_meta.get('label', 'Create Schedule'), 'template_meta': template_meta}
    return render(request, 'trend/trend_form.html', context)

@login_required
def trend_calendar(request):
    """Database-backed calendar restricted to the viewer's visible Trends."""
    institution = getattr(request, 'institution', None)
    if not institution:
        messages.error(request, "Select an institution or use your personal Trends page.")
        return redirect('trend_list')
    today = timezone.localdate()
    first_day = today.replace(day=1)
    last_day = (first_day + timedelta(days=32)).replace(day=1) - timedelta(days=1)
    trends = visible_trends(request.user, institution).filter(
        is_active=True, start_time__date__gte=first_day, start_time__date__lte=last_day
    ).select_related('target_level', 'organizer', 'subject', 'topic', 'subtopic').order_by('start_time')
    level_groups = []
    levels = EducationLevel.objects.filter(
        institution_level=institution, is_approved=True,
    ).order_by('order', 'name')
    for level in levels:
        level_trends = list(trends.filter(target_level=level))
        if level_trends:
            level_groups.append({'level': level, 'trends': level_trends})
    unassigned_trends = list(trends.filter(target_level__isnull=True))
    calendar_events = [{
        'id': str(item.id), 'title': item.title, 'start': item.start_time.isoformat(),
        'end': item.end_time.isoformat() if item.end_time else None,
        'type': item.trend_type, 'audience': item.get_audience_display(),
        'level': item.target_level.name if item.target_level else '',
    } for item in trends]
    return render(request, 'trend/trend_calendar.html', {
        'trends': trends, 'calendar_events': calendar_events,
        'institution': institution, 'current_month': today.strftime('%B %Y'),
        'level_groups': level_groups, 'unassigned_trends': unassigned_trends,
        'can_manage_trends': bool(_can_manage_institution_trends_for_user(request.user, institution)),
    })
@login_required
def user_invite(request):
    """Invite new users to the institution"""
    institution = getattr(request, 'institution', None)
    if not institution:
        messages.error(request, "You must access this page through your institution's subdomain")
        return redirect('dashboard')
    
    if request.method == 'POST':
        email = request.POST.get('email')
        role = request.POST.get('role')
        
        # Check if user already exists
        try:
            user = User.objects.get(email=email)
            # User exists, add to institution
            profile, created = Profile.objects.get_or_create(user=user)
            profile.institution = institution
            profile.institution_role = role
            profile.save()
            
            messages.success(request, f"User {email} added to institution as {role}")
        
        except User.DoesNotExist:
            # Create new user account
            username = email.split('@')[0]
            password = User.objects.make_random_password()
            
            user = User.objects.create_user(
                username=username,
                email=email,
                password=password,
                is_verified=True
            )
            
            profile = Profile.objects.create(
                user=user,
                institution=institution,
                institution_role=role,
                global_role='participant'
            )
            
            # TODO: Send invitation email with credentials
            messages.success(request, f"Invitation sent to {email}")
        
        return redirect('user_management')
    
    context = {
        'institution': institution,
        'roles': UserRole.CHOICES,
    }
    return render(request, 'trend/user_invite.html', context)

@login_required
def user_edit_role(request, user_id):
    """Edit user role within institution"""
    institution = getattr(request, 'institution', None)
    if not institution:
        messages.error(request, "You must access this page through your institution's subdomain")
        return redirect('dashboard')
    
    try:
        profile = Profile.objects.get(user_id=user_id, institution=institution)
        
        if request.method == 'POST':
            new_role = request.POST.get('role')
            profile.institution_role = new_role
            profile.save()
            InstitutionMembership.objects.filter(
                user=profile.user,
                institution=institution,
                status=InstitutionMembership.STATUS_ACCEPTED,
            ).update(requested_role=new_role)
            
            messages.success(request, f"Updated {profile.user.username}'s role to {new_role}")
            return redirect('user_management')
        
        context = {
            'institution': institution,
            'profile': profile,
            'roles': UserRole.CHOICES,
        }
        return render(request, 'trend/user_edit_role.html', context)
    
    except Profile.DoesNotExist:
        messages.error(request, "User not found in this institution")
        return redirect('user_management')


@login_required
def space_list(request):
    """List spaces - can be individual or institutional"""
    institution = getattr(request, 'institution', None)
    
    if institution:
        # Institutional access - show only institution spaces
        spaces = Space.objects.filter(institution=institution)
        template_context = {'institution': institution}
    else:
        # Individual access - show user's personal spaces
        spaces = Space.objects.filter(created_by=request.user, institution__isnull=True)
        template_context = {}
    
    # Filter by space type if provided
    space_type = request.GET.get('space_type')
    if space_type:
        spaces = spaces.filter(space_type=space_type)
    
    context = {
        'spaces': spaces,
        'space_types': SpaceType.CHOICES,
        **template_context
    }
    return render(request, 'trends/space_list.html', context)

@login_required
def space_create(request):
    """Create space - can be individual or institutional"""
    institution = getattr(request, 'institution', None)
    
    if request.method == 'POST':
        form = SpaceForm(request.POST, institution=institution, user=request.user)
        if form.is_valid():
            space = form.save()
            if institution:
                messages.success(request, f'Institutional space "{space.name}" created successfully!')
            else:
                messages.success(request, f'Personal space "{space.name}" created successfully!')
            return redirect('space_list')
    else:
        form = SpaceForm(institution=institution, user=request.user)
    
    title = 'Create Space'
    if institution:
        title = f'Create Space - {institution.name}'
    
    context = {
        'form': form,
        'title': title,
        'institution': institution,
    }
    return render(request, 'trend/space_form.html', context)

@login_required
def trend_list(request):
    institution = getattr(request, 'institution', None)
    trends = visible_trends(request.user, institution).filter(is_active=True)
    full_staff_scope = bool(institution and is_institution_staff(request.user, institution))
    now = timezone.now()
    date_filter = request.GET.get('date_filter', 'upcoming')
    if date_filter == 'past':
        trends = trends.filter(end_time__lt=now)
    else:
        trends = trends.filter(end_time__gte=now)
    level_filter = request.GET.get('level', '').strip()
    if level_filter: trends = trends.filter(target_level_id=level_filter)
    trend_type = request.GET.get('trend_type')
    if trend_type: trends = trends.filter(trend_type=trend_type)
    query = request.GET.get('q', '').strip()
    if query: trends = trends.filter(Q(title__icontains=query) | Q(description__icontains=query) | Q(subject__name__icontains=query) | Q(topic__name__icontains=query) | Q(subtopic__name__icontains=query))
    trends = trends.select_related('space', 'organizer', 'target_level', 'subject', 'topic', 'subtopic').order_by('start_time')
    page_obj = Paginator(trends, 24).get_page(request.GET.get('page'))
    levels = EducationLevel.objects.filter(institution_level=institution, is_approved=True).order_by('order', 'name') if institution else EducationLevel.objects.none()
    if institution and not full_staff_scope:
        levels = levels.filter(id__in=user_level_ids(request.user, institution))
    level_groups = []
    if full_staff_scope and not level_filter:
        for level in levels:
            level_items = list(trends.filter(target_level=level).order_by('start_time'))
            if level_items:
                level_groups.append({'level': level, 'trends': level_items})
    return render(request, 'trend/trend_list.html', {
        'trends': page_obj, 'page_obj': page_obj, 'trend_types': TrendType.CHOICES,
        'date_filter': date_filter, 'query': query, 'institution': institution,
        'level_filter': level_filter, 'levels': levels,
        'can_manage_trends': bool(institution and _can_manage_institution_trends_for_user(request.user, institution)),
        'staff_scope': 'institution' if full_staff_scope else ('level' if institution and is_institution_staff(request.user, institution) else 'member'),
        'level_groups': level_groups,
    })

@login_required
def trend_edit(request, pk):
    trend = get_object_or_404(Trend.objects.select_related('institution'), pk=pk)
    if not can_edit_trend(request.user, trend):
        messages.error(request, 'You do not have permission to edit this Trend.')
        return redirect('trend_list')
    form = TrendForm(request.POST or None, instance=trend, institution=trend.institution, user=request.user)
    if request.method == 'POST' and form.is_valid():
        form.save()
        if trend.institution and not is_institution_admin(request.user, trend.institution):
            submit_for_institution_approval(trend, institution=trend.institution, user=request.user)
        messages.success(request, 'Trend updated successfully.')
        return redirect('trend_list')
    return render(request, 'trend/trend_form.html', {'form': form, 'institution': trend.institution, 'title': 'Edit Trend', 'trend': trend})

@login_required
def institution_dashboard(request):
    """Dashboard that works for both individual and institutional access."""
    institution = getattr(request, 'institution', None)


    if institution and not is_institution_admin(request.user, institution):
        role = getattr(request.user.profile, 'institution_role', None)
        if role in {UserRole.TEACHER, UserRole.SETTER, UserRole.STAFF, UserRole.INSTITUTION_MANAGER}:
            return redirect('institution_staff_dashboard')
        return redirect('dashboard')

    if institution:
        # Institutional dashboard
        spaces_count = Space.objects.filter(institution=institution).count()
        visible_institution_trends = visible_trends(request.user, institution).filter(institution=institution)
        trends_count = visible_institution_trends.count()
        users_count = Profile.objects.filter(institution=institution).count()
        
        recent_trends = visible_institution_trends.order_by('-created_at')[:5]
        recent_spaces = Space.objects.filter(institution=institution).order_by('-created_at')[:5]
        
        context = {
            'institution': institution,
            'spaces_count': spaces_count,
            'trends_count': trends_count,
            'users_count': users_count,
            'recent_trends': recent_trends,
            'recent_spaces': recent_spaces,
            'dashboard_type': 'institutional',
            'can_manage_members': _community_institution_admin(request, institution),
            'pending_members_count': InstitutionMembership.objects.filter(
                institution=institution,
                status=InstitutionMembership.STATUS_PENDING,
            ).count(),
        }
    else:
        # Personal dashboard
        spaces_count = Space.objects.filter(created_by=request.user, institution__isnull=True).count()
        trends_count = Trend.objects.filter(organizer=request.user, institution__isnull=True).count()
        
        recent_trends = Trend.objects.filter(organizer=request.user, institution__isnull=True).order_by('-created_at')[:5]
        recent_spaces = Space.objects.filter(created_by=request.user, institution__isnull=True).order_by('-created_at')[:5]
        
        context = {
            'spaces_count': spaces_count,
            'trends_count': trends_count,
            'recent_trends': recent_trends,
            'recent_spaces': recent_spaces,
            'dashboard_type': 'personal'
        }
    
    return render(request, 'trend/institution_dashboard.html', context)


@login_required
def select_institution(request, institution_id):
    """Manually select an institution for testing"""
    try:
        institution = Institution.objects.filter(id=institution_id, is_active=True, is_approved=True).filter(Q(admin=request.user) | Q(membership_requests__user=request.user, membership_requests__status=InstitutionMembership.STATUS_ACCEPTED)).distinct().get()
        request.session['current_institution_id'] = str(institution.id)
        messages.success(request, f"Now accessing: {institution.name}")
        return redirect('institution_dashboard')
    except Institution.DoesNotExist:
        messages.error(request, "Institution not found or not approved")
        return redirect('dashboard')

def institution_switch(request):
    """Page to switch between institutions"""
    if request.user.is_authenticated:
        # Get institutions user has access to
        institutions = Institution.objects.filter(
            Q(admin=request.user) |
            Q(membership_requests__user=request.user, membership_requests__status=InstitutionMembership.STATUS_ACCEPTED)
        ).distinct()
    else:
        institutions = Institution.objects.filter(is_active=True, is_approved=True)
    
    pending_institutions = Institution.objects.filter(
        admin=request.user,
        is_active=True,
        is_approved=False,
    ) if request.user.is_authenticated else Institution.objects.none()
    from django.conf import settings
    institution_base_domain = getattr(settings, 'INSTITUTION_BASE_DOMAIN', 'spacesdev.duckdns.org')
    return render(request, 'trend/institution_switch.html', {
        'institutions': institutions.filter(is_active=True, is_approved=True),
        'pending_institutions': pending_institutions,
        'institution_base_domain': institution_base_domain,
    })


@login_required
def user_management(request):
    """Manage users within the institution"""
    institution = getattr(request, 'institution', None)
    if not institution:
        messages.error(request, "You must access this page through your institution's subdomain")
        return redirect('dashboard')
    
    # Check if user has permission to manage users
    if not (_community_institution_admin(request, institution)):
        messages.error(request, "You don't have permission to manage users")
        return redirect('institution_dashboard')
    
    users = Profile.objects.filter(institution=institution).select_related('user').order_by('user__username')
    pending_requests = InstitutionMembership.objects.filter(
        institution=institution,
        status=InstitutionMembership.STATUS_PENDING,
    ).select_related('user', 'requested_by').order_by('created_at')

    if request.method == 'POST':
        membership = get_object_or_404(
            InstitutionMembership,
            pk=request.POST.get('membership_id'),
            institution=institution,
            status=InstitutionMembership.STATUS_PENDING,
        )
        action = request.POST.get('action')
        if action == 'approve' and membership.requested_by_id != request.user.id:
            _community_accept_membership(request, membership, approved_role=request.POST.get('approved_role'))
            notify_user(membership.user, 'Institution membership approved', f'Your membership in {institution.name} was approved.', f'/institutions/{institution.id}/', kind='membership', actor=request.user)
            messages.success(request, f'{membership.user.username} was approved and added to the institution.')
        elif action == 'reject':
            membership.status = InstitutionMembership.STATUS_DECLINED
            membership.responded_at = timezone.now()
            membership.save(update_fields=['status', 'responded_at'])
            notify_user(membership.user, 'Institution membership declined', f'Your membership request for {institution.name} was declined.', f'/institutions/{institution.id}/', kind='membership', actor=request.user)
            messages.info(request, f'{membership.user.username} was declined.')
        else:
            messages.error(request, 'An invitation sent by an administrator must be accepted by the invited user.')
        return redirect('user_management')
    
    # Filter by role if provided
    role_filter = request.GET.get('role')
    if role_filter:
        users = users.filter(institution_role=role_filter)
    
    context = {
        'institution': institution,
        'users': users,
        'roles': UserRole.CHOICES,
        'pending_requests': pending_requests,
        'pending_count': pending_requests.count(),
    }
    return render(request, 'trend/user_management.html', context)

@login_required
def institution_settings(request):
    """Institution settings and configuration"""
    institution = getattr(request, 'institution', None)
    if not institution:
        messages.error(request, "You must access this page through your institution's subdomain")
        return redirect('dashboard')
    
    # Check if user has permission to edit settings
    profile = request.user.profile
    is_institution_admin = (
        profile.institution == institution and 
        profile.institution_role == UserRole.INSTITUTION_ADMIN
    )
    is_actual_admin = request.user == institution.admin
    
    if not (is_institution_admin or is_actual_admin or request.user.is_superuser):
        messages.error(request, "You don't have permission to edit institution settings")
        return redirect('institution_dashboard')
    
    if request.method == 'POST':
        form = InstitutionForm(request.POST, request.FILES, instance=institution, user=request.user)
        if form.is_valid():
            institution = form.save()
            messages.success(request, 'Institution settings updated successfully!')
            return redirect('institution_settings')
    else:
        form = InstitutionForm(instance=institution, user=request.user)
    
    context = {
        'institution': institution,
        'form': form,
    }
    return render(request, 'trend/institute_settings.html', context)


def load_subjects(request):
    """AJAX endpoint to load subjects for a given education level"""
    education_level_id = request.GET.get('education_level_id')
    
    if not education_level_id:
        return JsonResponse({'subjects': []})
    
    try:
        subjects = Subject.objects.filter(
            education_level_id=education_level_id,
            is_approved=True
        ).values('id', 'name').order_by('name')
        
        return JsonResponse({'subjects': list(subjects)})
    except Exception as e:
        return JsonResponse({'subjects': [], 'error': str(e)})


def load_topics(request):
    """AJAX endpoint to load topics for a given subject"""
    subject_id = request.GET.get('subject_id')
    
    if not subject_id:
        return JsonResponse({'topics': []})
    
    try:
        topics = Topic.objects.filter(
            subject_id=subject_id,
            is_approved=True
        ).values('id', 'name').order_by('name')
        
        return JsonResponse({'topics': list(topics)})
    except Exception as e:
        return JsonResponse({'topics': [], 'error': str(e)})


def get_education_levels_and_subjects(request, subject_id=None):
    """Helper function to get education levels and selected subject for forms"""
    education_levels = EducationLevel.objects.filter(is_approved=True).select_related('system').order_by('system__name', 'order')
    
    selected_level_id = None
    selected_subject_id = None
    subjects = []
    
    if subject_id:
        try:
            selected_subject = Subject.objects.get(id=subject_id)
            selected_subject_id = subject_id
            selected_level_id = selected_subject.education_level_id
            subjects = Subject.objects.filter(
                education_level_id=selected_level_id,
                is_approved=True
            ).order_by('name')
        except Subject.DoesNotExist:
            pass
    
    return {
        'education_levels': education_levels,
        'selected_level_id': selected_level_id,
        'selected_subject_id': selected_subject_id,
        'subjects': subjects,
    }


def delete_topic(request, pk):
    topic = get_object_or_404(Topic, pk=pk)
    subject_name = topic.subject.name
    topic_name = topic.name
    
    if request.method == 'POST':
        topic.delete()
        messages.success(request, f'Topic "{topic_name}" deleted successfully!')
        return redirect('dashboard')
    
    return render(request, 'trend/topic_confirm_delete.html', {
        'topic': topic,
        'subject_name': subject_name,
    })


@login_required
def staff_dashboard(request):
    """Dashboard for staff members"""
    if request.user.profile.global_role not in ['staff', 'admin'] and not request.user.is_superuser:
        messages.error(request, "Access denied. Staff only.")
        return redirect('dashboard')
    
    # Statistics
    pending_subjects = Subject.objects.filter(is_approved=False).count()
    pending_topics = Topic.objects.filter(is_approved=False).count()
    pending_exams = ExamSet.objects.filter(is_active=False).count()
    total_users = User.objects.count()
    total_teachers = Profile.objects.filter(global_role='teacher').count()
    
    # Recent pending items
    recent_subjects = Subject.objects.filter(is_approved=False).order_by('-created_at')[:5]
    recent_topics = Topic.objects.filter(is_approved=False).order_by('-created_at')[:5]
    
    context = {
        'pending_subjects': pending_subjects,
        'pending_topics': pending_topics,
        'pending_exams': pending_exams,
        'total_users': total_users,
        'total_teachers': total_teachers,
        'recent_subjects': recent_subjects,
        'recent_topics': recent_topics,
    }
    return render(request, 'trend/staff_dashboard.html', context)


@login_required
def teacher_dashboard(request):
    """Dashboard for teachers"""
    if request.user.profile.global_role not in ['teacher', 'staff', 'admin'] and not request.user.is_superuser:
        messages.error(request, "Access denied. Teachers only.")
        return redirect('dashboard')
    
    # Teacher's content
    my_exams = ExamSet.objects.filter(creator=request.user).count()
    my_resources = StudyResource.objects.filter(creator=request.user).count()
    my_pass_papers = PassPaper.objects.filter(uploaded_by=request.user).count()
    
    # Pending grading
    pending_grading = ExamAttempt.objects.filter(
        exam_set__creator=request.user,
        status='SUBMITTED',
        results_released=False
    ).count()
    
    # Recent activity
    recent_exams = ExamSet.objects.filter(creator=request.user).order_by('-created_at')[:5]
    
    context = {
        'my_exams': my_exams,
        'my_resources': my_resources,
        'my_pass_papers': my_pass_papers,
        'pending_grading': pending_grading,
        'recent_exams': recent_exams,
    }
    return render(request, 'trend/teacher_dashboard.html', context)
