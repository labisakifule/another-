from django.db.models import Q

from core.models import RecommendationEvent
from core.services.recommendations import (
    rank_items,
    record_event,
    record_search,
)
from .models import ExamSet


def education_level_metadata(exam_set):
    """
    Return general education metadata.

    This does not assume primary education. It works with any existing
    EducationLevel record: P.6, Form 2, Grade 8, Year 2, and so on.
    """
    level = exam_set.education_level

    if not level:
        return {
            'education_level': '',
            'education_stage': '',
            'education_system': '',
        }

    system = getattr(level, 'system', None)

    return {
        'education_level': getattr(level, 'name', ''),
        'education_stage': getattr(level, 'level_type', ''),
        'education_system': getattr(system, 'name', ''),
    }


def exam_metadata(exam_set):
    """
    Convert an ExamSet into universal recommendation metadata.
    """
    level_data = education_level_metadata(exam_set)

    subject_name = getattr(
        exam_set.subject,
        'name',
        '',
    )

    topic_name = getattr(
        exam_set.topic,
        'name',
        '',
    )

    popularity_score = min(
        15,
        max(
            0,
            int(exam_set.views or 0)
            + int(exam_set.likes or 0) * 2
            + int(exam_set.saves or 0) * 2
            + int(exam_set.shares or 0),
        ),
    )

    return {
        'id': str(exam_set.id),
        'title': exam_set.title,
        'description': exam_set.description,
        'source_app': 'spaces',
        'content_type': 'exam',
        'education_system': level_data['education_system'],
        'education_stage': level_data['education_stage'],
        'education_level': level_data['education_level'],
        'subject': subject_name,
        'subject_or_course_unit': subject_name,
        'topic': topic_name,
        'popularity_score': popularity_score,
        'created_at': exam_set.created_at,
    }


def apply_exam_recommendation(exam_set, metadata):
    """
    Attach ranking information without changing ExamSet database fields.
    """
    exam_set.recommendation_score = metadata.get(
        'recommendation_score',
        0,
    )

    exam_set.recommendation_reasons = metadata.get(
        'recommendation_reasons',
        [],
    )

    return exam_set


def discover_exams(
    user,
    query='',
    level_id='',
    limit=30,
):
    """
    Return active exams ranked through the universal recommendation service.

    Premium access remains controlled by the existing attempt/access flow.
    This adapter does not bypass credits or premium authorization.
    """
    query = (query or '').strip()

    exams = ExamSet.objects.filter(
        is_active=True,
    ).filter(
        Q(members_only=False) | Q(creator=user) | Q(institution__membership_requests__user=user, institution__membership_requests__status='accepted')
    ).distinct().filter(
    ).select_related(
        'subject',
        'topic',
        'education_level',
        'education_level__system',
        'creator',
    )

    if level_id:
        exams = exams.filter(
            education_level_id=level_id,
        )

    if query:
        exams = exams.filter(
            Q(title__icontains=query)
            | Q(description__icontains=query)
            | Q(subject__name__icontains=query)
            | Q(topic__name__icontains=query)
            | Q(education_level__name__icontains=query)
            | Q(education_level__system__name__icontains=query)
        )

        record_search(
            user=user,
            query=query,
            source_app='spaces',
        )

    if not query:
        exams = exams.order_by(
            '-views',
            '-likes',
            '-saves',
            '-created_at',
        )
    else:
        exams = exams.order_by(
            '-views',
            '-likes',
            '-created_at',
        )

    exam_objects = list(exams[:limit])

    if query:
        for exam_set in exam_objects:
            ExamSet.objects.filter(
                pk=exam_set.pk,
            ).update(
                views=(exam_set.views or 0) + 1,
            )

    metadata_items = [
        exam_metadata(exam_set)
        for exam_set in exam_objects
    ]

    ranked_items = rank_items(
        user=user,
        items=metadata_items,
        query=query,
        limit=limit,
    )

    exam_by_id = {
        str(exam_set.id): exam_set
        for exam_set in exam_objects
    }

    ranked_exams = []

    for item in ranked_items:
        exam_set = exam_by_id.get(
            str(item.get('id')),
        )

        if exam_set:
            apply_exam_recommendation(
                exam_set,
                item,
            )
            ranked_exams.append(exam_set)

    return ranked_exams


def record_exam_view(user, exam_set):
    """
    Record an exam detail-page view for universal recommendations.
    """
    if not user or not user.is_authenticated:
        return None

    return record_event(
        user=user,
        event_type=RecommendationEvent.EVENT_VIEW,
        source_app='spaces',
        content_type='exam',
        content_id=exam_set.id,
        metadata=exam_metadata(exam_set),
    )


