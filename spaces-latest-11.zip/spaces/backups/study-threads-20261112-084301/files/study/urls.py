from django.urls import path
from .views import *

app_name = 'study'

urlpatterns = [
    path('progress/', study_progress, name='progress'),
    path('path/', study_path, name='study_path'),
    path('path/<int:pk>/', study_unit_detail, name='study_unit_detail'),
    path('path/<int:pk>/complete/', mark_unit_complete, name='mark_unit_complete'),
    path('setter-progress/', setter_progress, name='setter_progress'),
    path('<uuid:pk>/complete/', mark_resource_complete, name='mark_resource_complete'),
    path('', StudyResourceListView.as_view(), name='resource_list'),
    path('create/', StudyResourceCreateView.as_view(), name='resource_create'),
    path('<uuid:pk>/', StudyResourceDetailView.as_view(), name='resource_detail'),
    path('<uuid:pk>/edit/', StudyResourceUpdateView.as_view(), name='resource_edit'),
    path('<uuid:pk>/bookmark/', toggle_bookmark, name='toggle_bookmark'),
    path('<uuid:resource_id>/exercise/create/', LessonExerciseCreateView.as_view(), name='exercise_create'),
    path('exercises/<int:pk>/', LessonExerciseDetailView.as_view(), name='exercise_detail'),
    path('exercises/<int:pk>/submissions/', exercise_submissions, name='exercise_submissions'),
    path('exercise-submissions/<int:pk>/review/', exercise_submission_review, name='exercise_submission_review'),

    path('passpapers/', PassPaperListView.as_view(), name='passpaper_list'),
    path('passpapers/upload/', upload_passpaper, name='upload_passpaper'),
    path('passpapers/bulk-upload/', bulk_upload_passpapers, name='bulk_upload_passpapers'),
    path('passpapers/my-uploads/', MyUploadsView.as_view(), name='my_uploads'),
    path('passpapers/<uuid:pk>/', PassPaperDetailView.as_view(), name='passpaper_detail'),
    path('passpapers/<uuid:pk>/edit/', PassPaperUpdateView.as_view(), name='passpaper_update'),
    path('passpapers/<uuid:pk>/delete/', PassPaperDeleteView.as_view(), name='passpaper_delete'),
    path('passpapers/<uuid:pk>/download/', download_passpaper, name='download_passpaper'),
    path('passpapers/statistics/', passpaper_statistics, name='passpaper_statistics'),
]