from django.views.generic import ListView, DetailView, CreateView, UpdateView, DeleteView  # Add DeleteView here
from django.urls import reverse_lazy
from django.contrib import messages
from django.shortcuts import get_object_or_404
from django.http import JsonResponse
from .models import *
from .forms import *
from trends.models import Subject, Topic, EducationLevel, SkillDomain
from .constants import ResourceType  # IMPORTANT: Add this import
from .discovery import discover_resources
from django.conf import settings
from django.contrib.auth.mixins import LoginRequiredMixin, UserPassesTestMixin
from django.db.models import Q, Count, Avg, Avg
from django.core.paginator import Paginator
from django.contrib.auth.decorators import login_required, user_passes_test
from django.views.decorators.http import require_http_methods
from django.views.generic import FormView
from django.utils import timezone
from .forms import LessonExerciseForm
from trends.access import can_view_content, content_visibility_q, is_institution_admin
from trends.approval import submit_for_institution_approval



def _touch_study_progress(user, resource, percent=25):
    if not getattr(user, 'is_authenticated', False) or user == resource.creator:
        return None
    now = timezone.now()
    progress, created = StudyResourceProgress.objects.get_or_create(
        user=user, resource=resource,
        defaults={'first_opened_at': now, 'last_opened_at': now, 'views': 1,
                  'progress_percent': min(100, percent), 'status': StudyResourceProgress.IN_PROGRESS},
    )
    if not created:
        progress.views += 1
        progress.last_opened_at = now
        if progress.status != StudyResourceProgress.COMPLETED:
            progress.status = StudyResourceProgress.IN_PROGRESS
            progress.progress_percent = max(progress.progress_percent, min(100, percent))
        progress.save(update_fields=['views', 'last_opened_at', 'status', 'progress_percent', 'updated_at'])
    return progress


def _refresh_study_unit_ancestors(user, unit):
    """Roll child-period percentages into each parent without publishing anything."""
    parent = unit.parent
    while parent:
        children = list(parent.children.all())
        percentages = [
            (StudyUnitProgress.objects.filter(user=user, unit=child).first().progress_percent
             if StudyUnitProgress.objects.filter(user=user, unit=child).exists() else 0)
            for child in children
        ]
        average = int(sum(percentages) / len(percentages)) if percentages else 0
        status = 'completed' if average == 100 else ('in_progress' if average else 'not_started')
        row, _ = StudyUnitProgress.objects.get_or_create(user=user, unit=parent)
        row.progress_percent = average
        row.status = status
        row.last_opened_at = timezone.now()
        if status == 'completed' and not row.completed_at:
            row.completed_at = timezone.now()
        row.save(update_fields=['progress_percent', 'status', 'last_opened_at', 'completed_at'])
        parent = parent.parent

# Update StudyResourceListView
class StudyResourceListView(ListView):
    model = StudyResource
    template_name = 'study/resource_list.html'
    context_object_name = 'resources'
    paginate_by = 12

    def get_queryset(self):
        query = self.request.GET.get('q', '').strip()

        if not query:
            query = self.request.GET.get(
                'search',
                '',
            ).strip()

        resource_type = self.request.GET.get(
            'type',
            '',
        ).strip()

        subject_id = self.request.GET.get(
            'subject',
            '',
        ).strip()

        level_id = self.request.GET.get(
            'level',
            '',
        ).strip()

        return discover_resources(
            user=self.request.user,
            query=query,
            resource_type=resource_type,
            subject_id=subject_id,
            level_id=level_id,
            limit=200,
        )

    def get_context_data(self, **kwargs):
        context = super().get_context_data(**kwargs)
        context['subjects'] = Subject.objects.all()
        context['topics'] = Topic.objects.all()
        context['education_levels'] = EducationLevel.objects.filter(is_approved=True)
        return context



class StudyResourceCreateView(CreateView):
    model = StudyResource
    form_class = StudyResourceForm
    template_name = 'study/resource_form.html'
    success_url = reverse_lazy('study:resource_list')
    
    def form_valid(self, form):
        form.instance.creator = self.request.user
        form.instance.institution = getattr(getattr(self.request.user, 'profile', None), 'institution', None)
        institution = form.instance.institution
        if institution:
            form.instance.is_approved = False
        messages.success(self.request, 'Resource created successfully!')
        response = super().form_valid(form)
        if institution:
            submit_for_institution_approval(self.object, institution=institution, user=self.request.user)
        return response
    
    def get_form_kwargs(self):
        kwargs = super().get_form_kwargs()
        kwargs['user'] = self.request.user
        return kwargs

class StudyResourceUpdateView(UpdateView):
    model = StudyResource
    form_class = StudyResourceForm
    template_name = 'study/resource_form.html'
    
    def get_success_url(self):
        return reverse_lazy('study:resource_detail', kwargs={'pk': self.object.pk})
    
    def form_valid(self, form):
        institution = self.object.institution
        messages.success(self.request, 'Resource updated successfully!')
        response = super().form_valid(form)
        if institution and not is_institution_admin(self.request.user, institution):
            submit_for_institution_approval(self.object, institution=institution, user=self.request.user)
        return response
    
    def get_form_kwargs(self):
        kwargs = super().get_form_kwargs()
        kwargs['user'] = self.request.user
        return kwargs

class StudyResourceDetailView(LoginRequiredMixin, DetailView):
    model = StudyResource
    def get_queryset(self):
        return StudyResource.objects.filter(
            Q(members_only=False, access_level='public') | Q(creator=self.request.user) | Q(creator__creator_memberships__member=self.request.user, creator__creator_memberships__status='accepted') | Q(institution__membership_requests__user=self.request.user, institution__membership_requests__status='accepted')
        ).distinct()
    context_object_name = 'resource'
    
    # Use ONE template for ALL resource types
    template_name = 'study/resource_detail.html'  # ← Single template
    
    def get(self, request, *args, **kwargs):
        response = super().get(request, *args, **kwargs)
        # Track view count
        self.object.view_count = (self.object.view_count or 0) + 1
        self.object.save(update_fields=['view_count'])
        _touch_study_progress(request.user, self.object)
        return response
    
    def get_context_data(self, **kwargs):
        context = super().get_context_data(**kwargs)
        resource = self.object
        
        # Bookmark status
        if self.request.user.is_authenticated:
            context['is_bookmarked'] = ResourceBookmark.objects.filter(
                user=self.request.user,
                resource=resource
            ).exists()
        
        # Related resources (by same subjects)
        related_resources = StudyResource.objects.filter(
            subjects__in=resource.subjects.all(),
            access_level='public'
        ).exclude(id=resource.id).distinct()[:5]
        context['related_resources'] = related_resources
        context['lesson_exercises'] = resource.exercises.order_by('created_at')
        context['lesson_exercise'] = context['lesson_exercises'].first()
        
        return context

def toggle_bookmark(request, pk):
    if not request.user.is_authenticated:
        return JsonResponse({'status': 'error', 'message': 'Authentication required'}, status=401)
        
    resource = get_object_or_404(StudyResource, pk=pk)
    bookmark, created = ResourceBookmark.objects.get_or_create(
        user=request.user,
        resource=resource
    )
    
    if not created:
        bookmark.delete()
    
    return JsonResponse({
        'status': 'success',
        'is_bookmarked': created
    })

# study/views.py

class PassPaperListView(ListView):
    model = PassPaper
    template_name = 'study/passpaper_list.html'
    context_object_name = 'papers'
    paginate_by = 20
    
    def get_queryset(self):
        queryset = PassPaper.objects.filter(is_public=True)
        
        # Filter by subject
        subject_id = self.request.GET.get('subject')
        if subject_id:
            queryset = queryset.filter(subject_id=subject_id)
        
        # Filter by year
        year = self.request.GET.get('year')
        if year:
            queryset = queryset.filter(year=year)
        
        # Filter by term
        term = self.request.GET.get('term')
        if term:
            queryset = queryset.filter(term=term)
        
        # Filter by education level
        level_id = self.request.GET.get('level')
        if level_id:
            queryset = queryset.filter(education_level_id=level_id)
        
        return queryset.select_related('subject', 'education_level', 'uploaded_by')
    
    def get_context_data(self, **kwargs):
        context = super().get_context_data(**kwargs)
        context['subjects'] = Subject.objects.all()
        context['education_levels'] = EducationLevel.objects.all()
        context['years'] = PassPaper.objects.values_list('year', flat=True).distinct().order_by('-year')
        return context


class PassPaperDetailView(DetailView):
    model = PassPaper
    template_name = 'study/passpaper_detail.html'
    context_object_name = 'paper'
    
    def get(self, request, *args, **kwargs):
        response = super().get(request, *args, **kwargs)
        # Increment view count
        self.object.view_count += 1
        self.object.save(update_fields=['view_count'])
        _touch_study_progress(request.user, self.object)
        return response
    
    def get_context_data(self, **kwargs):
        context = super().get_context_data(**kwargs)
        # Get related papers (same subject, different years)
        context['related_papers'] = PassPaper.objects.filter(
            subject=self.object.subject,
            is_public=True
        ).exclude(id=self.object.id)[:5]
        return context



# ==================== PASS PAPER LIST VIEW ====================

class PassPaperListView(ListView):
    """
    Display all pass papers with filtering options
    """
    model = PassPaper
    template_name = 'study/passpaper_list.html'
    context_object_name = 'papers'
    paginate_by = 12

    def get_queryset(self):
        queryset = PassPaper.objects.filter(is_public=True).select_related(
            'subject', 'education_level', 'uploaded_by'
        )

        # Filter by subject
        subject_id = self.request.GET.get('subject')
        if subject_id:
            queryset = queryset.filter(subject_id=subject_id)

        # Filter by year
        year = self.request.GET.get('year')
        if year:
            queryset = queryset.filter(year=year)

        # Filter by term
        term = self.request.GET.get('term')
        if term:
            queryset = queryset.filter(term=term)

        # Filter by education level
        level_id = self.request.GET.get('level')
        if level_id:
            queryset = queryset.filter(education_level_id=level_id)

        # Filter by paper type
        paper_type = self.request.GET.get('paper_type')
        if paper_type:
            queryset = queryset.filter(paper_type=paper_type)

        # Search by title/description
        search = self.request.GET.get('search')
        if search:
            queryset = queryset.filter(
                Q(title__icontains=search) | 
                Q(description__icontains=search)
            )

        return queryset.order_by('-year', 'subject__name')

    def get_context_data(self, **kwargs):
        context = super().get_context_data(**kwargs)
        context['subjects'] = Subject.objects.all()
        context['education_levels'] = EducationLevel.objects.all()
        context['years'] = PassPaper.objects.values_list('year', flat=True).distinct().order_by('-year')
        context['paper_types'] = PassPaper._meta.get_field('paper_type').choices
        context['terms'] = PassPaper._meta.get_field('term').choices
        
        # Keep filter values in context
        context['current_filters'] = {
            'subject': self.request.GET.get('subject', ''),
            'year': self.request.GET.get('year', ''),
            'term': self.request.GET.get('term', ''),
            'level': self.request.GET.get('level', ''),
            'paper_type': self.request.GET.get('paper_type', ''),
            'search': self.request.GET.get('search', ''),
        }
        
        return context


# ==================== PASS PAPER DETAIL VIEW ====================

class PassPaperDetailView(DetailView):
    """
    Display single pass paper with details and download options
    """
    model = PassPaper
    template_name = 'study/passpaper_detail.html'
    context_object_name = 'paper'

    def get(self, request, *args, **kwargs):
        response = super().get(request, *args, **kwargs)
        # Increment view count
        self.object.view_count += 1
        self.object.save(update_fields=['view_count'])
        return response

    def get_context_data(self, **kwargs):
        context = super().get_context_data(**kwargs)
        paper = self.object
        
        # Get related papers (same subject, different years)
        context['related_papers'] = PassPaper.objects.filter(
            subject=paper.subject,
            is_public=True
        ).exclude(id=paper.id).order_by('-year')[:5]
        
        # Check if user can download (credits check)
        if self.request.user.is_authenticated:
            if paper.requires_credits > 0:
                context['can_download'] = self.request.user.credits >= paper.requires_credits
                context['credits_needed'] = paper.requires_credits
                context['user_credits'] = self.request.user.credits
            else:
                context['can_download'] = True
        else:
            context['can_download'] = False
            context['login_required'] = True
        
        # Get file info
        if paper.file:
            context['file_size'] = self.get_file_size(paper.file)
            context['file_type'] = paper.file.format.upper() if paper.file.format else 'Unknown'
        
        return context
    
    def get_file_size(self, file_field):
        """Get human readable file size"""
        if hasattr(file_field, 'size') and file_field.size:
            size = file_field.size
            for unit in ['B', 'KB', 'MB', 'GB']:
                if size < 1024.0:
                    return f"{size:.1f} {unit}"
                size /= 1024.0
        return "Unknown size"


# ==================== UPLOAD PASS PAPER ====================

@login_required
@user_passes_test(lambda u: u.profile.role in ['setter', 'teacher', 'admin'])
def upload_passpaper(request):
    """
    Upload a new pass paper (setters, teachers, admins only)
    """
    if request.method == 'POST':
        form = PassPaperForm(request.POST, request.FILES, user=request.user)
        if form.is_valid():
            paper = form.save()
            messages.success(
                request, 
                f"✅ Pass paper '{paper.title}' uploaded successfully! It is now available for students."
            )
            return redirect('study:passpaper_detail', pk=paper.id)
        else:
            messages.error(request, "Please correct the errors below.")
    else:
        form = PassPaperForm(user=request.user)
    
    return render(request, 'study/passpaper_form.html', {
        'form': form,
        'title': 'Upload Past Paper'
    })


# ==================== EDIT PASS PAPER ====================

class PassPaperUpdateView(LoginRequiredMixin, UserPassesTestMixin, UpdateView):
    """
    Edit an existing pass paper
    """
    model = PassPaper
    form_class = PassPaperForm
    template_name = 'study/passpaper_form.html'
    
    def test_func(self):
        paper = self.get_object()
        # Allow if user is uploader, admin, or has setter/teacher role
        return (
            self.request.user == paper.uploaded_by or
            self.request.user.is_staff or
            self.request.user.profile.role in ['setter', 'teacher', 'admin']
        )
    
    def get_context_data(self, **kwargs):
        context = super().get_context_data(**kwargs)
        context['title'] = f'Edit: {self.object.title}'
        context['is_edit'] = True
        return context
    
    def form_valid(self, form):
        messages.success(self.request, "✅ Pass paper updated successfully!")
        return super().form_valid(form)
    
    def get_success_url(self):
        return reverse_lazy('study:passpaper_detail', kwargs={'pk': self.object.pk})


# ==================== DELETE PASS PAPER ====================

class PassPaperDeleteView(LoginRequiredMixin, UserPassesTestMixin, DeleteView):
    """
    Delete a pass paper
    """
    model = PassPaper
    template_name = 'study/passpaper_confirm_delete.html'
    success_url = reverse_lazy('study:passpaper_list')
    
    def test_func(self):
        paper = self.get_object()
        # Allow if user is uploader, admin, or has admin role
        return (
            self.request.user == paper.uploaded_by or
            self.request.user.is_staff or
            self.request.user.profile.role == 'admin'
        )
    
    def delete(self, request, *args, **kwargs):
        messages.success(request, "✅ Pass paper deleted successfully!")
        return super().delete(request, *args, **kwargs)


# ==================== DOWNLOAD PASS PAPER ====================

@login_required
def download_passpaper(request, pk):
    """
    Download a pass paper (handles credit deduction)
    """
    paper = get_object_or_404(PassPaper, pk=pk)
    
    # Check if paper is public
    if not paper.is_public and not request.user.is_staff:
        messages.error(request, "This paper is not available for download.")
        return redirect('study:passpaper_list')
    
    # Check credits if required
    if paper.requires_credits > 0:
        if request.user.credits < paper.requires_credits:
            messages.error(
                request, 
                f"Insufficient credits. You need {paper.requires_credits} credits but you have {request.user.credits}."
            )
            return redirect('study:passpaper_detail', pk=pk)
        
        # Deduct credits
        request.user.credits -= paper.requires_credits
        request.user.save()
        messages.info(request, f"{paper.requires_credits} credits deducted.")
    
    # Increment download count
    paper.download_count += 1
    paper.save(update_fields=['download_count'])
    
    # Log download (optional)
    # DownloadLog.objects.create(user=request.user, paper=paper)
    
    # Redirect to Cloudinary file
    return redirect(paper.file.url)


# ==================== BULK UPLOAD PASS PAPERS ====================

@login_required
@user_passes_test(lambda u: u.profile.role in ['admin'])
def bulk_upload_passpapers(request):
    """
    Bulk upload multiple pass papers via ZIP or CSV (admin only)
    """
    if request.method == 'POST':
        # Handle ZIP file upload
        zip_file = request.FILES.get('zip_file')
        csv_file = request.FILES.get('csv_file')
        
        if not zip_file and not csv_file:
            messages.error(request, "Please upload a ZIP file or CSV file.")
            return redirect('study:bulk_upload_passpapers')
        
        # Process bulk upload (simplified - you'd need to implement extraction)
        messages.success(request, f"Bulk upload feature coming soon!")
        return redirect('study:passpaper_list')
    
    return render(request, 'study/bulk_upload.html')


# ==================== MY UPLOADS (for setters/teachers) ====================

class MyUploadsView(LoginRequiredMixin, ListView):
    """
    View papers uploaded by the current user
    """
    model = PassPaper
    template_name = 'study/my_uploads.html'
    context_object_name = 'papers'
    paginate_by = 20
    
    def get_queryset(self):
        return PassPaper.objects.filter(
            uploaded_by=self.request.user
        ).select_related('subject', 'education_level').order_by('-uploaded_at')
    
    def get_context_data(self, **kwargs):
        context = super().get_context_data(**kwargs)
        context['total_downloads'] = self.get_queryset().aggregate(
            total=models.Sum('download_count')
        )['total'] or 0
        context['total_views'] = self.get_queryset().aggregate(
            total=models.Sum('view_count')
        )['total'] or 0
        return context


# ==================== PASS PAPER STATISTICS (for admins) ====================

@login_required
@user_passes_test(lambda u: u.is_staff or u.profile.role == 'admin')
def passpaper_statistics(request):
    """
    View statistics about pass papers (admin only)
    """
    total_papers = PassPaper.objects.count()
    total_downloads = PassPaper.objects.aggregate(total=models.Sum('download_count'))['total'] or 0
    total_views = PassPaper.objects.aggregate(total=models.Sum('view_count'))['total'] or 0
    
    # Most downloaded papers
    top_downloaded = PassPaper.objects.order_by('-download_count')[:10]
    
    # Papers by subject
    papers_by_subject = PassPaper.objects.values(
        'subject__name'
    ).annotate(
        count=models.Count('id'),
        downloads=models.Sum('download_count')
    ).order_by('-count')
    
    # Papers by year
    papers_by_year = PassPaper.objects.values('year').annotate(
        count=models.Count('id')
    ).order_by('-year')
    
    context = {
        'total_papers': total_papers,
        'total_downloads': total_downloads,
        'total_views': total_views,
        'top_downloaded': top_downloaded,
        'papers_by_subject': papers_by_subject,
        'papers_by_year': papers_by_year,
    }
    
    return render(request, 'study/passpaper_statistics.html', context)


# ==================== FEATURED PASS PAPERS (for homepage) ====================

def get_featured_passpapers(limit=6):
    """
    Utility function to get featured pass papers for homepage
    """
    return PassPaper.objects.filter(
        is_public=True
    ).select_related(
        'subject', 'education_level'
    ).order_by('-year', '-download_count')[:limit]

class LessonExerciseCreateView(LoginRequiredMixin, CreateView):
    model = LessonExercise
    form_class = LessonExerciseForm
    template_name = 'study/exercise_form.html'
    def dispatch(self, request, *args, **kwargs):
        self.resource = get_object_or_404(StudyResource, pk=kwargs['resource_id'], creator=request.user)
        return super().dispatch(request, *args, **kwargs)
    def form_valid(self, form):
        form.instance.resource = self.resource
        return super().form_valid(form)
    def get_success_url(self):
        return reverse_lazy('study:resource_detail', kwargs={'pk': self.resource.pk})

class LessonExerciseDetailView(LoginRequiredMixin, DetailView):
    model = LessonExercise
    template_name = 'study/exercise_detail.html'
    context_object_name = 'exercise'
    def get_queryset(self):
        return LessonExercise.objects.filter(
            resource__in=StudyResource.objects.filter(
                Q(members_only=False, access_level='public', is_approved=True)
                | Q(creator=self.request.user)
                | Q(creator__creator_memberships__member=self.request.user, creator__creator_memberships__status='accepted')
                | Q(institution__membership_requests__user=self.request.user, institution__membership_requests__status='accepted', is_approved=True)
            )
        ).distinct()
    def post(self, request, *args, **kwargs):
        self.object = self.get_object()
        score = 0
        total = 0
        results = []
        for index, question in enumerate(self.object.questions or []):
            total += 1
            answer = request.POST.get(f'q_{index}', '').strip()
            expected = str(question.get('answer', '')).strip()
            correct = False
            if expected and self.object.template_type == 'calculation':
                try:
                    tolerance = float(question.get('tolerance', self.object.template_config.get('tolerance', 0)))
                    correct = abs(float(answer) - float(expected)) <= tolerance
                except (TypeError, ValueError):
                    correct = False
            elif expected:
                correct = answer.lower() == expected.lower()
            score += int(correct)
            results.append({'question': question.get('question', ''), 'correct': correct, 'answer': answer, 'expected': expected})
        if self.object.marking_mode == 'TEACHER' or any(not q.get('answer') for q in (self.object.questions or [])):
            submission = LessonExerciseSubmission.objects.create(exercise=self.object, student=request.user, answers={str(i): request.POST.get(f'q_{i}', '') for i, _ in enumerate(self.object.questions or [])})
            return self.render_to_response(self.get_context_data(submitted=True, sent_to_teacher=True, submission=submission))
        percentage = (score / total * 100 if total else 0)
        submission = LessonExerciseSubmission.objects.create(exercise=self.object, student=request.user, answers={str(i): request.POST.get(f'q_{i}', '') for i, _ in enumerate(self.object.questions or [])}, status=LessonExerciseSubmission.MARKED, score=percentage)
        progress, _ = StudyResourceProgress.objects.get_or_create(user=request.user, resource=self.object.resource, defaults={'first_opened_at': timezone.now()})
        progress.exercises_attempted += 1
        progress.exercises_completed += 1
        progress.average_score = percentage
        progress.status = StudyResourceProgress.NEEDS_REVIEW if percentage < self.object.mastery_threshold else StudyResourceProgress.IN_PROGRESS
        progress.progress_percent = max(progress.progress_percent, min(95, int(percentage)))
        progress.last_opened_at = timezone.now()
        progress.save(update_fields=['exercises_attempted', 'exercises_completed', 'average_score', 'status', 'progress_percent', 'last_opened_at', 'updated_at'])
        if self.object.resource.study_unit_id:
            unit_progress, _ = StudyUnitProgress.objects.get_or_create(user=request.user, unit=self.object.resource.study_unit)
            unit_progress.progress_percent = max(unit_progress.progress_percent, min(95, int(percentage)))
            unit_progress.status = 'completed' if percentage >= self.object.mastery_threshold else 'needs_review'
            unit_progress.last_opened_at = timezone.now()
            if unit_progress.status == 'completed':
                unit_progress.completed_at = timezone.now()
            unit_progress.save(update_fields=['progress_percent', 'status', 'last_opened_at', 'completed_at'])
            _refresh_study_unit_ancestors(request.user, self.object.resource.study_unit)
        return self.render_to_response(self.get_context_data(results=results, score=score, total=total, submitted=True))

@login_required
def exercise_submissions(request, pk):
    exercise = get_object_or_404(LessonExercise, pk=pk, resource__creator=request.user)
    submissions = exercise.submissions.select_related('student').order_by('status', 'submitted_at')
    return render(request, 'study/exercise_submissions.html', {'exercise': exercise, 'submissions': submissions})

@login_required
@require_http_methods(['POST'])
def exercise_submission_review(request, pk):
    submission = get_object_or_404(LessonExerciseSubmission, pk=pk, exercise__resource__creator=request.user)
    submission.status = 'marked'; submission.score = float(request.POST.get('score', 0) or 0); submission.feedback = request.POST.get('feedback', '').strip(); submission.reviewed_by = request.user; submission.reviewed_at = timezone.now(); submission.save(update_fields=['status','score','feedback','reviewed_by','reviewed_at'])
    messages.success(request, 'Exercise submission marked.')
    return redirect('study:exercise_submissions', pk=submission.exercise_id)


@login_required
def mark_resource_complete(request, pk):
    if request.method != 'POST':
        return JsonResponse({'status': 'error', 'message': 'POST required'}, status=405)
    resource = get_object_or_404(StudyResource, pk=pk)
    if resource.creator == request.user:
        return JsonResponse({'status': 'error', 'message': 'Creators do not receive learner progress for their own material.'}, status=400)
    now = timezone.now()
    progress, _ = StudyResourceProgress.objects.get_or_create(user=request.user, resource=resource, defaults={'first_opened_at': now})
    progress.status = StudyResourceProgress.COMPLETED
    progress.progress_percent = 100
    progress.completed_at = now
    progress.last_opened_at = now
    progress.save(update_fields=['status', 'progress_percent', 'completed_at', 'last_opened_at', 'updated_at'])
    return JsonResponse({'status': 'success', 'progress_percent': 100, 'label': 'Completed'})

@login_required
def study_progress(request):
    rows = StudyResourceProgress.objects.filter(user=request.user).select_related('resource', 'resource__education_level')
    summary = {'materials_started': rows.exclude(status=StudyResourceProgress.NOT_STARTED).count(), 'materials_completed': rows.filter(status=StudyResourceProgress.COMPLETED).count(), 'exercises_attempted': sum(r.exercises_attempted for r in rows), 'needs_review': rows.filter(status=StudyResourceProgress.NEEDS_REVIEW).count()}
    return render(request, 'study/progress.html', {'progress_rows': rows[:12], 'summary': summary})

@login_required
def setter_progress(request):
    resources = StudyResource.objects.filter(creator=request.user)
    rows = []
    for resource in resources:
        progress = StudyResourceProgress.objects.filter(resource=resource)
        submissions = LessonExerciseSubmission.objects.filter(exercise__resource=resource)
        rows.append({'resource': resource, 'learners_started': progress.exclude(status=StudyResourceProgress.NOT_STARTED).count(), 'learners_completed': progress.filter(status=StudyResourceProgress.COMPLETED).count(), 'average_progress': round(progress.aggregate(value=Avg('progress_percent'))['value'] or 0), 'exercises_attempted': submissions.count(), 'average_score': round(submissions.aggregate(value=Avg('score'))['value'] or 0, 1)})
    return render(request, 'study/setter_progress.html', {'resource_rows': rows})


@login_required
def mark_resource_complete(request, pk):
    if request.method != 'POST':
        return JsonResponse({'status': 'error', 'message': 'POST required'}, status=405)
    resource = get_object_or_404(StudyResource, pk=pk)
    if resource.creator == request.user:
        return JsonResponse({'status': 'error', 'message': 'Creators do not receive learner progress for their own material.'}, status=400)
    now = timezone.now()
    progress, _ = StudyResourceProgress.objects.get_or_create(user=request.user, resource=resource, defaults={'first_opened_at': now})
    progress.status = StudyResourceProgress.COMPLETED
    progress.progress_percent = 100
    progress.completed_at = now
    progress.last_opened_at = now
    progress.save(update_fields=['status', 'progress_percent', 'completed_at', 'last_opened_at', 'updated_at'])
    return JsonResponse({'status': 'success', 'progress_percent': 100, 'label': 'Completed'})

@login_required
def study_progress(request):
    rows = StudyResourceProgress.objects.filter(user=request.user).select_related('resource', 'resource__education_level')
    summary = {'materials_started': rows.exclude(status=StudyResourceProgress.NOT_STARTED).count(), 'materials_completed': rows.filter(status=StudyResourceProgress.COMPLETED).count(), 'exercises_attempted': sum(r.exercises_attempted for r in rows), 'needs_review': rows.filter(status=StudyResourceProgress.NEEDS_REVIEW).count()}
    return render(request, 'study/progress.html', {'progress_rows': rows[:12], 'summary': summary})

@login_required
def setter_progress(request):
    resources = StudyResource.objects.filter(creator=request.user)
    rows = []
    for resource in resources:
        progress = StudyResourceProgress.objects.filter(resource=resource)
        submissions = LessonExerciseSubmission.objects.filter(exercise__resource=resource)
        rows.append({'resource': resource, 'learners_started': progress.exclude(status=StudyResourceProgress.NOT_STARTED).count(), 'learners_completed': progress.filter(status=StudyResourceProgress.COMPLETED).count(), 'average_progress': round(progress.aggregate(value=Avg('progress_percent'))['value'] or 0), 'exercises_attempted': submissions.count(), 'average_score': round(submissions.aggregate(value=Avg('score'))['value'] or 0, 1)})
    return render(request, 'study/setter_progress.html', {'resource_rows': rows})


@login_required
def study_path(request):
    institution_ids = list(request.user.institution_membership_requests.filter(status='accepted').values_list('institution_id', flat=True))
    institution_ids.extend(request.user.administered_institutions.values_list('id', flat=True))
    units = StudyUnit.objects.filter(institution_id__in=set(institution_ids), parent__isnull=True).select_related('education_level', 'subject', 'topic').prefetch_related('children')
    unit_rows = []
    for unit in units:
        children = list(unit.children.all())
        rows = [StudyUnitProgress.objects.filter(user=request.user, unit=child).first() for child in children]
        percent = int(sum(row.progress_percent if row else 0 for row in rows) / len(rows)) if rows else (StudyUnitProgress.objects.filter(user=request.user, unit=unit).values_list('progress_percent', flat=True).first() or 0)
        unit_rows.append((unit, percent))
    return render(request, 'study/path.html', {'unit_rows': unit_rows})

@login_required
def study_unit_detail(request, pk):
    unit = get_object_or_404(StudyUnit, pk=pk)
    is_member = unit.institution.membership_requests.filter(user=request.user, status='accepted').exists()
    if unit.institution and not (unit.is_published or unit.created_by == request.user or request.user.is_staff or is_member):
        return JsonResponse({'status': 'error', 'message': 'This Study unit is not available.'}, status=403)
    now = timezone.now()
    progress, _ = StudyUnitProgress.objects.get_or_create(user=request.user, unit=unit)
    if progress.status == 'not_started':
        progress.status = 'in_progress'; progress.progress_percent = max(progress.progress_percent, 10); progress.last_opened_at = now; progress.save(update_fields=['status','progress_percent','last_opened_at'])
    children = list(unit.children.all())
    child_rows = []
    for child in children:
        child_progress = StudyUnitProgress.objects.filter(user=request.user, unit=child).first()
        child_rows.append((child, child_progress))
    return render(request, 'study/unit_detail.html', {'unit': unit, 'progress': progress, 'child_rows': child_rows, 'resources': unit.resources.filter(is_approved=True), 'exercises': LessonExercise.objects.filter(resource__study_unit=unit)})

@login_required
def mark_unit_complete(request, pk):
    if request.method != 'POST': return JsonResponse({'status': 'error', 'message': 'POST required'}, status=405)
    unit = get_object_or_404(StudyUnit, pk=pk)
    progress, _ = StudyUnitProgress.objects.get_or_create(user=request.user, unit=unit)
    progress.status = 'completed'; progress.progress_percent = 100; progress.completed_at = timezone.now(); progress.last_opened_at = timezone.now(); progress.save()
    _refresh_study_unit_ancestors(request.user, unit)
    return redirect('study:study_unit_detail', pk=unit.pk)
