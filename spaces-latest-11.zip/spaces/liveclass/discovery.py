
from django.db import models
from django.db.models import Q

from core.services.recommendations import (
    profile_context,
    rank_items,
    record_search,
)
from .models import LiveClass
from trends.access import accepted_institution_ids, is_institution_member


def has_learning_context(user):
    """
    Return True when the learner has useful profile information.

    This works for primary, secondary, college, university,
    professional, and adult-learning users.
    """
    context = profile_context(user)

    context_keys = [
        'country',
        'education_system',
        'education_stage',
        'education_level',
        'institution',
        'program',
        'programme',
        'academic_year',
    ]

    if any(context.get(key) for key in context_keys):
        return True

    return bool(context.get('subjects'))


def public_live_classes(status_filter=''):
    """
    Return public scheduled/live classes only.

    Ended classes remain accessible through their existing links and
    My Classes, but do not appear in public discovery.
    """
    classes = LiveClass.objects.filter(
        deleted_at__isnull=True,
        visibility=LiveClass.VISIBILITY_PUBLIC,
        status__in=['scheduled', 'live', 'ended'],
    ).select_related(
        'teacher',
        'education_system',
        'education_level',
        'institution',
        'program',
        'academic_year',
    )

    if status_filter in {'live', 'scheduled'}:
        classes = classes.filter(status=status_filter)

    return classes


def class_metadata(live_class):
    """
    Convert a LiveClass object into universal recommendation metadata.
    """
    education_level = getattr(
        live_class.education_level,
        'name',
        '',
    )

    education_system = getattr(
        live_class.education_system,
        'name',
        '',
    )

    institution = getattr(
        live_class.institution,
        'name',
        '',
    )

    programme = getattr(
        live_class.program,
        'name',
        '',
    )

    academic_year = getattr(
        live_class.academic_year,
        'name',
        '',
    )

    country = ''

    if live_class.institution:
        country = str(
            getattr(
                live_class.institution,
                'country',
                '',
            )
        )

    return {
        'id': str(live_class.id),
        'title': live_class.title,
        'description': live_class.description,
        'source_app': 'spaces',
        'content_type': 'live_class',
        'country': country,
        'education_system': education_system,
        'education_stage': live_class.education_stage,
        'education_level': education_level,
        'institution': institution,
        'program': programme,
        'programme': programme,
        'academic_year': academic_year,
        'subject': live_class.subject_or_course_unit,
        'subject_or_course_unit': (
            live_class.subject_or_course_unit
        ),
        'topic': live_class.topic,
        'language': live_class.language,
        'popularity_score': live_class.popularity_score,
        'created_at': live_class.created_at,
    }


def apply_metadata_to_class(live_class, metadata):
    """
    Attach recommendation information to a model instance without
    writing recommendation fields to the database.
    """
    live_class.recommendation_score = metadata.get(
        'recommendation_score',
        0,
    )

    live_class.recommendation_reasons = metadata.get(
        'recommendation_reasons',
        [],
    )

    return live_class


def search_live_classes(
    user,
    query='',
    status_filter='',
    limit=30,
):
    """
    Search and rank public classes.

    Searches:
    - title
    - description
    - teacher username
    - subject/course unit
    - topic
    - education stage
    - education level
    - education system
    - programme
    - academic year
    """
    query = (query or '').strip()

    classes = public_live_classes(status_filter=status_filter)
    if query:
        # A known title may be searched; watch_class still enforces access.
        classes = LiveClass.objects.filter(
            deleted_at__isnull=True,
            status__in=['scheduled', 'live', 'ended'],
        ).select_related('teacher', 'education_system', 'education_level', 'institution', 'program', 'academic_year')
        if status_filter in {'live', 'scheduled'}:
            classes = classes.filter(status=status_filter)
        classes = classes.filter(
            Q(title__icontains=query)
            | Q(description__icontains=query)
            | Q(teacher__username__icontains=query)
            | Q(subject_or_course_unit__icontains=query)
            | Q(topic__icontains=query)
            | Q(education_stage__icontains=query)
            | Q(education_level__name__icontains=query)
            | Q(education_system__name__icontains=query)
            | Q(program__name__icontains=query)
            | Q(academic_year__name__icontains=query)
        )

        record_search(
            user=user,
            query=query,
            source_app='spaces',
        )

        classes.update(
            search_count=models.F('search_count') + 1,
        )

    class_objects = list(classes[:limit])

    metadata_items = [
        class_metadata(live_class)
        for live_class in class_objects
    ]

    ranked_items = rank_items(
        user=user,
        items=metadata_items,
        query=query,
        limit=limit,
    )

    object_by_id = {
        str(live_class.id): live_class
        for live_class in class_objects
    }

    ranked_classes = []

    for item in ranked_items:
        live_class = object_by_id.get(
            str(item.get('id')),
        )

        if live_class:
            apply_metadata_to_class(
                live_class,
                item,
            )
            ranked_classes.append(live_class)

    return ranked_classes


def discover_live_classes(
    user,
    query='',
    status_filter='',
    limit=30,
):
    """
    Main discovery entry point.

    - Search query: return matching public classes.
    - No search: return profile-ranked or popular public classes.
    """
    query = (query or '').strip()

    if query:
        return search_live_classes(
            user=user,
            query=query,
            status_filter=status_filter,
            limit=limit,
        )

    profile = getattr(user, 'profile', None)
    has_context = bool(
        profile and (
            getattr(profile, 'institution_id', None)
            or getattr(profile, 'education_level_id', None)
            or getattr(profile, 'education_system_id', None)
            or profile.studying_subjects.exists()
        )
    )
    if not has_context and not accepted_institution_ids(user):
        return []
    classes = public_live_classes(status_filter=status_filter)
    class_objects = list(
        classes.order_by(
            '-viewer_count',
            '-max_viewers',
            '-join_count',
            '-created_at',
        )[:limit]
    )

    metadata_items = [
        class_metadata(live_class)
        for live_class in class_objects
    ]

    ranked_items = rank_items(
        user=user,
        items=metadata_items,
        query='',
        limit=limit,
    )

    object_by_id = {
        str(live_class.id): live_class
        for live_class in class_objects
    }

    ranked_classes = []

    for item in ranked_items:
        live_class = object_by_id.get(
            str(item.get('id')),
        )

        if live_class:
            apply_metadata_to_class(
                live_class,
                item,
            )
            ranked_classes.append(live_class)

    return ranked_classes


def count_join(live_class):
    """
    Increment class popularity when a learner joins.
    """
    LiveClass.objects.filter(
        pk=live_class.pk,
    ).update(
        join_count=models.F('join_count') + 1,
    )


