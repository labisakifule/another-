from django.core.management.base import BaseCommand
from django.utils.text import slugify
from liveclass.models import LiveClass
from django.db import transaction
import re

class Command(BaseCommand):
    help = 'Clean and regenerate slugs for all LiveClass instances'

    def add_arguments(self, parser):
        parser.add_argument(
            '--dry-run',
            action='store_true',
            help='Show what would be changed without making changes',
        )

    def handle(self, *args, **options):
        dry_run = options.get('dry_run', False)
        
        self.stdout.write(self.style.WARNING('=' * 60))
        if dry_run:
            self.stdout.write(self.style.WARNING('🔍 DRY RUN MODE - No changes will be made'))
        else:
            self.stdout.write(self.style.WARNING('🔄 Cleaning and regenerating slugs...'))
        self.stdout.write(self.style.WARNING('=' * 60))

        classes = LiveClass.objects.all()
        total = classes.count()
        
        if total == 0:
            self.stdout.write(self.style.SUCCESS('✅ No classes found. Nothing to clean.'))
            return

        self.stdout.write(f'📊 Found {total} classes to process')

        updated_count = 0
        empty_slug_count = 0
        invalid_slug_count = 0

        for class_obj in classes:
            original_slug = class_obj.slug
            changed = False
            reason = ''

            # Check if slug is empty or None
            if not class_obj.slug:
                empty_slug_count += 1
                reason = 'empty slug'
                # Generate new slug from title
                base_slug = slugify(class_obj.title)
                if not base_slug:
                    # If title is empty or doesn't produce a slug, use a fallback
                    base_slug = f"class-{str(class_obj.id)[:8]}"
                
                class_obj.slug = base_slug
                changed = True

            # Check if slug is valid (only letters, numbers, hyphens, underscores)
            elif not re.match(r'^[a-zA-Z0-9_-]+$', class_obj.slug):
                invalid_slug_count += 1
                reason = 'invalid slug'
                # Regenerate from title
                new_slug = slugify(class_obj.title) or f"class-{str(class_obj.id)[:8]}"
                class_obj.slug = new_slug
                changed = True

            # Ensure slug is unique (add suffix if duplicate)
            if changed:
                self.stdout.write(f'  ⚠️ Class "{class_obj.title}" has {reason} (ID: {str(class_obj.id)[:8]})')
                
                # Check if slug already exists for another class
                existing = LiveClass.objects.filter(slug=class_obj.slug).exclude(id=class_obj.id)
                if existing.exists():
                    counter = 1
                    original_slug = class_obj.slug
                    while LiveClass.objects.filter(slug=class_obj.slug).exclude(id=class_obj.id).exists():
                        class_obj.slug = f"{original_slug}-{counter}"
                        counter += 1
                    self.stdout.write(f'  ℹ️ Slug conflict resolved: "{original_slug}" → "{class_obj.slug}"')

                # Save the changes
                if not dry_run:
                    with transaction.atomic():
                        class_obj.save(update_fields=['slug'])
                updated_count += 1
                self.stdout.write(f'  ✅ Updated: "{original_slug or "EMPTY"}" → "{class_obj.slug}"')

        # Display summary
        self.stdout.write(self.style.WARNING('=' * 60))
        self.stdout.write(self.style.SUCCESS('📋 SUMMARY:'))
        self.stdout.write(f'  • Total classes processed: {total}')
        self.stdout.write(f'  • Empty slugs found: {empty_slug_count}')
        self.stdout.write(f'  • Invalid slugs found: {invalid_slug_count}')
        self.stdout.write(f'  • Slugs updated: {updated_count}')
        
        if dry_run:
            self.stdout.write(self.style.WARNING('\n⚠️ This was a DRY RUN. No changes were saved.'))
            self.stdout.write(self.style.WARNING('Run without --dry-run to apply changes.'))
        else:
            self.stdout.write(self.style.SUCCESS('✅ All slugs have been cleaned and updated!'))

        self.stdout.write(self.style.WARNING('=' * 60))

        # Show a few examples
        if updated_count > 0:
            self.stdout.write('\n📝 Updated classes:')
            for class_obj in LiveClass.objects.filter(slug__isnull=False).exclude(slug='')[:5]:
                self.stdout.write(f'  • {class_obj.title}: slug="{class_obj.slug}"')
