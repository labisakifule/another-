import json
import logging

from django.conf import settings
from django.contrib import messages
from django.contrib.auth.decorators import login_required, user_passes_test
from django.db import models
from django.http import JsonResponse
from django.shortcuts import get_object_or_404, redirect, render
from django.utils import timezone
from django.views.decorators.http import require_http_methods

from .forms import LiveClassForm
from .models import ChatMessage, HandRaise, LiveClass, StudentStatus
from .discovery import discover_live_classes, has_learning_context
from trends.access import is_institution_member


logger = logging.getLogger(__name__)


VALID_CLASS_STATUSES = {
    'scheduled',
    'live',
    'ended',
}


def is_teacher_or_admin(user):
    """Allow platform staff and approved institution teaching staff to create classes."""
    if not user.is_authenticated:
        return False
    if user.is_staff or user.is_superuser:
        return True
    profile = getattr(user, 'profile', None)
    if not profile or not profile.institution_id:
        return False
    return (
        profile.institution_role in {'institution_admin', 'institution_manager', 'staff', 'teacher', 'setter'}
        and is_institution_member(user, profile.institution)
    )


def can_manage_class(user, live_class):
    """
    A class can be managed by its teacher, a staff member, or a
    superuser.
    """
    return (
        user.is_authenticated
        and (
            user == live_class.teacher
            or user.is_staff
            or user.is_superuser
        )
    )


def class_json(request):
    """
    Safely decode a JSON request body.
    """
    try:
        payload = json.loads(request.body or '{}')
    except (TypeError, ValueError, json.JSONDecodeError):
        return None

    return payload if isinstance(payload, dict) else None


@login_required
def dashboard_router(request):
    """
    Existing /liveclass/ entry point.

    Staff and superusers see all classes. Other users see classes
    assigned to them as teacher, preserving the current flow.
    """
    if request.user.is_staff or request.user.is_superuser:
        classes = LiveClass.objects.all().order_by('-created_at')
    else:
        classes = LiveClass.objects.filter(
            teacher=request.user
        ).order_by('-created_at')

    stats = {
        'total': classes.count(),
        'live': classes.filter(status='live').count(),
        'scheduled': classes.filter(status='scheduled').count(),
        'ended': classes.filter(status='ended').count(),
    }

    is_teacher = (
        classes.filter(teacher=request.user).exists()
        or request.user.is_staff
        or request.user.is_superuser
    )

    return render(
        request,
        'liveclass/teacher_dashboard.html',
        {
            'classes': classes,
            'stats': stats,
            'is_teacher_or_admin': is_teacher,
            'mediamtx_host': settings.MEDIAMTX_HOST,
        },
    )


@login_required
@user_passes_test(is_teacher_or_admin, login_url='dashboard')
def create_class(request):
    """
    Create a new Live Class using the existing LiveClassForm.
    """
    if request.method == 'POST':
        form = LiveClassForm(request.POST)

        if form.is_valid():
            live_class = form.save(commit=False)
            live_class.teacher = request.user
            profile = getattr(request.user, 'profile', None)
            if profile and profile.institution_id:
                live_class.institution = profile.institution

            if form.cleaned_data.get('start_now'):
                live_class.status = 'live'
                live_class.started_at = timezone.now()
            else:
                live_class.status = 'scheduled'

            live_class.save()

            messages.success(
                request,
                f'Class "{live_class.title}" created successfully.',
            )

            return redirect(
                'liveclass:class_dashboard',
                slug=live_class.slug,
            )
    else:
        form = LiveClassForm()

    return render(
        request,
        'liveclass/create_class.html',
        {
            'form': form,
            'mediamtx_host': settings.MEDIAMTX_HOST,
        },
    )


@login_required
def class_dashboard(request, slug):
    """
    Teacher classroom page.

    The teacher keeps access after the stream ends so saved chat
    history remains available.
    """
    live_class = get_object_or_404(LiveClass, slug=slug)

    if not can_manage_class(request.user, live_class):
        messages.error(
            request,
            'You do not have permission to manage this class.',
        )
        return redirect('liveclass:dashboard')

    recent_chat = live_class.chat_messages.all()[:100]

    active_students = StudentStatus.objects.filter(
        stream=live_class,
        is_active=True,
    ).select_related('user')

    hand_raises = HandRaise.objects.filter(
        stream=live_class,
        is_active=True,
    ).select_related('user')

    return render(
        request,
        'liveclass/class_dashboard.html',
        {
            'class': live_class,
            'recent_chat': recent_chat,
            'active_students': active_students,
            'hand_raises': hand_raises,
            'mediamtx_host': settings.MEDIAMTX_HOST,
            'publish_url': live_class.get_publish_url(),
            'watch_url': live_class.get_watch_url(),
            'rtmp_url': live_class.get_rtmp_url(),
            'class_ended': live_class.status == 'ended',
        },
    )


@login_required
@require_http_methods(['POST'])
def start_class(request, slug):
    """
    Mark a class as live.
    """
    live_class = get_object_or_404(LiveClass, slug=slug)

    if not can_manage_class(request.user, live_class):
        return JsonResponse(
            {'error': 'Permission denied'},
            status=403,
        )

    if live_class.status != 'live':
        live_class.status = 'live'

        if not live_class.started_at:
            live_class.started_at = timezone.now()

        live_class.ended_at = None
        live_class.save(
            update_fields=[
                'status',
                'started_at',
                'ended_at',
                'updated_at',
            ]
        )

        messages.success(request, 'Class is now live.')
    else:
        messages.info(request, 'Class is already live.')

    return redirect(
        'liveclass:class_dashboard',
        slug=slug,
    )


@login_required
@require_http_methods(['POST'])
def end_class(request, slug):
    """
    End the broadcast while preserving the class and all chat history.
    """
    live_class = get_object_or_404(LiveClass, slug=slug)

    if not can_manage_class(request.user, live_class):
        return JsonResponse(
            {'error': 'Permission denied'},
            status=403,
        )

    if live_class.status == 'live':
        live_class.status = 'ended'
        live_class.ended_at = timezone.now()
        live_class.save(
            update_fields=[
                'status',
                'ended_at',
                'updated_at',
            ]
        )

        messages.success(
            request,
            'Class ended. The classroom conversation remains available.',
        )
    else:
        messages.info(request, 'Class is not currently live.')

    return redirect(
        'liveclass:class_dashboard',
        slug=slug,
    )



@login_required
@require_http_methods(['POST'])
def delete_class(request, slug):
    """Permanently delete a class owned by the requester."""
    live_class = get_object_or_404(LiveClass, slug=slug)

    allowed = (
        request.user == live_class.teacher
        or request.user.is_staff
        or request.user.is_superuser
    )

    if not allowed:
        return JsonResponse(
            {'error': 'Permission denied'},
            status=403,
        )

    title = live_class.title
    live_class.delete()
    messages.success(request, f'Class "{title}" deleted permanently.')

    if request.user.is_staff or request.user.is_superuser:
        return redirect('liveclass:admin_all_classes')

    return redirect('liveclass:dashboard')

@login_required
def class_settings(request, slug):
    """
    Update class settings without deleting chat history.
    """
    live_class = get_object_or_404(LiveClass, slug=slug)

    if not can_manage_class(request.user, live_class):
        messages.error(request, 'Permission denied.')
        return redirect('liveclass:dashboard')

    if request.method == 'POST':
        form = LiveClassForm(
            request.POST,
            instance=live_class,
        )

        if form.is_valid():
            form.save()

            messages.success(
                request,
                'Settings updated successfully.',
            )

            return redirect(
                'liveclass:class_dashboard',
                slug=slug,
            )
    else:
        form = LiveClassForm(instance=live_class)

    return render(
        request,
        'liveclass/settings.html',
        {
            'class': live_class,
            'form': form,
            'mediamtx_host': settings.MEDIAMTX_HOST,
        },
    )


@login_required
def watch_class(request, slug):
    """
    Student watch page.

    Ended classes remain accessible so participants can review
    previous chat and continue the conversation. The stream player
    simply shows that the broadcast has ended.
    """
    live_class = get_object_or_404(LiveClass, slug=slug, deleted_at__isnull=True)

    if live_class.visibility == LiveClass.VISIBILITY_PRIVATE and not can_manage_class(request.user, live_class) and not StudentStatus.objects.filter(stream=live_class, user=request.user).exists():
        messages.error(request, 'This class is private. Join permission is required.')
        return redirect('liveclass:student_dashboard')
    if live_class.visibility == LiveClass.VISIBILITY_INSTITUTION and not can_manage_class(request.user, live_class):
        if not is_institution_member(request.user, live_class.institution):
            messages.error(request, 'This class is available only to institution members.')
            return redirect('liveclass:student_dashboard')

    return render(
        request,
        'liveclass/watch_class.html',
        {
            'class': live_class,
            'mediamtx_host': settings.MEDIAMTX_HOST,
            'watch_url': live_class.get_watch_url(),
            'class_ended': live_class.status == 'ended',
        },
    )


@login_required
def student_dashboard(request):
    """
    Browse public Live Classes through the universal discovery layer.

    New users see popular classes. Users with learner profile data see
    profile-ranked classes. Searches are saved for future relevance.
    """
    query = request.GET.get('q', '').strip()
    status_filter = request.GET.get('status', '').strip()

    if status_filter not in {'live', 'scheduled'}:
        status_filter = ''

    classes = discover_live_classes(
        user=request.user,
        query=query,
        status_filter=status_filter,
        limit=30,
    )

    has_context = has_learning_context(request.user)

    if query:
        section_title = f'Search results for “{query}”'
    elif has_context:
        section_title = 'Recommended for you'
    else:
        section_title = 'Popular live classes'

    return render(
        request,
        'liveclass/student_dashboard.html',
        {
            'classes': classes,
            'search_query': query,
            'status_filter': status_filter,
            'section_title': section_title,
            'has_learning_context': has_context,
            'mediamtx_host': settings.MEDIAMTX_HOST,
        },
    )

def my_classes(request):
    """
    Show every class the student has joined, including ended classes.

    This is important for post-class chat continuity.
    """
    student_statuses = StudentStatus.objects.filter(
        user=request.user,
    ).select_related('stream').order_by(
        '-stream__created_at'
    )

    classes = [status.stream for status in student_statuses]

    return render(
        request,
        'liveclass/my_classes.html',
        {
            'classes': classes,
            'mediamtx_host': settings.MEDIAMTX_HOST,
        },
    )


@login_required
def join_class(request, slug):
    """
    Join a live or scheduled class.

    If an ended class is opened through an old link, it remains
    accessible as a read-only stream page with persistent chat.
    """
    live_class = get_object_or_404(LiveClass, slug=slug)

    if live_class.status == 'ended':
        existing_status = StudentStatus.objects.filter(
            stream=live_class,
            user=request.user,
        ).first()

        if not existing_status:
            messages.info(
                request,
                'This class has ended. Opening its saved classroom chat.',
            )

        return redirect(
            'liveclass:watch_class',
            slug=slug,
        )

    status, created = StudentStatus.objects.get_or_create(
        stream=live_class,
        user=request.user,
        defaults={
            'is_active': True,
            'last_activity': timezone.now(),
        },
    )

    if not created:
        status.is_active = True
        status.last_activity = timezone.now()
        status.save(
            update_fields=[
                'is_active',
                'last_activity',
            ]
        )

    if created:
        count_join(live_class)

    live_class.viewer_count = StudentStatus.objects.filter(
        stream=live_class,
        is_active=True,
    ).count()

    if live_class.viewer_count > live_class.max_viewers:
        live_class.max_viewers = live_class.viewer_count

    live_class.save(
        update_fields=[
            'viewer_count',
            'max_viewers',
            'updated_at',
        ]
    )

    if created:
        messages.success(
            request,
            f'You joined "{live_class.title}".',
        )
    else:
        messages.info(
            request,
            f'You are already in "{live_class.title}".',
        )

    return redirect(
        'liveclass:watch_class',
        slug=slug,
    )


@login_required
def leave_class(request, slug):
    """
    Mark the participant inactive without deleting chat history.
    """
    live_class = get_object_or_404(LiveClass, slug=slug)

    StudentStatus.objects.filter(
        stream=live_class,
        user=request.user,
    ).update(
        is_active=False,
        last_activity=timezone.now(),
    )

    live_class.viewer_count = StudentStatus.objects.filter(
        stream=live_class,
        is_active=True,
    ).count()

    live_class.save(
        update_fields=[
            'viewer_count',
            'updated_at',
        ]
    )

    messages.info(
        request,
        f'You left "{live_class.title}".',
    )

    return redirect('liveclass:student_dashboard')


@login_required
@user_passes_test(
    lambda user: user.is_superuser or user.is_staff,
    login_url='dashboard',
)
def admin_all_classes(request):
    """
    Admin view of all classes.
    """
    classes = LiveClass.objects.all().order_by('-created_at')

    return render(
        request,
        'liveclass/admin_all_classes.html',
        {
            'classes': classes,
            'mediamtx_host': settings.MEDIAMTX_HOST,
        },
    )


@login_required
@user_passes_test(
    lambda user: user.is_superuser or user.is_staff,
    login_url='dashboard',
)
def admin_class_detail(request, slug):
    """
    Admin detail view, including persistent chat history.
    """
    live_class = get_object_or_404(LiveClass, slug=slug)

    active_students = StudentStatus.objects.filter(
        stream=live_class,
        is_active=True,
    ).select_related('user')

    chat_messages_list = live_class.chat_messages.all()[:100]

    hand_raises = HandRaise.objects.filter(
        stream=live_class,
        is_active=True,
    ).select_related('user')

    return render(
        request,
        'liveclass/admin_class_detail.html',
        {
            'class': live_class,
            'active_students': active_students,
            'chat_messages': chat_messages_list,
            'hand_raises': hand_raises,
            'class_ended': live_class.status == 'ended',
        },
    )


@login_required
@user_passes_test(
    lambda user: user.is_superuser or user.is_staff,
    login_url='dashboard',
)
@require_http_methods(['POST'])
def admin_delete_class(request, slug):
    """
    Delete the class and its related chat through the model's
    on_delete=models.CASCADE relationship.
    """
    live_class = get_object_or_404(LiveClass, slug=slug, deleted_at__isnull=True)
    title = live_class.title

    live_class.deleted_at = timezone.now()
    live_class.status = 'ended'
    live_class.save(update_fields=['deleted_at', 'status', 'updated_at'])

    messages.success(
        request,
        f'Class "{title}" and its chat history were deleted.',
    )

    return redirect('liveclass:admin_all_classes')


@login_required
def class_status(request, slug):
    """
    Class status API.

    GET is available to authenticated participants.
    POST is restricted to the teacher, staff, or superuser.
    """
    live_class = get_object_or_404(LiveClass, slug=slug)

    if request.method == 'POST':
        if not can_manage_class(request.user, live_class):
            return JsonResponse(
                {'error': 'Permission denied'},
                status=403,
            )

        data = class_json(request)

        if data is None:
            return JsonResponse(
                {'error': 'Invalid JSON body'},
                status=400,
            )

        status = data.get('status')

        if status not in VALID_CLASS_STATUSES:
            return JsonResponse(
                {'error': 'Invalid class status'},
                status=400,
            )

        live_class.status = status

        if status == 'live':
            if not live_class.started_at:
                live_class.started_at = timezone.now()

            live_class.ended_at = None

        elif status == 'ended':
            live_class.ended_at = timezone.now()

        live_class.save(
            update_fields=[
                'status',
                'started_at',
                'ended_at',
                'updated_at',
            ]
        )

        return JsonResponse({
            'status': 'ok',
            'class_status': live_class.status,
        })

    return JsonResponse({
        'status': live_class.status,
        'viewer_count': live_class.viewer_count,
        'is_live': live_class.is_live,
        'stream_key': live_class.stream_key,
        'slug': live_class.slug,
        'title': live_class.title,
        'teacher': live_class.teacher.username,
        'chat_available': True,
    })


@login_required
def chat_messages(request, slug):
    """
    Return saved chat history. This remains available after a
    broadcast ends until the class is deleted.
    """
    live_class = get_object_or_404(LiveClass, slug=slug)
    messages_list = live_class.chat_messages.all()[:100]

    return JsonResponse({
        'messages': [
            {
                'id': str(message.id),
                'username': message.user.username,
                'full_name': (
                    message.user.get_full_name()
                    or message.user.username
                ),
                'message': message.message,
                'created_at': message.created_at.isoformat(),
                'is_announcement': message.is_announcement,
            }
            for message in reversed(messages_list)
        ],
    })


@login_required
def toggle_hand_raise(request, slug):
    """
    HTTP fallback for hand raising.

    The main classroom UI uses the WebSocket consumer, but this
    endpoint remains available for the existing flow.
    """
    live_class = get_object_or_404(LiveClass, slug=slug)

    hand_raise, created = HandRaise.objects.get_or_create(
        stream=live_class,
        user=request.user,
        defaults={
            'is_active': True,
        },
    )

    if not created:
        hand_raise.is_active = not hand_raise.is_active
        hand_raise.save(
            update_fields=[
                'is_active',
                'raised_at',
            ]
            if hand_raise.is_active
            else ['is_active']
        )

    return JsonResponse({
        'is_active': hand_raise.is_active,
        'raised_at': hand_raise.raised_at.isoformat(),
    })


@login_required
@require_http_methods(['POST'])
def update_student_status(request, slug):
    """
    Update the participant's status and device state.
    """
    live_class = get_object_or_404(LiveClass, slug=slug)
    data = class_json(request)

    if data is None:
        return JsonResponse(
            {'error': 'Invalid JSON body'},
            status=400,
        )

    status_type = data.get('status', 'listening')

    allowed_statuses = {
        choice[0]
        for choice in StudentStatus.STATUS_CHOICES
    }

    if status_type not in allowed_statuses:
        status_type = 'listening'

    audio_enabled = bool(data.get('audio_enabled', False))
    camera_enabled = bool(data.get('camera_enabled', False))

    student_status, created = StudentStatus.objects.get_or_create(
        stream=live_class,
        user=request.user,
        defaults={
            'status': status_type,
            'audio_enabled': audio_enabled,
            'camera_enabled': camera_enabled,
            'is_active': True,
            'last_activity': timezone.now(),
        },
    )

    if not created:
        student_status.status = status_type
        student_status.audio_enabled = audio_enabled
        student_status.camera_enabled = camera_enabled
        student_status.is_active = True
        student_status.last_activity = timezone.now()
        student_status.save(
            update_fields=[
                'status',
                'audio_enabled',
                'camera_enabled',
                'is_active',
                'last_activity',
            ]
        )

    return JsonResponse({
        'status': 'ok',
        'class_status': live_class.status,
    })


