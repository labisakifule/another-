from django.urls import path
from . import views

app_name = 'liveclass'

urlpatterns = [
    # Student routes
    path('browse/', views.student_dashboard, name='student_dashboard'),
    path('my-classes/', views.my_classes, name='my_classes'),
    path('join/<slug:slug>/', views.join_class, name='join_class'),
    path('leave/<slug:slug>/', views.leave_class, name='leave_class'),
    path('<slug:slug>/watch/', views.watch_class, name='watch_class'),
    
    # Teacher/Admin routes
    path('', views.dashboard_router, name='dashboard'),
    path('create/', views.create_class, name='create_class'),
    path('<slug:slug>/', views.class_dashboard, name='class_dashboard'),
    path('<slug:slug>/delete/', views.delete_class, name='delete_class'),
    path('<slug:slug>/start/', views.start_class, name='start_class'),
    path('<slug:slug>/end/', views.end_class, name='end_class'),
    path('<slug:slug>/settings/', views.class_settings, name='class_settings'),
    
    # Admin routes
    path('admin/all/', views.admin_all_classes, name='admin_all_classes'),
    path('admin/<slug:slug>/', views.admin_class_detail, name='admin_class_detail'),
    path('admin/<slug:slug>/delete/', views.admin_delete_class, name='admin_delete_class'),
    
    # API routes
    path('api/<slug:slug>/status/', views.class_status, name='class_status'),
    path('api/<slug:slug>/chat/', views.chat_messages, name='chat_messages'),
    path('api/<slug:slug>/hand-raise/', views.toggle_hand_raise, name='toggle_hand_raise'),
    path('api/<slug:slug>/student-status/', views.update_student_status, name='update_student_status'),
]
