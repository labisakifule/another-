def liveclass_permissions(request):
    """Add permission checks to templates"""
    from .views import is_teacher_or_admin
    
    return {
        'is_teacher_or_admin': is_teacher_or_admin(request.user) if request.user.is_authenticated else False,
    }