from django.apps import AppConfig

class LiveclassConfig(AppConfig):
    default_auto_field = 'django.db.models.BigAutoField'
    name = 'liveclass'
    
    def ready(self):
        # Import signals if any
        pass