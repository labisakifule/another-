import json
import logging

from channels.db import database_sync_to_async
from channels.generic.websocket import AsyncWebsocketConsumer
from django.utils import timezone

from .models import ChatMessage, HandRaise, LiveClass, StudentStatus


logger = logging.getLogger(__name__)


class LiveClassConsumer(AsyncWebsocketConsumer):
    """
    WebSocket consumer for the existing route:

        /ws/liveclass/<class_id>/

    Chat is persisted in ChatMessage and remains available after the
    livestream ends. It is removed only when the LiveClass is deleted.
    """

    async def connect(self):
        self.class_id = self.scope['url_route']['kwargs']['class_id']
        self.room_group_name = f'liveclass_{self.class_id}'
        self.user = self.scope.get('user')
        self.accepted = False

        if not self.user or not self.user.is_authenticated:
            await self.close()
            return

        self.live_class = await self.get_class(self.class_id)

        if not self.live_class:
            await self.close()
            return

        await self.channel_layer.group_add(
            self.room_group_name,
            self.channel_name,
        )

        await self.accept()
        self.accepted = True

        is_teacher = await self.is_class_teacher()

        if not is_teacher:
            await self.update_student_status(True)
            await self.broadcast_viewer_count()

        await self.send_json({
            'type': 'stream_status',
            'is_streaming': await self.get_stream_status(),
            'class_status': self.live_class.status,
        })

        await self.send_json({
            'type': 'recent_chat',
            'messages': await self.get_recent_chat(),
        })

        await self.send_json({
            'type': 'hand_raises',
            'raises': await self.get_active_hand_raises(),
        })

        await self.send_json({
            'type': 'viewer_count',
            'count': await self.get_viewer_count(),
        })

        logger.info(
            'LiveClass WebSocket connected: user=%s class=%s',
            self.user.username,
            self.class_id,
        )

    async def disconnect(self, close_code):
        if hasattr(self, 'room_group_name'):
            await self.channel_layer.group_discard(
                self.room_group_name,
                self.channel_name,
            )

        if (
            getattr(self, 'accepted', False)
            and hasattr(self, 'live_class')
        ):
            is_teacher = await self.is_class_teacher()

            if not is_teacher:
                await self.update_student_status(False)
                await self.broadcast_viewer_count()

        if self.user:
            logger.info(
                'LiveClass WebSocket disconnected: user=%s class=%s code=%s',
                self.user.username,
                getattr(self, 'class_id', 'unknown'),
                close_code,
            )

    async def receive(self, text_data):
        try:
            data = json.loads(text_data or '{}')
        except (TypeError, ValueError, json.JSONDecodeError):
            logger.warning('Invalid LiveClass WebSocket JSON')
            return

        if not isinstance(data, dict):
            return

        message_type = data.get('type')

        try:
            if message_type == 'join':
                await self.handle_join()

            elif message_type == 'chat':
                await self.handle_chat(data)

            elif message_type == 'hand_raise':
                await self.handle_hand_raise(data)

            elif message_type == 'reaction':
                await self.handle_reaction(data)

            elif message_type == 'heartbeat':
                await self.handle_heartbeat()

            elif message_type == 'stream_available':
                await self.handle_stream_available()

            elif message_type == 'stream_unavailable':
                await self.handle_stream_unavailable()

        except Exception:
            logger.exception(
                'Error processing LiveClass WebSocket message: %s',
                message_type,
            )

    async def handle_join(self):
        """
        The frontend sends join after opening the socket. The initial
        history is already sent from connect(); this acknowledgement
        confirms that the socket is ready.
        """
        await self.send_json({
            'type': 'joined',
            'class_id': str(self.class_id),
            'class_status': self.live_class.status,
        })

    async def handle_chat(self, data):
        message = str(data.get('message', '')).strip()

        if not message:
            return

        message = message[:2000]

        is_teacher = await self.is_class_teacher()

        # The teacher can always use the classroom chat. For students,
        # respect the class setting.
        if not is_teacher and not self.live_class.allow_chat:
            await self.send_json({
                'type': 'chat_disabled',
                'message': 'Chat is disabled for this class.',
            })
            return

        saved_message = await self.create_chat_message(message)

        await self.channel_layer.group_send(
            self.room_group_name,
            {
                'type': 'chat_message',
                'user_id': str(self.user.id),
                'username': self.user.username,
                'full_name': (
                    self.user.get_full_name()
                    or self.user.username
                ),
                'message': message,
                'timestamp': saved_message['timestamp'],
                'is_teacher': is_teacher,
            },
        )

    async def handle_hand_raise(self, data):
        action = data.get('action')

        if action == 'raise':
            hand_raise = await self.create_hand_raise()

            await self.broadcast_hand_raise(
                hand_raise,
                is_active=True,
            )

        elif action == 'lower':
            hand_raise = await self.remove_hand_raise()

            if hand_raise:
                await self.broadcast_hand_raise(
                    hand_raise,
                    is_active=False,
                )

        elif action == 'acknowledge':
            can_acknowledge = await self.can_manage_class()

            if not can_acknowledge:
                await self.send_json({
                    'type': 'error',
                    'message': 'Only the teacher or an administrator can acknowledge hands.',
                })
                return

            target_user_id = str(data.get('user_id', '')).strip()

            if not target_user_id:
                return

            hand_raise = await self.acknowledge_hand_raise(
                target_user_id,
            )

            if hand_raise:
                await self.broadcast_hand_raise(
                    hand_raise,
                    is_active=False,
                )

    async def handle_reaction(self, data):
        reaction = str(data.get('reaction', 'reaction')).strip()

        if not reaction:
            return

        await self.channel_layer.group_send(
            self.room_group_name,
            {
                'type': 'reaction_update',
                'user_id': str(self.user.id),
                'username': self.user.username,
                'reaction': reaction[:100],
                'timestamp': timezone.now().isoformat(),
            },
        )

    async def handle_heartbeat(self):
        await self.update_last_activity()

    async def handle_stream_available(self):
        if not await self.can_manage_class():
            return

        await self.update_class_status('live')

        await self.channel_layer.group_send(
            self.room_group_name,
            {
                'type': 'stream_available',
                'stream_key': self.live_class.stream_key,
            },
        )

        logger.info(
            'Stream available: class=%s',
            self.class_id,
        )

    async def handle_stream_unavailable(self):
        if not await self.can_manage_class():
            return

        # Ending the broadcast does not delete ChatMessage records.
        await self.update_class_status('ended')

        await self.channel_layer.group_send(
            self.room_group_name,
            {
                'type': 'stream_unavailable',
            },
        )

        logger.info(
            'Stream unavailable: class=%s',
            self.class_id,
        )

    async def broadcast_hand_raise(self, hand_raise, is_active):
        user_data = await self.get_user_data(hand_raise.user)

        await self.channel_layer.group_send(
            self.room_group_name,
            {
                'type': 'hand_raise_update',
                'user_id': str(hand_raise.user_id),
                'username': user_data['username'],
                'full_name': user_data['full_name'],
                'is_active': is_active,
                'timestamp': timezone.now().isoformat(),
            },
        )

    async def send_json(self, payload):
        await self.send(text_data=json.dumps(payload))

    # ------------------------------------------------------------------
    # Channel-layer event handlers
    # ------------------------------------------------------------------

    async def chat_message(self, event):
        await self.send_json({
            'type': 'chat',
            'user_id': event['user_id'],
            'username': event['username'],
            'full_name': event['full_name'],
            'message': event['message'],
            'timestamp': event['timestamp'],
            'is_teacher': event['is_teacher'],
        })

    async def hand_raise_update(self, event):
        await self.send_json({
            'type': 'hand_raise',
            'user_id': event['user_id'],
            'username': event['username'],
            'full_name': event['full_name'],
            'is_active': event['is_active'],
            'timestamp': event['timestamp'],
        })

    async def reaction_update(self, event):
        await self.send_json({
            'type': 'reaction',
            'user_id': event['user_id'],
            'username': event['username'],
            'reaction': event['reaction'],
            'timestamp': event['timestamp'],
        })

    async def stream_available(self, event):
        await self.send_json({
            'type': 'stream_available',
            'stream_key': event['stream_key'],
        })

    async def stream_unavailable(self, event):
        await self.send_json({
            'type': 'stream_unavailable',
            'class_status': 'ended',
        })

    async def viewer_count_update(self, event):
        await self.send_json({
            'type': 'viewer_count',
            'count': event['count'],
        })

    # ------------------------------------------------------------------
    # Database helpers
    # ------------------------------------------------------------------

    @database_sync_to_async
    def get_class(self, class_id):
        try:
            return LiveClass.objects.get(id=class_id)
        except LiveClass.DoesNotExist:
            return None

    @database_sync_to_async
    def is_class_teacher(self):
        return self.user == self.live_class.teacher

    @database_sync_to_async
    def can_manage_class(self):
        return (
            self.user == self.live_class.teacher
            or self.user.is_staff
            or self.user.is_superuser
        )

    @database_sync_to_async
    def get_user_data(self, user):
        return {
            'username': user.username,
            'full_name': (
                user.get_full_name()
                or user.username
            ),
        }

    @database_sync_to_async
    def get_stream_status(self):
        return self.live_class.status == 'live'

    @database_sync_to_async
    def update_class_status(self, status):
        self.live_class.status = status

        if status == 'live':
            if not self.live_class.started_at:
                self.live_class.started_at = timezone.now()

            self.live_class.ended_at = None

        elif status == 'ended':
            self.live_class.ended_at = timezone.now()

        self.live_class.save(
            update_fields=[
                'status',
                'started_at',
                'ended_at',
                'updated_at',
            ],
        )

    @database_sync_to_async
    def update_student_status(self, is_active):
        StudentStatus.objects.update_or_create(
            stream=self.live_class,
            user=self.user,
            defaults={
                'is_active': is_active,
                'last_activity': timezone.now(),
            },
        )

    @database_sync_to_async
    def get_viewer_count(self):
        return StudentStatus.objects.filter(
            stream=self.live_class,
            is_active=True,
        ).count()

    async def broadcast_viewer_count(self):
        count = await self.get_viewer_count()

        await self.update_saved_viewer_count(count)

        await self.channel_layer.group_send(
            self.room_group_name,
            {
                'type': 'viewer_count_update',
                'count': count,
            },
        )

    @database_sync_to_async
    def update_saved_viewer_count(self, count):
        self.live_class.viewer_count = count

        if count > self.live_class.max_viewers:
            self.live_class.max_viewers = count

        self.live_class.save(
            update_fields=[
                'viewer_count',
                'max_viewers',
                'updated_at',
            ],
        )

    @database_sync_to_async
    def get_recent_chat(self):
        messages = ChatMessage.objects.filter(
            stream=self.live_class,
        ).select_related(
            'user',
        ).order_by(
            '-created_at',
        )[:100]

        return [
            {
                'user_id': str(message.user_id),
                'username': message.user.username,
                'full_name': (
                    message.user.get_full_name()
                    or message.user.username
                ),
                'message': message.message,
                'timestamp': message.created_at.isoformat(),
                'is_teacher': (
                    message.user_id
                    == self.live_class.teacher_id
                ),
            }
            for message in reversed(messages)
        ]

    @database_sync_to_async
    def create_chat_message(self, message):
        saved_message = ChatMessage.objects.create(
            stream=self.live_class,
            user=self.user,
            message=message,
            is_announcement=(
                self.user == self.live_class.teacher
            ),
        )

        return {
            'timestamp': saved_message.created_at.isoformat(),
        }

    @database_sync_to_async
    def get_active_hand_raises(self):
        raises = HandRaise.objects.filter(
            stream=self.live_class,
            is_active=True,
        ).select_related(
            'user',
        ).order_by(
            'raised_at',
        )

        return [
            {
                'user_id': str(hand_raise.user_id),
                'username': hand_raise.user.username,
                'full_name': (
                    hand_raise.user.get_full_name()
                    or hand_raise.user.username
                ),
                'timestamp': hand_raise.raised_at.isoformat(),
            }
            for hand_raise in raises
        ]

    @database_sync_to_async
    def create_hand_raise(self):
        hand_raise, created = HandRaise.objects.get_or_create(
            stream=self.live_class,
            user=self.user,
            defaults={
                'is_active': True,
                'raised_at': timezone.now(),
            },
        )

        if not created:
            hand_raise.is_active = True
            hand_raise.raised_at = timezone.now()
            hand_raise.acknowledged_at = None
            hand_raise.save(
                update_fields=[
                    'is_active',
                    'raised_at',
                    'acknowledged_at',
                ],
            )

        return hand_raise

    @database_sync_to_async
    def remove_hand_raise(self):
        hand_raise = HandRaise.objects.filter(
            stream=self.live_class,
            user=self.user,
            is_active=True,
        ).first()

        if hand_raise:
            hand_raise.is_active = False
            hand_raise.save(
                update_fields=[
                    'is_active',
                ],
            )

        return hand_raise

    @database_sync_to_async
    def acknowledge_hand_raise(self, user_id):
        hand_raise = HandRaise.objects.filter(
            stream=self.live_class,
            user_id=user_id,
            is_active=True,
        ).select_related(
            'user',
        ).first()

        if hand_raise:
            hand_raise.acknowledge()

        return hand_raise

    @database_sync_to_async
    def update_last_activity(self):
        StudentStatus.objects.filter(
            stream=self.live_class,
            user=self.user,
            is_active=True,
        ).update(
            last_activity=timezone.now(),
        )


