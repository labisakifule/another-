import secrets
import string
import uuid

from django.conf import settings
from django.contrib.auth import get_user_model
from django.db import models
from django.utils import timezone
from django.utils.text import slugify


User = get_user_model()


class LiveClass(models.Model):
    id = models.UUIDField(
        primary_key=True,
        default=uuid.uuid4,
        editable=False,
    )

    title = models.CharField(max_length=200)

    slug = models.SlugField(
        max_length=200,
        unique=True,
        blank=True,
    )

    description = models.TextField(blank=True)

    teacher = models.ForeignKey(
        User,
        on_delete=models.CASCADE,
        related_name='live_classes',
    )

    stream_key = models.CharField(
        max_length=100,
        unique=True,
        blank=True,
    )

    STATUS_CHOICES = [
        ('scheduled', 'Scheduled'),
        ('live', 'Live'),
        ('ended', 'Ended'),
    ]

    status = models.CharField(
        max_length=20,
        choices=STATUS_CHOICES,
        default='scheduled',
    )

    VISIBILITY_PUBLIC = 'public'
    VISIBILITY_UNLISTED = 'unlisted'
    VISIBILITY_PRIVATE = 'private'
    VISIBILITY_INSTITUTION = 'institution'

    VISIBILITY_CHOICES = [
        (VISIBILITY_PUBLIC, 'Public'),
        (VISIBILITY_UNLISTED, 'Unlisted'),
        (VISIBILITY_PRIVATE, 'Private'),
        (VISIBILITY_INSTITUTION, 'Institution members only'),
    ]

    # ------------------------------------------------------------------
    # Universal education metadata
    # ------------------------------------------------------------------

    education_system = models.ForeignKey(
        'trends.EducationalSystem',
        on_delete=models.SET_NULL,
        null=True,
        blank=True,
        related_name='live_classes',
    )

    education_stage = models.CharField(
        max_length=80,
        blank=True,
        help_text=(
            'Examples: primary, secondary, college, university, '
            'professional, adult learning.'
        ),
    )

    education_level = models.ForeignKey(
        'trends.EducationLevel',
        on_delete=models.SET_NULL,
        null=True,
        blank=True,
        related_name='live_classes',
    )

    institution = models.ForeignKey(
        'trends.Institution',
        on_delete=models.SET_NULL,
        null=True,
        blank=True,
        related_name='live_classes',
    )

    program = models.ForeignKey(
        'trends.Program',
        on_delete=models.SET_NULL,
        null=True,
        blank=True,
        related_name='live_classes',
    )

    academic_year = models.ForeignKey(
        'trends.Year',
        on_delete=models.SET_NULL,
        null=True,
        blank=True,
        related_name='live_classes',
    )

    subject_or_course_unit = models.CharField(
        max_length=200,
        blank=True,
        help_text=(
            'Examples: Mathematics, Biology, Database Systems.'
        ),
    )

    topic = models.CharField(
        max_length=200,
        blank=True,
    )

    language = models.CharField(
        max_length=40,
        default='en',
        blank=True,
        help_text='Language code or name, for example en or English.',
    )

    visibility = models.CharField(
        max_length=20,
        choices=VISIBILITY_CHOICES,
        default=VISIBILITY_PUBLIC,
    )

    # ------------------------------------------------------------------
    # Scheduling and classroom controls
    # ------------------------------------------------------------------

    scheduled_start = models.DateTimeField(
        null=True,
        blank=True,
    )

    scheduled_end = models.DateTimeField(
        null=True,
        blank=True,
    )

    started_at = models.DateTimeField(
        null=True,
        blank=True,
    )

    ended_at = models.DateTimeField(
        null=True,
        blank=True,
    )

    allow_student_audio = models.BooleanField(
        default=False,
    )

    allow_chat = models.BooleanField(
        default=True,
    )

    record_stream = models.BooleanField(
        default=False,
    )

    # ------------------------------------------------------------------
    # Popularity and recommendation signals
    # ------------------------------------------------------------------

    viewer_count = models.IntegerField(
        default=0,
    )

    max_viewers = models.IntegerField(
        default=0,
    )

    join_count = models.PositiveIntegerField(
        default=0,
    )

    search_count = models.PositiveIntegerField(
        default=0,
    )

    created_at = models.DateTimeField(
        auto_now_add=True,
    )

    updated_at = models.DateTimeField(
        auto_now=True,
    )


    deleted_at = models.DateTimeField(null=True, blank=True, db_index=True)

    class Meta:
        indexes = [
            models.Index(
                fields=['stream_key'],
                name='liveclass_stream_key_idx',
            ),
            models.Index(
                fields=['status'],
                name='liveclass_status_idx',
            ),
            models.Index(
                fields=['slug'],
                name='liveclass_slug_idx',
            ),
            models.Index(
                fields=['visibility', 'status'],
                name='lc_visibility_status_idx',
            ),
            models.Index(
                fields=['education_stage', 'status'],
                name='liveclass_stage_status_idx',
            ),
            models.Index(
                fields=['subject_or_course_unit'],
                name='liveclass_subject_idx',
            ),
            models.Index(
                fields=['topic'],
                name='liveclass_topic_idx',
            ),
        ]

    def save(self, *args, **kwargs):
        if not self.slug and self.title:
            base_slug = slugify(self.title)
            slug = base_slug
            counter = 1

            while LiveClass.objects.filter(
                slug=slug,
            ).exclude(
                pk=self.pk,
            ).exists():
                slug = f'{base_slug}-{counter}'
                counter += 1

            self.slug = slug

        if not self.stream_key:
            alphabet = string.ascii_lowercase + string.digits
            random_key = ''.join(
                secrets.choice(alphabet)
                for _ in range(8)
            )
            self.stream_key = f'class_{random_key}'

        super().save(*args, **kwargs)

    def __str__(self):
        return self.title

    @property
    def is_live(self):
        return self.status == 'live'

    @property
    def is_discoverable(self):
        return (
            self.deleted_at is None
            and self.visibility == self.VISIBILITY_PUBLIC
            and self.status in {'scheduled', 'live', 'ended'}
        )

    @property
    def duration_minutes(self):
        if self.started_at:
            end = self.ended_at or timezone.now()
            delta = end - self.started_at
            return int(delta.total_seconds() / 60)

        return 0

    @property
    def popularity_score(self):
        return min(
            15,
            max(
                0,
                self.viewer_count * 2
                + self.max_viewers
                + self.join_count,
            ),
        )

    def get_publish_url(self):
        protocol = (
            'https'
            if getattr(
                settings,
                'SECURE_SSL_REDIRECT',
                False,
            )
            else 'http'
        )

        return (
            f'{protocol}://'
            f'{settings.MEDIAMTX_HOST}:8889/'
            f'classroom/{self.stream_key}/whip'
        )

    def get_watch_url(self):
        protocol = (
            'https'
            if getattr(
                settings,
                'SECURE_SSL_REDIRECT',
                False,
            )
            else 'http'
        )

        return (
            f'{protocol}://'
            f'{settings.MEDIAMTX_HOST}:8889/'
            f'classroom/{self.stream_key}/whep'
        )

    def get_rtmp_url(self):
        return (
            f'rtmp://{settings.MEDIAMTX_HOST}:1935/'
            f'classroom/{self.stream_key}'
        )

    def get_absolute_url(self):
        return f'/liveclass/{self.slug}/'

    def get_watch_page_url(self):
        return f'/liveclass/{self.slug}/watch/'


class ChatMessage(models.Model):
    id = models.UUIDField(
        primary_key=True,
        default=uuid.uuid4,
        editable=False,
    )

    stream = models.ForeignKey(
        LiveClass,
        on_delete=models.CASCADE,
        related_name='chat_messages',
    )

    user = models.ForeignKey(
        User,
        on_delete=models.CASCADE,
    )

    message = models.TextField()

    is_pinned = models.BooleanField(
        default=False,
    )

    is_announcement = models.BooleanField(
        default=False,
    )

    created_at = models.DateTimeField(
        auto_now_add=True,
    )

    class Meta:
        ordering = ['-created_at']
        indexes = [
            models.Index(
                fields=['stream', '-created_at'],
                name='chat_stream_created_idx',
            ),
        ]

    def __str__(self):
        return f'{self.user.username}: {self.message[:30]}'

    @property
    def time_ago(self):
        from django.utils.timesince import timesince

        return timesince(self.created_at)


class HandRaise(models.Model):
    id = models.UUIDField(
        primary_key=True,
        default=uuid.uuid4,
        editable=False,
    )

    stream = models.ForeignKey(
        LiveClass,
        on_delete=models.CASCADE,
        related_name='hand_raises',
    )

    user = models.ForeignKey(
        User,
        on_delete=models.CASCADE,
    )

    is_active = models.BooleanField(
        default=True,
    )

    raised_at = models.DateTimeField(
        auto_now_add=True,
    )

    acknowledged_at = models.DateTimeField(
        null=True,
        blank=True,
    )

    class Meta:
        unique_together = ['stream', 'user']
        indexes = [
            models.Index(
                fields=['stream', 'is_active'],
                name='hand_stream_active_idx',
            ),
        ]

    def __str__(self):
        return f'{self.user.username} raised hand'

    def acknowledge(self):
        self.is_active = False
        self.acknowledged_at = timezone.now()
        self.save(
            update_fields=[
                'is_active',
                'acknowledged_at',
            ],
        )


class StudentStatus(models.Model):
    id = models.UUIDField(
        primary_key=True,
        default=uuid.uuid4,
        editable=False,
    )

    stream = models.ForeignKey(
        LiveClass,
        on_delete=models.CASCADE,
        related_name='student_statuses',
    )

    user = models.ForeignKey(
        User,
        on_delete=models.CASCADE,
    )

    STATUS_CHOICES = [
        ('listening', 'Listening'),
        ('speaking', 'Speaking'),
        ('away', 'Away'),
    ]

    status = models.CharField(
        max_length=20,
        choices=STATUS_CHOICES,
        default='listening',
    )

    audio_enabled = models.BooleanField(
        default=False,
    )

    camera_enabled = models.BooleanField(
        default=False,
    )

    is_active = models.BooleanField(
        default=True,
    )

    joined_at = models.DateTimeField(
        auto_now_add=True,
    )

    last_activity = models.DateTimeField(
        auto_now=True,
    )

    class Meta:
        unique_together = ['stream', 'user']
        indexes = [
            models.Index(
                fields=['stream', 'is_active'],
                name='student_stream_active_idx',
            ),
        ]

    def __str__(self):
        return f'{self.user.username} - {self.status}'


