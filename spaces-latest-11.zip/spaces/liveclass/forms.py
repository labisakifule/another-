from django import forms

from .models import LiveClass


class LiveClassForm(forms.ModelForm):
    start_now = forms.BooleanField(
        required=False,
        label='Start this class immediately',
        help_text=(
            'Check this to start the class now instead of scheduling it.'
        ),
    )

    class Meta:
        model = LiveClass

        fields = [
            'title',
            'description',
            'education_system',
            'education_stage',
            'education_level',
            'institution',
            'program',
            'academic_year',
            'subject_or_course_unit',
            'topic',
            'language',
            'visibility',
            'scheduled_start',
            'scheduled_end',
            'allow_student_audio',
            'allow_chat',
            'record_stream',
        ]

        widgets = {
            'title': forms.TextInput(
                attrs={
                    'class': 'w-full px-4 py-2 border rounded-xl',
                    'placeholder': 'Class title',
                },
            ),

            'description': forms.Textarea(
                attrs={
                    'class': 'w-full px-4 py-2 border rounded-xl',
                    'rows': 4,
                    'placeholder': (
                        'Describe what learners will study in this class'
                    ),
                },
            ),

            'education_stage': forms.TextInput(
                attrs={
                    'class': 'w-full px-4 py-2 border rounded-xl',
                    'placeholder': (
                        'Primary, secondary, university, professional...'
                    ),
                },
            ),

            'subject_or_course_unit': forms.TextInput(
                attrs={
                    'class': 'w-full px-4 py-2 border rounded-xl',
                    'placeholder': (
                        'Mathematics, Biology, Database Systems...'
                    ),
                },
            ),

            'topic': forms.TextInput(
                attrs={
                    'class': 'w-full px-4 py-2 border rounded-xl',
                    'placeholder': (
                        'Fractions, SQL, revision, exam preparation...'
                    ),
                },
            ),

            'language': forms.TextInput(
                attrs={
                    'class': 'w-full px-4 py-2 border rounded-xl',
                    'placeholder': 'en',
                },
            ),

            'scheduled_start': forms.DateTimeInput(
                attrs={
                    'class': 'w-full px-4 py-2 border rounded-xl',
                    'type': 'datetime-local',
                },
            ),

            'scheduled_end': forms.DateTimeInput(
                attrs={
                    'class': 'w-full px-4 py-2 border rounded-xl',
                    'type': 'datetime-local',
                },
            ),

            'education_system': forms.Select(
                attrs={
                    'class': 'w-full px-4 py-2 border rounded-xl',
                },
            ),

            'education_level': forms.Select(
                attrs={
                    'class': 'w-full px-4 py-2 border rounded-xl',
                },
            ),

            'institution': forms.Select(
                attrs={
                    'class': 'w-full px-4 py-2 border rounded-xl',
                },
            ),

            'program': forms.Select(
                attrs={
                    'class': 'w-full px-4 py-2 border rounded-xl',
                },
            ),

            'academic_year': forms.Select(
                attrs={
                    'class': 'w-full px-4 py-2 border rounded-xl',
                },
            ),

            'visibility': forms.Select(
                attrs={
                    'class': 'w-full px-4 py-2 border rounded-xl',
                },
            ),

            'allow_student_audio': forms.CheckboxInput(
                attrs={
                    'class': 'rounded',
                },
            ),

            'allow_chat': forms.CheckboxInput(
                attrs={
                    'class': 'rounded',
                },
            ),

            'record_stream': forms.CheckboxInput(
                attrs={
                    'class': 'rounded',
                },
            ),
        }

        labels = {
            'education_system': 'Education system',
            'education_stage': 'Education stage',
            'education_level': 'Class or level',
            'institution': 'Institution',
            'program': 'Programme',
            'academic_year': 'Academic year',
            'subject_or_course_unit': 'Subject or course unit',
            'topic': 'Topic',
            'language': 'Language',
            'visibility': 'Who can discover this class?',
        }

        help_texts = {
            'education_stage': (
                'Examples: primary, secondary, college, university, '
                'professional, or adult learning.'
            ),
            'education_level': (
                'Examples: P.6, Form 2, Grade 8, Year 2, or Level 4.'
            ),
            'subject_or_course_unit': (
                'Use a school subject or a university course unit.'
            ),
            'visibility': (
                'Public classes can appear in search and recommendations.'
            ),
        }

    def __init__(self, *args, **kwargs):
        super().__init__(*args, **kwargs)

        self.fields['visibility'].required = False
        self.fields['visibility'].initial = 'public'
        self.fields['scheduled_start'].required = False
        self.fields['scheduled_end'].required = False

        # New classification fields are optional for compatibility with
        # existing teachers and existing class-creation workflows.
        optional_fields = [
            'education_system',
            'education_stage',
            'education_level',
            'institution',
            'program',
            'academic_year',
            'subject_or_course_unit',
            'topic',
            'language',
        ]

        for field_name in optional_fields:
            self.fields[field_name].required = False

        # Keep existing classes and old forms public unless a teacher
        # explicitly chooses another visibility setting.
        if not self.instance.pk:
            self.initial.setdefault(
                'visibility',
                LiveClass.VISIBILITY_PUBLIC,
            )

        if not self.instance.pk:
            self.initial.setdefault('language', 'en')

    def clean(self):
        cleaned_data = super().clean()

        if not cleaned_data.get('visibility'):
            cleaned_data['visibility'] = 'public'

        start_now = cleaned_data.get('start_now', False)
        start = cleaned_data.get('scheduled_start')
        end = cleaned_data.get('scheduled_end')

        if not start_now:
            if not start:
                self.add_error(
                    'scheduled_start',
                    'Start time is required when scheduling.',
                )

            if not end:
                self.add_error(
                    'scheduled_end',
                    'End time is required when scheduling.',
                )

            if start and end and start >= end:
                raise forms.ValidationError(
                    'End time must be after start time.',
                )

        return cleaned_data


