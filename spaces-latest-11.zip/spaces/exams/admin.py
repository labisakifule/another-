from django.contrib import admin
from django.utils.translation import gettext_lazy as _
from .models import TextAssessmentSession, TextQuestionAssessment

class CompletedFilter(admin.SimpleListFilter):
    """Custom filter for is_completed property based on completed_at field."""
    title = _('completed')
    parameter_name = 'completed'

    def lookups(self, request, model_admin):
        return (
            ('yes', _('Completed')),
            ('no', _('Incomplete')),
        )

    def queryset(self, request, queryset):
        if self.value() == 'yes':
            return queryset.filter(completed_at__isnull=False)
        if self.value() == 'no':
            return queryset.filter(completed_at__isnull=True)
        return queryset

@admin.register(TextAssessmentSession)
class TextAssessmentSessionAdmin(admin.ModelAdmin):
    list_display = ['id', 'setter', 'attempt', 'created_at', 'completed_at', 'is_completed']
    list_filter = [CompletedFilter]  # Replace 'is_completed' with custom filter
    readonly_fields = ['immutable_hash', 'created_at', 'completed_at']
    search_fields = ['setter__username', 'attempt__id']


class SessionCompletedFilter(admin.SimpleListFilter):
    """Custom filter for session__is_completed based on session's completed_at."""
    title = _('session completed')
    parameter_name = 'session_completed'

    def lookups(self, request, model_admin):
        return (
            ('yes', _('Session Completed')),
            ('no', _('Session Incomplete')),
        )

    def queryset(self, request, queryset):
        if self.value() == 'yes':
            return queryset.filter(session__completed_at__isnull=False)
        if self.value() == 'no':
            return queryset.filter(session__completed_at__isnull=True)
        return queryset

@admin.register(TextQuestionAssessment)
class TextQuestionAssessmentAdmin(admin.ModelAdmin):
    list_display = ['id', 'session', 'question', 'score', 'created_at']
    list_filter = [SessionCompletedFilter]  # Replace 'session__is_completed' with custom filter
    readonly_fields = ['assessed_at', 'created_at']
    search_fields = ['session__setter__username', 'question__text']