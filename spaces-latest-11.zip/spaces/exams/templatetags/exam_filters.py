# exams/templatetags/exam_filters.py

import re
from django import template

register = template.Library()

@register.filter
def youtube_embed_url(url):
    """Convert YouTube URL to embed URL"""
    if not url:
        return ''
    
    # Extract video ID from various YouTube URL formats
    patterns = [
        r'youtu\.be/([^/?]+)',
        r'youtube\.com/watch\?v=([^&]+)',
        r'youtube\.com/embed/([^/?]+)',
        r'youtube\.com/v/([^/?]+)',
        r'youtube\.com/shorts/([^/?]+)',
    ]
    
    for pattern in patterns:
        match = re.search(pattern, url)
        if match:
            video_id = match.group(1)
            return f'https://www.youtube.com/embed/{video_id}'
    
    # If no pattern matches, return original URL
    return url

@register.filter
def make_range(value):
    """Make a range from a number"""
    return range(value)

@register.filter
def replace_blanks(text, context_name):
    """Replace ___ with input fields in fill-in-the-blank questions"""
    # This is a placeholder - actual implementation in JavaScript
    return text
