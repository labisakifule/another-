# exams/views.py

import json
import hashlib
from django.shortcuts import render, redirect, get_object_or_404
from django.views import View
from django.views.generic import ListView, CreateView, UpdateView, DetailView, DeleteView
from django.urls import reverse, reverse_lazy
from django.utils import timezone
from django.http import JsonResponse
from django.db import transaction
from django.contrib import messages
from django.contrib.auth.mixins import LoginRequiredMixin
from django.core.paginator import Paginator
from django.db.models import Q, Count, Sum
from django.contrib.auth.decorators import login_required
from django.views.decorators.http import require_http_methods
from datetime import timedelta

from .models import *
from .forms import (
    ExamSetForm, MCQQuestionForm, TextQuestionForm,
    AnswerForm, GradingForm, CorrectionForm
)
from .services.redis_service import redis_service
from trends.models import User, EducationalSystem, EducationLevel, Subject, Topic
from .constants import QUESTION_TYPE_MCQ, QUESTION_TYPE_TEXT
from .discovery import discover_exams
from trends.access import can_view_content, is_institution_member, is_creator_member


# ===== PRICE CONSTANT (for premium content) =====
# The actual price is stored in ExamSet.soma_price


# ==================== EXAM SET VIEWS ====================

class ExamSetListView(LoginRequiredMixin, ListView):
    model = ExamSet
    template_name = 'exams/exam_set_list.html'
    context_object_name = 'exam_sets'
    paginate_by = 12

    def get_queryset(self):
        query = self.request.GET.get('q', '').strip()

        if not query:
            query = self.request.GET.get(
                'search',
                '',
            ).strip()

        level_id = self.request.GET.get(
            'level',
            '',
        ).strip()

        return discover_exams(
            user=self.request.user,
            query=query,
            level_id=level_id,
            limit=200,
        )

    def get_context_data(self, **kwargs):
        context = super().get_context_data(**kwargs)
        context['education_levels'] = EducationLevel.objects.filter(is_approved=True)
        context['total_exams'] = len(self.object_list)
        return context


def get_exam_set_form_context(request, exam_set=None):
    """Helper function to get education levels and subjects for exam set form"""
    education_levels = EducationLevel.objects.filter(is_approved=True).select_related('system').order_by('system__name', 'order')

    selected_level_id = None
    selected_subject_id = None
    subjects = []

    if exam_set and exam_set.subject:
        selected_subject_id = str(exam_set.subject.id)
        selected_level_id = exam_set.subject.education_level_id
        subjects = Subject.objects.filter(
            education_level_id=selected_level_id,
            is_approved=True
        ).order_by('name')

    return {
        'education_levels': education_levels,
        'selected_level_id': selected_level_id,
        'selected_subject_id': selected_subject_id,
        'subjects': subjects,
    }


@login_required
def exam_set_create(request):
    # ===== CHECK SERVER-SIDE CREATOR PERMISSIONS =====
    profile = getattr(request.user, 'profile', None)
    institution = getattr(profile, 'institution', None) if profile else None
    role_values = {
        getattr(profile, 'global_role', '') if profile else '',
        getattr(profile, 'role', '') if profile else '',
        getattr(profile, 'institution_role', '') if profile else '',
    }
    approved_creator = bool(
        profile
        and profile.teacher_approved
        and role_values.intersection({'teacher', 'setter'})
    )
    approved_institution_admin = bool(
        institution
        and institution.is_active
        and institution.is_approved
        and institution.admin_id == request.user.id
    )
    can_create_exam = bool(
        request.user.is_superuser
        or request.user.is_staff
        or approved_creator
        or approved_institution_admin
        or role_values.intersection({'staff', 'admin'})
    )
    if not can_create_exam:
        messages.warning(
            request,
            "You need approved Creator, Staff, or Institution Administrator permissions to create an exam."
        )
        return redirect('exams:exam_set_list')

    if request.method == 'POST':
        form = ExamSetForm(request.POST)
        if form.is_valid():
            instance = form.save(commit=False)
            instance.creator = request.user
            instance.institution = getattr(getattr(request.user, 'profile', None), 'institution', None)

            subject_id = request.POST.get('subject')
            if subject_id:
                instance.subject = get_object_or_404(Subject, id=subject_id)

            instance.save()
            form.save_m2m()
            messages.success(request, f"Exam set '{instance.title}' created successfully! Now add sections and questions.")
            return redirect('exams:manage_sections', set_id=instance.id)
        else:
            messages.error(request, "Please correct the errors below.")
    else:
        form = ExamSetForm()
        if request.user.profile.onboarding_completed and request.user.profile.education_level:
            form.fields['education_level'].initial = request.user.profile.education_level.pk

    context = get_exam_set_form_context(request)
    context['form'] = form
    context['education_levels'] = EducationLevel.objects.filter(is_approved=True)

    return render(request, 'exams/exam_set_form.html', context)


class ExamSetUpdateView(LoginRequiredMixin, UpdateView):
    model = ExamSet
    form_class = ExamSetForm
    template_name = 'exams/exam_set_form.html'

    def get_success_url(self):
        return reverse('exams:exam_set_detail', kwargs={'pk': self.object.pk})

    def get_context_data(self, **kwargs):
        context = super().get_context_data(**kwargs)
        context['object'] = self.object
        exam_context = get_exam_set_form_context(self.request, self.object)
        context.update(exam_context)
        return context

    def form_valid(self, form):
        response = super().form_valid(form)

        subject_id = self.request.POST.get('subject')
        if subject_id:
            self.object.subject = get_object_or_404(Subject, id=subject_id)
            self.object.save()

        return response


class ExamSetDetailView(LoginRequiredMixin, DetailView):
    model = ExamSet
    def get_queryset(self):
        return ExamSet.objects.filter(
            Q(creator=self.request.user)
            | Q(creator__creator_memberships__member=self.request.user, creator__creator_memberships__status='accepted')
            | Q(members_only=False)
            | Q(institution__membership_requests__user=self.request.user, institution__membership_requests__status='accepted')
        ).distinct()
    template_name = 'exams/exam_set_detail.html'
    context_object_name = 'exam_set'

    def get_context_data(self, **kwargs):
        context = super().get_context_data(**kwargs)
        exam_set = self.object

        sections = exam_set.sections.prefetch_related('questions').order_by('order')
        context['sections'] = sections

        total_questions = 0
        total_marks = 0
        mcq_count = 0
        text_count = 0

        for section in sections:
            section_questions = section.questions.all()
            section_total = section_questions.count()
            total_questions += section_total
            total_marks += section.total_marks
            mcq_count += section_questions.filter(question_type=QUESTION_TYPE_MCQ).count()
            text_count += section_questions.filter(question_type=QUESTION_TYPE_TEXT).count()

        context['total_questions'] = total_questions
        context['total_marks'] = total_marks
        context['mcq_count'] = mcq_count
        context['text_count'] = text_count

        if self.request.user.is_authenticated:
            first_attempt = ExamAttempt.objects.filter(
                user=self.request.user,
                exam_set=exam_set,
                is_first_attempt=True
            ).first()
            context['has_first_attempt'] = bool(first_attempt)

            if first_attempt and first_attempt.results_released:
                context['results_available'] = True
                try:
                    record = ExamRecord.objects.get(
                        user=self.request.user,
                        exam_set=exam_set
                    )
                    context['record'] = record
                except ExamRecord.DoesNotExist:
                    context['record'] = None

                practice_attempt = ExamAttempt.objects.filter(
                    user=self.request.user,
                    exam_set=exam_set,
                    is_first_attempt=False,
                    status='IN_PROGRESS'
                ).first()
                context['practice_in_progress'] = bool(practice_attempt)
                if practice_attempt:
                    context['practice_attempt_id'] = practice_attempt.id

            context['practice_count'] = ExamAttempt.objects.filter(
                user=self.request.user,
                exam_set=exam_set,
                is_first_attempt=False
            ).count()

        return context


class ExamSetDeleteView(LoginRequiredMixin, DeleteView):
    model = ExamSet
    template_name = 'exams/exam_set_confirm_delete.html'
    success_url = reverse_lazy('exams:exam_set_list')

    def get_queryset(self):
        return ExamSet.objects.filter(creator=self.request.user)

    def delete(self, request, *args, **kwargs):
        messages.success(request, "Exam set deleted successfully.")
        return super().delete(request, *args, **kwargs)


# ==================== SECTION MANAGEMENT ====================

@login_required
def manage_sections(request, set_id):
    exam_set = get_object_or_404(ExamSet, id=set_id, creator=request.user)
    sections = exam_set.sections.prefetch_related('questions').order_by('order')

    context = {
        'exam_set': exam_set,
        'sections': sections,
    }
    return render(request, 'exams/manage_sections.html', context)


@login_required
def add_section(request, set_id):
    exam_set = get_object_or_404(ExamSet, id=set_id, creator=request.user)

    if request.method == 'POST':
        letter = request.POST.get('letter', '').upper()
        name = request.POST.get('name', '')
        instructions = request.POST.get('instructions', '')

        last_order = exam_set.sections.aggregate(max_order=models.Max('order'))['max_order'] or 0
        order = last_order + 1

        section = ExamSection.objects.create(
            exam_set=exam_set,
            letter=letter,
            name=name,
            instructions=instructions,
            order=order
        )

        messages.success(request, f"Section {letter} added successfully!")
        return redirect('exams:manage_sections', set_id=exam_set.id)

    return redirect('exams:manage_sections', set_id=exam_set.id)


@login_required
def edit_section(request, section_id):
    section = get_object_or_404(ExamSection, id=section_id, exam_set__creator=request.user)

    if request.method == 'POST':
        section.letter = request.POST.get('letter', section.letter).upper()
        section.name = request.POST.get('name', section.name)
        section.instructions = request.POST.get('instructions', section.instructions)
        section.save()

        messages.success(request, f"Section {section.letter} updated successfully!")
        return redirect('exams:manage_sections', set_id=section.exam_set.id)

    context = {
        'section': section,
        'exam_set': section.exam_set,
    }
    return render(request, 'exams/edit_section.html', context)


@login_required
def delete_section(request, section_id):
    section = get_object_or_404(ExamSection, id=section_id, exam_set__creator=request.user)
    exam_set_id = section.exam_set.id

    if request.method == 'POST':
        section.delete()
        messages.success(request, f"Section deleted successfully!")

    return redirect('exams:manage_sections', set_id=exam_set_id)


# ==================== QUESTION MANAGEMENT ====================

@login_required
def add_question_to_section(request, section_id):
    section = get_object_or_404(ExamSection, id=section_id, exam_set__creator=request.user)
    question_type = request.GET.get('type', 'TEXT')

    if question_type == 'MCQ':
        form_class = MCQQuestionForm
        template = 'exams/mcq_question_form.html'
    else:
        form_class = TextQuestionForm
        template = 'exams/text_question_form.html'

    if request.method == 'POST':
        form = form_class(request.POST, request.FILES)
        if form.is_valid():
            question = form.save(commit=False)
            question.exam_set = section.exam_set
            question.section = section
            question.created_by = request.user
            question.question_type = 'TEXT' if question_type == 'TEXT' else 'MCQ'

            last_order = section.questions.aggregate(max_order=models.Max('section_order'))['max_order'] or 0
            question.section_order = last_order + 1

            question.save()

            messages.success(request, f"Question added to Section {section.letter}!")
            return redirect('exams:manage_sections', set_id=section.exam_set.id)
        else:
            messages.error(request, "Please correct the errors below.")
    else:
        form = form_class()

    context = {
        'form': form,
        'section': section,
        'exam_set': section.exam_set,
        'question_type': question_type,
    }
    return render(request, template, context)


@login_required
def edit_question(request, question_id):
    question = get_object_or_404(Question, id=question_id, exam_set__creator=request.user)

    if question.question_type == 'MCQ':
        form_class = MCQQuestionForm
        template = 'exams/mcq_question_form.html'
    else:
        form_class = TextQuestionForm
        template = 'exams/text_question_form.html'

    if request.method == 'POST':
        form = form_class(request.POST, request.FILES, instance=question)
        if form.is_valid():
            form.save()
            messages.success(request, "Question updated successfully!")
            return redirect('exams:manage_sections', set_id=question.exam_set.id)
    else:
        initial = {}
        if question.question_type == 'MCQ':
            initial = {
                'choices': json.dumps(question.choices),
                'correct_choice': question.correct_choice
            }
        form = form_class(instance=question, initial=initial)

    context = {
        'form': form,
        'question': question,
        'section': question.section,
        'exam_set': question.exam_set,
    }
    return render(request, template, context)


@login_required
def delete_question(request, question_id):
    question = get_object_or_404(Question, id=question_id, exam_set__creator=request.user)
    exam_set_id = question.exam_set.id

    if request.method == 'POST':
        question.delete()
        messages.success(request, "Question deleted successfully!")

    return redirect('exams:manage_sections', set_id=exam_set_id)


# ==================== EXAM ATTEMPT VIEWS ====================

class ExamAttemptStartView(LoginRequiredMixin, View):
    def get(self, request, pk):
        exam_set = get_object_or_404(ExamSet, pk=pk)
        if (
            exam_set.members_only
            and request.user != exam_set.creator
            and not is_creator_member(request.user, exam_set.creator)
            and not is_institution_member(request.user, exam_set.institution)
        ):
            messages.error(request, 'This exam is private. Membership or creator permission is required.')
            return redirect('exams:exam_set_list')

        # ===== SILENT PREMIUM CHECK =====
        if exam_set.access_type == 'premium':
            has_access = ExamAttempt.objects.filter(
                user=request.user,
                exam_set=exam_set,
                is_first_attempt=True,
                status__in=['SUBMITTED', 'GRADED']
            ).exists()

            if exam_set.creator == request.user:
                has_access = True

            if not has_access:
                if request.user.credits < exam_set.soma_price:
                    messages.warning(
                        request,
                        f"This course requires {exam_set.soma_price} SOMA. "
                        f"You have {request.user.credits} SOMA. Earn more SOMA!"
                    )
                    return redirect('exams:exam_set_detail', pk=pk)

                request.user.credits -= exam_set.soma_price
                request.user.save()

        # Check if user already has a permanent record
        has_record = ExamRecord.objects.filter(
            user=request.user,
            exam_set=exam_set
        ).exists()

        is_first_attempt = not has_record

        # For practice attempts, check if one is already in progress
        if not is_first_attempt:
            existing_practice = ExamAttempt.objects.filter(
                user=request.user,
                exam_set=exam_set,
                is_first_attempt=False,
                status='IN_PROGRESS'
            ).first()

            if existing_practice:
                messages.info(request, "📝 Continuing your practice attempt. Take your time!")
                return redirect('exams:exam_interface', pk=existing_practice.id)

            messages.info(request, "🎯 PRACTICE MODE: This attempt will NOT create a permanent record. Take as many practice attempts as you want!")

        # Premium check for first attempt only
        if is_first_attempt and exam_set.set_type == 'PREMIUM' and request.user.credits < exam_set.credits_required:
            messages.warning(request, "You don't have enough credits to take this exam")
            return redirect('exams:exam_set_detail', pk=pk)

        # Create attempt
        attempt = ExamAttempt.objects.create(
            user=request.user,
            exam_set=exam_set,
            is_first_attempt=is_first_attempt,
            status='IN_PROGRESS',
            start_time=timezone.now()
        )

        redis_data = {
            'user_id': str(request.user.id),
            'exam_set_id': str(exam_set.id),
            'start_time': str(attempt.start_time.timestamp()),
            'browser_leaves': '0',
            'is_first_attempt': str(is_first_attempt),
            'current_question': ''
        }

        first_question = Question.objects.filter(exam_set=exam_set).order_by('section__order', 'section_order', 'part').first()
        if first_question:
            redis_data['current_question'] = str(first_question.id)

        if is_first_attempt:
            redis_service.cache_attempt_state(
                str(attempt.id),
                redis_data,
                exam_set.duration_minutes * 60 + 300
            )
            redis_service.schedule_auto_submit(
                str(attempt.id),
                exam_set.duration_minutes
            )
            messages.info(request, "📝 FIRST ATTEMPT: This will create a permanent record after grading.")
        else:
            redis_service.cache_attempt_state(
                str(attempt.id),
                redis_data,
                7 * 24 * 60 * 60
            )
            messages.info(request, "🎯 PRACTICE MODE: No time pressure! Your score won't affect your permanent record.")

        return redirect('exams:exam_interface', pk=attempt.id)


class ExamInterfaceView(LoginRequiredMixin, View):
    def get(self, request, pk):
        attempt = get_object_or_404(ExamAttempt, pk=pk, user=request.user)

        if attempt.status != 'IN_PROGRESS':
            if attempt.is_first_attempt and not attempt.results_released:
                return redirect('exams:student_pending_view', pk=attempt.id)
            return redirect('exams:exam_set_detail', pk=attempt.exam_set.id)

        sections = attempt.exam_set.sections.prefetch_related('questions').order_by('order')

        all_questions = []
        section_data = []

        for section in sections:
            questions = list(section.questions.order_by('section_order', 'part'))
            section_questions = []

            for q in questions:
                answered = attempt.answers.filter(question=q).exists()
                existing_answer = attempt.answers.filter(question=q).first()
                existing_text = existing_answer.text_answer if existing_answer else ''

                existing_answers_list = []
                if existing_text and q.question_type == 'TEXT':
                    try:
                        parsed = json.loads(existing_text)
                        if isinstance(parsed, list):
                            existing_answers_list = parsed
                    except:
                        existing_answers_list = [existing_text] if existing_text else []

                q_data = {
                    'id': q.id,
                    'display_number': q.display_number,
                    'text': q.text,
                    'type': q.question_type,
                    'points': q.points,
                    'answered': answered,
                    'section_letter': section.letter,
                    'question': q,
                    'answers_required': q.answers_required if q.question_type == 'TEXT' else 0,
                    'points_per_answer': q.points_per_answer if q.question_type == 'TEXT' else 0,
                    'existing_answer': existing_text,
                    'existing_answers_list': existing_answers_list,
                    'min_words': q.min_words if q.question_type == 'TEXT' else 0,
                    'max_words': q.max_words if q.question_type == 'TEXT' else 0,
                    'media_type': q.media_type,
                    'media_file': q.media_file,
                    'media_url': q.media_url,
                    'media_embed_code': q.media_embed_code,
                    'media_caption': q.media_caption,
                }
                section_questions.append(q_data)
                all_questions.append(q_data)

            section_data.append({
                'id': section.id,
                'letter': section.letter,
                'name': section.name,
                'instructions': section.instructions,
                'total_marks': section.total_marks,
                'question_count': len(questions),
                'completed_count': sum(1 for q in section_questions if q['answered']),
                'questions': section_questions
            })

        redis_data = redis_service.get_attempt_state(str(attempt.id)) or {}
        current_question_id = redis_data.get('current_question')

        if 'go_to' in request.GET:
            current_question_id = request.GET.get('go_to')

        current_question_data = None
        current_index = 0

        if current_question_id:
            for i, q in enumerate(all_questions):
                if str(q['id']) == current_question_id:
                    current_question_data = q
                    current_index = i
                    break

        if not current_question_data and all_questions:
            current_question_data = all_questions[0]
            current_index = 0

        current_question = None
        if current_question_data:
            current_question = Question.objects.get(id=current_question_data['id'])

        # ===== Timer logic =====
        if attempt.is_first_attempt:
            time_remaining_seconds = attempt.time_remaining
            minutes = time_remaining_seconds // 60
            seconds = time_remaining_seconds % 60
            time_remaining_display = f"{minutes}:{seconds:02d}"
            time_elapsed_display = None
        else:
            time_remaining_seconds = None
            time_remaining_display = None
            elapsed_seconds = int((timezone.now() - attempt.start_time).total_seconds())
            elapsed_minutes = elapsed_seconds // 60
            elapsed_seconds_remainder = elapsed_seconds % 60
            time_elapsed_display = f"{elapsed_minutes}:{elapsed_seconds_remainder:02d}"

        answered_count = attempt.answers.exclude(
            Q(mcq_answer='') &
            (Q(text_answer='') | Q(text_answer='[]') | Q(text_answer__isnull=True))
        ).count()

        progress_percent = int((answered_count / len(all_questions)) * 100) if all_questions else 0

        total_marks = attempt.exam_set.sections.aggregate(total=Sum('total_marks'))['total'] or 0
        earned_marks = 0
        for answer in attempt.answers.filter(is_correct=True):
            earned_marks += answer.question.points

        existing_text_answers = []
        existing_text_answers_json = '[]'
        if current_question_data and current_question_data['type'] == 'TEXT':
            existing_text_answers = current_question_data.get('existing_answers_list', [])
            existing_text_answers_json = json.dumps(existing_text_answers)

        context = {
            'attempt': attempt,
            'sections': section_data,
            'current_section': next((s for s in section_data if any(q['id'] == current_question_data['id'] for q in s['questions'])), None) if current_question_data else None,
            'question': current_question,
            'question_data': current_question_data,
            'all_questions': all_questions,
            'current_index': current_index,
            'total_questions': len(all_questions),
            'previous_question': all_questions[current_index - 1] if current_index > 0 else None,
            'next_question': all_questions[current_index + 1] if current_index < len(all_questions) - 1 else None,
            'is_first_attempt': attempt.is_first_attempt,
            'progress_percent': progress_percent,
            'time_remaining_display': time_remaining_display,
            'time_remaining_seconds': time_remaining_seconds,
            'time_elapsed_display': time_elapsed_display,
            'answered_count': answered_count,
            'total_marks': total_marks,
            'earned_marks': earned_marks,
            'existing_mcq_answer': attempt.answers.filter(question=current_question).first().mcq_answer if current_question and attempt.answers.filter(question=current_question).exists() else '',
            'existing_text_answer': attempt.answers.filter(question=current_question).first().text_answer if current_question and attempt.answers.filter(question=current_question).exists() else '',
            'existing_text_answers': existing_text_answers,
            'existing_text_answers_json': existing_text_answers_json,
        }

        return render(request, 'exams/exam_interface.html', context)

    def post(self, request, pk):
        attempt = get_object_or_404(ExamAttempt, pk=pk, user=request.user)

        if attempt.status != 'IN_PROGRESS':
            return redirect('exams:exam_set_detail', pk=attempt.exam_set.id)

        # Browser leave tracking - only for first attempt
        if request.POST.get('type') == 'browser_leave':
            if not attempt.is_first_attempt:
                return JsonResponse({'status': 'ignored', 'reason': 'practice mode'})

            redis_data = redis_service.get_attempt_state(str(attempt.id)) or {}
            leaves = int(redis_data.get('browser_leaves', 0)) + 1
            redis_service.cache_attempt_state(
                str(attempt.id),
                {**redis_data, 'browser_leaves': str(leaves)}
            )

            if leaves >= 3:
                return redirect('exams:exam_submit', pk=attempt.id)

            return JsonResponse({'status': 'leave recorded', 'count': leaves})

        question_id = request.POST.get('question_id')
        if not question_id:
            return redirect('exams:exam_interface', pk=attempt.id)

        question = get_object_or_404(Question, pk=question_id)

        # ===== Handle answer based on question type =====
        if question.question_type == QUESTION_TYPE_MCQ:
            mcq_answer = request.POST.get('mcq_answer', '')
            text_answer = ''
        else:
            mcq_answer = ''
            text_answer_json = request.POST.get('text_answer', '[]')
            try:
                parsed = json.loads(text_answer_json)
                if isinstance(parsed, list):
                    parsed = [a for a in parsed if a and a.strip()]
                    text_answer = json.dumps(parsed) if parsed else ''
                else:
                    text_answer = text_answer_json
            except:
                text_answer = text_answer_json

        has_content = False

        if question.question_type == QUESTION_TYPE_MCQ:
            if mcq_answer and mcq_answer.strip():
                has_content = True
        else:
            if text_answer and text_answer.strip() and text_answer != '[]' and text_answer != '""':
                try:
                    parsed = json.loads(text_answer)
                    if parsed and len(parsed) > 0:
                        has_content = True
                except:
                    if text_answer.strip():
                        has_content = True

        if has_content:
            Answer.objects.update_or_create(
                attempt=attempt,
                question=question,
                defaults={
                    'mcq_answer': mcq_answer,
                    'text_answer': text_answer
                }
            )
        else:
            Answer.objects.filter(attempt=attempt, question=question).delete()

        redis_data = redis_service.get_attempt_state(str(attempt.id)) or {}

        if 'go_to' in request.POST:
            redis_data['current_question'] = request.POST.get('go_to')
            redis_service.cache_attempt_state(str(attempt.id), redis_data)
            return redirect('exams:exam_interface', pk=attempt.id)
        elif 'next' in request.POST and request.POST.get('next_question_id'):
            redis_data['current_question'] = request.POST.get('next_question_id')
            redis_service.cache_attempt_state(str(attempt.id), redis_data)
            return redirect('exams:exam_interface', pk=attempt.id)
        elif 'prev' in request.POST and request.POST.get('prev_question_id'):
            redis_data['current_question'] = request.POST.get('prev_question_id')
            redis_service.cache_attempt_state(str(attempt.id), redis_data)
            return redirect('exams:exam_interface', pk=attempt.id)
        elif 'submit' in request.POST:
            return redirect('exams:exam_submit', pk=attempt.id)

        return redirect('exams:exam_interface', pk=attempt.id)


class ExamSubmitView(LoginRequiredMixin, View):
    def get(self, request, pk):
        attempt = get_object_or_404(ExamAttempt, pk=pk, user=request.user)
        is_auto_submit = request.GET.get('auto', '0') == '1'

        if is_auto_submit:
            return self.submit_exam(request, attempt, is_auto_submit=True)

        if attempt.status != 'IN_PROGRESS':
            messages.warning(request, "This exam has already been submitted.")
            return redirect('exams:student_dashboard')

        total_questions = attempt.exam_set.questions.count()

        answered_count = attempt.answers.exclude(
            Q(mcq_answer='') &
            (Q(text_answer='') | Q(text_answer='[]') | Q(text_answer__isnull=True))
        ).count()

        unanswered_count = total_questions - answered_count

        context = {
            'attempt': attempt,
            'total_questions': total_questions,
            'answered_count': answered_count,
            'unanswered_count': unanswered_count,
            'is_first_attempt': attempt.is_first_attempt,
        }
        return render(request, 'exams/exam_submit.html', context)

    def post(self, request, pk):
        attempt = get_object_or_404(ExamAttempt, pk=pk, user=request.user)
        is_auto_submit = request.POST.get('auto', '0') == '1'
        return self.submit_exam(request, attempt, is_auto_submit)

    def submit_exam(self, request, attempt, is_auto_submit=False):
        if attempt.status != 'IN_PROGRESS':
            return redirect('exams:student_dashboard')

        # Grade MCQ answers
        mcq_answers = attempt.answers.filter(question__question_type='MCQ').select_related('question')
        for answer in mcq_answers:
            question = answer.question
            is_correct = (answer.mcq_answer and answer.mcq_answer.upper() == question.correct_choice.upper())
            answer.is_correct = is_correct
            answer.save()

            Grading.objects.update_or_create(
                attempt=attempt,
                question=question,
                defaults={
                    'is_correct': is_correct,
                    'feedback': "Auto-graded MCQ",
                    'graded_by': None
                }
            )

        # Grade text answers
        text_answers = attempt.answers.filter(question__question_type='TEXT').select_related('question')
        total_points = 0
        earned_points = 0

        for answer in text_answers:
            question = answer.question
            points_per_answer = question.points_per_answer or 1

            student_answers = []
            try:
                parsed = json.loads(answer.text_answer) if answer.text_answer else []
                if isinstance(parsed, list):
                    student_answers = [ans.strip().lower() for ans in parsed if ans.strip()]
            except:
                if answer.text_answer:
                    student_answers = [answer.text_answer.strip().lower()]

            expected_answers = question.expected_answers or []
            expected_lower = [exp.strip().lower() for exp in expected_answers]

            correct_count = 0
            feedback_parts = []
            for i, student_ans in enumerate(student_answers, 1):
                is_correct = student_ans in expected_lower if expected_lower else False
                if is_correct:
                    correct_count += 1
                    feedback_parts.append(f"Answer {i}: '{student_ans}' ✓")
                else:
                    feedback_parts.append(f"Answer {i}: '{student_ans}' ✗")

            question_points = correct_count * points_per_answer
            total_points += len(student_answers) * points_per_answer
            earned_points += question_points
            is_correct = correct_count > 0

            answer.is_correct = is_correct
            answer.save()

            feedback_text = "\n".join(feedback_parts)
            Grading.objects.update_or_create(
                attempt=attempt,
                question=question,
                defaults={
                    'is_correct': is_correct,
                    'feedback': feedback_text,
                    'graded_by': None
                }
            )

        attempt.end_time = timezone.now()

        max_points = 0
        for answer in attempt.answers.all():
            max_points += answer.question.points

        score_percentage = (earned_points / max_points * 100) if max_points > 0 else 0

        if attempt.is_first_attempt:
            attempt.status = 'SUBMITTED'
            attempt.final_score = score_percentage

            if text_answers.count() > 0:
                attempt.results_released = False
                if not is_auto_submit:
                    messages.success(request, f"✅ Exam submitted! {text_answers.count()} text answer(s) need teacher review.")
            else:
                attempt.results_released = True
                attempt.released_at = timezone.now()

                record = ExamRecord.objects.create(
                    user=attempt.user,
                    exam_set=attempt.exam_set,
                    title=attempt.exam_set.title,
                    description=attempt.exam_set.description,
                    total_questions=attempt.exam_set.questions.count(),
                    total_points=max_points,
                    earned_points=earned_points,
                    score_percentage=score_percentage,
                    duration_minutes=int((attempt.end_time - attempt.start_time).total_seconds() / 60),
                )
                attempt.record = record

                for idx, answer in enumerate(attempt.answers.order_by('question__section__order', 'question__section_order'), 1):
                    grading = Grading.objects.filter(attempt=attempt, question=answer.question).first()
                    ExamRecordAnswer.objects.create(
                        record=record,
                        question_text=answer.question.text,
                        question_type=answer.question.question_type,
                        points=answer.question.points,
                        student_answer=answer.text_answer or answer.mcq_answer or '',
                        is_correct=answer.is_correct or False,
                        earned_points=answer.question.points if answer.is_correct else 0,
                        teacher_feedback=grading.feedback if grading else '',
                        feedback_from=None,
                        order=idx
                    )

                if not is_auto_submit:
                    messages.success(request, f"✅ Exam completed! Your score: {score_percentage:.1f}%")
        else:
            attempt.status = 'SUBMITTED'
            attempt.final_score = score_percentage
            messages.info(request, f"🎯 Practice completed! Score: {score_percentage:.1f}%. Take another practice to improve!")

        attempt.save()

        redis_service.delete_attempt_state(str(attempt.id))
        if attempt.is_first_attempt:
            redis_service.clear_auto_submit(str(attempt.id))

        if attempt.is_first_attempt and not attempt.results_released:
            return redirect('exams:student_pending_view', pk=attempt.id)
        else:
            return redirect('exams:exam_set_detail', pk=attempt.exam_set.id)


# ==================== STUDENT VIEWS ====================

class StudentDashboardView(LoginRequiredMixin, View):
    template_name = 'exams/student_dashboard.html'

    def get(self, request):
        records = ExamRecord.objects.filter(
            user=request.user
        ).select_related('exam_set').order_by('-taken_at')

        pending_attempts = ExamAttempt.objects.filter(
            user=request.user,
            is_first_attempt=True,
            status='SUBMITTED',
            results_released=False
        ).select_related('exam_set')

        practice_attempts = ExamAttempt.objects.filter(
            user=request.user,
            is_first_attempt=False
        ).select_related('exam_set').order_by('-end_time')[:5]

        context = {
            'records': records,
            'pending_attempts': pending_attempts,
            'practice_attempts': practice_attempts,
            'pending_count': pending_attempts.count(),
        }
        return render(request, self.template_name, context)


class StudentPendingView(LoginRequiredMixin, DetailView):
    model = ExamAttempt
    template_name = 'exams/student_pending.html'
    context_object_name = 'attempt'

    def get_queryset(self):
        return ExamAttempt.objects.filter(user=self.request.user, is_first_attempt=True)

    def get_context_data(self, **kwargs):
        context = super().get_context_data(**kwargs)
        attempt = self.object

        if attempt.end_time:
            time_diff = timezone.now() - attempt.end_time
            hours_pending = time_diff.total_seconds() / 3600
            context['hours_pending'] = round(hours_pending, 1)

        earlier_count = ExamAttempt.objects.filter(
            exam_set__creator=attempt.exam_set.creator,
            status='SUBMITTED',
            end_time__lt=attempt.end_time
        ).count()
        context['queue_position'] = earlier_count + 1

        return context


class StudentRecordView(LoginRequiredMixin, DetailView):
    model = ExamRecord
    template_name = 'exams/student_record.html'
    context_object_name = 'record'

    def get_queryset(self):
        return ExamRecord.objects.filter(user=self.request.user)

    def get_context_data(self, **kwargs):
        context = super().get_context_data(**kwargs)
        record = self.object

        answers = record.answers.all().order_by('order')
        correct_count = answers.filter(is_correct=True).count()
        total_questions = answers.count()

        context.update({
            'answers': answers,
            'correct_count': correct_count,
            'incorrect_count': total_questions - correct_count,
            'total_questions': total_questions,
            'score_percentage': record.score_percentage,
            'grade_letter': self.get_grade_letter(record.score_percentage),
            'performance_level': self.get_performance_level(record.score_percentage),
        })

        return context

    def get_grade_letter(self, percentage):
        if percentage >= 90: return 'A'
        elif percentage >= 80: return 'B'
        elif percentage >= 70: return 'C'
        elif percentage >= 60: return 'D'
        else: return 'F'

    def get_performance_level(self, percentage):
        if percentage >= 90: return 'Excellent'
        elif percentage >= 80: return 'Very Good'
        elif percentage >= 70: return 'Good'
        elif percentage >= 60: return 'Fair'
        else: return 'Needs Improvement'


# ==================== SETTER VIEWS ====================

class SetterDashboardView(LoginRequiredMixin, View):
    template_name = 'exams/setter_dashboard.html'

    def get(self, request):
        if request.user.profile.role != 'setter' and not request.user.is_staff:
            messages.error(request, "Access denied. Setters only.")
            return redirect('dashboard')

        all_attempts = ExamAttempt.objects.filter(
            exam_set__creator=request.user
        ).select_related(
            'user', 'exam_set', 'released_by'
        ).order_by('-end_time')

        stats = {
            'total_attempts': all_attempts.count(),
            'first_attempts': all_attempts.filter(is_first_attempt=True).count(),
            'practice_attempts': all_attempts.filter(is_first_attempt=False).count(),
            'submitted': all_attempts.filter(status='SUBMITTED').count(),
            'graded': all_attempts.filter(status='GRADED').count(),
            'pending_grading': all_attempts.filter(status='GRADING_PENDING').count(),
            'results_released': all_attempts.filter(results_released=True).count(),
        }

        pending_release = all_attempts.filter(
            status='SUBMITTED',
            results_released=False
        ).count()

        status_filter = request.GET.get('status', 'all')
        if status_filter == 'submitted':
            attempts = all_attempts.filter(status='SUBMITTED')
        elif status_filter == 'graded':
            attempts = all_attempts.filter(status='GRADED')
        elif status_filter == 'pending':
            attempts = all_attempts.filter(status='GRADING_PENDING')
        elif status_filter == 'released':
            attempts = all_attempts.filter(results_released=True)
        elif status_filter == 'unreleased':
            attempts = all_attempts.filter(results_released=False, status='GRADED')
        else:
            attempts = all_attempts

        search_query = request.GET.get('search', '')
        if search_query:
            attempts = attempts.filter(
                Q(user__username__icontains=search_query) |
                Q(user__email__icontains=search_query) |
                Q(user__first_name__icontains=search_query) |
                Q(user__last_name__icontains=search_query) |
                Q(exam_set__title__icontains=search_query)
            )

        paginator = Paginator(attempts, 20)
        page = request.GET.get('page', 1)
        attempts_page = paginator.get_page(page)

        context = {
            'attempts': attempts_page,
            'stats': stats,
            'pending_release': pending_release,
            'current_filters': {
                'status': status_filter,
                'search': search_query,
            },
            'is_paginated': attempts_page.has_other_pages(),
        }

        return render(request, self.template_name, context)


class SetterAttemptDetailView(LoginRequiredMixin, DetailView):
    model = ExamAttempt
    template_name = 'exams/setter_attempt_detail.html'
    context_object_name = 'attempt'

    def get_queryset(self):
        return ExamAttempt.objects.filter(
            exam_set__creator=self.request.user
        ).select_related('user', 'exam_set', 'record')

    def get_context_data(self, **kwargs):
        context = super().get_context_data(**kwargs)
        attempt = self.object

        answers = attempt.answers.select_related('question').order_by('question__section__order', 'question__section_order')
        context['answers'] = answers

        if attempt.end_time and attempt.start_time:
            duration = (attempt.end_time - attempt.start_time).total_seconds() / 60
            context['duration_minutes'] = round(duration, 1)

        return context


class SetterReleaseResultsView(LoginRequiredMixin, View):
    template_name = 'exams/setter_release_results.html'

    def get(self, request, pk):
        attempt = get_object_or_404(ExamAttempt, pk=pk)

        if attempt.exam_set.creator != request.user:
            messages.error(request, "You don't have permission to grade this attempt")
            return redirect('exams:grading_dashboard')

        answers = attempt.answers.select_related('question').order_by('question__section__order', 'question__section_order')

        for answer in answers:
            if answer.question.question_type == 'TEXT' and answer.text_answer:
                try:
                    parsed = json.loads(answer.text_answer)
                    if isinstance(parsed, list):
                        answer.parsed_answers = parsed
                    else:
                        answer.parsed_answers = [answer.text_answer]
                except:
                    answer.parsed_answers = [answer.text_answer] if answer.text_answer else []
            else:
                answer.parsed_answers = []

        context = {
            'attempt': attempt,
            'answers': answers,
            'student': attempt.user,
            'exam_set': attempt.exam_set,
        }
        return render(request, self.template_name, context)

    def post(self, request, pk):
        attempt = get_object_or_404(ExamAttempt, pk=pk)

        if attempt.exam_set.creator != request.user:
            messages.error(request, "Permission denied")
            return redirect('exams:grading_dashboard')

        action = request.POST.get('action')

        if action == 'release':
            total_points = 0
            earned_points = 0

            for answer in attempt.answers.all():
                question = answer.question

                if question.question_type == 'TEXT':
                    parsed_answers = []
                    try:
                        parsed = json.loads(answer.text_answer) if answer.text_answer else []
                        if isinstance(parsed, list):
                            parsed_answers = parsed
                    except:
                        parsed_answers = [answer.text_answer] if answer.text_answer else []

                    correct_count = 0
                    feedback_parts = []

                    for i, student_ans in enumerate(parsed_answers, 1):
                        is_correct_key = f'q_{answer.id}_correct_{i}'
                        feedback_key = f'feedback_{answer.id}_{i}'

                        is_correct = request.POST.get(is_correct_key) == 'true'
                        feedback = request.POST.get(feedback_key, '')

                        if is_correct:
                            correct_count += 1
                            feedback_parts.append(f"Answer {i}: '{student_ans}' ✓ - {feedback}" if feedback else f"Answer {i}: '{student_ans}' ✓")
                        else:
                            feedback_parts.append(f"Answer {i}: '{student_ans}' ✗ - {feedback}" if feedback else f"Answer {i}: '{student_ans}' ✗")

                        if is_correct:
                            earned_points += question.points_per_answer or 1
                        total_points += question.points_per_answer or 1

                    answer.is_correct = correct_count > 0
                    answer.save()

                    combined_feedback = "\n".join(feedback_parts)
                    Grading.objects.update_or_create(
                        attempt=attempt,
                        question=question,
                        defaults={
                            'is_correct': answer.is_correct,
                            'feedback': combined_feedback,
                            'graded_by': request.user,
                        }
                    )
                else:
                    is_correct = request.POST.get(f'q_{answer.id}_correct') == 'true'
                    feedback = request.POST.get(f'feedback_{answer.id}', '')

                    answer.is_correct = is_correct
                    answer.save()

                    Grading.objects.update_or_create(
                        attempt=attempt,
                        question=question,
                        defaults={
                            'is_correct': is_correct,
                            'feedback': feedback,
                            'graded_by': request.user,
                        }
                    )

                    total_points += question.points
                    if is_correct:
                        earned_points += question.points

            score_percentage = (earned_points / total_points * 100) if total_points > 0 else 0

            if attempt.is_first_attempt:
                record = ExamRecord.objects.create(
                    user=attempt.user,
                    exam_set=attempt.exam_set,
                    title=attempt.exam_set.title,
                    description=attempt.exam_set.description,
                    total_questions=attempt.exam_set.questions.count(),
                    total_points=total_points,
                    earned_points=earned_points,
                    score_percentage=score_percentage,
                    duration_minutes=int((attempt.end_time - attempt.start_time).total_seconds() / 60),
                )

                for idx, answer in enumerate(attempt.answers.order_by('question__section__order', 'question__section_order'), 1):
                    grading = Grading.objects.filter(attempt=attempt, question=answer.question).first()
                    student_answer_display = answer.text_answer or answer.mcq_answer or ''

                    if answer.question.question_type == 'TEXT':
                        try:
                            parsed = json.loads(student_answer_display)
                            if isinstance(parsed, list):
                                student_answer_display = ', '.join(parsed)
                        except:
                            pass

                    ExamRecordAnswer.objects.create(
                        record=record,
                        question_text=answer.question.text,
                        question_type=answer.question.question_type,
                        points=answer.question.points,
                        student_answer=student_answer_display,
                        is_correct=answer.is_correct or False,
                        earned_points=answer.question.points if answer.is_correct else 0,
                        teacher_feedback=grading.feedback if grading else '',
                        feedback_from=request.user,
                        order=idx
                    )

                attempt.record = record

            attempt.final_score = score_percentage
            attempt.results_released = True
            attempt.released_at = timezone.now()
            attempt.released_by = request.user
            attempt.status = 'GRADED'
            attempt.save()

            messages.success(request, f"✅ Results released for {attempt.user.username}")

        return redirect('exams:grading_dashboard')


# ==================== LEGACY VIEWS ====================

class QuestionCreateView(LoginRequiredMixin, CreateView):
    template_name = 'exams/question_form.html'

    def get_form_class(self):
        question_type = self.request.GET.get('type')
        if question_type == QUESTION_TYPE_MCQ:
            return MCQQuestionForm
        return TextQuestionForm

    def get_template_names(self):
        question_type = self.request.GET.get('type')
        if question_type == QUESTION_TYPE_MCQ:
            return ['exams/mcq_question_form.html']
        return ['exams/text_question_form.html']

    def form_valid(self, form):
        form.instance.exam_set = get_object_or_404(ExamSet, pk=self.kwargs['exam_set_id'])
        form.instance.created_by = self.request.user
        return super().form_valid(form)

    def get_success_url(self):
        return reverse('exams:exam_set_detail', kwargs={'pk': self.kwargs['exam_set_id']})

    def get_context_data(self, **kwargs):
        context = super().get_context_data(**kwargs)
        context['exam_set'] = get_object_or_404(ExamSet, pk=self.kwargs['exam_set_id'])
        return context


class QuestionUpdateView(LoginRequiredMixin, UpdateView):
    model = Question
    template_name = 'exams/question_form.html'

    def get_form_class(self):
        if self.object.question_type == QUESTION_TYPE_MCQ:
            return MCQQuestionForm
        return TextQuestionForm

    def get_template_names(self):
        if self.object.question_type == QUESTION_TYPE_MCQ:
            return ['exams/mcq_question_form.html']
        return ['exams/text_question_form.html']

    def get_success_url(self):
        return reverse('exams:exam_set_detail', kwargs={'pk': self.object.exam_set.id})


def add_mcq_question(request, set_id):
    exam_set = get_object_or_404(ExamSet, id=set_id)
    if request.method == 'POST':
        form = MCQQuestionForm(request.POST, request.FILES)
        if form.is_valid():
            question = form.save(commit=False)
            question.exam_set = exam_set
            question.save()
            return redirect('exams:exam_set_detail', pk=exam_set.id)
    else:
        form = MCQQuestionForm()
    return render(request, 'exams/mcq_question_form.html', {
        'form': form,
        'exam_set': exam_set,
    })


def add_text_question(request, set_id):
    exam_set = get_object_or_404(ExamSet, id=set_id)
    if request.method == 'POST':
        form = TextQuestionForm(request.POST, request.FILES)
        if form.is_valid():
            question = form.save(commit=False)
            question.exam_set = exam_set
            question.question_type = 'TEXT'
            question.save()
            return redirect('exams:exam_set_detail', pk=exam_set.id)
    else:
        form = TextQuestionForm()
    return render(request, 'exams/text_question_form.html', {
        'form': form,
        'exam_set': exam_set
    })


# ==================== GRADING VIEWS ====================

class GradingDashboardView(LoginRequiredMixin, View):
    template_name = 'exams/grading_dashboard.html'

    def get(self, request):
        if request.user.profile.role != 'setter' and not request.user.is_staff:
            messages.error(request, "Access denied. Setters only.")
            return redirect('dashboard')

        pending_attempts = ExamAttempt.objects.filter(
            exam_set__creator=request.user,
            status='SUBMITTED',
            results_released=False
        ).select_related(
            'user', 'exam_set'
        ).order_by('-end_time')

        pending_count = pending_attempts.count()
        total_attempts = ExamAttempt.objects.filter(
            exam_set__creator=request.user
        ).count()

        text_questions_count = Question.objects.filter(
            exam_set__creator=request.user,
            question_type='TEXT'
        ).count()

        week_ago = timezone.now() - timedelta(days=7)
        recent_graded = ExamAttempt.objects.filter(
            exam_set__creator=request.user,
            status='GRADED',
            released_at__gte=week_ago
        ).select_related('user', 'exam_set').order_by('-released_at')[:5]

        today_start = timezone.now().replace(hour=0, minute=0, second=0)
        graded_today = ExamAttempt.objects.filter(
            exam_set__creator=request.user,
            status='GRADED',
            released_at__gte=today_start
        ).count()

        context = {
            'pending_attempts': pending_attempts,
            'pending_count': pending_count,
            'total_attempts': total_attempts,
            'text_questions_count': text_questions_count,
            'recent_graded': recent_graded,
            'graded_today': graded_today,
        }

        return render(request, self.template_name, context)


class GradingInterfaceView(LoginRequiredMixin, View):
    template_name = 'exams/grading_interface.html'

    def get(self, request, pk):
        attempt = get_object_or_404(ExamAttempt, pk=pk)

        if attempt.exam_set.creator != request.user:
            messages.error(request, "You don't have permission to grade this attempt")
            return redirect('exams:grading_dashboard')

        text_questions = attempt.exam_set.questions.filter(question_type=QUESTION_TYPE_TEXT)
        text_answers = Answer.objects.filter(
            attempt=attempt,
            question__in=text_questions
        ).select_related('question')

        redis_data = redis_service.get_attempt_state(str(attempt.id)) or {}
        current_index = int(redis_data.get('grading_index', 0))

        if text_answers and current_index < len(text_answers):
            current_answer = text_answers[current_index]
            auto_grade = Grading.objects.filter(
                attempt=attempt,
                question=current_answer.question,
                grading_source='AUTO'
            ).first()

            initial = {
                'is_correct': auto_grade.is_correct if auto_grade else True,
                'feedback': auto_grade.feedback if auto_grade else ''
            }
            form = GradingForm(initial=initial)
        else:
            current_answer = None
            form = None

        context = {
            'attempt': attempt,
            'answers': text_answers,
            'current_answer': current_answer,
            'current_index': current_index,
            'form': form,
            'total_questions': len(text_answers),
            'auto_grade': auto_grade if current_answer else None
        }
        return render(request, self.template_name, context)

    def post(self, request, pk):
        attempt = get_object_or_404(ExamAttempt, pk=pk)

        if attempt.exam_set.creator != request.user:
            messages.error(request, "You don't have permission to grade this attempt")
            return redirect('exams:grading_dashboard')

        answer = get_object_or_404(Answer, pk=request.POST.get('answer_id'))
        form = GradingForm(request.POST)

        if form.is_valid():
            Grading.objects.update_or_create(
                attempt=attempt,
                question=answer.question,
                defaults={
                    'is_correct': form.cleaned_data['is_correct'],
                    'feedback': form.cleaned_data['feedback'],
                    'graded_by': request.user,
                    'grading_source': 'TEACHER_REVIEW'
                }
            )

            answer.is_correct = form.cleaned_data['is_correct']
            answer.save()

            text_answers = Answer.objects.filter(
                attempt=attempt,
                question__question_type=QUESTION_TYPE_TEXT
            ).order_by('question__order')

            total_questions = text_answers.count()
            redis_data = redis_service.get_attempt_state(str(attempt.id)) or {}
            current_index = int(redis_data.get('grading_index', 0))

            if 'next' in request.POST and current_index < total_questions - 1:
                redis_data['grading_index'] = str(current_index + 1)
                redis_service.cache_attempt_state(str(attempt.id), redis_data)
                return redirect('exams:grading_interface', pk=attempt.id)
            elif 'prev' in request.POST and current_index > 0:
                redis_data['grading_index'] = str(current_index - 1)
                redis_service.cache_attempt_state(str(attempt.id), redis_data)
                return redirect('exams:grading_interface', pk=attempt.id)

            # ===== FIX: Calculate score and redirect to release page =====
            total_points = 0
            earned_points = 0
            for ans in attempt.answers.all():
                total_points += ans.question.points
                if ans.is_correct:
                    earned_points += ans.question.points

            attempt.final_score = (earned_points / total_points * 100) if total_points > 0 else 0
            attempt.status = 'GRADED'
            attempt.graded_at = timezone.now()
            attempt.save()

            redis_service.delete_attempt_state(str(attempt.id))
            messages.success(request, f"✅ Grading completed! Score: {attempt.final_score:.1f}%")
            return redirect('exams:setter_release_results', pk=attempt.id)

        return redirect('exams:grading_interface', pk=attempt.id)


class GradingSubmitView(LoginRequiredMixin, View):
    def post(self, request, pk):
        attempt = get_object_or_404(ExamAttempt, pk=pk)

        if attempt.exam_set.creator != request.user:
            messages.error(request, "You don't have permission to grade this attempt")
            return redirect('exams:grading_dashboard')

        total_points = 0
        earned_points = 0

        for answer in attempt.answers.all():
            total_points += answer.question.points
            if answer.is_correct:
                earned_points += answer.question.points

        attempt.final_score = (earned_points / total_points * 100) if total_points > 0 else 0
        attempt.status = 'GRADED'
        attempt.graded_at = timezone.now()
        attempt.save()

        redis_service.delete_attempt_state(str(attempt.id))
        messages.success(request, "Grading completed successfully!")

        return redirect('exams:grading_dashboard')


class ExamResultView(LoginRequiredMixin, DetailView):
    model = ExamAttempt
    template_name = 'exams/exam_result.html'
    context_object_name = 'attempt'

    def get_queryset(self):
        if self.request.user.profile.role == 'setter':
            return ExamAttempt.objects.filter(exam_set__creator=self.request.user)
        return ExamAttempt.objects.filter(user=self.request.user)

    def get_context_data(self, **kwargs):
        context = super().get_context_data(**kwargs)
        attempt = self.object

        answers = attempt.answers.select_related('question').order_by('question__order')
        context['answers'] = answers

        correct_answers = answers.filter(is_correct=True).count()
        context['correct_answers'] = correct_answers
        context['incorrect_answers'] = answers.count() - correct_answers

        return context


class ExamResultListView(LoginRequiredMixin, ListView):
    model = ExamAttempt
    template_name = 'exams/exam_result_list.html'
    context_object_name = 'attempts'

    def get_queryset(self):
        return ExamAttempt.objects.filter(user=self.request.user).order_by('-start_time')


# ==================== DEBUG VIEWS ====================

def debug_questions(request, set_id):
    exam_set = get_object_or_404(ExamSet, id=set_id)
    questions = Question.objects.filter(exam_set=exam_set).select_related('section')

    data = {
        'exam_set': exam_set.title,
        'total_questions': questions.count(),
        'questions': []
    }

    for q in questions:
        data['questions'].append({
            'id': str(q.id),
            'text': q.text[:50],
            'type': q.question_type,
            'section': q.section.letter if q.section else 'No section',
            'has_reference': bool(q.reference_answer),
            'max_length': q.max_length
        })

    return JsonResponse(data)

# Shared marking pool: setter invites teachers, accepted teachers claim distinct attempts.
def _marking_member(request, exam_set):
    if request.user == exam_set.creator or request.user.is_superuser:
        return True
    return ExamMarkerInvitation.objects.filter(exam_set=exam_set, teacher=request.user, status=ExamMarkerInvitation.ACCEPTED).exists()

@login_required
def marker_invite(request, pk):
    exam = get_object_or_404(ExamSet, pk=pk)
    if request.user != exam.creator and not request.user.is_superuser:
        return HttpResponse('Only the exam setter can invite markers.', status=403)
    teacher_id = request.POST.get('teacher_id')
    teacher_username = request.POST.get('teacher_username', '').strip()
    teacher = get_object_or_404(User, **({'pk': teacher_id} if teacher_id else {'username': teacher_username}), is_active=True)
    ExamMarkerInvitation.objects.update_or_create(exam_set=exam, teacher=teacher, defaults={'setter': request.user, 'status': ExamMarkerInvitation.PENDING, 'responded_at': None})
    messages.success(request, 'Marker invitation sent.')
    return redirect('exams:marking_queue', pk=exam.pk)

@login_required
def marker_invitation_respond(request, pk):
    invitation = get_object_or_404(ExamMarkerInvitation, pk=pk, teacher=request.user, status=ExamMarkerInvitation.PENDING)
    invitation.status = ExamMarkerInvitation.ACCEPTED if request.POST.get('action') == 'accept' else ExamMarkerInvitation.DECLINED
    invitation.responded_at = timezone.now(); invitation.save(update_fields=['status','responded_at'])
    messages.success(request, f'Marking invitation {invitation.status}.')
    return redirect('exams:marking_queue', pk=invitation.exam_set_id)

@login_required
def marking_queue(request, pk):
    exam = get_object_or_404(ExamSet, pk=pk)
    if not _marking_member(request, exam): return HttpResponse('You are not part of this marking pool.', status=403)
    attempts = ExamAttempt.objects.filter(exam_set=exam, status__in=['GRADING_PENDING','SUBMITTED']).select_related('user').order_by('end_time')
    if request.user != exam.creator:
        attempts = attempts.filter(Q(marking_claim__isnull=True) | Q(marking_claim__teacher=request.user, marking_claim__status=ExamMarkingClaim.CLAIMED))
    return render(request, 'exams/marking_queue.html', {'exam': exam, 'attempts': attempts, 'invitations': ExamMarkerInvitation.objects.filter(teacher=request.user, status=ExamMarkerInvitation.PENDING)})

@login_required
@require_http_methods(['POST'])
def marking_claim(request, attempt_id):
    attempt = get_object_or_404(ExamAttempt.objects.select_related('exam_set'), pk=attempt_id)
    if not _marking_member(request, attempt.exam_set): return HttpResponse('Not authorized.', status=403)
    if attempt.marking_claim_id and attempt.marking_claim.status == ExamMarkingClaim.CLAIMED:
        messages.info(request, 'This submission is already claimed by another marker.')
    else:
        ExamMarkingClaim.objects.update_or_create(attempt=attempt, defaults={'teacher': request.user, 'status': ExamMarkingClaim.CLAIMED, 'released_at': None})
        messages.success(request, 'Submission claimed.')
    return redirect('exams:marking_queue', pk=attempt.exam_set_id)

@login_required
@require_http_methods(['GET','POST'])
def marking_review(request, attempt_id):
    attempt = get_object_or_404(ExamAttempt.objects.select_related('exam_set','user'), pk=attempt_id)
    claim = getattr(attempt, 'marking_claim', None)
    if not _marking_member(request, attempt.exam_set) or (claim and claim.status == ExamMarkingClaim.CLAIMED and claim.teacher_id != request.user.id and request.user != attempt.exam_set.creator):
        return HttpResponse('Not authorized for this submission.', status=403)
    if request.method == 'POST':
        for answer in attempt.answers.select_related('question'):
            if answer.question.question_type != 'MCQ':
                value = request.POST.get(f'correct_{answer.pk}') == '1'
                Grading.objects.update_or_create(attempt=attempt, question=answer.question, defaults={'is_correct': value, 'feedback': request.POST.get(f'feedback_{answer.pk}', ''), 'graded_by': request.user, 'grading_source': 'TEACHER_REVIEW'})
        total = attempt.answers.select_related('question').aggregate(total=Sum('question__points'))['total'] or 0
        earned = sum(a.question.points for a in attempt.answers.all() if getattr(getattr(a, 'question', None), 'question_type', '') == 'MCQ' and a.is_correct)
        earned += sum(g.question.points for g in Grading.objects.filter(attempt=attempt, is_correct=True).select_related('question'))
        attempt.final_score = (earned / total * 100) if total else 0; attempt.graded_at = timezone.now(); attempt.status = 'GRADED'; attempt.save(update_fields=['final_score','graded_at','status'])
        if request.POST.get('release') == '1':
            attempt.results_released = True; attempt.released_at = timezone.now(); attempt.released_by = request.user; attempt.save(update_fields=['results_released','released_at','released_by'])
            if claim: claim.status = ExamMarkingClaim.RELEASED; claim.released_at = timezone.now(); claim.save(update_fields=['status','released_at'])
        messages.success(request, 'Marked work saved and released.' if attempt.results_released else 'Marked work saved.')
        return redirect('exams:marking_queue', pk=attempt.exam_set_id)
    return render(request, 'exams/marking_review.html', {'attempt': attempt, 'answers': attempt.answers.select_related('question').all()})
