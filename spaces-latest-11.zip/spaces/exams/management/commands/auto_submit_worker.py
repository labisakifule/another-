# exams/management/commands/auto_submit_worker.py

import time
import logging
from django.core.management.base import BaseCommand
from django.utils import timezone
from django.db import transaction
from django.conf import settings
from exams.services.redis_service import redis_service
from exams.models import ExamAttempt, Answer, Grading, ExamRecord, ExamRecordAnswer
from exams.constants import ATTEMPT_STATUS_AUTO_SUBMITTED
from exams.services.grading_service import grading_service

logger = logging.getLogger(__name__)

class Command(BaseCommand):
    help = 'Processes auto-submission of timed-out exam attempts'

    def handle(self, *args, **options):
        self.stdout.write("🔄 Auto-submit worker started (silent mode)...")
        
        while True:
            try:
                due_attempts = redis_service.get_due_auto_submits()
                
                for attempt_id in due_attempts:
                    self.process_auto_submit(attempt_id)
                
                time.sleep(5)
                
            except KeyboardInterrupt:
                self.stdout.write("\n🛑 Auto-submit worker stopped")
                break
            except Exception as e:
                logger.error(f"Error in auto-submit worker: {str(e)}")
                time.sleep(5)
    
    def process_auto_submit(self, attempt_id):
        """Process a single auto-submit silently"""
        try:
            attempt = ExamAttempt.objects.select_related(
                'user', 'exam_set'
            ).get(id=attempt_id, status='IN_PROGRESS')
            
            self.stdout.write(f"⏰ Auto-submitting attempt {attempt_id}")
            
            with transaction.atomic():
                # Grade MCQ answers
                mcq_answers = Answer.objects.filter(
                    attempt=attempt,
                    question__question_type='MCQ'
                ).select_related('question')
                
                for answer in mcq_answers:
                    question = answer.question
                    is_correct = (answer.mcq_answer and 
                                answer.mcq_answer.upper() == question.correct_choice.upper())
                    answer.is_correct = is_correct
                    answer.save()
                    
                    Grading.objects.create(
                        attempt=attempt,
                        question=question,
                        is_correct=is_correct,
                        feedback="Auto-graded MCQ",
                        graded_by=None
                    )
                
                # Grade text answers
                text_answers = Answer.objects.filter(
                    attempt=attempt,
                    question__question_type='TEXT',
                    text_answer__isnull=False
                ).exclude(
                    text_answer__exact=''
                ).select_related('question')
                
                text_count = text_answers.count()
                
                for answer in text_answers:
                    question = answer.question
                    result = grading_service.grade_answer(
                        question=question,
                        student_answer=answer.text_answer
                    )
                    
                    answer.is_correct = result['is_correct']
                    answer.save()
                    
                    Grading.objects.create(
                        attempt=attempt,
                        question=question,
                        is_correct=result['is_correct'],
                        feedback=result['feedback'],
                        graded_by=None
                    )
                
                # Update attempt
                attempt.end_time = timezone.now()
                
                # Calculate totals
                total_points = attempt.exam_set.questions.aggregate(
                    total=models.Sum('points')
                )['total'] or 0
                
                earned_points = Answer.objects.filter(
                    attempt=attempt,
                    is_correct=True
                ).aggregate(
                    total=models.Sum('question__points')
                )['total'] or 0
                
                score_percentage = (earned_points / total_points * 100) if total_points > 0 else 0
                
                # Handle first attempt
                if attempt.is_first_attempt:
                    if text_count > 0:
                        # Has text questions - needs review
                        attempt.status = 'SUBMITTED'
                        attempt.results_released = False
                        self.stdout.write(f"📝 Attempt {attempt_id} needs review ({text_count} text answers)")
                    else:
                        # No text questions - auto-grade complete
                        attempt.status = 'GRADED'
                        attempt.results_released = True
                        attempt.released_at = timezone.now()
                        
                        # Create permanent record
                        record = ExamRecord.objects.create(
                            user=attempt.user,
                            exam_set=attempt.exam_set,
                            title=attempt.exam_set.title,
                            description=attempt.exam_set.description,
                            total_questions=attempt.exam_set.questions.count(),
                            total_points=total_points,
                            earned_points=earned_points,
                            score_percentage=score_percentage,
                            duration_minutes=int((attempt.end_time - attempt.start_time).total_seconds() / 60),
                        )
                        
                        attempt.record = record
                        
                        # Create record answers
                        for idx, answer in enumerate(attempt.answers.order_by('question__section__order', 'question__section_order'), 1):
                            grading = Grading.objects.filter(attempt=attempt, question=answer.question).first()
                            ExamRecordAnswer.objects.create(
                                record=record,
                                question_text=answer.question.text,
                                question_type=answer.question.question_type,
                                points=answer.question.points,
                                student_answer=answer.text_answer or answer.mcq_answer or '',
                                is_correct=answer.is_correct or False,
                                earned_points=answer.question.points if answer.is_correct else 0,
                                teacher_feedback=grading.feedback if grading else '',
                                feedback_from=None,
                                order=idx
                            )
                        
                        self.stdout.write(f"🎉 Attempt {attempt_id} auto-released: {score_percentage:.1f}%")
                else:
                    # Practice attempt
                    attempt.status = 'SUBMITTED'
                
                attempt.save()
                
                # Clean up Redis
                redis_service.clear_auto_submit(attempt_id)
                redis_service.delete_attempt_state(attempt_id)
                
                self.stdout.write(self.style.SUCCESS(f"✅ Auto-submitted attempt {attempt_id}"))
                
        except ExamAttempt.DoesNotExist:
            self.stdout.write(f"⚠️ Attempt {attempt_id} not found or already submitted")
            redis_service.clear_auto_submit(attempt_id)
        except Exception as e:
            self.stdout.write(self.style.ERROR(f"❌ Error auto-submitting {attempt_id}: {str(e)}"))