"""
Emoji Reference for Log Messages

Copy and paste these emoji characters directly into your strings.
Windows console may still have issues displaying them, but they'll show in
modern terminals and log files opened with UTF-8 support.
"""

EMOJI = {
    # Status
    'SUCCESS': '✅',
    'ERROR': '❌',
    'WARNING': '⚠️',
    'INFO': 'ℹ️',
    
    # Actions
    'START': '🚀',
    'STOP': '🛑',
    'PAUSE': '⏸️',
    'PLAY': '▶️',
    'FINISH': '🏁',
    
    # Objects
    'CLOCK': '⏰',
    'ALARM': '⏱️',
    'HOURGLASS': '⌛',
    'DATABASE': '🗄️',
    'REDIS': '📦',
    'EXAM': '📝',
    'USER': '👤',
    'GROUP': '👥',
    
    # Arrows
    'RIGHT': '➡️',
    'LEFT': '⬅️',
    'UP': '⬆️',
    'DOWN': '⬇️',
    
    # Misc
    'CHECK': '✓',
    'CROSS': '✗',
    'STAR': '⭐',
    'FIRE': '🔥',
    'ZAP': '⚡',
    'GEAR': '⚙️',
    'LOCK': '🔒',
    'UNLOCK': '🔓',
    'KEY': '🔑',
    'BELL': '🔔',
    'MAIL': '📧',
    'PHONE': '📱',
    'COMPUTER': '💻',
    
    # Faces
    'SMILE': '😊',
    'SAD': '😢',
    'ANGRY': '😠',
    'SURPRISED': '😮',
    
    # Weather
    'SUN': '☀️',
    'CLOUD': '☁️',
    'RAIN': '☔',
    'SNOW': '❄️',
    
    # Hearts
    'HEART': '❤️',
    'BROKEN_HEART': '💔',
    
    # Numbers (circled)
    'ZERO': '⓪',
    'ONE': '①',
    'TWO': '②',
    'THREE': '③',
    'FOUR': '④',
    'FIVE': '⑤',
    'SIX': '⑥',
    'SEVEN': '⑦',
    'EIGHT': '⑧',
    'NINE': '⑨',
    'TEN': '⑩',
}

# Example usage in your code:
"""
from exams.management.commands.emoji_reference import EMOJI

print(f"{EMOJI['START']} Starting worker")
print(f"{EMOJI['SUCCESS']} Attempt auto-submitted")
print(f"{EMOJI['ERROR']} Connection failed")
"""