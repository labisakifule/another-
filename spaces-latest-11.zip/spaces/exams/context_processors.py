# exams/context_processors.py

from django.db.models import Q
from django.utils import timezone

def notification_count(request):
    """Add notification count to all templates"""
    if request.user.is_authenticated:
        try:
            from .models import ExamAttempt
            pending_count = ExamAttempt.objects.filter(
                user=request.user,
                is_first_attempt=True,
                status='SUBMITTED',
                results_released=False
            ).count()
            return {'pending_notifications': pending_count}
        except:
            return {'pending_notifications': 0}
    return {'pending_notifications': 0}
