# exams/models.py

import uuid
import hashlib
from django.db import models
from django.utils import timezone
from django.conf import settings
from trends.models import User, Subject, Topic
from .constants import (
    QUESTION_TYPE_MCQ, QUESTION_TYPE_TEXT, QUESTION_TYPE_CHOICES,
    EXAM_SET_TYPE_FREE, EXAM_SET_TYPE_PREMIUM, EXAM_SET_TYPE_REWARD, EXAM_SET_TYPE_CHOICES,
    ATTEMPT_STATUS_IN_PROGRESS, ATTEMPT_STATUS_SUBMITTED, ATTEMPT_STATUS_AUTO_SUBMITTED,
    ATTEMPT_STATUS_GRADING_PENDING, ATTEMPT_STATUS_GRADED, ATTEMPT_STATUS_CHOICES,
)
from .services.redis_service import redis_service


class ExamSet(models.Model):
    id = models.UUIDField(primary_key=True, default=uuid.uuid4, editable=False)
    title = models.CharField(max_length=200)
    description = models.TextField()
    creator = models.ForeignKey(User, on_delete=models.CASCADE, related_name='created_exam_sets')
    institution = models.ForeignKey('trends.Institution', on_delete=models.SET_NULL, null=True, blank=True, related_name='exam_sets')
    members_only = models.BooleanField(default=False, db_index=True)
    set_type = models.CharField(max_length=10, choices=EXAM_SET_TYPE_CHOICES, default=EXAM_SET_TYPE_FREE)
    credits_required = models.PositiveIntegerField(default=0)
    subject = models.ForeignKey(Subject, on_delete=models.CASCADE)
    topic = models.ForeignKey(Topic, on_delete=models.SET_NULL, null=True, blank=True)
    duration_minutes = models.PositiveIntegerField(default=30)
    is_active = models.BooleanField(default=True)
    created_at = models.DateTimeField(auto_now_add=True)
    immutable_hash = models.CharField(max_length=64, blank=True)
    reward_eligible = models.BooleanField(default=False)
    education_level = models.ForeignKey(
        'trends.EducationLevel', 
        on_delete=models.SET_NULL, 
        null=True, 
        blank=True,
        related_name='exam_sets'
    )
    
    # ===== NEW: Premium access =====
    access_type = models.CharField(
        max_length=20,
        choices=[
            ('free', 'Free'),
            ('premium', 'Premium - SOMA Required'),
        ],
        default='free'
    )
    
    # ===== NEW: Premium pricing =====
    soma_price = models.PositiveIntegerField(default=0)
    
    # ===== NEW: Content metrics =====
    views = models.PositiveIntegerField(default=0)
    likes = models.PositiveIntegerField(default=0)
    saves = models.PositiveIntegerField(default=0)
    shares = models.PositiveIntegerField(default=0)
    
    # ===== NEW: Rating =====
    rating = models.DecimalField(max_digits=3, decimal_places=2, default=0)
    review_count = models.PositiveIntegerField(default=0)

    def __str__(self):
        return self.title

    @property
    def uid(self):
        return f"exm-{str(self.id)[:7]}"

    def save(self, *args, **kwargs):
        created = not self.pk
        super().save(*args, **kwargs)
        if self.questions.filter(question_type=QUESTION_TYPE_TEXT).exists() and self.reward_eligible:
            self.reward_eligible = False
            super().save(update_fields=['reward_eligible'])

    def generate_hash(self):
        data = f"{self.id}{self.created_at.timestamp()}"
        for question in self.questions.order_by('order'):
            data += f"{question.id}{question.text}{question.points}"
            if question.question_type == QUESTION_TYPE_MCQ:
                data += f"{question.choices}{question.correct_choice}"
            else:
                data += f"{question.reference_answer}{question.max_length}"
        return hashlib.sha256(data.encode()).hexdigest()

    def generate_assessment_hash(self):
        return hashlib.sha256(f"{self.id}-assessment".encode()).hexdigest()

    @property
    def total_marks(self):
        """Calculate total marks from all questions"""
        return self.questions.aggregate(total=models.Sum('points'))['total'] or 0
    
    # ===== NEW: Methods =====
    def can_access(self, user):
        """Check if user can access this exam"""
        if self.access_type == 'free':
            return True
        
        # Check if already purchased
        from exams.models import ExamAttempt
        if ExamAttempt.objects.filter(
            user=user, 
            exam_set=self,
            status__in=['SUBMITTED', 'GRADED']
        ).exists():
            return True
        
        # Check SOMA balance
        return user.credits >= self.soma_price


class ExamSection(models.Model):
    """
    Represents a section in an exam (e.g., Section A, Section B)
    """
    id = models.UUIDField(primary_key=True, default=uuid.uuid4, editable=False)
    exam_set = models.ForeignKey(ExamSet, on_delete=models.CASCADE, related_name='sections')
    
    # Section identification
    name = models.CharField(max_length=100)  # e.g., "Section A: Multiple Choice"
    letter = models.CharField(max_length=1)  # A, B, C, D
    order = models.PositiveIntegerField(default=1)
    
    # Section instructions
    instructions = models.TextField(blank=True, help_text="Instructions for this section")
    
    # Section settings
    question_type = models.CharField(
        max_length=20,
        choices=[
            ('MIXED', 'Mixed Types'),
            ('MCQ_ONLY', 'Multiple Choice Only'),
            ('TEXT_ONLY', 'Text Answers Only'),
        ],
        default='MIXED'
    )
    
    # Time allocation (optional - for timed sections)
    recommended_minutes = models.PositiveIntegerField(null=True, blank=True)
    
    # Display options
    show_question_numbers = models.BooleanField(default=True)
    total_marks = models.PositiveIntegerField(default=0, editable=False)
    
    class Meta:
        ordering = ['exam_set', 'order']
        unique_together = [('exam_set', 'letter')]
    
    def __str__(self):
        return f"{self.exam_set.title} - Section {self.letter}: {self.name}"
    
    def save(self, *args, **kwargs):
        # Auto-calculate total marks when saving
        super().save(*args, **kwargs)
        if hasattr(self, 'questions'):
            total = self.questions.aggregate(total=models.Sum('points'))['total'] or 0
            if self.total_marks != total:
                self.total_marks = total
                super().save(update_fields=['total_marks'])


class Question(models.Model):
    id = models.UUIDField(primary_key=True, default=uuid.uuid4, editable=False)
    exam_set = models.ForeignKey(ExamSet, on_delete=models.CASCADE, related_name='questions')
    section = models.ForeignKey(
        'ExamSection', 
        on_delete=models.CASCADE, 
        related_name='questions',
        null=True, 
        blank=True
    )
    
    # Core fields
    text = models.TextField()
    order = models.PositiveIntegerField(default=1)  # Global order
    points = models.PositiveIntegerField(default=1)
    question_type = models.CharField(max_length=4, choices=QUESTION_TYPE_CHOICES, default=QUESTION_TYPE_MCQ)
    
    # Section-specific fields
    section_order = models.PositiveIntegerField(default=1)  # Order within section
    part = models.CharField(max_length=5, blank=True, help_text="e.g., 'a', 'b', 'c'")
    
    # Difficulty level
    difficulty = models.CharField(
        max_length=10,
        choices=[
            ('EASY', 'Easy'),
            ('MEDIUM', 'Medium'),
            ('HARD', 'Hard'),
        ],
        default='MEDIUM'
    )
    
    # MCQ fields
    choices = models.JSONField(default=list, blank=True)
    correct_choice = models.CharField(max_length=1, blank=True, null=True)
    
    # Text question fields
    reference_answer = models.TextField(blank=True, null=True)
    max_length = models.PositiveIntegerField(null=True, blank=True)
    
    # Hybrid grading fields
    GRADING_TYPES = [
        ('SINGLE', 'Single Correct Answer'),
        ('MULTIPLE', 'Multiple Acceptable Answers'),
        ('KEY_POINTS', 'Key Points / Rubric'),
        ('COMBINATION', 'Combination of Points'),
    ]
    
    grading_type = models.CharField(
        max_length=20,
        choices=GRADING_TYPES,
        default='SINGLE',
        help_text="How this question should be graded"
    )
    
    # For MULTIPLE type
    acceptable_answers = models.JSONField(
        default=list,
        blank=True,
        help_text="List of acceptable answers as text (for MULTIPLE type)"
    )
    
    # For KEY_POINTS type
    key_points = models.JSONField(
        default=list,
        blank=True,
        help_text="List of key points with point values, e.g., [{'point': 'Hitler invaded Poland', 'points': 2}]"
    )
    
    # For COMBINATION type
    required_items = models.JSONField(
        default=list,
        blank=True,
        help_text="List of required items (for COMBINATION type)"
    )
    
    points_per_item = models.PositiveIntegerField(
        default=1,
        help_text="Points awarded per correct item (for COMBINATION type)"
    )
    
    minimum_points_to_pass = models.PositiveIntegerField(
        default=0,
        help_text="Minimum points needed to be considered correct"
    )
    
    # Metadata
    created_by = models.ForeignKey(User, on_delete=models.SET_NULL, null=True, related_name='created_questions')
    created_at = models.DateTimeField(auto_now_add=True, null=True)
    expected_answers = models.JSONField(
        default=list,
        blank=True,
        help_text="List of all possible correct answers"
    )
    answers_required = models.PositiveIntegerField(
        default=1,
        help_text="How many answers the student must provide"
    )
    points_per_answer = models.PositiveIntegerField(
        default=1,
        help_text="Points awarded per correct answer found"
    )

    # ===== NEW: ESSAY FIELDS =====
    min_words = models.PositiveIntegerField(default=0, help_text="Minimum words required for essay")
    max_words = models.PositiveIntegerField(default=500, help_text="Maximum words allowed for essay")
    rubric = models.JSONField(default=dict, blank=True, help_text="Rubric for essay grading")

    # ===== NEW: MEDIA SUPPORT =====
    media_type = models.CharField(
        max_length=20,
        choices=[
            ('none', 'No Media'),
            ('image', 'Image'),
            ('audio', 'Audio'),
            ('video', 'Video'),
            ('youtube', 'YouTube Video'),
            ('embed', 'Embed Code'),
        ],
        default='none'
    )
    media_file = models.FileField(
        upload_to='questions/%Y/%m/%d/',
        blank=True,
        null=True
    )
    media_url = models.URLField(blank=True, null=True)
    media_embed_code = models.TextField(blank=True, null=True)
    media_caption = models.CharField(max_length=255, blank=True, null=True)

    class Meta:
        ordering = ['section__order', 'section_order', 'part']

    def __str__(self):
        return f"{self.exam_set.title} - Q{self.order}"

    @property
    def uid(self):
        return f"q-{str(self.id)[:7]}"
    
    @property
    def display_number(self):
        """Return formatted question number like '1a', '1b', etc."""
        if self.part:
            return f"{self.section_order}{self.part}"
        return str(self.section_order)
    
    def get_total_points(self):
        """Calculate total possible points based on grading type"""
        if self.grading_type == 'KEY_POINTS' and self.key_points:
            return sum(kp.get('points', 1) for kp in self.key_points)
        elif self.grading_type == 'COMBINATION' and self.required_items:
            return len(self.required_items) * self.points_per_item
        else:
            return self.points


class Answer(models.Model):
    id = models.UUIDField(primary_key=True, default=uuid.uuid4, editable=False)
    attempt = models.ForeignKey('ExamAttempt', on_delete=models.CASCADE, related_name='answers')
    question = models.ForeignKey(Question, on_delete=models.CASCADE)
    mcq_answer = models.CharField(max_length=1, blank=True, null=True)
    text_answer = models.TextField(blank=True, null=True)
    is_correct = models.BooleanField(null=True, blank=True)
    graded_at = models.DateTimeField(null=True, blank=True)
    created_at = models.DateTimeField(auto_now_add=True, null=True)

    def __str__(self):
        return f"Answer to {self.question}"

    def save(self, *args, **kwargs):
        if self.question.question_type == QUESTION_TYPE_MCQ and self.mcq_answer:
            self.is_correct = (self.mcq_answer.upper() == self.question.correct_choice.upper())
        super().save(*args, **kwargs)

    @property
    def uid(self):
        return f"ans-{str(self.id)[:7]}"


class Grading(models.Model):
    id = models.UUIDField(primary_key=True, default=uuid.uuid4, editable=False)
    attempt = models.ForeignKey('ExamAttempt', on_delete=models.CASCADE, related_name='gradings')
    question = models.ForeignKey(Question, on_delete=models.CASCADE)
    is_correct = models.BooleanField()
    feedback = models.TextField(blank=True, null=True)
    graded_by = models.ForeignKey(User, on_delete=models.SET_NULL, null=True)
    graded_at = models.DateTimeField(auto_now_add=True)
    grading_source = models.CharField(max_length=20, default='AUTO', choices=[
        ('AUTO', 'Auto-graded'),
        ('TEACHER_REVIEW', 'Teacher Reviewed'),
    ])

    class Meta:
        unique_together = [('attempt', 'question')]

    def __str__(self):
        return f"Grading for {self.attempt} - Q{self.question.order}"

    @property
    def uid(self):
        return f"grd-{str(self.id)[:7]}"


class Correction(models.Model):
    id = models.UUIDField(primary_key=True, default=uuid.uuid4, editable=False)
    exam_set = models.ForeignKey(ExamSet, on_delete=models.CASCADE, related_name='corrections')
    question = models.ForeignKey(Question, on_delete=models.CASCADE, related_name='corrections')
    explanation = models.TextField()
    created_by = models.ForeignKey(User, on_delete=models.SET_NULL, null=True)
    created_at = models.DateTimeField(auto_now_add=True)

    class Meta:
        unique_together = [('exam_set', 'question')]

    def __str__(self):
        return f"Correction for {self.exam_set.title} Q{self.question.order}"

    @property
    def uid(self):
        return f"corr-{str(self.id)[:7]}"


class ExamAttempt(models.Model):
    id = models.UUIDField(primary_key=True, default=uuid.uuid4, editable=False)
    user = models.ForeignKey(User, on_delete=models.CASCADE, related_name='exam_attempts')
    exam_set = models.ForeignKey(ExamSet, on_delete=models.CASCADE, related_name='attempts')
    start_time = models.DateTimeField(default=timezone.now)
    end_time = models.DateTimeField(null=True, blank=True)
    status = models.CharField(max_length=20, choices=ATTEMPT_STATUS_CHOICES, default=ATTEMPT_STATUS_IN_PROGRESS)
    is_first_attempt = models.BooleanField(default=True)
    final_score = models.FloatField(null=True, blank=True)
    assessment_hash = models.CharField(max_length=64, blank=True)
    graded_at = models.DateTimeField(null=True, blank=True)
    results_released = models.BooleanField(default=False)
    released_at = models.DateTimeField(null=True, blank=True)
    released_by = models.ForeignKey(
        User, 
        on_delete=models.SET_NULL, 
        null=True, 
        blank=True,
        related_name='released_attempts'
    )
    
    # Results release notes
    release_notes = models.TextField(blank=True, help_text="Optional notes to student when releasing results")
    
    # ===== NEW: Blockchain tracking =====
    token_amount = models.PositiveIntegerField(default=0)
    blockchain_tx_id = models.CharField(max_length=100, blank=True)
    payment_status = models.CharField(max_length=20, choices=[
        ('pending', 'Pending'),
        ('confirmed', 'Confirmed'),
        ('failed', 'Failed'),
    ], default='pending')
    
    # ===== NEW: Record reference =====
    record = models.ForeignKey('ExamRecord', on_delete=models.SET_NULL, null=True, blank=True, related_name='attempt_records')

    def __str__(self):
        return f"{self.user.username} - {self.exam_set.title} ({self.get_status_display()})"

    @property
    def uid(self):
        return f"att-{str(self.id)[:7]}"

    @property
    def time_remaining(self):
        if self.status != ATTEMPT_STATUS_IN_PROGRESS:
            return 0
        elapsed = (timezone.now() - self.start_time).total_seconds()
        total = self.exam_set.duration_minutes * 60
        remaining = total - elapsed
        return max(0, int(remaining))

    @property
    def submission_hash(self):
        """Alias for assessment_hash to match admin expectation"""
        return self.assessment_hash

    @property
    def browser_leaves(self):
        """Retrieve browser leaves count from Redis"""
        state = redis_service.get_attempt_state(str(self.id))
        return int(state.get('browser_leaves', 0)) if state else 0

    def mark_as_submitted(self, auto_submitted=False):
        self.end_time = timezone.now()
        self.status = ATTEMPT_STATUS_AUTO_SUBMITTED if auto_submitted else ATTEMPT_STATUS_SUBMITTED
        if self.exam_set.questions.filter(question_type=QUESTION_TYPE_TEXT).exists():
            self.status = ATTEMPT_STATUS_GRADING_PENDING
        self.save()

    def generate_assessment_hash(self):
        data = f"{self.id}{self.end_time.timestamp()}"
        for answer in self.answers.order_by('question__order'):
            if answer.question.question_type == QUESTION_TYPE_MCQ:
                data += f"{answer.question.id}{answer.mcq_answer}"
            else:
                data += f"{answer.question.id}{answer.text_answer}"
        return hashlib.sha256(data.encode()).hexdigest()


class ExamMarkerInvitation(models.Model):
    PENDING = 'pending'; ACCEPTED = 'accepted'; DECLINED = 'declined'; REVOKED = 'revoked'
    STATUS_CHOICES = [(PENDING, 'Pending'), (ACCEPTED, 'Accepted'), (DECLINED, 'Declined'), (REVOKED, 'Revoked')]
    exam_set = models.ForeignKey(ExamSet, on_delete=models.CASCADE, related_name='marker_invitations')
    setter = models.ForeignKey(User, on_delete=models.CASCADE, related_name='sent_marker_invitations')
    teacher = models.ForeignKey(User, on_delete=models.CASCADE, related_name='received_marker_invitations')
    status = models.CharField(max_length=20, choices=STATUS_CHOICES, default=PENDING)
    created_at = models.DateTimeField(auto_now_add=True)
    responded_at = models.DateTimeField(null=True, blank=True)
    class Meta:
        constraints = [models.UniqueConstraint(fields=['exam_set', 'teacher'], name='unique_exam_marker_invite')]


class ExamMarkingClaim(models.Model):
    CLAIMED = 'claimed'; RELEASED = 'released'; REASSIGNED = 'reassigned'
    STATUS_CHOICES = [(CLAIMED, 'Claimed'), (RELEASED, 'Released'), (REASSIGNED, 'Reassigned')]
    attempt = models.OneToOneField(ExamAttempt, on_delete=models.CASCADE, related_name='marking_claim')
    teacher = models.ForeignKey(User, on_delete=models.CASCADE, related_name='exam_marking_claims')
    status = models.CharField(max_length=20, choices=STATUS_CHOICES, default=CLAIMED)
    claimed_at = models.DateTimeField(auto_now_add=True)
    released_at = models.DateTimeField(null=True, blank=True)
    class Meta:
        indexes = [models.Index(fields=['teacher', 'status']), models.Index(fields=['status'])]


class TextAssessmentSession(models.Model):
    id = models.UUIDField(primary_key=True, default=uuid.uuid4, editable=False)
    setter = models.ForeignKey(
        settings.AUTH_USER_MODEL,
        on_delete=models.CASCADE,
        related_name='grading_sessions'
    )
    attempt = models.ForeignKey(
        ExamAttempt,
        on_delete=models.CASCADE,
        related_name='assessment_sessions'
    )
    created_at = models.DateTimeField(auto_now_add=True)
    completed_at = models.DateTimeField(null=True, blank=True)
    immutable_hash = models.CharField(max_length=64, blank=True)

    def __str__(self):
        return f"Grading session for {self.attempt} by {self.setter.username}"

    @property
    def uid(self):
        return f"ses-{str(self.id)[:7]}"

    @property
    def is_completed(self):
        return self.completed_at is not None

    def mark_as_completed(self):
        self.completed_at = timezone.now()
        self.save()
        self.immutable_hash = hashlib.sha256(f"{self.id}{self.completed_at.timestamp()}".encode()).hexdigest()
        self.save(update_fields=['immutable_hash'])


class TextQuestionAssessment(models.Model):
    id = models.UUIDField(primary_key=True, default=uuid.uuid4, editable=False)
    session = models.ForeignKey(
        TextAssessmentSession,
        on_delete=models.CASCADE,
        related_name='assessments'
    )
    question = models.ForeignKey(
        Question,
        on_delete=models.CASCADE
    )
    score = models.PositiveIntegerField(default=0, help_text="Points awarded for this question")
    feedback = models.TextField(blank=True, null=True)
    created_at = models.DateTimeField(auto_now_add=True, null=True)
    assessed_at = models.DateTimeField(auto_now_add=True)

    class Meta:
        unique_together = [('session', 'question')]

    def __str__(self):
        return f"Assessment of {self.question} - Score: {self.score}"

    @property
    def uid(self):
        return f"asmt-{str(self.id)[:7]}"


class ExamRecord(models.Model):
    """
    IMMUTABLE record of a student's first attempt.
    This is like a certificate - once created, it's permanent.
    """
    id = models.UUIDField(primary_key=True, default=uuid.uuid4, editable=False)
    user = models.ForeignKey(User, on_delete=models.CASCADE, related_name='exam_records')
    exam_set = models.ForeignKey(ExamSet, on_delete=models.CASCADE, related_name='records')
    
    # Core data (immutable once created)
    title = models.CharField(max_length=200)  # Snapshot of exam title
    description = models.TextField(blank=True)  # Snapshot of description
    total_questions = models.PositiveIntegerField(default=0)
    total_points = models.PositiveIntegerField(default=0)
    earned_points = models.PositiveIntegerField(default=0)
    score_percentage = models.FloatField(default=0)
    
    # Metadata
    taken_at = models.DateTimeField(auto_now_add=True)
    duration_minutes = models.PositiveIntegerField(default=0)  # How long they took
    
    # For integrity
    record_hash = models.CharField(max_length=64, unique=True, blank=True)
    
    # ===== NEW: NFT tracking =====
    nft_token_id = models.CharField(max_length=100, blank=True)
    nft_transaction_hash = models.CharField(max_length=100, blank=True)
    nft_minted = models.BooleanField(default=False)
    nft_minted_at = models.DateTimeField(null=True, blank=True)
    
    class Meta:
        # One record per user per exam set (first attempt only)
        unique_together = [('user', 'exam_set')]
        ordering = ['-taken_at']
    
    def __str__(self):
        return f"Record: {self.user.username} - {self.title} ({self.taken_at.date()})"
    
    def save(self, *args, **kwargs):
        # Set taken_at if not set
        if not self.taken_at:
            self.taken_at = timezone.now()
            
        # Generate hash if not set
        if not self.record_hash:
            data = f"{self.user.id}{self.exam_set.id}{self.taken_at.timestamp()}{self.score_percentage}"
            self.record_hash = hashlib.sha256(data.encode()).hexdigest()[:16]
        super().save(*args, **kwargs)


class ExamRecordAnswer(models.Model):
    """
    Individual answers for the exam record (immutable)
    """
    id = models.UUIDField(primary_key=True, default=uuid.uuid4, editable=False)
    record = models.ForeignKey(ExamRecord, on_delete=models.CASCADE, related_name='answers')
    
    # Snapshot of question data (immutable)
    question_text = models.TextField()
    question_type = models.CharField(max_length=10, choices=QUESTION_TYPE_CHOICES, default=QUESTION_TYPE_MCQ)
    points = models.PositiveIntegerField(default=0)
    
    # Student's answer
    student_answer = models.TextField(blank=True)
    is_correct = models.BooleanField(default=False)
    earned_points = models.PositiveIntegerField(default=0)
    
    # Feedback (immutable once record is created)
    teacher_feedback = models.TextField(blank=True)
    feedback_from = models.ForeignKey(User, null=True, on_delete=models.SET_NULL, blank=True)
    
    # Order
    order = models.PositiveIntegerField(default=0)
    
    class Meta:
        ordering = ['order']
    
    def __str__(self):
        return f"Answer {self.order} for {self.record}"
