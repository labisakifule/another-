# exams/signals.py

from django.db.models.signals import post_save
from django.dispatch import receiver
from .models import ExamSet, Question, ExamAttempt, ExamRecord
from .constants import QUESTION_TYPE_TEXT
from .services.redis_service import redis_service
from django.utils import timezone


# ===== ORIGINAL SIGNALS =====

@receiver(post_save, sender=ExamAttempt)
def schedule_auto_submit(sender, instance, created, **kwargs):
    if created and instance.status == 'IN_PROGRESS' and instance.is_first_attempt:
        redis_service.schedule_auto_submit(
            str(instance.id),
            instance.exam_set.duration_minutes
        )
        with open("exam_monitor.log", "a") as f:
            f.write(f"[{timezone.now()}] SCHEDULED: Attempt {instance.id} for {instance.exam_set.title}\n")


@receiver(post_save, sender=Question)
def update_exam_set_reward_eligibility(sender, instance, **kwargs):
    exam_set = instance.exam_set
    if exam_set and instance.question_type == QUESTION_TYPE_TEXT:
        if exam_set.reward_eligible:
            exam_set.reward_eligible = False
            exam_set.save(update_fields=['reward_eligible'])


@receiver(post_save, sender=ExamSet)
def initial_exam_set_check(sender, instance, created, **kwargs):
    if created:
        if instance.questions.filter(question_type=QUESTION_TYPE_TEXT).exists():
            if instance.reward_eligible:
                instance.reward_eligible = False
                instance.save(update_fields=['reward_eligible'])


@receiver(post_save, sender=ExamSet)
def generate_exam_set_hash(sender, instance, created, **kwargs):
    if created and not instance.immutable_hash:
        instance.immutable_hash = instance.generate_hash()
        instance.save(update_fields=['immutable_hash'])


# ===== NEW: NFT Certificate Minting (Silent) =====

@receiver(post_save, sender=ExamRecord)
def silent_certificate_mint(sender, instance, created, **kwargs):
    """
    Silently mint NFT certificate when record is created.
    This is a silent background process - user doesn't see anything.
    Only for premium exams with passing score.
    """
    if not created:
        return
    
    exam_set = instance.exam_set
    user = instance.user
    
    # Only for premium exams with passing score
    if (hasattr(exam_set, 'access_type') and 
        exam_set.access_type == 'premium' and 
        instance.score_percentage >= 50 and
        not instance.nft_minted):
        
        # Silent API call to Nugram (if available)
        try:
            # Try to import and use Nugram client
            from nugram_client import NugramClient
            result = NugramClient.mint_certificate(
                user_id=user.id,
                metadata={
                    'exam_title': exam_set.title,
                    'score': str(instance.score_percentage),
                    'record_hash': instance.record_hash,
                    'exam_id': str(exam_set.id)
                }
            )
            
            if result.get('success'):
                instance.nft_token_id = result.get('token_id', '')
                instance.nft_transaction_hash = result.get('transaction_hash', '')
                instance.nft_minted = True
                instance.nft_minted_at = timezone.now()
                instance.save()
                
                # Silent log (no user notification)
                print(f"✅ NFT Minted for {user.username}: {result.get('token_id', 'unknown')}")
                
        except ImportError:
            # Nugram client not available - skip silently
            pass
        except Exception as e:
            # Silent failure - log only, don't disturb user
            print(f"❌ NFT Mint failed for {user.username}: {e}")