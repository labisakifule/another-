# exams/services/redis_service.py

import redis
import time
import logging
import sys
from django.conf import settings

# Fix Windows console encoding
if sys.platform == 'win32':
    import io
    sys.stdout = io.TextIOWrapper(sys.stdout.buffer, encoding='utf-8', errors='ignore')
    sys.stderr = io.TextIOWrapper(sys.stderr.buffer, encoding='utf-8', errors='ignore')

logger = logging.getLogger(__name__)

class RedisService:
    def __init__(self):
        if not hasattr(settings, 'REDIS_GRADING_QUEUE_KEY'):
            settings.REDIS_GRADING_QUEUE_KEY = 'grading_queue'
        if not hasattr(settings, 'REDIS_AUTO_SUBMIT_KEY'):
            settings.REDIS_AUTO_SUBMIT_KEY = 'auto_submit'
        
        # Default Redis settings if not in Django settings
        self.REDIS_EXAM_ATTEMPTS_PREFIX = getattr(settings, 'REDIS_EXAM_ATTEMPTS_PREFIX', 'exam_attempt:')
        
        try:
            redis_url = getattr(settings, 'REDIS_URL', 'redis://localhost:6379')
            
            # Parse Redis URL
            if redis_url.startswith('redis://'):
                import urllib.parse
                parsed = urllib.parse.urlparse(redis_url)
                host = parsed.hostname or 'localhost'
                port = parsed.port or 6379
                password = parsed.password
                db = 0
            else:
                host = getattr(settings, 'REDIS_HOST', 'localhost')
                port = getattr(settings, 'REDIS_PORT', 6379)
                password = getattr(settings, 'REDIS_PASSWORD', None)
                db = getattr(settings, 'REDIS_DB', 0)
            
            # Create Redis connection
            self.redis = redis.Redis(
                host=host,
                port=port,
                password=password,
                db=db,
                decode_responses=True,
                socket_connect_timeout=5,
                socket_timeout=5,
                retry_on_timeout=True
            )
            
            # Test connection
            self.redis.ping()
            print(f"Redis connected successfully to {host}:{port}")
            logger.info(f"Redis connected successfully to {host}:{port}")
            
        except Exception as e:
            print(f"Redis connection failed: {str(e)}")
            logger.error(f"Redis connection failed: {str(e)}")
            
            if settings.DEBUG:
                print("Running in DEBUG mode - Redis features will be simulated")
                self.redis = None
            else:
                # In production, we might want to raise the exception
                # but for now, let's continue with simulation
                print("WARNING: Redis is required for production use")
                self.redis = None

    def cache_attempt_state(self, attempt_id, data, ttl=None):
        """Cache exam attempt state in Redis"""
        if not self.redis:
            print(f"Redis not available - attempt state not cached for {attempt_id}")
            return False
        
        try:
            key = f"{self.REDIS_EXAM_ATTEMPTS_PREFIX}{attempt_id}"
            # Convert all values to strings
            str_data = {k: str(v) for k, v in data.items()}
            
            # Use pipeline for better performance
            pipe = self.redis.pipeline()
            pipe.hset(key, mapping=str_data)
            
            # Set TTL (Time To Live)
            if ttl:
                pipe.expire(key, ttl)
            else:
                pipe.expire(key, 86400)  # Default 24 hours
            
            pipe.execute()
            print(f"Cached attempt state for {attempt_id}")
            return True
            
        except Exception as e:
            logger.error(f"Error caching attempt state: {str(e)}")
            return False

    def get_attempt_state(self, attempt_id):
        """Get exam attempt state from Redis"""
        if not self.redis:
            print(f"Redis not available - cannot get state for {attempt_id}")
            return {}
        
        try:
            key = f"{self.REDIS_EXAM_ATTEMPTS_PREFIX}{attempt_id}"
            data = self.redis.hgetall(key)
            
            if data:
                print(f"Retrieved attempt state for {attempt_id}")
            else:
                print(f"No attempt state found for {attempt_id}")
            
            return data
            
        except Exception as e:
            logger.error(f"Error getting attempt state: {str(e)}")
            return {}

    def update_attempt_state(self, attempt_id, updates):
        """Update specific fields in attempt state"""
        if not self.redis:
            print(f"Redis not available - cannot update state for {attempt_id}")
            return False
        
        try:
            key = f"{self.REDIS_EXAM_ATTEMPTS_PREFIX}{attempt_id}"
            str_updates = {k: str(v) for k, v in updates.items()}
            self.redis.hset(key, mapping=str_updates)
            print(f"Updated attempt state for {attempt_id}")
            return True
            
        except Exception as e:
            logger.error(f"Error updating attempt state: {str(e)}")
            return False

    def delete_attempt_state(self, attempt_id):
        """Delete exam attempt state from Redis"""
        if not self.redis:
            return False
        
        try:
            key = f"{self.REDIS_EXAM_ATTEMPTS_PREFIX}{attempt_id}"
            result = self.redis.delete(key)
            if result:
                print(f"Deleted attempt state for {attempt_id}")
            return bool(result)
            
        except Exception as e:
            logger.error(f"Error deleting attempt state: {str(e)}")
            return False

    def add_to_grading_queue(self, attempt_id):
        """Add attempt to grading queue"""
        if not self.redis:
            return False
        
        try:
            self.redis.lpush(settings.REDIS_GRADING_QUEUE_KEY, str(attempt_id))
            print(f"Added {attempt_id} to grading queue")
            return True
            
        except Exception as e:
            logger.error(f"Error adding to grading queue: {str(e)}")
            return False

    def get_next_grading_task(self):
        """Get next attempt from grading queue"""
        if not self.redis:
            return None
        
        try:
            return self.redis.rpop(settings.REDIS_GRADING_QUEUE_KEY)
            
        except Exception as e:
            logger.error(f"Error getting next grading task: {str(e)}")
            return None

    def schedule_auto_submit(self, attempt_id, exam_duration_minutes):
        """Schedule auto-submission for an exam attempt"""
        if not self.redis:
            print(f"Redis not available - auto-submit not scheduled for {attempt_id}")
            return False
        
        try:
            delay_seconds = exam_duration_minutes * 60
            scheduled_time = time.time() + delay_seconds
            
            self.redis.zadd(
                settings.REDIS_AUTO_SUBMIT_KEY,
                {str(attempt_id): scheduled_time}
            )
            print(f"Scheduled auto-submit for {attempt_id} in {exam_duration_minutes} minutes")
            return True
            
        except Exception as e:
            logger.error(f"Error scheduling auto-submit: {str(e)}")
            return False

    def get_due_auto_submits(self):
        """Get all due auto-submissions"""
        if not self.redis:
            return []
        
        try:
            now = time.time()
            due = self.redis.zrangebyscore(
                settings.REDIS_AUTO_SUBMIT_KEY,
                0,
                now
            )
            
            if due:
                print(f"Found {len(due)} due auto-submits")
            
            return due
            
        except Exception as e:
            logger.error(f"Error getting due auto submits: {str(e)}")
            return []

    def clear_auto_submit(self, attempt_id):
        """Remove attempt from auto-submit schedule"""
        if not self.redis:
            return False
        
        try:
            result = self.redis.zrem(settings.REDIS_AUTO_SUBMIT_KEY, str(attempt_id))
            if result:
                print(f"Cleared auto-submit for {attempt_id}")
            return bool(result)
            
        except Exception as e:
            logger.error(f"Error clearing auto submit: {str(e)}")
            return False

    def get_first_attempts(self):
        """Get all first attempt states"""
        if not self.redis:
            return []
        
        try:
            pattern = f"{self.REDIS_EXAM_ATTEMPTS_PREFIX}*"
            keys = self.redis.keys(pattern)
            
            attempts = []
            for key in keys:
                data = self.redis.hgetall(key)
                if data.get('is_first_attempt') == 'True':
                    attempts.append({
                        'attempt_id': key.replace(self.REDIS_EXAM_ATTEMPTS_PREFIX, ''),
                        'data': data
                    })
            
            return attempts
            
        except Exception as e:
            logger.error(f"Error getting first attempts: {str(e)}")
            return []

    def increment_browser_leaves(self, attempt_id):
        """Increment browser leave counter"""
        if not self.redis:
            return 0
        
        try:
            key = f"{self.REDIS_EXAM_ATTEMPTS_PREFIX}{attempt_id}"
            leaves = self.redis.hincrby(key, 'browser_leaves', 1)
            print(f"Browser leaves for {attempt_id}: {leaves}")
            return leaves
            
        except Exception as e:
            logger.error(f"Error incrementing browser leaves: {str(e)}")
            return 0

    def get_browser_leaves(self, attempt_id):
        """Get current browser leave count"""
        if not self.redis:
            return 0
        
        try:
            key = f"{self.REDIS_EXAM_ATTEMPTS_PREFIX}{attempt_id}"
            leaves = self.redis.hget(key, 'browser_leaves')
            return int(leaves) if leaves else 0
            
        except Exception as e:
            logger.error(f"Error getting browser leaves: {str(e)}")
            return 0

    def health_check(self):
        """Check Redis connection health"""
        if not self.redis:
            return {'status': 'simulated', 'message': 'Running in simulation mode'}
        
        try:
            self.redis.ping()
            info = self.redis.info('server')
            return {
                'status': 'connected',
                'version': info.get('redis_version', 'unknown'),
                'mode': info.get('redis_mode', 'unknown')
            }
        except Exception as e:
            return {
                'status': 'error',
                'message': str(e)
            }

# Create global instance
redis_service = RedisService()