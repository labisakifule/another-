from django.urls import path
from . import views

app_name = 'exams'

urlpatterns = [
    # ==================== EXAM SET URLs ====================
    path('sets/', views.ExamSetListView.as_view(), name='exam_set_list'),
    path('sets/create/', views.exam_set_create, name='exam_set_create'),
    path('sets/<uuid:pk>/', views.ExamSetDetailView.as_view(), name='exam_set_detail'),
    path('sets/<uuid:pk>/marking/', views.marking_queue, name='marking_queue'),
    path('sets/<uuid:pk>/markers/invite/', views.marker_invite, name='marker_invite'),
    path('marking/invitations/<int:pk>/respond/', views.marker_invitation_respond, name='marker_invitation_respond'),
    path('marking/<uuid:attempt_id>/claim/', views.marking_claim, name='marking_claim'),
    path('marking/<uuid:attempt_id>/review/', views.marking_review, name='marking_review'),
    path('sets/<uuid:pk>/update/', views.ExamSetUpdateView.as_view(), name='exam_set_update'),
    path('sets/<uuid:pk>/delete/', views.ExamSetDeleteView.as_view(), name='exam_set_delete'),
    
    # ==================== SECTION URLs ====================
    path('sets/<uuid:set_id>/sections/', views.manage_sections, name='manage_sections'),
    path('sets/<uuid:set_id>/sections/add/', views.add_section, name='add_section'),
    path('sections/<uuid:section_id>/edit/', views.edit_section, name='edit_section'),
    path('sections/<uuid:section_id>/delete/', views.delete_section, name='delete_section'),
    path('sections/<uuid:section_id>/questions/add/', views.add_question_to_section, name='add_question_to_section'),
    
    # ==================== QUESTION URLs ====================
    path('questions/<uuid:question_id>/edit/', views.edit_question, name='edit_question'),
    path('questions/<uuid:question_id>/delete/', views.delete_question, name='delete_question'),
    path('sets/<uuid:set_id>/questions/add/', views.QuestionCreateView.as_view(), name='add_question'),
    path('questions/<uuid:pk>/update/', views.QuestionUpdateView.as_view(), name='update_question'),
    path('sets/<uuid:set_id>/add/mcq/', views.add_mcq_question, name='add_mcq_question'),
    path('sets/<uuid:set_id>/add/text/', views.add_text_question, name='add_text_question'),
    
    # ==================== EXAM ATTEMPT URLs ====================
    path('attempt/<uuid:pk>/start/', views.ExamAttemptStartView.as_view(), name='exam_attempt_start'),
    path('attempt/<uuid:pk>/', views.ExamInterfaceView.as_view(), name='exam_interface'),
    path('attempt/<uuid:pk>/submit/', views.ExamSubmitView.as_view(), name='exam_submit'),
    
    # ==================== STUDENT URLs ====================
    path('my-records/', views.StudentDashboardView.as_view(), name='student_dashboard'),
    path('record/<uuid:pk>/', views.StudentRecordView.as_view(), name='student_record'),
    path('pending/<uuid:pk>/', views.StudentPendingView.as_view(), name='student_pending_view'),
    
    # ==================== SETTER URLs ====================
    path('setter/dashboard/', views.SetterDashboardView.as_view(), name='setter_dashboard'),
    path('setter/attempt/<uuid:pk>/', views.SetterAttemptDetailView.as_view(), name='setter_attempt_detail'),
    path('setter/release/<uuid:pk>/', views.SetterReleaseResultsView.as_view(), name='setter_release_results'),
    
    # ==================== GRADING URLs ====================
    path('grading/', views.GradingDashboardView.as_view(), name='grading_dashboard'),
    path('grading/attempt/<uuid:pk>/', views.GradingInterfaceView.as_view(), name='grading_interface'),
    path('grading/attempt/<uuid:pk>/submit/', views.GradingSubmitView.as_view(), name='grading_submit'),
    
    # ==================== RESULT URLs ====================
    path('results/', views.ExamResultListView.as_view(), name='exam_result_list'),
    path('results/<uuid:pk>/', views.ExamResultView.as_view(), name='exam_result'),
    
    # ==================== DEBUG URLs ====================
    path('debug/questions/<uuid:set_id>/', views.debug_questions, name='debug_questions'),
]
