# exams/forms.py

import json
from django import forms
from .models import ExamSet, Question, Answer, Grading, Correction, ExamSection
from trends.models import Subject, Topic
from .constants import QUESTION_TYPE_MCQ, QUESTION_TYPE_TEXT, EXAM_SET_TYPE_PREMIUM
from trends.models import EducationLevel

class ExamSetForm(forms.ModelForm):
    class Meta:
        model = ExamSet
        fields = ['title', 'description', 'education_level', 'subject', 'topic', 
                  'set_type', 'credits_required', 'duration_minutes', 'is_active', 'reward_eligible']
        widgets = {
            'title': forms.TextInput(attrs={'class': 'w-full px-4 py-3 border rounded-xl'}),
            'description': forms.Textarea(attrs={'rows': 4, 'class': 'w-full px-4 py-3 border rounded-xl'}),
            'education_level': forms.Select(attrs={'class': 'w-full px-4 py-3 border rounded-xl'}),
            'subject': forms.Select(attrs={'class': 'w-full px-4 py-3 border rounded-xl'}),
            'topic': forms.Select(attrs={'class': 'w-full px-4 py-3 border rounded-xl'}),
            'set_type': forms.Select(attrs={'class': 'w-full px-4 py-3 border rounded-xl'}),
            'credits_required': forms.NumberInput(attrs={'class': 'w-full px-4 py-3 border rounded-xl', 'min': 0}),
            'duration_minutes': forms.NumberInput(attrs={'class': 'w-full px-4 py-3 border rounded-xl', 'min': 1}),
            'is_active': forms.CheckboxInput(attrs={'class': 'rounded'}),
            'reward_eligible': forms.CheckboxInput(attrs={'class': 'rounded'}),
        }
    
    def __init__(self, *args, **kwargs):
        super().__init__(*args, **kwargs)
        self.fields['topic'].required = False
        self.fields['credits_required'].required = False
        self.fields['education_level'].queryset = EducationLevel.objects.filter(is_approved=True).order_by('order')
        
        # Filter subjects based on selected education level
        if 'education_level' in self.data:
            try:
                level_id = int(self.data.get('education_level'))
                self.fields['subject'].queryset = Subject.objects.filter(education_level_id=level_id, is_approved=True).order_by('name')
            except (ValueError, TypeError):
                pass
        elif self.instance.pk and self.instance.education_level:
            self.fields['subject'].queryset = Subject.objects.filter(education_level=self.instance.education_level, is_approved=True).order_by('name')

class MCQQuestionForm(forms.ModelForm):
    choices = forms.CharField(
        widget=forms.HiddenInput(),
        required=False
    )
    correct_choice = forms.CharField(
        max_length=1,
        required=False,
        widget=forms.HiddenInput()  # Hidden from students
    )

    class Meta:
        model = Question
        fields = ['text', 'points', 'order', 'section_order', 'part', 'difficulty',
                  # ===== NEW: Media fields =====
                  'media_type', 'media_file', 'media_url', 'media_embed_code', 'media_caption']
        widgets = {
            'text': forms.Textarea(attrs={'rows': 4, 'class': 'w-full px-4 py-3 border rounded-xl'}),
            'points': forms.NumberInput(attrs={'class': 'w-full px-4 py-3 border rounded-xl', 'min': 1}),
            'order': forms.NumberInput(attrs={'class': 'w-full px-4 py-3 border rounded-xl', 'min': 1}),
            'section_order': forms.NumberInput(attrs={'class': 'w-full px-4 py-3 border rounded-xl', 'min': 1}),
            'part': forms.TextInput(attrs={'class': 'w-full px-4 py-3 border rounded-xl', 'maxlength': 5}),
            'difficulty': forms.Select(attrs={'class': 'w-full px-4 py-3 border rounded-xl'}),
            # ===== NEW: Media widgets =====
            'media_type': forms.Select(attrs={'class': 'w-full px-4 py-3 border rounded-xl'}),
            'media_file': forms.FileInput(attrs={'class': 'w-full px-4 py-3 border rounded-xl'}),
            'media_url': forms.URLInput(attrs={'class': 'w-full px-4 py-3 border rounded-xl', 'placeholder': 'https://www.youtube.com/watch?v=...'}),
            'media_embed_code': forms.Textarea(attrs={'rows': 3, 'class': 'w-full px-4 py-3 border rounded-xl font-mono', 'placeholder': '<iframe src="..." ...></iframe>'}),
            'media_caption': forms.TextInput(attrs={'class': 'w-full px-4 py-3 border rounded-xl', 'placeholder': 'Caption for media...'}),
        }

    def __init__(self, *args, **kwargs):
        super().__init__(*args, **kwargs)
        if self.instance and self.instance.pk:
            if self.instance.choices:
                self.initial['choices'] = json.dumps(self.instance.choices)
            if self.instance.correct_choice:
                self.initial['correct_choice'] = self.instance.correct_choice
        self.fields['section_order'].required = False
        self.fields['section_order'].initial = 1
        self.fields['part'].required = False

    def clean_choices(self):
        data = self.cleaned_data['choices']
        if not data:
            return []
        try:
            choices = json.loads(data)
            if not isinstance(choices, list):
                raise forms.ValidationError("Choices must be a list")
            if len(choices) < 2:
                raise forms.ValidationError("At least two choices are required")
            for choice in choices:
                if 'letter' not in choice or 'text' not in choice:
                    raise forms.ValidationError("Each choice must have 'letter' and 'text' properties")
                if not choice['text'].strip():
                    raise forms.ValidationError("Choice text cannot be empty")
            return choices
        except json.JSONDecodeError:
            raise forms.ValidationError("Invalid choices format")

    def clean_correct_choice(self):
        data = self.cleaned_data.get('correct_choice', '')
        choices = self.cleaned_data.get('choices', [])
        if choices and not data:
            raise forms.ValidationError("Please select the correct answer")
        if choices and data:
            choice_letters = [c['letter'] for c in choices]
            if data not in choice_letters:
                raise forms.ValidationError("Correct choice must be one of the provided options")
        return data

    def save(self, commit=True):
        instance = super().save(commit=False)
        instance.question_type = QUESTION_TYPE_MCQ
        instance.choices = self.cleaned_data.get('choices', [])
        instance.correct_choice = self.cleaned_data.get('correct_choice', '')
        if commit:
            instance.save()
        return instance


class TextQuestionForm(forms.ModelForm):
    class Meta:
        model = Question
        fields = [
            'text', 'points', 'order', 'section_order', 'part', 'difficulty',
            'expected_answers', 'answers_required', 'points_per_answer', 'max_length',
            'min_words', 'max_words', 'rubric',
            # ===== NEW: Media fields =====
            'media_type', 'media_file', 'media_url', 'media_embed_code', 'media_caption'
        ]
        widgets = {
            'text': forms.Textarea(attrs={
                'rows': 4,
                'class': 'w-full px-4 py-3 border rounded-xl focus:ring-2 focus:ring-blue-500',
                'placeholder': 'Enter your question here...'
            }),
            'points': forms.NumberInput(attrs={
                'class': 'w-full px-4 py-3 border rounded-xl',
                'min': 1
            }),
            'order': forms.NumberInput(attrs={
                'class': 'w-full px-4 py-3 border rounded-xl',
                'min': 1
            }),
            'section_order': forms.NumberInput(attrs={
                'class': 'w-full px-4 py-3 border rounded-xl',
                'min': 1
            }),
            'part': forms.TextInput(attrs={
                'class': 'w-full px-4 py-3 border rounded-xl',
                'maxlength': 5,
                'placeholder': 'e.g., a, b, c'
            }),
            'difficulty': forms.Select(attrs={
                'class': 'w-full px-4 py-3 border rounded-xl'
            }),
            'expected_answers': forms.Textarea(attrs={
                'rows': 8,
                'class': 'w-full px-4 py-3 border-2 border-amber-300 rounded-xl font-mono text-sm',
                'placeholder': 'Enter each possible correct answer on a new line...'
            }),
            'answers_required': forms.NumberInput(attrs={
                'class': 'w-full px-4 py-3 border rounded-xl',
                'min': 1
            }),
            'points_per_answer': forms.NumberInput(attrs={
                'class': 'w-full px-4 py-3 border rounded-xl',
                'min': 1
            }),
            'max_length': forms.NumberInput(attrs={
                'class': 'w-full px-4 py-3 border rounded-xl',
                'min': 1,
                'value': 1000
            }),
            # ===== NEW: Essay widgets =====
            'min_words': forms.NumberInput(attrs={
                'class': 'w-full px-4 py-3 border rounded-xl',
                'min': 0,
                'placeholder': 'Minimum words required'
            }),
            'max_words': forms.NumberInput(attrs={
                'class': 'w-full px-4 py-3 border rounded-xl',
                'min': 1,
                'value': 500,
                'placeholder': 'Maximum words allowed'
            }),
            'rubric': forms.Textarea(attrs={
                'rows': 4,
                'class': 'w-full px-4 py-3 border rounded-xl font-mono',
                'placeholder': '{"criteria": {"Content": {"points": 10, "description": "..."}}'
            }),
            # ===== NEW: Media widgets =====
            'media_type': forms.Select(attrs={'class': 'w-full px-4 py-3 border rounded-xl'}),
            'media_file': forms.FileInput(attrs={'class': 'w-full px-4 py-3 border rounded-xl'}),
            'media_url': forms.URLInput(attrs={'class': 'w-full px-4 py-3 border rounded-xl', 'placeholder': 'https://www.youtube.com/watch?v=...'}),
            'media_embed_code': forms.Textarea(attrs={'rows': 3, 'class': 'w-full px-4 py-3 border rounded-xl font-mono', 'placeholder': '<iframe src="..." ...></iframe>'}),
            'media_caption': forms.TextInput(attrs={'class': 'w-full px-4 py-3 border rounded-xl', 'placeholder': 'Caption for media...'}),
        }

    def __init__(self, *args, **kwargs):
        super().__init__(*args, **kwargs)
        self.fields['section_order'].required = False
        self.fields['section_order'].initial = 1
        self.fields['part'].required = False
        self.fields['answers_required'].initial = 3
        self.fields['points_per_answer'].initial = 10
        self.fields['max_length'].initial = 1000
        self.fields['min_words'].initial = 0
        self.fields['max_words'].initial = 500
        
        if self.instance and self.instance.pk:
            if self.instance.expected_answers and isinstance(self.instance.expected_answers, list):
                self.initial['expected_answers'] = '\n'.join(self.instance.expected_answers)
            self.initial['answers_required'] = self.instance.answers_required
            self.initial['points_per_answer'] = self.instance.points_per_answer
            self.initial['min_words'] = self.instance.min_words
            self.initial['max_words'] = self.instance.max_words
            if self.instance.rubric:
                self.initial['rubric'] = json.dumps(self.instance.rubric, indent=2)

    def clean_expected_answers(self):
        data = self.cleaned_data.get('expected_answers', '')
        if isinstance(data, str):
            answers = [line.strip() for line in data.split('\n') if line.strip()]
            if not answers:
                raise forms.ValidationError("Please enter at least one expected answer")
            # Remove duplicates while preserving order
            seen = set()
            unique_answers = []
            for answer in answers:
                if answer.lower() not in seen:
                    seen.add(answer.lower())
                    unique_answers.append(answer)
            return unique_answers
        return data

    def clean_rubric(self):
        data = self.cleaned_data.get('rubric', '')
        if isinstance(data, str) and data.strip():
            try:
                return json.loads(data)
            except json.JSONDecodeError:
                raise forms.ValidationError("Invalid JSON format for rubric")
        return {}

    def clean(self):
        cleaned_data = super().clean()
        answers_required = cleaned_data.get('answers_required', 1)
        points_per_answer = cleaned_data.get('points_per_answer', 1)
        expected_answers = cleaned_data.get('expected_answers', [])
        min_words = cleaned_data.get('min_words', 0)
        max_words = cleaned_data.get('max_words', 500)
        
        # Auto-calculate total points
        cleaned_data['points'] = answers_required * points_per_answer
        
        if expected_answers and answers_required > len(expected_answers):
            self.add_error('answers_required', 
                f"You require {answers_required} answers, but only provided {len(expected_answers)} expected answers")
        
        if min_words > max_words:
            self.add_error('min_words', "Minimum words cannot exceed maximum words")
        
        return cleaned_data

    def save(self, commit=True):
        instance = super().save(commit=False)
        instance.question_type = QUESTION_TYPE_TEXT
        if commit:
            instance.save()
        return instance


class AnswerForm(forms.ModelForm):
    class Meta:
        model = Answer
        fields = ['mcq_answer', 'text_answer']
        widgets = {
            'mcq_answer': forms.RadioSelect(attrs={'class': 'mr-2'}),
            'text_answer': forms.HiddenInput(),
        }

    def __init__(self, *args, **kwargs):
        self.question = kwargs.pop('question', None)
        super().__init__(*args, **kwargs)
        
        if self.question:
            if self.question.question_type == QUESTION_TYPE_MCQ:
                self.fields['mcq_answer'].required = True
                self.fields['mcq_answer'].widget = forms.RadioSelect(
                    choices=[(choice['letter'], f"{choice['letter']}. {choice['text']}") 
                            for choice in self.question.choices]
                )
                self.fields['mcq_answer'].widget.attrs.update({'class': 'mr-2'})
            else:
                self.fields['mcq_answer'].required = False
                self.fields['mcq_answer'].widget = forms.HiddenInput()
                
    def clean_text_answer(self):
        """Convert JSON array back to string for storage"""
        data = self.cleaned_data.get('text_answer', '')
        if isinstance(data, str) and data.startswith('['):
            try:
                # If it's a JSON array, join with newlines
                answers = json.loads(data)
                if isinstance(answers, list):
                    return '\n\n---\n\n'.join(answers)
            except:
                pass
        return data


class GradingForm(forms.ModelForm):
    class Meta:
        model = Grading
        fields = ['is_correct', 'feedback']
        widgets = {
            'is_correct': forms.RadioSelect(choices=[(True, 'Correct'), (False, 'Incorrect')]),
            'feedback': forms.Textarea(attrs={
                'rows': 4,
                'class': 'w-full px-4 py-3 border rounded-xl'
            }),
        }


class CorrectionForm(forms.ModelForm):
    class Meta:
        model = Correction
        fields = ['explanation']
        widgets = {
            'explanation': forms.Textarea(attrs={
                'rows': 4,
                'class': 'w-full px-4 py-3 border rounded-xl'
            }),
        }


class ExamSectionForm(forms.ModelForm):
    class Meta:
        model = ExamSection
        fields = ['letter', 'name', 'instructions', 'order']
        widgets = {
            'letter': forms.TextInput(attrs={
                'class': 'w-full px-4 py-3 border rounded-xl',
                'maxlength': 1,
                'placeholder': 'A'
            }),
            'name': forms.TextInput(attrs={
                'class': 'w-full px-4 py-3 border rounded-xl',
                'placeholder': 'Section name'
            }),
            'instructions': forms.Textarea(attrs={
                'rows': 3,
                'class': 'w-full px-4 py-3 border rounded-xl',
                'placeholder': 'Optional instructions for this section'
            }),
            'order': forms.NumberInput(attrs={
                'class': 'w-full px-4 py-3 border rounded-xl',
                'min': 1
            }),
        }

