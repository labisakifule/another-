# trends/middleware.py - Update with better local development handling
import threading
import re
from django.utils.deprecation import MiddlewareMixin
from django.conf import settings
from django.db.models import Q
from .models import Institution, InstitutionMembership

_thread_locals = threading.local()

def get_current_institution():
    return getattr(_thread_locals, 'institution', None)

def set_current_institution(institution):
    _thread_locals.institution = institution

def clear_current_institution():
    if hasattr(_thread_locals, 'institution'):
        delattr(_thread_locals, 'institution')

class InstitutionMiddleware(MiddlewareMixin):
    def process_request(self, request):
        clear_current_institution()
        
        host = request.get_host().split(':')[0]  # Remove port
        institution = None
        
        # Debug info
        # print(f"DEBUG: Host: {host}, Path: {request.path}")
        
        # Method 1: Resolve approved institution subdomains. This works
        # on both the public configured domain and local development hosts.
        base_domain = getattr(settings, 'INSTITUTION_BASE_DOMAIN', '').lower().strip('.')
        subdomain = None
        if base_domain and host.endswith('.' + base_domain):
            candidate = host[:-(len(base_domain) + 1)]
            if candidate and '.' not in candidate:
                subdomain = candidate
        if not subdomain:
            local_patterns = [
                r'^([a-zA-Z0-9-]+)\.127\.0\.0\.1$',
                r'^([a-zA-Z0-9-]+)\.localhost$',
                r'^([a-zA-Z0-9-]+)\.local$',
            ]
            for pattern in local_patterns:
                match = re.match(pattern, host)
                if match:
                    subdomain = match.group(1)
                    break
        if subdomain:
            try:
                institution = Institution.objects.get(
                    subdomain=subdomain.lower(),
                    is_active=True,
                    is_approved=True,
                )
            except Institution.DoesNotExist:
                institution = None
        
        # Manual/session context is valid only for the owner or an accepted member.
        if not institution and request.user.is_authenticated and 'current_institution_id' in request.session:
            institution = Institution.objects.filter(
                id=request.session['current_institution_id'], is_active=True, is_approved=True,
            ).filter(
                Q(admin=request.user) | Q(membership_requests__user=request.user, membership_requests__status=InstitutionMembership.STATUS_ACCEPTED)
            ).distinct().first()
        
        if institution:
            set_current_institution(institution)
            request.institution = institution
            # print(f"DEBUG: Institution set to: {institution.name}")
        
        return None
    
    def process_response(self, request, response):
        clear_current_institution()
        return response