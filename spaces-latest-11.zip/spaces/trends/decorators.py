# trends/decorators.py
from django.core.exceptions import PermissionDenied
from django.contrib.auth.decorators import user_passes_test

def role_required(allowed_roles):
    def decorator(view_func):
        def wrapper(request, *args, **kwargs):
            if not request.user.is_authenticated:
                raise PermissionDenied
            user_role = request.user.profile.global_role
            if user_role not in allowed_roles and not request.user.is_superuser:
                raise PermissionDenied
            return view_func(request, *args, **kwargs)
        return wrapper
    return decorator

def staff_required(view_func):
    return role_required(['staff', 'admin'])(view_func)

def teacher_required(view_func):
    return role_required(['teacher', 'staff', 'admin'])(view_func)

def can_promote_to_teacher(view_func):
    def wrapper(request, *args, **kwargs):
        if not request.user.is_authenticated:
            raise PermissionDenied
        user_role = request.user.profile.global_role
        if user_role in ['staff', 'admin'] or request.user.is_superuser:
            return view_func(request, *args, **kwargs)
        raise PermissionDenied
    return wrapper