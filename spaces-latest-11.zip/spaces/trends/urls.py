from django.urls import path
from . import views

urlpatterns = [
    # Authentication
    path('login/', views.login_view, name='login'),
    path('logout/', views.logout_view, name='logout'),
    path('register/', views.register_view, name='register'),
    path('welcome/', views.welcome_view, name='welcome'),
    
    # User Profile
    path('profile/edit/', views.edit_profile, name='edit_profile'),
    path('members/<str:username>/', views.member_profile, name='member_profile'),
    path('notifications/', views.notification_list, name='notification_list'),
    path('notifications/<int:notification_id>/', views.notification_open, name='notification_open'),
    path('notifications/mark-all-read/', views.notification_mark_all_read, name='notification_mark_all_read'),
    path('institutions/<uuid:institution_id>/', views.institution_public, name='institution_public'),
    path('community/membership-requests/', views.membership_requests, name='membership_requests'),
    path('community/subscriptions/', views.subscription_list, name='subscription_list'),
    path('community/subscribe/', views.subscription_toggle, name='subscription_toggle'),
    path('community/institutions/<uuid:institution_id>/join/', views.institution_join_request, name='institution_join_request'),
    path('community/institutions/<uuid:institution_id>/leave/', views.institution_leave, name='institution_leave'),
    path('community/creators/<uuid:user_id>/join/', views.creator_join_request, name='creator_join_request'),
    path('community/creators/memberships/<uuid:membership_id>/review/', views.creator_membership_review, name='creator_membership_review'),
    path('institution/members/search/', views.institution_member_search, name='institution_member_search'),
    path('institution/members/request/<uuid:institution_id>/', views.institution_membership_request, name='institution_membership_request'),
    
    # Dashboard
    path('', views.dashboard_view, name='dashboard'),
    
    # Content Creation
    path('system/create/', views.create_educational_system, name='system_create'),
    path('level/create/', views.create_education_level, name='create_level'),
    path('subject/create/', views.create_subject, name='subject_create'),
    path('topic/create/', views.create_topic, name='create_topic'),
    path('domain/create/', views.create_skill_domain, name='create_domain'),
    path('institution/create/', views.create_institution, name='create_institution'),
    path('trend/create/', views.create_trend, name='create_trend'),
    
    # AJAX Loaders
    path('ajax/load-levels/', views.load_education_levels, name='ajax_load_levels'),
    path('ajax/load-programs/', views.load_programs, name='ajax_load_programs'),
    path('ajax/load-years/', views.load_years, name='ajax_load_years'),
    
    # Admin Views
    path('admin/dashboard/', views.admin_dashboard, name='admin_dashboard'),
    path('admin/users/', views.admin_user_list, name='admin_user_list'),
    path('admin/users/<uuid:pk>/', views.admin_user_detail, name='admin_user_detail'),
    path('admin/content-review/', views.content_review_dashboard, name='content_review'),
    path('admin/approve/<str:model>/<uuid:pk>/', views.approve_item, name='approve_item'),
    path('admin/reject/<str:model>/<uuid:pk>/', views.reject_item, name='reject_item'),
    path('admin/metrics/', views.system_metrics, name='system_metrics'),

    path('institution/register/', views.register_institution, name='register_institution'),
    path('institution/dashboard/', views.institution_dashboard, name='institution_dashboard'),
    path('institution/onboarding/', views.institution_onboarding, name='institution_onboarding'),
    path('institution/student-dashboard/', views.institution_student_dashboard, name='institution_student_dashboard'),
    path('institution/staff-dashboard/', views.institution_staff_dashboard, name='institution_staff_dashboard'),
    path('institution/approvals/', views.institution_approval_center, name='institution_approval_center'),
    path('institution/approvals/<uuid:pk>/review/', views.institution_review_approval, name='institution_review_approval'),

    path('institution/level/create/', views.create_institution_level, name='create_institution_level'),
    path('institution/subject/create/', views.create_institution_subject, name='create_institution_subject'),
    path('institution/topic/create/', views.create_institution_topic, name='create_institution_topic'),
    path('institution/trend/create/', views.create_institution_trend, name='create_institution_trend'),
    
    path('test-registration/', views.test_institution_registration, name='test_registration'),
    path('subdomain-test/', views.subdomain_test, name='subdomain_test'),
    
    # Add these placeholder URLs for the dashboard links
    
    path('users/manage/', views.user_management, name='user_management'),
    path('users/invite/', views.user_invite, name='user_invite'),
    path('users/<uuid:user_id>/role/', views.user_edit_role, name='user_edit_role'),
    path('settings/', views.institution_settings, name='institution_settings'),
    
    
    # Space URLs
    path('spaces/', views.space_list, name='space_list'),
    path('spaces/create/', views.space_create, name='space_create'),
    path('spaces/<uuid:pk>/', views.space_detail, name='space_detail'),
    path('spaces/<uuid:pk>/edit/', views.space_edit, name='space_edit'),
    
    # Trend URLs
    path('trends/', views.trend_list, name='trend_list'),
    path('trends/templates/', views.trend_templates, name='trend_templates'),
    path('trends/uganda-timetable/', views.trend_uganda_timetable, name='trend_uganda_timetable'),
    path('trends/create/', views.trend_create, name='trend_create'),
    path('trends/<uuid:pk>/edit/', views.trend_edit, name='trend_edit'),
    path('trends/calendar/', views.trend_calendar, name='trend_calendar'),
    
    path('institution/switch/', views.institution_switch, name='institution_switch'),
    path('institution/select/<uuid:institution_id>/', views.select_institution, name='select_institution'),

    path('ajax/load-subjects/', views.load_subjects, name='ajax_load_subjects'),
    path('ajax/load-topics/', views.load_topics, name='ajax_load_topics'),

    path('topic/<uuid:pk>/edit/', views.edit_topic, name='edit_topic'),
    path('topic/<uuid:pk>/delete/', views.delete_topic, name='delete_topic'),

    path('dashboard/staff/', views.staff_dashboard, name='staff_dashboard'),
    path('dashboard/teacher/', views.teacher_dashboard, name='teacher_dashboard'),
    path('api/search/', views.search_api, name='search_api'),

    # Health Check Endpoints
    path('health/', views.health_check, name='health_check'),
    path('health-check/', views.health_check, name='health_check_alt'),
    path('ping/', views.health_check, name='ping'),          # For UptimeRobot
    path('status/', views.health_check, name='status'),      # Alternative
    
    # Text-based health check (minimal)
    path('health.txt/', views.health_check_text, name='health_text'),
]
