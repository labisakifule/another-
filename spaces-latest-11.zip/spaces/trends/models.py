import uuid
from django.db import models
from django.contrib.contenttypes.fields import GenericForeignKey
from django.contrib.contenttypes.models import ContentType
from django.utils.translation import gettext_lazy as _
from django_countries.fields import CountryField
from django.contrib.auth.models import AbstractUser
from django.conf import settings
from cloudinary.models import CloudinaryField
from .constants import *
from django.db.models import Q
from django.utils import timezone


class UUIDMixin(models.Model):
    id = models.UUIDField(primary_key=True, default=uuid.uuid4, editable=False)
    
    class Meta:
        abstract = True


class User(AbstractUser, UUIDMixin):
    PARTICIPANT = 'participant'
    TEACHER = 'teacher'
    STAFF = 'staff'
    SETTER = 'setter'  # Legacy - can map to teacher
    ADMIN = 'admin'
    INSTITUTION_ADMIN = 'institution_admin'
    INSTITUTION_MANAGER = 'institution_manager'
    INSTITUTION_USER = 'institution_user'
    
    CHOICES = [
        (PARTICIPANT, 'Participant'),
        (TEACHER, 'Teacher'),
        (STAFF, 'Staff'),
        (SETTER, 'Setter'),
        (ADMIN, 'Admin'),
        (INSTITUTION_ADMIN, 'Institution Admin'),
        (INSTITUTION_MANAGER, 'Institution Manager'),
        (INSTITUTION_USER, 'Institution User'),
    ]  
  
  
    is_verified = models.BooleanField(default=False)
    credits = models.PositiveIntegerField(default=0)

    @property
    def uid(self):
        return f"usr-{str(self.id)[:7]}"

    def save(self, *args, **kwargs):
        super().save(*args, **kwargs)
        if self.is_superuser and not self.is_verified:
            self.is_verified = True
            super().save(update_fields=['is_verified'])


class EducationalSystem(UUIDMixin, models.Model):
    name = models.CharField(_('system name'), max_length=100, unique=True)
    system_type = models.CharField(
        _('system type'),
        max_length=20,
        choices=SystemType.CHOICES,
        default=SystemType.SECONDARY
    )
    description = models.TextField(_('description'), blank=True)
    created_by = models.ForeignKey(
        User,
        on_delete=models.SET_NULL,
        null=True,
        related_name='created_systems'
    )
    is_approved = models.BooleanField(_('approved'), default=False)
    created_at = models.DateTimeField(_('created at'), auto_now_add=True)

    def __str__(self):
        return self.name

    @property
    def uid(self):
        return f"sys-{str(self.id)[:7]}"


class Institution(UUIDMixin, models.Model):
    name = models.CharField(_('name'), max_length=200)
    institution_type = models.CharField(
        _('institution type'),
        max_length=20,
        choices=InstitutionType.CHOICES,
        default=InstitutionType.EDUCATIONAL
    )
    description = models.TextField(_('description'), blank=True)
    email = models.EmailField(_('email'), blank=True)
    phone = models.CharField(_('phone'), max_length=20, blank=True)
    website = models.URLField(_('website'), blank=True)
    address = models.TextField(_('address'), blank=True)
    country = CountryField(blank=True)
    subdomain = models.CharField(_('subdomain'), max_length=50, unique=True, null=True, blank=True)
    custom_domain = models.CharField(_('custom domain'), max_length=100, unique=True, null=True, blank=True)
    is_approved = models.BooleanField(_('approved'), default=False)
    is_active = models.BooleanField(_('active'), default=True)
    verified = models.BooleanField(_('verified'), default=False)
    admin = models.ForeignKey(
        User,
        on_delete=models.CASCADE,
        related_name='administered_institutions'
    )
    logo = CloudinaryField(
        'logo',
        folder='institution_logos/',
        null=True,
        blank=True,
        transformation=[
            {'width': 200, 'height': 200, 'crop': 'fill', 'gravity': 'auto'},
            {'quality': 'auto'},
            {'fetch_format': 'auto'}
        ]
    )
    banner = CloudinaryField(
        'banner',
        folder='institution_banners/',
        null=True,
        blank=True,
        transformation=[
            {'width': 1200, 'height': 300, 'crop': 'fill'},
            {'quality': 'auto'},
            {'fetch_format': 'auto'}
        ]
    )
    primary_color = models.CharField(max_length=7, default='#3B82F6')
    secondary_color = models.CharField(max_length=7, default='#10B981')
    allow_user_registration = models.BooleanField(_('allow user registration'), default=True)
    require_domain_email = models.BooleanField(_('require domain email'), default=False)
    allowed_email_domains = models.CharField(_('allowed email domains'), max_length=500, blank=True)
    user_limit = models.PositiveIntegerField(_('user limit'), default=100)
    storage_quota_mb = models.PositiveIntegerField(_('storage quota (MB)'), default=1024)
    created_at = models.DateTimeField(_('created at'), auto_now_add=True, null=True)
    updated_at = models.DateTimeField(_('updated at'), auto_now=True)
    expiry_date = models.DateField(_('expiry date'), null=True, blank=True)

    class Meta:
        constraints = [
            models.UniqueConstraint(
                fields=['subdomain'],
                name='unique_subdomain',
                condition=Q(subdomain__isnull=False)
            ),
            models.UniqueConstraint(
                fields=['custom_domain'],
                name='unique_custom_domain',
                condition=Q(custom_domain__isnull=False)
            )
        ]

    def __str__(self):
        return f"{self.name} ({self.get_institution_type_display()})"

    @property
    def uid(self):
        return f"inst-{str(self.id)[:7]}"




# SPACES_COMMUNITY_FEATURES_V1
class InstitutionMembership(UUIDMixin, models.Model):
    STATUS_PENDING = 'pending'
    STATUS_ACCEPTED = 'accepted'
    STATUS_DECLINED = 'declined'
    STATUS_CANCELLED = 'cancelled'
    STATUS_REMOVED = 'removed'
    STATUS_CHOICES = [
        (STATUS_PENDING, 'Pending'),
        (STATUS_ACCEPTED, 'Accepted'),
        (STATUS_DECLINED, 'Declined'),
        (STATUS_CANCELLED, 'Cancelled'),
        (STATUS_REMOVED, 'Removed'),
    ]
    ROLE_CHOICES = [
        (UserRole.INSTITUTION_USER, 'Member'),
        (UserRole.STUDENT, 'Student'),
        (UserRole.TEACHER, 'Teacher / Creator'),
        (UserRole.SETTER, 'Setter / Creator'),
        (UserRole.STAFF, 'Staff'),
        (UserRole.INSTITUTION_MANAGER, 'Institution Manager'),
    ]
    user = models.ForeignKey(User, on_delete=models.CASCADE, related_name='institution_membership_requests')
    institution = models.ForeignKey(Institution, on_delete=models.CASCADE, related_name='membership_requests')
    requested_role = models.CharField(max_length=30, choices=ROLE_CHOICES, default=UserRole.INSTITUTION_USER)
    status = models.CharField(max_length=20, choices=STATUS_CHOICES, default=STATUS_PENDING)
    requested_by = models.ForeignKey(User, on_delete=models.SET_NULL, null=True, blank=True, related_name='created_membership_requests')
    created_at = models.DateTimeField(auto_now_add=True)
    responded_at = models.DateTimeField(null=True, blank=True)
    intention = models.CharField(max_length=40, blank=True)
    intention_other = models.TextField(blank=True)
    request_message = models.TextField(blank=True)
    class Meta:
        constraints = [
            models.UniqueConstraint(fields=['user', 'institution'], name='unique_institution_membership_request')
        ]
        indexes = [models.Index(fields=['user', 'status']), models.Index(fields=['institution', 'status'])]


class InstitutionContentApproval(UUIDMixin, models.Model):
    STATUS_PENDING = 'pending'
    STATUS_APPROVED = 'approved'
    STATUS_REJECTED = 'rejected'
    STATUS_CHANGES = 'changes_requested'
    STATUS_CHOICES = [
        (STATUS_PENDING, 'Pending review'),
        (STATUS_APPROVED, 'Approved'),
        (STATUS_REJECTED, 'Rejected'),
        (STATUS_CHANGES, 'Changes requested'),
    ]
    institution = models.ForeignKey(Institution, on_delete=models.CASCADE, related_name='content_approvals')
    submitted_by = models.ForeignKey(User, on_delete=models.SET_NULL, null=True, related_name='submitted_content_approvals')
    reviewed_by = models.ForeignKey(User, on_delete=models.SET_NULL, null=True, blank=True, related_name='reviewed_content_approvals')
    content_type = models.ForeignKey(ContentType, on_delete=models.CASCADE)
    object_id = models.UUIDField()
    content_object = GenericForeignKey('content_type', 'object_id')
    status = models.CharField(max_length=24, choices=STATUS_CHOICES, default=STATUS_PENDING, db_index=True)
    review_note = models.TextField(blank=True)
    created_at = models.DateTimeField(auto_now_add=True)
    reviewed_at = models.DateTimeField(null=True, blank=True)

    class Meta:
        indexes = [models.Index(fields=['institution', 'status']), models.Index(fields=['content_type', 'object_id'])]


class CreatorMembership(UUIDMixin, models.Model):
    STATUS_PENDING = 'pending'
    STATUS_ACCEPTED = 'accepted'
    STATUS_DECLINED = 'declined'
    STATUS_CANCELLED = 'cancelled'
    STATUS_CHOICES = [(STATUS_PENDING, 'Pending'), (STATUS_ACCEPTED, 'Accepted'), (STATUS_DECLINED, 'Declined'), (STATUS_CANCELLED, 'Cancelled')]
    creator = models.ForeignKey(User, on_delete=models.CASCADE, related_name='creator_memberships')
    member = models.ForeignKey(User, on_delete=models.CASCADE, related_name='joined_creator_memberships')
    status = models.CharField(max_length=20, choices=STATUS_CHOICES, default=STATUS_PENDING)
    intention = models.CharField(max_length=40, blank=True)
    intention_other = models.TextField(blank=True)
    requested_at = models.DateTimeField(auto_now_add=True)
    responded_at = models.DateTimeField(null=True, blank=True)
    class Meta:
        constraints = [models.UniqueConstraint(fields=['creator', 'member'], name='unique_creator_membership')]
        indexes = [models.Index(fields=['creator', 'status']), models.Index(fields=['member', 'status'])]


class Subscription(UUIDMixin, models.Model):
    subscriber = models.ForeignKey(User, on_delete=models.CASCADE, related_name='subscriptions')
    user_target = models.ForeignKey(User, on_delete=models.CASCADE, null=True, blank=True, related_name='user_subscribers')
    institution_target = models.ForeignKey(Institution, on_delete=models.CASCADE, null=True, blank=True, related_name='subscribers')
    created_at = models.DateTimeField(auto_now_add=True)
    class Meta:
        constraints = [
            models.CheckConstraint(
                check=(
                    (Q(user_target__isnull=False) & Q(institution_target__isnull=True)) |
                    (Q(user_target__isnull=True) & Q(institution_target__isnull=False))
                ),
                name='subscription_one_target_only',
            ),
            models.UniqueConstraint(fields=['subscriber', 'user_target'], name='unique_user_subscription'),
            models.UniqueConstraint(fields=['subscriber', 'institution_target'], name='unique_institution_subscription'),
        ]
        indexes = [models.Index(fields=['subscriber', 'created_at'])]

class EducationLevel(UUIDMixin, models.Model):
    system = models.ForeignKey(
        EducationalSystem,
        on_delete=models.CASCADE,
        related_name='levels',
        null=True,
        blank=True
    )
    institution_level = models.ForeignKey(
        Institution,
        on_delete=models.CASCADE,
        related_name='levels',
        null=True,
        blank=True
    )
    level_type = models.CharField(
        _('level type'),
        max_length=20,
        choices=LevelType.CHOICES,
        default=LevelType.GRADE
    )
    name = models.CharField(_('name'), max_length=100)
    order = models.PositiveSmallIntegerField(_('order'), default=1)
    parent = models.ForeignKey(
        'self',
        on_delete=models.SET_NULL,
        null=True,
        blank=True,
        related_name='children'
    )
    created_by = models.ForeignKey(
        User,
        on_delete=models.SET_NULL,
        null=True,
        related_name='created_levels'
    )
    is_approved = models.BooleanField(_('approved'), default=False)
    created_at = models.DateTimeField(_('created at'), auto_now_add=True,null=True)

    def __str__(self):
        return f"{self.name} ({self.get_level_type_display()})"

    @property
    def uid(self):
        return f"lev-{str(self.id)[:7]}"


class Subject(UUIDMixin, models.Model):
    education_level = models.ForeignKey(
        EducationLevel,
        on_delete=models.CASCADE,
        related_name='subjects',
        null=True,
        blank=True
    )
    institution = models.ForeignKey(
        Institution,
        on_delete=models.CASCADE,
        related_name='subjects',
        null=True,
        blank=True
    )
    name = models.CharField(_('name'), max_length=100)
    description = models.TextField(_('description'), blank=True)
    order = models.PositiveSmallIntegerField(_('order'), default=1)
    created_by = models.ForeignKey(
        User,
        on_delete=models.SET_NULL,
        null=True,
        related_name='created_subjects'
    )
    is_approved = models.BooleanField(_('approved'), default=False)
    created_at = models.DateTimeField(_('created at'), auto_now_add=True,null=True)

    def __str__(self):
        return self.name

    @property
    def uid(self):
        return f"sub-{str(self.id)[:7]}"


class Topic(UUIDMixin, models.Model):
    subject = models.ForeignKey(
        Subject,
        on_delete=models.CASCADE,
        related_name='topics'
    )
    name = models.CharField(_('name'), max_length=100)
    description = models.TextField(_('description'), blank=True)
    order = models.PositiveSmallIntegerField(_('order'), default=1)
    created_by = models.ForeignKey(
        User,
        on_delete=models.SET_NULL,
        null=True,
        related_name='created_topics'
    )
    is_approved = models.BooleanField(_('approved'), default=False)
    created_at = models.DateTimeField(_('created at'), auto_now_add=True,null=True)

    def __str__(self):
        return self.name

    @property
    def uid(self):
        return f"top-{str(self.id)[:7]}"


class Subtopic(UUIDMixin, models.Model):
    topic = models.ForeignKey(Topic, on_delete=models.CASCADE, related_name='subtopics')
    name = models.CharField(_('name'), max_length=160)
    description = models.TextField(_('description'), blank=True)
    order = models.PositiveSmallIntegerField(_('order'), default=1)
    created_by = models.ForeignKey(User, on_delete=models.SET_NULL, null=True, related_name='created_subtopics')
    is_approved = models.BooleanField(_('approved'), default=False)
    created_at = models.DateTimeField(auto_now_add=True, null=True)

    class Meta:
        ordering = ('order', 'name')
        constraints = [models.UniqueConstraint(fields=['topic', 'name'], name='unique_topic_subtopic')]

    def __str__(self):
        return f'{self.topic.name} — {self.name}'

    @property
    def uid(self):
        return f'subtop-{str(self.id)[:7]}'

class SkillDomain(UUIDMixin, models.Model):
    name = models.CharField(_('domain name'), max_length=100, unique=True)
    description = models.TextField(_('description'), blank=True)
    created_by = models.ForeignKey(
        User,
        on_delete=models.SET_NULL,
        null=True,
        related_name='created_domains'
    )
    is_approved = models.BooleanField(_('approved'), default=False)
    created_at = models.DateTimeField(_('created at'), auto_now_add=True)

    def __str__(self):
        return self.name

    @property
    def uid(self):
        return f"dom-{str(self.id)[:7]}"


class SkillSubdomain(UUIDMixin, models.Model):
    domain = models.ForeignKey(
        SkillDomain,
        on_delete=models.CASCADE,
        related_name='subdomains'
    )
    name = models.CharField(_('name'), max_length=100)
    description = models.TextField(_('description'), blank=True)
    created_by = models.ForeignKey(
        User,
        on_delete=models.SET_NULL,
        null=True,
        related_name='created_subdomains'
    )
    is_approved = models.BooleanField(_('approved'), default=False)
    created_at = models.DateTimeField(_('created at'), auto_now_add=True,null=True)

    def __str__(self):
        return f"{self.domain.name} - {self.name}"

    @property
    def uid(self):
        return f"subdom-{str(self.id)[:7]}"


class Program(UUIDMixin, models.Model):
    institution = models.ForeignKey(
        Institution,
        on_delete=models.CASCADE,
        related_name='programs'
    )
    name = models.CharField(_('program name'), max_length=200)
    duration = models.PositiveSmallIntegerField(
        _('duration in years'),
        default=4
    )
    created_by = models.ForeignKey(
        User,
        on_delete=models.SET_NULL,
        null=True,
        related_name='created_programs'
    )
    is_approved = models.BooleanField(_('approved'), default=False)

    def __str__(self):
        return self.name

    @property
    def uid(self):
        return f"prog-{str(self.id)[:7]}"


class Year(UUIDMixin, models.Model):
    program = models.ForeignKey(
        Program,
        on_delete=models.CASCADE,
        related_name='years'
    )
    name = models.CharField(_('year name'), max_length=100)
    order = models.PositiveSmallIntegerField(_('order'), default=1)

    class Meta:
        unique_together = [('program', 'name')]

    def __str__(self):
        return f"{self.program.name} - {self.name}"

    @property
    def uid(self):
        return f"yr-{str(self.id)[:7]}"


class Semester(UUIDMixin, models.Model):
    year = models.ForeignKey(
        Year,
        on_delete=models.CASCADE,
        related_name='semesters'
    )
    name = models.CharField(_('semester name'), max_length=50)
    order = models.PositiveSmallIntegerField(_('order'), default=1)
    start_date = models.DateField(null=True, blank=True)
    end_date = models.DateField(null=True, blank=True)

    class Meta:
        unique_together = [('year', 'name')]

    def __str__(self):
        return f"{self.year} - {self.name}"

    @property
    def uid(self):
        return f"sem-{str(self.id)[:7]}"


class Profile(UUIDMixin, models.Model):
    user = models.OneToOneField(User, on_delete=models.CASCADE, related_name='profile')
    role = models.CharField(max_length=20, choices=UserRole.CHOICES, default=UserRole.PARTICIPANT)
    global_role = models.CharField(max_length=20, choices=UserRole.CHOICES, default=UserRole.PARTICIPANT)
    teacher_approved = models.BooleanField(default=False, help_text='Teacher application approved by staff/superuser')
    institution_role = models.CharField(
        _('institution role'),
        max_length=20,
        choices=UserRole.CHOICES,
        default=UserRole.PARTICIPANT
    )
    institution = models.ForeignKey(
        Institution,
        on_delete=models.SET_NULL,
        null=True,
        blank=True,
        related_name='members'
    )
    education_system = models.ForeignKey('EducationalSystem', on_delete=models.SET_NULL, null=True, blank=True)
    education_level = models.ForeignKey('EducationLevel', on_delete=models.SET_NULL, null=True, blank=True)
    institution_onboarding_completed = models.BooleanField(default=False)
    studying_subjects = models.ManyToManyField('Subject', blank=True)
    onboarding_completed = models.BooleanField(default=False)
    PROFILE_VISIBILITY_CHOICES = [
        ('public', 'Public'),
        ('authenticated', 'Registered users'),
        ('private', 'Private'),
    ]
    profile_visibility = models.CharField(
        max_length=20,
        choices=PROFILE_VISIBILITY_CHOICES,
        default='authenticated',
    )
    bio = models.TextField(_('bio'), blank=True)
    profile_picture = CloudinaryField(
        'profile_picture',
        folder='profile_pictures/',
        null=True,
        blank=True,
        transformation=[
            {'width': 300, 'height': 300, 'crop': 'fill', 'gravity': 'face'},
            {'quality': 'auto'},
            {'fetch_format': 'auto'}
        ]
    )
    date_of_birth = models.DateField(_('date of birth'), null=True, blank=True)
    phone = models.CharField(_('phone'), max_length=20, blank=True)
    address = models.TextField(_('address'), blank=True)
    city = models.CharField(_('city'), max_length=100, blank=True)
    country = CountryField(blank=True)
    website = models.URLField(_('website'), blank=True)
    institution_name = models.CharField(_('institution name'), max_length=200, blank=True)
    institution_logo = CloudinaryField(
        'institution_logo',
        folder='institution_logos/',
        null=True,
        blank=True,
        transformation=[
            {'width': 200, 'height': 200, 'crop': 'fill', 'gravity': 'auto'},
            {'quality': 'auto'},
            {'fetch_format': 'auto'}
        ]
    )
    institution_description = models.TextField(_('institution description'), blank=True)
    education_system = models.ForeignKey(
        EducationalSystem,
        on_delete=models.SET_NULL,
        null=True,
        blank=True
    )
    education_level = models.ForeignKey(
        EducationLevel,
        on_delete=models.SET_NULL,
        null=True,
        blank=True
    )
    program = models.ForeignKey(
        Program,
        on_delete=models.SET_NULL,
        null=True,
        blank=True
    )
    academic_year = models.ForeignKey(
        Year,
        on_delete=models.SET_NULL,
        null=True,
        blank=True
    )

    def __str__(self):
        return f"{self.user.username}'s profile"

    @property
    def uid(self):
        return f"prof-{str(self.id)[:7]}"


class Space(UUIDMixin, models.Model):
    name = models.CharField(_('name'), max_length=200)
    space_type = models.CharField(
        _('space type'),
        max_length=20,
        choices=SpaceType.CHOICES,
        default=SpaceType.STUDY
    )
    description = models.TextField(_('description'), blank=True)
    institution = models.ForeignKey(
        Institution,
        on_delete=models.CASCADE,
        related_name='spaces',
        null=True,
        blank=True
    )
    created_by = models.ForeignKey(
        User,
        on_delete=models.SET_NULL,
        null=True,
        related_name='created_spaces'
    )
    building = models.CharField(_('building'), max_length=100, blank=True)
    capacity = models.PositiveIntegerField(_('capacity'), default=1)
    meeting_link = models.URLField(_('meeting link'), blank=True)
    access_code = models.CharField(_('access code'), max_length=50, blank=True)
    available_from = models.TimeField(_('available from'), null=True, blank=True)
    available_to = models.TimeField(_('available to'), null=True, blank=True)
    supervisors = models.ManyToManyField(
        User,
        related_name='supervised_spaces',
        blank=True
    )
    tags = models.CharField(_('tags'), max_length=500, blank=True)
    created_at = models.DateTimeField(_('created at'), auto_now_add=True)
    is_active = models.BooleanField(_('active'), default=True)  # Added for admin

    def __str__(self):
        return self.name

    @property
    def uid(self):
        return f"spc-{str(self.id)[:7]}"


class Trend(UUIDMixin, models.Model):
    AUDIENCE_PERSONAL = 'personal'
    AUDIENCE_INSTITUTION = 'institution'
    AUDIENCE_LEVEL = 'level'
    AUDIENCE_STAFF = 'staff'
    AUDIENCE_PUBLIC = 'public'
    AUDIENCE_CHOICES = [
        (AUDIENCE_PERSONAL, 'Only me'),
        (AUDIENCE_INSTITUTION, 'Institution members'),
        (AUDIENCE_LEVEL, 'My class or level'),
        (AUDIENCE_STAFF, 'Institution staff'),
        (AUDIENCE_PUBLIC, 'Public'),
    ]
    title = models.CharField(_('title'), max_length=200)
    description = models.TextField(_('description'), blank=True)
    trend_type = models.CharField(
        _('trend type'),
        max_length=20,
        choices=TrendType.CHOICES,
        default=TrendType.CLASS_SCHEDULE
    )
    organizer = models.ForeignKey(
        User,
        on_delete=models.CASCADE,
        related_name='organized_trends',
        null=True
    )
    institution = models.ForeignKey(
        Institution,
        on_delete=models.CASCADE,
        related_name='trends',
        null=True,
        blank=True
    )
    target_level = models.ForeignKey(
        EducationLevel,
        on_delete=models.SET_NULL,
        null=True,
        blank=True,
        related_name='targeted_trends',
        help_text=_('Optional institution class, stream, department, or level.'),
    )
    audience = models.CharField(
        _('audience'),
        max_length=20,
        choices=AUDIENCE_CHOICES,
        default=AUDIENCE_PERSONAL,
        db_index=True,
    )
    subject = models.ForeignKey('Subject', on_delete=models.SET_NULL, null=True, blank=True, related_name='scheduled_trends')
    topic = models.ForeignKey('Topic', on_delete=models.SET_NULL, null=True, blank=True, related_name='scheduled_trends')
    subtopic = models.ForeignKey('Subtopic', on_delete=models.SET_NULL, null=True, blank=True, related_name='scheduled_trends')
    space = models.ForeignKey(
        Space,
        on_delete=models.SET_NULL,
        null=True,
        blank=True,
        related_name='trends'
    )
    start_time = models.DateTimeField(_('start time'))
    end_time = models.DateTimeField(_('end time'),null=True)
    is_recurring = models.BooleanField(_('is recurring'), default=False)
    recurrence_pattern = models.CharField(_('recurrence pattern'), max_length=100, blank=True)
    access_level = models.CharField(
        _('access level'),
        max_length=20,
        choices=AccessLevel.ACCESS_LEVEL_CHOICES,
        default=AccessLevel.PUBLIC
    )
    is_approved = models.BooleanField(_('approved'), default=False)
    is_active = models.BooleanField(_('active'), default=True)  # Added for admin
    created_at = models.DateTimeField(_('created at'), auto_now_add=True)
    updated_at = models.DateTimeField(_('updated at'), auto_now=True)  # Added for admin

    def __str__(self):
        return self.title

    @property
    def is_ongoing(self):
        now = timezone.now()
        return self.start_time <= now <= self.end_time

    @property
    def uid(self):
        return f"trnd-{str(self.id)[:7]}"


class ResourceCategory(UUIDMixin, models.Model):
    name = models.CharField(_('name'), max_length=100)
    description = models.TextField(_('description'), blank=True)

    def __str__(self):
        return self.name

    @property
    def uid(self):
        return f"cat-{str(self.id)[:7]}"


class ResourceBookmark(UUIDMixin, models.Model):
    user = models.ForeignKey(
        User,
        on_delete=models.CASCADE,
        related_name='trend_bookmarks'
    )
    resource = models.ForeignKey(
        'study.StudyResource',
        on_delete=models.CASCADE,
        related_name='trend_bookmarks'
    )
    created_at = models.DateTimeField(_('created at'), auto_now_add=True)

    class Meta:
        unique_together = [('user', 'resource')]

    def __str__(self):
        return f"{self.user.username} bookmarked {self.resource.title}"

    @property
    def uid(self):
        return f"bmk-{str(self.id)[:7]}"
