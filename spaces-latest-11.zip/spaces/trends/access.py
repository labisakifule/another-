from django.db.models import Q

from .models import InstitutionMembership, CreatorMembership, Trend


def accepted_institution_ids(user):
    if not user or not getattr(user, 'is_authenticated', False):
        return []
    return InstitutionMembership.objects.filter(user=user, status=InstitutionMembership.STATUS_ACCEPTED).values_list('institution_id', flat=True)


def is_institution_member(user, institution):
    if not user or not getattr(user, 'is_authenticated', False) or not institution:
        return False
    if user == institution.admin or user.is_superuser:
        return True
    return InstitutionMembership.objects.filter(user=user, institution=institution, status=InstitutionMembership.STATUS_ACCEPTED).exists()


def is_creator_member(user, creator):
    if not user or not getattr(user, 'is_authenticated', False) or not creator:
        return False
    if user == creator or user.is_superuser:
        return True
    return CreatorMembership.objects.filter(creator=creator, member=user, status=CreatorMembership.STATUS_ACCEPTED).exists()


def is_institution_staff(user, institution):
    if not user or not getattr(user, 'is_authenticated', False) or not institution:
        return False
    if user.is_superuser or user == institution.admin:
        return True
    profile = getattr(user, 'profile', None)
    roles = {'institution_admin', 'institution_manager', 'staff', 'teacher', 'setter'}
    return bool(
        profile and profile.institution_id == institution.id
        and InstitutionMembership.objects.filter(
            user=user, institution=institution, status=InstitutionMembership.STATUS_ACCEPTED
        ).exists()
        and profile.institution_role in roles
    )


def is_institution_admin(user, institution):
    """Institution leaders may review every level; scoped staff do not."""
    if not user or not getattr(user, 'is_authenticated', False) or not institution:
        return False
    if user.is_superuser or user == institution.admin:
        return True
    profile = getattr(user, 'profile', None)
    admin_roles = {'institution_admin', 'institution_manager'}
    return bool(
        profile and profile.institution_id == institution.id
        and InstitutionMembership.objects.filter(
            user=user, institution=institution, status=InstitutionMembership.STATUS_ACCEPTED
        ).exists()
        and profile.institution_role in admin_roles
    )


def user_level_ids(user, institution=None):
    profile = getattr(user, 'profile', None) if user and getattr(user, 'is_authenticated', False) else None
    level = getattr(profile, 'education_level', None) if profile else None
    if not level or (institution and level.institution_level_id not in (None, institution.id)):
        return []
    return [level.id]


def visible_trends_q(user, institution=None):
    """The shared visibility predicate for list, calendar, search, and direct access."""
    public = Q(audience=Trend.AUDIENCE_PUBLIC, access_level='public', is_approved=True)
    own = Q(organizer=user)
    if not user or not getattr(user, 'is_authenticated', False):
        return public
    clauses = public | own
    if institution:
        member = is_institution_member(user, institution)
        staff = is_institution_staff(user, institution)
        if member or staff:
            clauses |= Q(institution=institution, audience=Trend.AUDIENCE_INSTITUTION, is_approved=True)
            clauses |= Q(institution=institution, audience=Trend.AUDIENCE_LEVEL, target_level_id__in=user_level_ids(user, institution), is_approved=True)
        if staff:
            clauses |= Q(institution=institution, audience=Trend.AUDIENCE_STAFF, is_approved=True)
            # Staff and institution administrators can review every approved
            # class level in their selected institution.
            clauses |= Q(institution=institution, audience=Trend.AUDIENCE_LEVEL, is_approved=True)
    else:
        institution_ids = accepted_institution_ids(user)
        clauses |= Q(institution_id__in=institution_ids, audience=Trend.AUDIENCE_INSTITUTION, is_approved=True)
        clauses |= Q(institution_id__in=institution_ids, audience=Trend.AUDIENCE_LEVEL, target_level_id__in=user_level_ids(user), is_approved=True)
    return clauses


def visible_trends(user, institution=None):
    return Trend.objects.filter(visible_trends_q(user, institution)).distinct()


def can_view_trend(user, trend):
    return bool(trend and Trend.objects.filter(pk=trend.pk).filter(visible_trends_q(user, trend.institution)).exists())


def can_edit_trend(user, trend):
    return bool(user and getattr(user, 'is_authenticated', False) and trend and (user.is_superuser or trend.organizer_id == user.id or is_institution_staff(user, trend.institution)))


def can_view_content(user, *, institution=None, creator=None, members_only=False):
    if not members_only:
        return True
    return is_institution_member(user, institution) or is_creator_member(user, creator)


def content_visibility_q(user, institution_field='institution', creator_field='creator', members_field='members_only'):
    institution_ids = accepted_institution_ids(user)
    return Q(**{members_field: False}) | Q(**{f'{institution_field}__isnull': False, f'{institution_field}__id__in': institution_ids}) | Q(**{creator_field: user})
