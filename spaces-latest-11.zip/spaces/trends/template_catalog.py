TEMPLATES=[
{"key":"uganda_academic","label":"Ugandan academic timetable","description":"Generate class lessons across an official term using Uganda teaching dates and closures.","types":{"educational"},"route":"trend_uganda_timetable","trend_type":"class_schedule"},
{"key":"lesson","label":"Lesson or class session","description":"Schedule one lesson with a level, subject, topic, teacher, and room.","types":{"educational"},"trend_type":"class_schedule"},
{"key":"school_activity","label":"School activity","description":"Create an assembly, club, sports activity, trip, or school notice.","types":{"educational"},"trend_type":"event"},
{"key":"meeting","label":"Meeting or programme","description":"Schedule a meeting with a clear time, venue, organiser, and audience.","types":{"corporate","government","religious","community","other"},"trend_type":"meeting_schedule"},
{"key":"shift","label":"Work shift","description":"Plan duty, service, or staff coverage with a start and end time.","types":{"corporate","medical","government","community"},"trend_type":"work_shift"},
{"key":"appointment","label":"Appointment or service","description":"Schedule an appointment, consultation, or service slot.","types":{"medical","corporate","government","community"},"trend_type":"appointment"},
{"key":"programme","label":"Service or programme","description":"Plan a service, ministry programme, gathering, or recurring activity.","types":{"religious"},"trend_type":"event"},
{"key":"general","label":"General schedule","description":"Create a straightforward event for any institution.","types":{"educational","medical","corporate","government","religious","community","other"},"trend_type":"event"},]
def get_templates(institution_type='other'):
    preferred=[x for x in TEMPLATES if institution_type in x['types']]
    return preferred+[x for x in TEMPLATES if x not in preferred]
def get_template(key):
    return next((x for x in TEMPLATES if x['key']==key),TEMPLATES[-1])
