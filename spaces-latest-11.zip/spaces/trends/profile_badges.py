ROLE_BADGE_PRIORITY = {
    'none': 0,
    'creator': 1,
    'staff': 2,
    'admin': 3,
}


def get_role_badge(user):
    """Return the highest effective authority badge for a user."""
    profile = getattr(user, 'profile', None)

    if user.is_superuser or (
        profile and profile.global_role in {
            'admin',
            'institution_admin',
        }
    ):
        return {
            'level': 'admin',
            'label': 'Super Admin' if user.is_superuser else 'Institution Admin',
            'color': '#C9A84C',
            'icon': 'star',
        }

    if user.is_staff or (
        profile and profile.global_role in {'staff'}
    ):
        return {
            'level': 'staff',
            'label': 'Staff',
            'color': '#6B7280',
            'icon': 'star',
        }

    if profile and (
        profile.global_role in {'teacher', 'setter'}
        or profile.role in {'teacher', 'setter'}
    ):
        return {
            'level': 'creator',
            'label': 'Creator',
            'color': '#2563EB',
            'icon': 'star',
        }

    return None
