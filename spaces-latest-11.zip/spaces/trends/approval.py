from django.contrib.contenttypes.models import ContentType
from django.utils import timezone

from .access import is_institution_admin
from .models import InstitutionContentApproval


def submit_for_institution_approval(obj, *, institution, user):
    """Create or reset a pending approval for institution-owned content."""
    if not institution or not obj:
        return None
    if is_institution_admin(user, institution):
        if hasattr(obj, 'is_approved'):
            obj.is_approved = True
            obj.save(update_fields=['is_approved'])
        return None
    if hasattr(obj, 'is_approved'):
        obj.is_approved = False
        obj.save(update_fields=['is_approved'])
    content_type = ContentType.objects.get_for_model(obj, for_concrete_model=False)
    approval, _ = InstitutionContentApproval.objects.update_or_create(
        institution=institution,
        content_type=content_type,
        object_id=str(obj.pk),
        defaults={
            'submitted_by': user,
            'reviewed_by': None,
            'status': InstitutionContentApproval.STATUS_PENDING,
            'review_note': '',
            'reviewed_at': None,
        },
    )
    return approval


def review_approval(approval, *, reviewer, status, note=''):
    approval.status = status
    approval.reviewed_by = reviewer
    approval.review_note = note
    approval.reviewed_at = timezone.now()
    obj = approval.content_object
    if obj is not None and hasattr(obj, 'is_approved'):
        obj.is_approved = status == InstitutionContentApproval.STATUS_APPROVED
        obj.save(update_fields=['is_approved'])
    approval.save(update_fields=['status', 'reviewed_by', 'review_note', 'reviewed_at'])
    return obj
