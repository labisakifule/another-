UGANDA SCHOOL TIMETABLE TEXT PACK
===============================

Files included:
- NURSERY_1.txt, NURSERY_2.txt, NURSERY_3.txt
- P1.txt through P7.txt
- S1.txt through S4.txt
- S5_ARTS.txt, S6_ARTS.txt, S5_SCIENCE.txt, S6_SCIENCE.txt

These are typical planning skeletons in plain text. Nursery uses integrated play and routine blocks rather than formal subject lessons. P1-P3 follow the thematic/literacy approach. P4-P7 use 40-minute periods and the standard 40-period weekly pattern, with the P7 variant reflecting the higher English and Mathematics allocation. S1-S4 use eight 40-minute periods and an afternoon supervised programme.

Advanced Level note:
S5 and S6 vary by approved subject combination. The Arts and Science files are example combination templates only. Replace the subjects with the actual principal subjects, General Paper, subsidiaries and school programme used by the school.

Before publishing:
1. Check the current MoES school calendar and NCDC curriculum documents.
2. Confirm that every class receives its required weekly allocation.
3. Check teacher, room, laboratory and ICT clashes.
4. Preserve double periods for practical subjects.
5. Print separate class, teacher and room/resource timetables.
