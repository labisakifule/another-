from datetime import timedelta

from django.test import TestCase
from django.utils import timezone

from study.models import LessonExercise, StudyResource
from .access import visible_trends
from .approval import submit_for_institution_approval, review_approval
from .constants import AccessLevel, UserRole
from .models import EducationLevel, Institution, InstitutionContentApproval, InstitutionMembership, Profile, Trend, User


class TrendVisibilityTests(TestCase):
    def setUp(self):
        self.admin = User.objects.create_user(username='admin', password='x')
        self.member = User.objects.create_user(username='member', password='x')
        self.outsider = User.objects.create_user(username='outsider', password='x')
        self.institution = Institution.objects.create(name='Nusu Academy', admin=self.admin, is_active=True, is_approved=True)
        InstitutionMembership.objects.create(user=self.member, institution=self.institution, status='accepted')
        self.level = EducationLevel.objects.create(institution_level=self.institution, name='S3', is_approved=True, created_by=self.admin)
        profile, _ = Profile.objects.get_or_create(user=self.member)
        Profile.objects.filter(pk=profile.pk).update(institution_id=self.institution.id, education_level_id=self.level.id)
        self.member.refresh_from_db()
        now = timezone.now() + timedelta(days=1)
        self.class_trend = Trend.objects.create(
            title='S3 Mathematics', organizer=self.admin, institution=self.institution,
            start_time=now, end_time=now + timedelta(hours=1), access_level=AccessLevel.INSTITUTIONAL,
            audience=Trend.AUDIENCE_LEVEL, target_level=self.level, is_approved=True,
        )
        self.other_trend = Trend.objects.create(
            title='S6 Mathematics', organizer=self.admin, institution=self.institution,
            start_time=now, end_time=now + timedelta(hours=1), access_level=AccessLevel.INSTITUTIONAL,
            audience=Trend.AUDIENCE_LEVEL, target_level=EducationLevel.objects.create(institution_level=self.institution, name='S6', is_approved=True, created_by=self.admin), is_approved=True,
        )
        self.institution_trend = Trend.objects.create(
            title='Academy Assembly', organizer=self.admin, institution=self.institution,
            start_time=now, end_time=now + timedelta(hours=1), access_level=AccessLevel.INSTITUTIONAL,
            audience=Trend.AUDIENCE_INSTITUTION, is_approved=True,
        )

    def test_outsider_sees_no_institution_trends(self):
        self.assertNotIn(self.class_trend, visible_trends(self.outsider, self.institution))
        self.assertNotIn(self.institution_trend, visible_trends(self.outsider, self.institution))

    def test_member_sees_institution_and_own_level_only(self):
        visible = visible_trends(self.member, self.institution)
        self.assertIn(self.class_trend, visible)
        self.assertIn(self.institution_trend, visible)
        self.assertNotIn(self.other_trend, visible)

    def test_institution_admin_sees_all_class_levels(self):
        visible = visible_trends(self.admin, self.institution)
        self.assertIn(self.class_trend, visible)
        self.assertIn(self.other_trend, visible)

    def test_staff_submission_requires_admin_approval(self):
        staff = User.objects.create_user(username='kasoma', password='x')
        staff_profile, _ = Profile.objects.get_or_create(user=staff)
        Profile.objects.filter(pk=staff_profile.pk).update(institution_id=self.institution.id, institution_role='teacher', role='teacher')
        staff.refresh_from_db()
        trend = Trend.objects.create(
            title='Pending staff schedule', organizer=staff, institution=self.institution,
            start_time=timezone.now() + timedelta(days=2), access_level=AccessLevel.INSTITUTIONAL,
            audience=Trend.AUDIENCE_INSTITUTION, is_approved=False,
        )
        approval = submit_for_institution_approval(trend, institution=self.institution, user=staff)
        self.assertEqual(approval.status, InstitutionContentApproval.STATUS_PENDING)
        self.assertNotIn(trend, visible_trends(self.member, self.institution))
        review_approval(approval, reviewer=self.admin, status=InstitutionContentApproval.STATUS_APPROVED)
        self.assertIn(trend, visible_trends(self.member, self.institution))

    def test_creator_sees_own_pending_institution_trend_but_member_does_not(self):
        creator = User.objects.create_user(username='kasoma_creator', password='x')
        trend = Trend.objects.create(
            title='Kasoma private draft', organizer=creator, institution=self.institution,
            start_time=timezone.now() + timedelta(days=3), access_level=AccessLevel.INSTITUTIONAL,
            audience=Trend.AUDIENCE_LEVEL, target_level=self.level, is_approved=False,
        )
        self.assertIn(trend, visible_trends(creator, self.institution))
        self.assertNotIn(trend, visible_trends(self.member, self.institution))


class MultipleExerciseTests(TestCase):
    def test_resource_supports_multiple_exercises(self):
        user = User.objects.create_user(username='teacher', password='x')
        resource = StudyResource.objects.create(title='Photosynthesis', description='Lesson', creator=user, access_level=AccessLevel.PUBLIC)
        LessonExercise.objects.create(resource=resource, title='Vocabulary')
        LessonExercise.objects.create(resource=resource, title='Exam practice')
        self.assertEqual(resource.exercises.count(), 2)


class InstitutionRoleApprovalTests(TestCase):
    def setUp(self):
        self.owner = User.objects.create_user(username='role_owner', password='x')
        self.applicant = User.objects.create_user(username='role_applicant', password='x')
        self.institution = Institution.objects.create(
            name='Role Approval Institute', admin=self.owner,
            is_active=True, is_approved=True,
        )

    def test_staff_intention_defaults_to_member_until_admin_assigns_role(self):
        membership = InstitutionMembership.objects.create(
            user=self.applicant, institution=self.institution,
            requested_role=UserRole.INSTITUTION_USER,
            intention='staff', status=InstitutionMembership.STATUS_PENDING,
        )
        from .views import _community_accept_membership
        _community_accept_membership(None, membership)
        self.applicant.refresh_from_db()
        self.assertEqual(self.applicant.profile.institution_role, UserRole.INSTITUTION_USER)

    def test_creator_can_see_own_pending_trend(self):
        profile = self.applicant.profile
        profile.institution = self.institution
        profile.institution_role = UserRole.INSTITUTION_USER
        profile.save(update_fields=['institution', 'institution_role'])
        InstitutionMembership.objects.create(
            user=self.applicant, institution=self.institution,
            requested_role=UserRole.INSTITUTION_USER,
            status=InstitutionMembership.STATUS_ACCEPTED,
        )
        trend = Trend.objects.create(
            title='My institutional draft', organizer=self.applicant,
            institution=self.institution,
            start_time=timezone.now() + timedelta(days=1),
            end_time=timezone.now() + timedelta(days=1, hours=1),
            access_level=AccessLevel.INSTITUTIONAL,
            audience=Trend.AUDIENCE_STAFF, is_approved=False,
        )
        self.assertIn(trend, visible_trends(self.applicant, self.institution))
