import uuid
from django.db import migrations, models
import django.db.models.deletion

class Migration(migrations.Migration):
    dependencies = [('trends', '0013_profile_institution_onboarding_completed')]
    operations = [
        migrations.CreateModel(
            name='Subtopic',
            fields=[
                ('id', models.UUIDField(default=uuid.uuid4, editable=False, primary_key=True, serialize=False)),
                ('name', models.CharField(max_length=160, verbose_name='name')),
                ('description', models.TextField(blank=True, verbose_name='description')),
                ('order', models.PositiveSmallIntegerField(default=1, verbose_name='order')),
                ('is_approved', models.BooleanField(default=False, verbose_name='approved')),
                ('created_at', models.DateTimeField(auto_now_add=True, null=True)),
                ('created_by', models.ForeignKey(null=True, on_delete=django.db.models.deletion.SET_NULL, related_name='created_subtopics', to='trends.user')),
                ('topic', models.ForeignKey(on_delete=django.db.models.deletion.CASCADE, related_name='subtopics', to='trends.topic')),
            ],
            options={'ordering': ('order', 'name')},
        ),
        migrations.AddConstraint(model_name='subtopic', constraint=models.UniqueConstraint(fields=('topic', 'name'), name='unique_topic_subtopic')),
        migrations.AddField(model_name='trend', name='subject', field=models.ForeignKey(blank=True, null=True, on_delete=django.db.models.deletion.SET_NULL, related_name='scheduled_trends', to='trends.subject')),
        migrations.AddField(model_name='trend', name='topic', field=models.ForeignKey(blank=True, null=True, on_delete=django.db.models.deletion.SET_NULL, related_name='scheduled_trends', to='trends.topic')),
        migrations.AddField(model_name='trend', name='subtopic', field=models.ForeignKey(blank=True, null=True, on_delete=django.db.models.deletion.SET_NULL, related_name='scheduled_trends', to='trends.subtopic')),
    ]
