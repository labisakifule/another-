from django.db import migrations, models


class Migration(migrations.Migration):
    dependencies = [
        ('trends', '0011_institutioncontentapproval'),
    ]

    operations = [
        migrations.AlterField(
            model_name='institutionmembership',
            name='requested_role',
            field=models.CharField(
                choices=[
                    ('institution_user', 'Member'),
                    ('student', 'Student'),
                    ('teacher', 'Teacher / Creator'),
                    ('setter', 'Setter / Creator'),
                    ('staff', 'Staff'),
                    ('institution_manager', 'Institution Manager'),
                ],
                default='institution_user',
                max_length=30,
            ),
        ),
    ]
