from django.db import migrations, models


class Migration(migrations.Migration):
    dependencies = [
        ('trends', '0012_institutionmembership_role_choices'),
    ]

    operations = [
        migrations.AddField(
            model_name='profile',
            name='institution_onboarding_completed',
            field=models.BooleanField(default=False),
        ),
    ]
