from django.core.management.base import BaseCommand, CommandError
from trends.models import Institution, Trend, User


class Command(BaseCommand):
    help = 'Attribute imported Nusu official timetable Trends to the actual creator.'

    def add_arguments(self, parser):
        parser.add_argument('--institution', required=True, help='Institution name or UUID')
        parser.add_argument('--organizer', required=True, help='Username of the actual Trend creator')

    def handle(self, *args, **options):
        institution_value = options['institution']
        institution = Institution.objects.filter(name__iexact=institution_value).first()
        if not institution:
            try:
                institution = Institution.objects.get(pk=institution_value)
            except (Institution.DoesNotExist, ValueError):
                raise CommandError(f'Institution not found: {institution_value}')

        try:
            organizer = User.objects.get(username=options['organizer'])
        except User.DoesNotExist:
            raise CommandError(f'User not found: {options["organizer"]}')

        queryset = Trend.objects.filter(
            institution=institution,
            description__startswith='NUSU_OFFICIAL_TIMETABLE_V1|',
        )
        updated = queryset.exclude(organizer=organizer).update(organizer=organizer)
        self.stdout.write(self.style.SUCCESS(
            f'Attributed {updated} official Nusu Trends for {institution.name} to {organizer.username}.'
        ))
