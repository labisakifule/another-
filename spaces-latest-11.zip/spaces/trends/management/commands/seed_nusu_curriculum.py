from django.core.management.base import BaseCommand, CommandError
from django.db import transaction

from trends.constants import LevelType, SystemType, UserRole
from trends.models import EducationalSystem, EducationLevel, Institution, Subject, Topic, Subtopic


CURRICULUM = {
    'Early Childhood Education': {
        'system_type': SystemType.PRE_SCHOOL,
        'levels': {
            'Baby Class': ['Language and Communication', 'Early Numeracy', 'Environment and Discovery', 'Creative Arts', 'Physical Development', 'Personal and Social Development'],
            'Middle Class': ['Language and Communication', 'Early Numeracy', 'Environment and Discovery', 'Creative Arts', 'Physical Development', 'Personal and Social Development'],
            'Top Class': ['Language and Communication', 'Early Numeracy', 'Environment and Discovery', 'Creative Arts', 'Physical Development', 'Personal and Social Development'],
        },
    },
    'Uganda primary education curriculum': {
        'system_type': SystemType.PRIMARY,
        'levels': {
            'Primary One (P1)': ['Mathematics', 'English', 'Literacy I', 'Literacy II', 'Physical Education', 'Music', 'Art and Craft', 'Religious Education', 'News'],
            'Primary Two (P2)': ['Mathematics', 'English', 'Literacy I', 'Literacy II', 'Physical Education', 'Music', 'Art and Craft', 'Religious Education', 'Oral Literature', 'Free Activity'],
            'Primary Three (P3)': ['Mathematics', 'English', 'Literacy I', 'Literacy II', 'Physical Education', 'Music', 'Art and Craft', 'Religious Education', 'Oral Literature', 'Library'],
            'Primary Four (P4)': ['English', 'Mathematics', 'Integrated Science', 'Social Studies', 'Religious Education', 'Physical Education', 'Local Language', 'Art and Technology', 'Music, Dance and Drama', 'Library Reading'],
            'Primary Five (P5)': ['English', 'Mathematics', 'Integrated Science', 'Social Studies', 'Religious Education', 'Physical Education', 'Local Language', 'Art and Technology', 'Music, Dance and Drama', 'Library Reading'],
            'Primary Six (P6)': ['English', 'Mathematics', 'Integrated Science', 'Social Studies', 'Religious Education', 'Physical Education', 'Local Language', 'Art and Technology', 'Music, Dance and Drama', 'Library Reading'],
            'Primary Seven (P7)': ['English', 'Mathematics', 'Integrated Science', 'Social Studies', 'Religious Education', 'Physical Education', 'Local Language', 'Art and Technology', 'Music, Dance and Drama', 'Library Reading'],
        },
    },
    'Uganda lower secondary curriculum': {
        'system_type': SystemType.SECONDARY,
        'levels': {
            'Senior One (S1)': ['English', 'Mathematics', 'General Science', 'Physics', 'Chemistry', 'Biology', 'Geography', 'History and Political Education', 'Religious Education', 'Physical Education', 'Library', 'School Programme', 'Elective'],
            'Senior Two (S2)': ['English', 'Mathematics', 'General Science', 'Physics', 'Chemistry', 'Biology', 'Geography', 'History and Political Education', 'Religious Education', 'Physical Education', 'Library', 'School Programme', 'Elective'],
            'Senior Three (S3)': ['English', 'Mathematics', 'Physics', 'Chemistry', 'Biology', 'Geography', 'History and Political Education', 'Religious Education', 'Physical Education', 'Library', 'School Programme', 'Elective 1', 'Elective 2', 'Practical Elective'],
            'Senior Four (S4)': ['English', 'Mathematics', 'Physics', 'Chemistry', 'Biology', 'Geography', 'History and Political Education', 'Religious Education', 'Physical Education', 'Library', 'School Programme', 'Elective 1', 'Elective 2', 'Practical Elective'],
        },
    },
    'Uganda advanced level curriculum': {
        'system_type': SystemType.SECONDARY,
        'levels': {
            'Senior Five Arts (S5 Arts)': ['History', 'Literature', 'Geography', 'Economics', 'General Paper', 'Subsidiary Mathematics', 'Subsidiary ICT'],
            'Senior Six Arts (S6 Arts)': ['History', 'Literature', 'Geography', 'Economics', 'General Paper', 'Subsidiary Mathematics', 'Subsidiary ICT'],
            'Senior Five Science (S5 Science)': ['Mathematics', 'Biology', 'Chemistry', 'Physics', 'General Paper', 'Subsidiary Mathematics', 'Subsidiary ICT'],
            'Senior Six Science (S6 Science)': ['Mathematics', 'Biology', 'Chemistry', 'Physics', 'General Paper', 'Subsidiary Mathematics', 'Subsidiary ICT'],
        },
    },
}

TOPICS = {
    'Mathematics': ['Number and Place Value', 'Fractions, Decimals and Percentages', 'Measurement', 'Geometry', 'Algebra', 'Data Handling and Probability', 'Problem Solving'],
    'English': ['Listening and Speaking', 'Reading Comprehension', 'Grammar', 'Vocabulary', 'Writing Composition', 'Literature'],
    'Literacy I': ['Phonics and Word Recognition', 'Reading', 'Handwriting', 'Spelling', 'Writing'],
    'Literacy II': ['Reading Fluency', 'Comprehension', 'Grammar', 'Vocabulary', 'Creative Writing'],
    'Integrated Science': ['Living Things', 'Matter and Materials', 'Energy', 'Force and Motion', 'The Environment', 'Health and Safety'],
    'General Science': ['Scientific Inquiry', 'Matter', 'Energy', 'Living Things', 'The Environment', 'Health'],
    'Biology': ['Cell Biology', 'Nutrition', 'Transport in Plants and Animals', 'Reproduction', 'Ecology', 'Human Health'],
    'Chemistry': ['Matter and Measurement', 'Atomic Structure', 'Chemical Bonding', 'Chemical Reactions', 'Acids and Bases', 'Organic Chemistry'],
    'Physics': ['Measurement', 'Mechanics', 'Heat', 'Light', 'Sound', 'Electricity and Magnetism'],
    'Geography': ['Map Reading', 'Weather and Climate', 'Landforms', 'Population', 'Resources and Economic Activities', 'Environmental Management'],
    'History and Political Education': ['Sources of History', 'East African History', 'Uganda’s History', 'Colonialism', 'Independence', 'Citizenship and Governance'],
    'Social Studies': ['Our Community', 'Leadership and Governance', 'Uganda and East Africa', 'Resources', 'Culture and Heritage', 'Environment'],
    'Religious Education': ['Faith and Values', 'Creation and Stewardship', 'Moral Living', 'Community Responsibility', 'Religious Celebrations'],
    'Physical Education': ['Fitness', 'Athletics', 'Games', 'Gymnastics', 'Health and Safety'],
    'Local Language': ['Listening and Speaking', 'Reading', 'Grammar', 'Vocabulary', 'Oral Literature', 'Writing'],
    'History': ['Historical Sources', 'East African History', 'European History', 'Nationalism', 'Independence Movements', 'Political Development'],
    'Literature': ['Literary Genres', 'Poetry', 'Drama', 'Prose', 'Character and Setting', 'Themes and Style'],
    'Economics': ['Basic Economic Concepts', 'Demand and Supply', 'Production', 'Markets', 'Money and Banking', 'National Income and Development'],
    'General Paper': ['Communication Skills', 'Contemporary Issues', 'Culture and Society', 'Science and Technology', 'Governance and Development'],
    'Music': ['Singing', 'Rhythm', 'Movement', 'Instruments', 'Creative Performance'],
    'Art and Craft': ['Drawing', 'Painting', 'Pattern and Design', 'Modelling', 'Craft Materials'],
    'Art and Technology': ['Design', 'Drawing', 'Materials and Tools', 'Technology in Daily Life', 'Practical Projects'],
    'Music, Dance and Drama': ['Music', 'Dance', 'Drama', 'Performance', 'Cultural Expression'],
    'Language and Communication': ['Listening', 'Speaking', 'Storytelling', 'Vocabulary', 'Early Reading'],
    'Early Numeracy': ['Counting', 'Sorting and Matching', 'Shapes', 'Patterns', 'Measurement'],
    'Environment and Discovery': ['Self and Family', 'Our School', 'Animals and Plants', 'Weather', 'Health and Hygiene'],
    'Creative Arts': ['Drawing', 'Colour', 'Music', 'Dance', 'Dramatic Play'],
    'Physical Development': ['Movement', 'Balance', 'Coordination', 'Outdoor Play', 'Personal Care'],
    'Personal and Social Development': ['Identity', 'Relationships', 'Values', 'Safety', 'Independence'],
}


SECONDARY_SUBTOPICS = {
    'Mathematics': ['Number concepts and operations', 'Algebraic expressions and equations', 'Geometry and measurement', 'Statistics and probability'],
    'General Science': ['Scientific investigation', 'Matter and materials', 'Energy and its transformations', 'Living things and the environment'],
    'Physics': ['Measurement and physical quantities', 'Mechanics and motion', 'Heat and temperature', 'Light and sound', 'Electricity and magnetism'],
    'Chemistry': ['Particles and atomic structure', 'Chemical bonding', 'Chemical reactions', 'Acids, bases and salts', 'Organic chemistry'],
    'Biology': ['Cell structure and organisation', 'Nutrition and transport', 'Reproduction and growth', 'Ecology and conservation', 'Health and disease'],
    'Geography': ['Map work and field skills', 'Weather and climate', 'Relief and drainage', 'Population and settlement', 'Resources and development'],
    'History and Political Education': ['Historical sources and interpretation', 'East African societies', 'Colonial rule and responses', 'Nationalism and independence', 'Citizenship and governance'],
    'English': ['Listening and speaking', 'Grammar and language use', 'Reading comprehension', 'Functional writing', 'Literature and response'],
    'History': ['Historical sources', 'East African history', 'Nationalism and independence', 'Political development'],
    'Literature': ['Poetry', 'Drama', 'Prose', 'Character, theme and style'],
    'Economics': ['Basic economic concepts', 'Production and markets', 'Money and banking', 'National income and development'],
    'General Paper': ['Communication skills', 'Contemporary issues', 'Governance and development', 'Science, technology and society'],
}

def get_or_create_system(name, system_type, user):
    system = EducationalSystem.objects.filter(name__iexact=name).first()
    if not system:
        system = EducationalSystem.objects.create(name=name, system_type=system_type, created_by=user, is_approved=True)
    elif not system.is_approved:
        system.is_approved = True
        system.save(update_fields=['is_approved'])
    return system


class Command(BaseCommand):
    help = 'Create missing Nusu Academy Ugandan curriculum systems, levels, subjects, and starter topics.'

    def add_arguments(self, parser):
        parser.add_argument('--institution', required=True, help='Exact institution name or UUID')
        parser.add_argument('--created-by', help='Username to use as creator; defaults to institution admin')

    @transaction.atomic
    def handle(self, *args, **options):
        value = options['institution']
        institution = Institution.objects.filter(name__iexact=value).first()
        if not institution:
            try:
                institution = Institution.objects.get(pk=value)
            except (Institution.DoesNotExist, ValueError):
                raise CommandError(f'Institution not found: {value}')
        if not institution.is_active or not institution.is_approved:
            raise CommandError('Institution must be active and approved.')
        creator = institution.admin
        if options.get('created_by'):
            from django.contrib.auth import get_user_model
            try:
                creator = get_user_model().objects.get(username=options['created_by'])
            except get_user_model().DoesNotExist:
                raise CommandError(f'Creator not found: {options["created_by"]}')
        counts = {'systems': 0, 'levels': 0, 'subjects': 0, 'topics': 0}
        for system_name, config in CURRICULUM.items():
            system_before = EducationalSystem.objects.filter(name__iexact=system_name).exists()
            system = get_or_create_system(system_name, config['system_type'], creator)
            counts['systems'] += int(not system_before)
            for order, (level_name, subject_names) in enumerate(config['levels'].items(), start=1):
                level = EducationLevel.objects.filter(system=system, name__iexact=level_name).first()
                if not level:
                    level = EducationLevel.objects.create(system=system, name=level_name, level_type=LevelType.GRADE, order=order, created_by=creator, is_approved=True)
                    counts['levels'] += 1
                elif not level.is_approved:
                    level.is_approved = True
                    level.save(update_fields=['is_approved'])
                for subject_order, subject_name in enumerate(subject_names, start=1):
                    subject = Subject.objects.filter(education_level=level, name__iexact=subject_name).first()
                    if not subject:
                        subject = Subject.objects.create(education_level=level, name=subject_name, order=subject_order, created_by=creator, is_approved=True)
                        counts['subjects'] += 1
                    elif not subject.is_approved:
                        subject.is_approved = True
                        subject.save(update_fields=['is_approved'])
                    for topic_order, topic_name in enumerate(TOPICS.get(subject_name, ['Introduction', 'Core Concepts', 'Practice and Application', 'Revision']), start=1):
                        topic, created = Topic.objects.get_or_create(subject=subject, name=topic_name, defaults={'order': topic_order, 'created_by': creator, 'is_approved': True})
                        if created:
                            counts['topics'] += 1
                        elif not topic.is_approved:
                            topic.is_approved = True
                            topic.save(update_fields=['is_approved'])
                        for subtopic_order, subtopic_name in enumerate(SECONDARY_SUBTOPICS.get(subject_name, []), start=1):
                            Subtopic.objects.get_or_create(
                                topic=topic, name=subtopic_name,
                                defaults={'order': subtopic_order, 'created_by': creator, 'is_approved': True},
                            )
        self.stdout.write(self.style.SUCCESS(f'Curriculum seeded for {institution.name}.'))
        self.stdout.write('Created: ' + ', '.join(f'{key}={value}' for key, value in counts.items()))
