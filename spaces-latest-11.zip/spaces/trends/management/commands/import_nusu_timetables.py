import json
from collections import defaultdict
from datetime import datetime, time, timedelta
from pathlib import Path

from django.core.management.base import BaseCommand, CommandError
from django.db import transaction
from django.db.models import Q
from django.utils import timezone

from trends.constants import AccessLevel, TrendType
from trends.models import EducationLevel, Institution, Subject, Subtopic, Topic, Trend, User

DAYS = ('Monday', 'Tuesday', 'Wednesday', 'Thursday', 'Friday')
COLUMN_STARTS = (18, 43, 68, 93, 118)
SOURCE_FILES = ('NURSERY_1.txt', 'NURSERY_2.txt', 'NURSERY_3.txt', 'P1.txt', 'P2.txt', 'P3.txt', 'P4.txt', 'P5.txt', 'P6.txt', 'P7.txt', 'S1.txt', 'S2.txt', 'S3.txt', 'S4.txt', 'S5_ARTS.txt', 'S5_SCIENCE.txt', 'S6_ARTS.txt', 'S6_SCIENCE.txt')
SPECIAL_LONG_BLOCKS = {**{key: 'Games / Clubs / Remedial / Supervised Departure' for key in ('P1', 'P2', 'P3', 'P4', 'P5', 'P6', 'P7')}, **{key: 'Creativity / Innovation / Clubs / Library / Games / Study' for key in ('S1', 'S2', 'S3', 'S4')}, **{key: 'Supervised Study / Clubs / Games' for key in ('S5_ARTS', 'S5_SCIENCE', 'S6_ARTS', 'S6_SCIENCE')}}
LONG_SUBJECT_ROWS = {(key, '10:35-11:15'): ['History & Political Education', 'Biology', 'History & Political Education', 'Mathematics', 'History & Political Education'] for key in ('S1', 'S2', 'S3', 'S4')}
NURSERY_ACTIVITIES = {'NURSERY_1': {'8:00-8:20': 'Arrival / Free Play', '8:20-8:35': 'Circle / Songs', '8:35-9:05': 'Story / Oral Language', '9:05-9:35': 'Sensory Play / Exploration', '9:35-9:50': 'Snack / Hygiene', '9:50-10:30': 'Outdoor Play / Movement', '10:30-11:00': 'Small-Group Play Centres', '11:00-11:25': 'Sorting / Counting Play', '11:25-11:45': 'Art / Music / Dance', '11:45-12:00': 'Review / Safe Dismissal'}, 'NURSERY_2': {'8:00-8:20': 'Arrival / Choice Activities', '8:20-8:35': 'Circle / Attendance / Weather', '8:35-9:05': 'Language / Rhymes / Story', '9:05-9:35': 'Environment / Nature Activities', '9:35-9:50': 'Snack / Self-Care', '9:50-10:30': 'Outdoor PE / Free Play', '10:30-11:00': 'Learning Centres / Role Play', '11:00-11:25': 'Mathematical Concepts', '11:25-11:45': 'Creative Arts / Music', '11:45-12:00': 'Reflection / Departure'}, 'NURSERY_3': {'8:00-8:20': 'Arrival / Free Choice', '8:20-8:35': 'Circle / News / Values', '8:35-9:05': 'Pre-Literacy / Story / Phonics Games', '9:05-9:35': 'Pre-Numeracy / Practical Mathematics', '9:35-9:50': 'Snack / Hygiene', '9:50-10:30': 'Outdoor PE / Games', '10:30-11:00': 'Small-Group Language Activities', '11:00-11:25': 'Environment / Discovery', '11:25-11:45': 'Art / Music / Dramatic Play', '11:45-12:00': 'Review / Dismissal'}}
SUBJECT_ALIASES = {'PE': 'Physical Education', 'Subsidiary Maths': 'Subsidiary Mathematics', 'History & Political Education': 'History and Political Education'}
ACADEMIC_SUBJECTS = {'English', 'Mathematics', 'General Science', 'Physics', 'Chemistry', 'Biology', 'Geography', 'History', 'Literature', 'Economics', 'General Paper', 'Physical Education', 'Subsidiary Mathematics', 'Subsidiary ICT', 'History and Political Education'}
TOPIC_CATALOG = {
    'Mathematics': ['Number and Place Value', 'Fractions, Decimals and Percentages', 'Measurement', 'Geometry', 'Algebra', 'Data Handling and Probability', 'Problem Solving'],
    'English': ['Listening and Speaking', 'Reading Comprehension', 'Grammar', 'Vocabulary', 'Writing Composition', 'Literature'],
    'General Science': ['Scientific Inquiry', 'Matter', 'Energy', 'Living Things', 'The Environment', 'Health'],
    'Physics': ['Measurement', 'Mechanics', 'Heat', 'Light', 'Sound', 'Electricity and Magnetism'],
    'Chemistry': ['Matter and Measurement', 'Atomic Structure', 'Chemical Bonding', 'Chemical Reactions', 'Acids and Bases', 'Organic Chemistry'],
    'Biology': ['Cell Biology', 'Nutrition', 'Transport in Plants and Animals', 'Reproduction', 'Ecology', 'Human Health'],
    'Geography': ['Map Reading', 'Weather and Climate', 'Landforms', 'Population', 'Resources and Economic Activities', 'Environmental Management'],
    'History and Political Education': ['Sources of History', 'East African History', 'Uganda’s History', 'Colonialism', 'Independence', 'Citizenship and Governance'],
    'History': ['Historical Sources', 'East African History', 'Nationalism', 'Independence Movements', 'Political Development'],
    'Literature': ['Literary Genres', 'Poetry', 'Drama', 'Prose', 'Character and Setting', 'Themes and Style'],
    'Economics': ['Basic Economic Concepts', 'Demand and Supply', 'Production', 'Markets', 'Money and Banking', 'National Income and Development'],
    'General Paper': ['Communication Skills', 'Contemporary Issues', 'Culture and Society', 'Science and Technology', 'Governance and Development'],
}
SUBTOPIC_CATALOG = {
    'Number and Place Value': ['Place value and expanded notation', 'Comparing and ordering numbers', 'Rounding and estimation'],
    'Scientific Inquiry': ['Observation and measurement', 'Fair tests and variables', 'Recording and communicating findings'],
    'Cell Biology': ['Cell structure', 'Cell organisation', 'Microscopy and biological drawings'],
    'Measurement': ['Units and instruments', 'Accuracy and recording', 'Practical measurement'],
    'Map Reading': ['Scale and distance', 'Grid references', 'Relief and contour interpretation'],
    'Sources of History': ['Primary and secondary sources', 'Oral evidence', 'Chronology and interpretation'],
}

def parse_time_range(value):
    start_text, end_text = value.split('-', 1)
    def parse(text):
        hour, minute = (int(part) for part in text.strip().split(':'))
        if hour in (1, 2, 3, 4):
            hour += 12
        return hour, minute
    return parse(start_text), parse(end_text)

def parse_rows(path, class_key):
    rows = []
    for line in path.read_text(encoding='utf-8').splitlines():
        if '-' not in line[:17] or ':' not in line[:17]:
            continue
        label = line[:17].strip()
        if class_key in NURSERY_ACTIVITIES:
            cells = [NURSERY_ACTIVITIES[class_key][label]] * 5
        elif label in {'3:30-4:30', '2:40-4:30'}:
            cells = [SPECIAL_LONG_BLOCKS[class_key]] * 5
        elif (class_key, label) in LONG_SUBJECT_ROWS:
            cells = LONG_SUBJECT_ROWS[(class_key, label)]
        else:
            cells = [line[start:(COLUMN_STARTS[i + 1] if i + 1 < len(COLUMN_STARTS) else None)].strip() for i, start in enumerate(COLUMN_STARTS)]
        rows.append((label, cells))
    if not rows:
        raise CommandError(f'No timetable rows found in {path.name}.')
    return rows

def class_label(key):
    return {'NURSERY_1': 'Baby Class', 'NURSERY_2': 'Middle Class', 'NURSERY_3': 'Top Class', 'S5_ARTS': 'S5 Arts', 'S5_SCIENCE': 'S5 Science', 'S6_ARTS': 'S6 Arts', 'S6_SCIENCE': 'S6 Science'}.get(key, key)

def local_datetime(date_value, hour, minute):
    return timezone.make_aware(datetime.combine(date_value, time(hour, minute)), timezone.get_current_timezone())


def easter_sunday(year):
    a = year % 19
    b = year // 100
    c = year % 100
    d = b // 4
    e = b % 4
    f = (b + 8) // 25
    g = (b - f + 1) // 3
    h = (19 * a + b - d - g + 15) % 30
    i = c // 4
    k = c % 4
    l = (32 + 2 * e + 2 * i - h - k) % 7
    m = (a + 11 * h + 22 * l) // 451
    month = (h + l - 7 * m + 114) // 31
    day = ((h + l - 7 * m + 114) % 31) + 1
    return datetime(year, month, day).date()

def uganda_public_holidays(start_year, end_year):
    holidays = set()
    for year in range(start_year, end_year + 1):
        fixed = ((1, 1), (1, 26), (3, 8), (5, 1), (6, 3), (6, 9), (10, 9), (12, 25), (12, 26))
        holidays.update(datetime(year, month, day).date() for month, day in fixed)
        easter = easter_sunday(year)
        holidays.add(easter - timedelta(days=2))
        holidays.add(easter + timedelta(days=1))
    return holidays

def read_holidays(path):
    if not path:
        return set()
    payload = json.loads(Path(path).read_text(encoding='utf-8'))
    values = payload.get('holidays', payload) if isinstance(payload, dict) else payload
    return {datetime.strptime(str(value), '%Y-%m-%d').date() for value in values}

class Command(BaseCommand):
    help = 'Import Uganda timetable templates as recurring Trends or dated academic-term Trends.'

    def add_arguments(self, parser):
        parser.add_argument('--institution', required=True)
        parser.add_argument('--source-dir', required=True)
        parser.add_argument('--organizer')
        parser.add_argument('--replace', action='store_true')
        parser.add_argument('--start-date', help='Term start date YYYY-MM-DD. Enables dated term generation.')
        parser.add_argument('--end-date', help='Term end date YYYY-MM-DD. Enables dated term generation.')
        parser.add_argument('--academic-year', default='')
        parser.add_argument('--term', default='')
        parser.add_argument('--holiday-file', help='JSON array or {"holidays": ["YYYY-MM-DD"]}. Adds school-specific closure dates.')
        parser.add_argument('--no-public-holidays', action='store_true', help='Do not automatically exclude fixed and Easter Uganda public holidays.')
        parser.add_argument('--dry-run', action='store_true')

    @transaction.atomic
    def handle(self, *args, **options):
        value = options['institution']
        institution = Institution.objects.filter(name__iexact=value).first() or Institution.objects.filter(subdomain__iexact=value).first()
        if not institution:
            try:
                institution = Institution.objects.get(pk=value)
            except (Institution.DoesNotExist, ValueError):
                raise CommandError(f'Institution not found: {value}')
        if not institution.is_active or not institution.is_approved:
            raise CommandError('The institution must be active and approved before importing official timetables.')
        organizer = institution.admin
        if options.get('organizer'):
            try:
                organizer = User.objects.get(username=options['organizer'])
            except User.DoesNotExist:
                raise CommandError(f'Organizer not found: {options["organizer"]}')
        source_dir = Path(options['source_dir'])
        if not source_dir.is_dir():
            raise CommandError(f'Source directory does not exist: {source_dir}')
        dated = bool(options.get('start_date') or options.get('end_date'))
        if dated and not (options.get('start_date') and options.get('end_date')):
            raise CommandError('Use both --start-date and --end-date for term generation.')
        start_date = datetime.strptime(options['start_date'], '%Y-%m-%d').date() if dated else timezone.localdate() - timedelta(days=timezone.localdate().weekday())
        end_date = datetime.strptime(options['end_date'], '%Y-%m-%d').date() if dated else start_date + timedelta(days=4)
        if end_date < start_date:
            raise CommandError('End date cannot be before start date.')
        holidays = read_holidays(options.get('holiday_file'))
        if dated and not options.get('no_public_holidays'):
            holidays.update(uganda_public_holidays(start_date.year, end_date.year))
        term = options.get('term') or 'Weekly template'
        year = options.get('academic_year') or ''
        marker_prefix = 'NUSU_OFFICIAL_TIMETABLE_V2|'
        if options['replace'] and not options['dry_run']:
            query = Trend.objects.filter(institution=institution).filter(Q(description__startswith=marker_prefix) | Q(description__startswith='NUSU_OFFICIAL_TIMETABLE_V1|'))
            if dated and year and term:
                query = query.filter(description__contains=f'academic_year={year}|term={term}|')
            deleted, _ = query.delete()
            self.stdout.write(f'Removed {deleted} previous official timetable Trends.')
        counts = defaultdict(int)
        subject_cache = {}
        for filename in SOURCE_FILES:
            path = source_dir / filename
            if not path.exists():
                raise CommandError(f'Missing timetable file: {path}')
            key = path.stem
            label = class_label(key)
            level, _ = EducationLevel.objects.get_or_create(institution_level=institution, name=label, defaults={'level_type': 'stage', 'order': SOURCE_FILES.index(filename) + 1, 'created_by': organizer, 'is_approved': True})
            level.is_approved = True
            level.save(update_fields=['is_approved'])
            subject_occurrences = defaultdict(int)
            for time_label, cells in parse_rows(path, key):
                (start_hour, start_minute), (end_hour, end_minute) = parse_time_range(time_label)
                for day_index, activity in enumerate(cells):
                    activity = ' '.join(activity.split())
                    if not activity:
                        continue
                    subject_name = SUBJECT_ALIASES.get(activity, activity)
                    subject = topic = subtopic = None
                    if subject_name in ACADEMIC_SUBJECTS:
                        cache_key = (level.id, subject_name)
                        subject = subject_cache.get(cache_key)
                        if subject is None:
                            subject = Subject.objects.filter(education_level=level, name__iexact=subject_name).first()
                            if not subject:
                                subject = Subject.objects.create(education_level=level, institution=institution, name=subject_name, order=100, created_by=organizer, is_approved=True)
                            subject_cache[cache_key] = subject
                        topics = list(Topic.objects.filter(subject=subject).order_by('order', 'name'))
                        if not topics:
                            for topic_order, topic_name in enumerate(TOPIC_CATALOG.get(subject_name, ['Introduction', 'Core Concepts', 'Practice and Application', 'Revision']), start=1):
                                topic, _ = Topic.objects.get_or_create(subject=subject, name=topic_name, defaults={'order': topic_order, 'created_by': organizer, 'is_approved': True})
                                for subtopic_order, subtopic_name in enumerate(SUBTOPIC_CATALOG.get(topic_name, []), start=1):
                                    Subtopic.objects.get_or_create(topic=topic, name=subtopic_name, defaults={'order': subtopic_order, 'created_by': organizer, 'is_approved': True})
                            topics = list(Topic.objects.filter(subject=subject).order_by('order', 'name'))
                        if topics:
                            occurrence = subject_occurrences[(level.id, subject.id)]
                            topic = topics[occurrence % len(topics)]
                            subs = list(Subtopic.objects.filter(topic=topic).order_by('order', 'name'))
                            if subs:
                                subtopic = subs[occurrence % len(subs)]
                            subject_occurrences[(level.id, subject.id)] += 1
                    dates = []
                    if dated:
                        cursor = start_date
                        while cursor <= end_date:
                            if cursor.weekday() == day_index and cursor not in holidays:
                                dates.append(cursor)
                            cursor += timedelta(days=1)
                    else:
                        dates = [start_date + timedelta(days=day_index)]
                    for date_value in dates:
                        start = local_datetime(date_value, start_hour, start_minute)
                        end = local_datetime(date_value, end_hour, end_minute)
                        fields = f'academic_year={year}|term={term}|' if dated else ''
                        marker = f'{marker_prefix}{fields}class={key}|day={DAYS[day_index]}|date={date_value.isoformat()}|time={time_label}'
                        description = marker + f'\nOfficial timetable template for {label}. Uganda timezone: Africa/Kampala.'
                        title = f'{label} — {activity}' + (f' · {topic.name}' if topic else '')
                        defaults = {'title': title, 'description': description, 'trend_type': TrendType.CLASS_SCHEDULE, 'organizer': organizer, 'start_time': start, 'end_time': end, 'is_recurring': not dated, 'recurrence_pattern': 'weekly' if not dated else f'{term} {year}'.strip(), 'access_level': AccessLevel.INSTITUTIONAL, 'audience': Trend.AUDIENCE_LEVEL, 'target_level': level, 'subject': subject, 'topic': topic, 'subtopic': subtopic, 'is_approved': True, 'is_active': True}
                        counts['trends'] += 1
                        if not options['dry_run']:
                            existing = Trend.objects.filter(institution=institution, description__startswith=marker).first()
                            if existing:
                                for field, value in defaults.items():
                                    setattr(existing, field, value)
                                existing.save()
                            else:
                                Trend.objects.create(institution=institution, **defaults)
        mode = f'{term} {year}'.strip() if dated else 'one weekly template'
        self.stdout.write(self.style.SUCCESS(f'Prepared {counts["trends"]} official Trends for {institution.name} ({mode}).'))
        if dated:
            self.stdout.write(f'Teaching window: {start_date} to {end_date}; skipped holidays: {len(holidays)}; timezone: Africa/Kampala')
        if options['dry_run']:
            self.stdout.write('Dry run only: no database records were changed.')
            transaction.set_rollback(True)
